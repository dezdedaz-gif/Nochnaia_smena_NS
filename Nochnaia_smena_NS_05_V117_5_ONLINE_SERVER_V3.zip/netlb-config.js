// NS-05 V117.3 ONLINE
// The Game API key is public. The Server API key must NEVER be placed here.
window.NETLB_CONFIG = {
  gameKey: 'dev_2c489e5e63d44c21b3ae4678264bafdc',
  devMode: true,
  environment: 'development',
  gameVersion: '1.17.5.0',
  host: 'https://api.lootlocker.com/game',
  backendUrl: 'https://ns05-online-v3.onrender.com',
  boards: { score: 'night_shift_score_v2', time: 'night_shift_time_v2' },
  count: 25
};
