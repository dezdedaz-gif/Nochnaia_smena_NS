// NS-05 V117.1 trusted score gateway. Node 20+; no npm dependencies required.
// Set LOOTLOCKER_SERVER_API_KEY in the hosting provider's secret environment.
// Do NOT put that key into the itch.io ZIP.
import http from 'node:http';

const PORT=Number(process.env.PORT||8787);
const LL='https://api.lootlocker.io/server';
const SERVER_KEY=String(process.env.LOOTLOCKER_SERVER_API_KEY||'').trim();
const ALLOWED_ORIGIN=String(process.env.ALLOWED_ORIGIN||'*').trim();
const SCORE_BOARD=process.env.SCORE_BOARD||'night_shift_score';
const TIME_BOARD=process.env.TIME_BOARD||'night_shift_time';
const GAME_VERSION=process.env.GAME_VERSION||'1.17.4.0';
const MAX_SCORE=108000, MAX_TIME=3600, MAX_RATE=30;
const recent=new Map();
let serverToken='', serverTokenAt=0;
async function getServerToken(){
 if(serverToken && Date.now()-serverTokenAt<50*60*1000)return serverToken;
 const r=await fetch(`${LL}/session`,{method:'POST',headers:{'Content-Type':'application/json','LL-Version':'2021-03-01','x-server-key':SERVER_KEY},body:JSON.stringify({game_version:GAME_VERSION})});
 const j=await r.json().catch(()=>({})); if(!r.ok||!j.token)throw new Error('server_session_failed');
 serverToken=j.token;serverTokenAt=Date.now();return serverToken;
}
async function resolvePlayer(sessionToken){
 const tok=String(sessionToken||''); if(tok.length<20)throw new Error('bad_session');
 const r=await fetch(`${LL}/player/info/token`,{method:'POST',headers:{'Content-Type':'application/json','LL-Version':'2021-03-01','x-auth-token':await getServerToken()},body:JSON.stringify({tokens:[tok]})});
 const j=await r.json().catch(()=>({})); if(!r.ok)throw new Error('player_lookup_failed');
 const p=(j.player_info_list||[])[0]; if(!p)throw new Error('unknown_player'); return String(p.legacy_id);
}

function cors(res){res.setHeader('Access-Control-Allow-Origin',ALLOWED_ORIGIN);res.setHeader('Access-Control-Allow-Headers','Content-Type');res.setHeader('Access-Control-Allow-Methods','POST,OPTIONS');}
function json(res,status,obj){cors(res);res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(obj));}
function body(req){return new Promise((resolve,reject)=>{let s='';req.on('data',c=>{s+=c;if(s.length>20000)req.destroy();});req.on('end',()=>{try{resolve(JSON.parse(s||'{}'))}catch(e){reject(e)}});req.on('error',reject)})}
function cleanName(v){return String(v||'АНОНИМ').replace(/[^A-Za-zА-Яа-яЁё0-9 _.-]/g,'').trim().slice(0,24)||'АНОНИМ'}
function validate(x){
 const m=(x&&x.metadata&&typeof x.metadata==='object')?x.metadata:{};
 const score=Number(x.score), t=Number(x.time ?? m.t), n=Number(x.night ?? m.night ?? m.ni), flags=Array.isArray(x.flags)?x.flags:(Array.isArray(m.flags)?m.flags:[]);
 if(!Number.isFinite(score)||!Number.isFinite(t)||!Number.isInteger(n))return 'BAD_TYPES';
 if(score<0||score>MAX_SCORE||t<5||t>MAX_TIME||n<1||n>5)return 'BAD_RANGE';
 if(score>t*MAX_RATE+120)return 'IMPOSSIBLE_SCORE';
 if(flags.length)return 'CLIENT_FLAGS';
 return null;
}
async function llSubmit(board,memberId,score,metadata){
 const r=await fetch(`${LL}/leaderboards/${encodeURIComponent(board)}/submit`,{method:'POST',headers:{'Content-Type':'application/json','LL-Version':'2021-03-01','x-auth-token':await getServerToken()},body:JSON.stringify({member_id:memberId,score,metadata})});
 const j=await r.json().catch(()=>({}));if(!r.ok)throw new Error(j.message||j.error||`LootLocker HTTP ${r.status}`);return j;
}
const server=http.createServer(async(req,res)=>{
 if(req.method==='OPTIONS'){cors(res);res.writeHead(204);return res.end()}
 if(req.method==='GET'&&req.url==='/health')return json(res,200,{ok:true,version:GAME_VERSION});
 if(req.method!=='POST'||req.url!=='/api/submit')return json(res,404,{error:'not_found'});
 if(!SERVER_KEY)return json(res,503,{error:'server_not_configured'});
 try{
  const x=await body(req), err=validate(x);if(err)return json(res,400,{accepted:false,error:err});
  const memberId=String(x.playerId||'');if(!/^\d+$/.test(memberId))return json(res,400,{accepted:false,error:'BAD_PLAYER_ID'});
  const verifiedPlayer=await resolvePlayer(x.sessionToken);
  if(verifiedPlayer!==memberId)return json(res,403,{accepted:false,error:'PLAYER_MISMATCH'});
  const guest=String(x.guestId||'').slice(0,80);const now=Date.now();const last=recent.get(memberId)||0;
  if(now-last<3000)return json(res,429,{accepted:false,error:'RATE_LIMIT'});recent.set(memberId,now);
  const board=x.kind==='time'?TIME_BOARD:SCORE_BOARD;
  const metadata=JSON.stringify({n:cleanName(x.metadata?.n),a:Number(x.metadata?.a)||0,s:Number(x.metadata?.s)||0,t:Number(x.metadata?.t)||0,ni:Number(x.night)||Number(x.metadata?.ni)||1,se:Number(x.metadata?.se)||0,ru:Number(x.metadata?.ru)||0,v:true,g:guest,ts:now}).slice(0,900);
  const out=await llSubmit(board,memberId,Math.floor(Number(x.score)),metadata);
  return json(res,200,{accepted:true,rank:out.rank??null,score:out.score??Number(x.score)});
 }catch(e){console.error(e);return json(res,502,{accepted:false,error:'upstream_error'})}
});
server.listen(PORT,()=>console.log(`NS-05 V117.1 score gateway on :${PORT}`));
