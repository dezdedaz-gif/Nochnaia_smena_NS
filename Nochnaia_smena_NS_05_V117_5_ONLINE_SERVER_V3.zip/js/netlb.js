/* NS-05 V117.1 — online leaderboard client.
 * Reads may use LootLocker Game API. Score writes prefer a trusted HTTPS backend.
 * Never put a LootLocker Server/Admin API key in this file.
 */
(function(){
 const CFG=Object.assign({
  gameKey:'',devMode:false,gameVersion:'1.17.1.0',
  host:'https://api.lootlocker.com/game',
  backendUrl:'',
  boards:{score:'night_shift_score',time:'night_shift_time'},count:25
 },window.NETLB_CONFIG||{});
 const TIMEOUT=9000, ID_KEY='night_shift_guest_id';
 const S={status:'off',token:'',playerId:'',uid:'',ident:'',name:'',err:'',tries:0};
 function key(){return String((window.NETLB_CONFIG?.gameKey)||CFG.gameKey||'').trim()}
 function backend(){return String((window.NETLB_CONFIG?.backendUrl)||CFG.backendUrl||'').trim().replace(/\/$/,'')}
 function enabled(){return !!key()}
 function secureWrites(){return !!backend()}
 function ident(){
  if(S.ident)return S.ident; let v='';
  try{v=localStorage.getItem(ID_KEY)||''}catch(e){}
  if(!v){v='ns05-'+cryptoRandom()+cryptoRandom();try{localStorage.setItem(ID_KEY,v)}catch(e){}}
  S.ident=v;return v;
 }
 function cryptoRandom(){try{const a=new Uint32Array(1);crypto.getRandomValues(a);return a[0].toString(36).slice(0,8)}catch(e){return Math.random().toString(36).slice(2,10)}}
 async function api(path,method,body,auth){
  const ctl=new AbortController(), t=setTimeout(()=>ctl.abort(),TIMEOUT);
  try{const h={'Content-Type':'application/json'};if(auth)h['x-session-token']=S.token;
   const res=await fetch(CFG.host.replace(/\/+$/,'')+'/'+path,{method,headers:h,signal:ctl.signal,body:body?JSON.stringify(body):undefined});
   let js=null;try{js=await res.json()}catch(e){}
   if(!res.ok){const e=new Error((js&&(js.message||js.error))||('HTTP '+res.status));e.code=res.status;throw e}return js||{};
  }finally{clearTimeout(t)}
 }
 let loginPromise=null;
 function login(){
  if(!enabled()){S.status='off';return Promise.resolve(false)}
  if(S.token)return Promise.resolve(true);if(loginPromise)return loginPromise;S.status='connecting';
  loginPromise=api('v2/session/guest','POST',{game_key:key(),game_version:CFG.gameVersion,player_identifier:ident(),development_mode:!!CFG.devMode},false)
   .then(js=>{S.token=js.session_token||'';S.playerId=String(js.player_id||js.player_ulid||'');S.uid=String(js.public_uid||js.player_public_uid||'');S.name=js.player_name||js.name||'';S.status=S.token?'online':'error';return !!S.token})
   .catch(e=>{S.status='error';S.err=String(e?.message||e);S.tries++;console.warn('NetLB login:',S.err);return false})
   .finally(()=>{loginPromise=null});
  return loginPromise;
 }
 async function setName(name){const n=String(name||'').trim().slice(0,32);if(!n)return false;if(!await login())return false;try{await api('player/name','PATCH',{name:n},true);S.name=n;return true}catch(e){console.warn('NetLB setName:',e.message);return false}}
 function parseMeta(m){if(!m)return null;if(typeof m==='object')return m;try{return JSON.parse(m)}catch(e){return null}}
 function norm(items,kind){return (items||[]).map((it,i)=>{const meta=parseMeta(it.metadata),pl=it.player||{};const mine=(S.playerId&&String(pl.id||pl.player_id||'')===S.playerId)||(S.uid&&String(pl.public_uid||'')===S.uid)||(S.ident&&meta&&meta.g===S.ident);const sc=kind==='time'?((meta&&meta.s)|0):(it.score|0),sec=kind==='time'?(it.score|0):((meta&&meta.t)|0);return{rank:it.rank||i+1,name:String((meta&&meta.n)||pl.name||pl.public_uid||'АНОНИМ').slice(0,24),score:sc,seconds:sec,you:!!mine,global:true,meta:meta||null,avatar:(meta&&meta.a|0)||0}})}
 async function top(kind,count){const board=CFG.boards[kind];if(!board||!await login())return null;const n=Math.max(1,Math.min(200,count||CFG.count||25));try{const js=await api('leaderboards/'+encodeURIComponent(board)+'/list?count='+n,'GET',null,true);return norm(js.items||js.scores||[],kind)}catch(e){console.warn('NetLB top:',e.message);return null}}
 async function secureSubmit(kind,value,meta){
  if(!secureWrites())return false;
  if(!await login())return false;
  const board=CFG.boards[kind];if(!board)return false;
  const m=meta&&typeof meta==='object'?meta:{};
  const payload={kind,board,score:Math.max(0,Math.floor(Number(value)||0)),playerId:S.playerId,publicUid:S.uid,guestId:ident(),sessionToken:S.token,metadata:m,gameVersion:CFG.gameVersion,night:Number(m.night??m.ni??1),time:Number(m.t??0),flags:Array.isArray(m.flags)?m.flags:[]};
  try{const ctl=new AbortController(),t=setTimeout(()=>ctl.abort(),TIMEOUT);const r=await fetch(backend()+'/api/submit',{method:'POST',headers:{'Content-Type':'application/json'},signal:ctl.signal,body:JSON.stringify(payload)});clearTimeout(t);const j=await r.json().catch(()=>({}));if(!r.ok)throw new Error(j.error||('HTTP '+r.status));return j.accepted===true}catch(e){console.warn('NetLB secure submit:',e.message);return false}
 }
 async function submit(kind,value,meta){
  // V117.3: score writes are backend-only.
  if(!secureWrites()) return false;
  return secureSubmit(kind,value,meta);
 }

 window.NetLB={enabled,login,setName,submit,top,status:()=>S.status,error:()=>S.err,ident,playerId:()=>S.playerId,boards:()=>CFG.boards,cfg:()=>CFG,secureWrites,backendUrl:backend};
})();
