Original generated key art for the game's Felix/NRS character. Gameplay uses procedural vector rendering in world.js and game.js.
