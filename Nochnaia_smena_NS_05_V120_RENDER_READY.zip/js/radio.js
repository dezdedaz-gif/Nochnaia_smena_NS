window.RadioSystem=(()=>{
 const msgs=['...служебный канал...','не оставляйте свет включённым дольше необходимого...','камера временно не отвечает...','если услышите стук — сначала проверьте монитор...','...тишина сохраняется...'];
 function toggle(game){
   const was=game.radio.on; game.radio.on=!was; game.radio.timer=1+Math.random()*4;
   AudioFX.play('radio',.8,{group:'radio'});
   if(!was){game.radio.track=(game.radio.track||0)+1;AudioFX.startRadioMusic?.(game.radio.track);game.ach?.('radio_listener');if(game.radio.track>=2)game.ach?.('radio_again');game.say('РАДИО: КАНАЛ ВКЛЮЧЁН',1.5)}
   else {AudioFX.stopRadioMusic?.();game.say('РАДИО: КАНАЛ ВЫКЛЮЧЕН',1.5)}
 }
 function update(game,dt){if(!game.radio.on)return;game.radio.timer-=dt;if(game.radio.timer<=0){game.radio.timer=6+Math.random()*10;game.say(msgs[Math.floor(Math.random()*msgs.length)],2);if(Math.random()<.35)AudioFX.play('radio',.35,{group:'radio'});}}
 return {toggle,update};
})();
