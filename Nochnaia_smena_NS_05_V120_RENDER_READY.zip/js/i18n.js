// ============================================================================
// V83: ЛОКАЛИЗАЦИЯ. Игра рисует текст на Canvas, поэтому язык подменяется не
// в разметке, а на уровне самого рисования: fillText / strokeText / measureText
// проходят через словарь. Благодаря этому переведён ВЕСЬ интерфейс, включая
// подписи камер, субтитры, записки, достижения и финальные экраны — без
// переписывания семи тысяч строк игрового кода.
//
// Три уровня поиска перевода:
//   1) точное совпадение строки;
//   2) совпадение без учёта регистра (в коде много ВЕРХНЕГО РЕГИСТРА);
//   3) подстановка известных фрагментов — для строк, собранных из кусков
//      («ЛИНИЯ » + номер + « // НЕТ ОТВЕТА»).
//
// Плюс защита вёрстки: если перевод шире исходной русской строки, текст
// сжимается по горизонтали до ширины оригинала. Ни одна надпись не выезжает
// за свою рамку и не наползает на соседнюю — то есть «кривого» текста нет.
// ============================================================================
window.I18N = (() => {
  const LANGS = [
    { code: 'ru', native: 'РУССКИЙ',  voice: 'ru', html: 'ru' },
    { code: 'en', native: 'ENGLISH',  voice: 'en', html: 'en' },
    { code: 'de', native: 'DEUTSCH',  voice: 'en', html: 'de' },
    { code: 'fr', native: 'FRANÇAIS', voice: 'en', html: 'fr' },
    { code: 'es', native: 'ESPAÑOL',  voice: 'en', html: 'es' },
    { code: 'pl', native: 'POLSKI',   voice: 'en', html: 'pl' }
  ];
  const CYR = /[А-Яа-яЁё]/;
  let lang = 'ru';
  let exact = null, lower = null, frag = null;
  let cache = new Map();
  const listeners = [];

  function info(code) { return LANGS.find(l => l.code === code) || LANGS[0]; }

  // ---- подбор языка при первом запуске: сохранённый → платформа → браузер ----
  function detect() {
    // ?lang=xx — явное переопределение (удобно для проверки вёрстки и для
    // площадок, которые передают язык в адресе страницы).
    try {
      const q = new URLSearchParams(location.search).get('lang');
      if (q && LANGS.some(l => l.code === q.slice(0, 2).toLowerCase())) return q.slice(0, 2).toLowerCase();
    } catch (e) {}
    try {
      const saved = window.SaveSystem?.settings?.lang;
      if (saved && LANGS.some(l => l.code === saved)) return saved;
    } catch (e) {}
    const guess = [];
    try { guess.push(window.Platform?.lang?.()); } catch (e) {}
    try { (navigator.languages || [navigator.language]).forEach(l => guess.push(l)); } catch (e) {}
    for (const g of guess) {
      if (!g) continue;
      const c = String(g).slice(0, 2).toLowerCase();
      if (LANGS.some(l => l.code === c)) return c;
    }
    return 'ru';
  }

  function esc(s) { return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }

  function build() {
    cache = new Map();
    const data = (window.I18N_DATA || {})[lang];
    if (lang === 'ru' || !data) { exact = lower = frag = null; return; }
    exact = data;
    lower = Object.create(null);
    for (const k in data) lower[k.toLowerCase()] = data[k];
    // Фрагменты: только достаточно длинные куски, иначе можно испортить
    // случайное совпадение внутри другой фразы. Сортировка по длине —
    // сначала подставляем самые длинные.
    // V83: короткие ключи (4 буквы, например «НОЧЬ » в строке «НОЧЬ 1 / 5») тоже
    // участвуют, но только на границе слова — иначе можно было бы испортить
    // середину другого слова («ПОЛНОЧЬ»).
    const keys = Object.keys(data).filter(k => k.trim().length >= 4).sort((a, b) => b.length - a.length);
    // Справа тоже граница слова: без неё ключ «МОНСТР» превращал «МОНСТРЫ»
    // в уродливое «MONSTERы».
    const CY = /[А-Яа-яЁё]/;
    const pat = keys.map(k => (k.trim().length >= 5 ? '' : '(?<![А-Яа-яЁё])') + esc(k) + (CY.test(k.slice(-1)) ? '(?![А-Яа-яЁё])' : ''));
    try {
      frag = keys.length ? new RegExp(pat.join('|'), 'gi') : null;
    } catch (e) {
      // Старый движок без lookbehind — берём только долгие ключи.
      const safe = keys.filter(k => k.trim().length >= 5).map(esc);
      frag = safe.length ? new RegExp(safe.join('|'), 'gi') : null;
    }
  }

  // Восстановление регистра: код часто зовёт .toUpperCase() до отрисовки.
  function matchCase(src, dst) {
    if (src === src.toUpperCase() && src !== src.toLowerCase()) return dst.toUpperCase();
    if (src[0] && src[0] === src[0].toUpperCase() && dst[0]) return dst[0].toUpperCase() + dst.slice(1);
    return dst;
  }

  function T(s) {
    if (lang === 'ru' || typeof s !== 'string' || !s || !CYR.test(s)) return s;
    if (!exact) return s;
    const hit = cache.get(s);
    if (hit !== undefined) return hit;
    let out = exact[s];
    if (out === undefined) {
      const lo = lower[s.toLowerCase()];
      if (lo !== undefined) out = matchCase(s, lo);
    }
    if (out === undefined && frag) {
      const rep = s.replace(frag, m => {
        const t = lower[m.toLowerCase()];
        return t === undefined ? m : matchCase(m, t);
      });
      // V85: подстановку по фрагментам принимаем ТОЛЬКО если от русского текста
      // ничего не осталось. Иначе новые надписи меню превращались в кашу вида
      // «GO BACK К ДЕЛУ» или «CLOSE ARCHIVE» рядом с «МАТЕРИАЛЫ ДЕЛА»:
      // часть строки совпадала со старым ключом, часть — нет.
      out = (rep !== s && !CYR.test(rep)) ? rep : s;
    }
    if (out === undefined) out = s;
    cache.set(s, out);
    return out;
  }

  function setLang(code, opts) {
    const l = info(code);
    lang = l.code;
    build();
    try {
      if (window.SaveSystem?.settings) {
        window.SaveSystem.settings.lang = lang;
        if (!opts || opts.save !== false) window.SaveSystem.saveSettings();
      }
    } catch (e) {}
    try {
      document.documentElement.setAttribute('lang', l.html);
      document.title = T('Ночная смена — NS-04');
      const rot = document.getElementById('rotate');
      if (rot) rot.textContent = T('Поверните устройство горизонтально');
      const ui = document.getElementById('settings-ui');
      if (ui) { ui.dataset.ready = ''; }
    } catch (e) {}
    listeners.forEach(fn => { try { fn(lang); } catch (e) {} });
    return lang;
  }

  function onChange(fn) { if (typeof fn === 'function') listeners.push(fn); }

  // ==== перехват отрисовки текста на холсте ====
  const P = CanvasRenderingContext2D.prototype;
  const _fill = P.fillText, _stroke = P.strokeText, _measure = P.measureText;
  const MIN_SQUEEZE = 0.74;   // сильнее сжимать нельзя — станет нечитаемо

  function drawFit(ctx, fn, src, out, x, y, mw) {
    if (mw !== undefined) { fn.call(ctx, out, x, y, mw); return; }
    let w0 = 0, w1 = 0;
    try { w0 = _measure.call(ctx, src).width; w1 = _measure.call(ctx, out).width; } catch (e) {}
    if (!w0 || !w1 || w1 <= w0 * 1.03) { fn.call(ctx, out, x, y); return; }
    const k = Math.max(MIN_SQUEEZE, (w0 * 1.02) / w1);
    ctx.save();
    ctx.translate(x, 0); ctx.scale(k, 1); ctx.translate(-x, 0);
    fn.call(ctx, out, x, y);
    ctx.restore();
  }

  P.fillText = function (t, x, y, mw) {
    if (lang === 'ru' || typeof t !== 'string') return _fill.call(this, t, x, y, mw);
    const s = T(t);
    if (s === t) return _fill.call(this, t, x, y, mw);
    return drawFit(this, _fill, t, s, x, y, mw);
  };
  P.strokeText = function (t, x, y, mw) {
    if (lang === 'ru' || typeof t !== 'string') return _stroke.call(this, t, x, y, mw);
    const s = T(t);
    if (s === t) return _stroke.call(this, t, x, y, mw);
    return drawFit(this, _stroke, t, s, x, y, mw);
  };
  // Измерять нужно уже переведённый текст, иначе переносы строк и авто-подбор
  // размера шрифта считались бы по русской длине.
  P.measureText = function (t) {
    return _measure.call(this, lang === 'ru' || typeof t !== 'string' ? t : T(t));
  };

  function langs() { return LANGS.slice(); }
  function voiceLang() { return info(lang).voice; }

  return { T, setLang, onChange, detect, langs, voiceLang, get lang() { return lang; }, info };
})();
window.T = s => window.I18N.T(s);
