(async()=>{
  // V83: шрифты игры (Oswald / Inter / JetBrains Mono) лежат рядом с игрой и
  // должны быть загружены ДО первой отрисовки — иначе холст мерил бы текст
  // системным шрифтом, и подписи «прыгали» бы на первых кадрах.
  try{
    if(document.fonts?.load){
      await Promise.race([
        Promise.all([
          document.fonts.load('700 32px "Oswald"','НОЧНАЯ СМЕНА NIGHT SHIFT'),
          document.fonts.load('500 20px "Oswald"','НОЧНАЯ СМЕНА NIGHT SHIFT'),
          document.fonts.load('400 14px "Inter"','Ночная смена Night shift ĄĘŁŚŻ'),
          document.fonts.load('600 14px "Inter"','Ночная смена Night shift ĄĘŁŚŻ'),
          document.fonts.load('800 14px "Inter"','Ночная смена Night shift ĄĘŁŚŻ'),
          document.fonts.load('400 13px "JetBrains Mono"','КАМ 01 CAM 01'),
          document.fonts.load('700 13px "JetBrains Mono"','КАМ 01 CAM 01')
        ]),
        new Promise(r=>setTimeout(r,2500))
      ]);
    }
  }catch(e){}
  try{ await window.Platform.init(); }catch(e){}
  try{ window.SaveSystem.applyPlatformSettings?.(); }catch(e){}
  // Язык: сохранённый выбор игрока → язык Яндекс Игр → язык браузера → русский.
  try{
    const saved=window.SaveSystem?.settings?.lang;
    window.I18N?.setLang(window.I18N.detect(),{save:!!saved});
  }catch(e){}
  window.NIGHT_SHIFT_READY=true;
  // V103: ТРЕБОВАНИЕ ЯНДЕКС ИГР 1.19.2 — Game Ready отправляется в момент,
  // когда меню уже отрисовано и игрок может нажимать кнопки. Ждём два кадра:
  // первый — раскладка после resize(), второй — уже готовая картинка меню.
  try{
    requestAnimationFrame(()=>requestAnimationFrame(()=>{
      window.Platform?.gameReady?.();
    }));
  }catch(e){ try{window.Platform?.gameReady?.()}catch(_){} }
})();
