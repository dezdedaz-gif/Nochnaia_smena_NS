// ===========================================================================
// НОЧНАЯ СМЕНА — V101. ПЕРЕПИСАННЫЕ РАСКАДРОВКИ ТРЁХ КОНЦОВОК.
//
// ПОЧЕМУ ТАК БЫЛО.
//  1) «РАССВЕТ» — герой вставал, за две секунды доходил до двери, дверь
//     давала жёлтый свет, вспышка, и сразу поляна. Никакого пути через
//     пиццерию не было: аниматроники стояли декорацией у стены. Уход
//     читался как «дверь была не заперта».
//  2) «ПЕПЕЛ» — канистра и спичка проскакивали за две секунды на общем
//     плане, обрушение здания шло издалека, и финал заканчивался тем, что
//     маленькая фигурка убегает вправо.
//  3) «ЕЩЁ ОДИН КОСТЮМ» — сцены были разной длины (одна 5 с, другая 1.4 с),
//     из-за чего монтаж дёргался, героя никто не трогал, и в последнем
//     кадре он был мелким на фоне зала.
//
// СТАЛО. Три раскадровки собраны заново, РАВНОМЕРНЫМИ битами, с одним
// размером фигуры в кадре (высота ≈ 0.5…0.62 высоты кадра), с кровью,
// с настоящими звуками из audio.js и с субъективными кадрами из end_pov.js:
//   РАССВЕТ  — скрытное продвижение через три помещения, дверь, ТЬМА за ней,
//              никотиновый флэшбэк, отъезд камеры и белый покой.
//   ПЕПЕЛ    — бег от аниматроников, канистра, КРУПНАЯ спичка, огонь, улица,
//              обрушение и падение на траву от первого лица.
//   ЕЩЁ ОДИН КОСТЮМ — подъём с кресла из последних сил, побег, когти,
//              заложенный кирпичом проём, разворот и возвращение в кресло.
//
// Помощники приходят через объект A (как в endings_truth.js и endings_coda.js):
// game.js — одна очень большая функция, и держать внутри неё ещё три
// раскадровки нечитаемо.
// Ни в одной сцене НЕТ текста, кроме финальной карточки с названием.
// ===========================================================================
window.EndScene=(function(){
 const cl=v=>v<0?0:v>1?1:v;
 const eio=x=>x<.5?2*x*x:1-Math.pow(-2*x+2,2)/2;
 const eo=x=>1-Math.pow(1-x,3);
 const ei=x=>x*x*x;
 const sfx=(k,v)=>{try{window.AudioFX.synth?.(k,v)}catch(e){}};
 const bed=(k,v)=>{try{window.AudioFX.bedStart?.(k,v)}catch(e){}};

 function glow(c,x,y,r,col,a){
  if(a<=0.002)return;
  c.save();c.globalCompositeOperation='lighter';
  const g=c.createRadialGradient(x,y,1,x,y,r);
  g.addColorStop(0,'rgba('+col+','+a.toFixed(3)+')');
  g.addColorStop(0.5,'rgba('+col+','+(a*0.30).toFixed(3)+')');
  g.addColorStop(1,'rgba('+col+',0)');
  c.fillStyle=g;c.fillRect(x-r,y-r,r*2,r*2);c.restore();
 }
 // Затемнение стыка между битами: биты равномерные, поэтому и стык один и тот же.
 function cut(c,w,h,tc,len){
  const a=Math.max(0,1-tc/(len||0.34));
  if(a<=0.004)return;
  c.save();c.globalAlpha=a;c.fillStyle='#000';c.fillRect(0,0,w,h);c.restore();
 }
 function fadeOut(c,w,h,t,at,len){
  const a=cl((t-at)/(len||0.9));
  if(a<=0.002)return;
  c.save();c.globalAlpha=a;c.fillStyle='#000';c.fillRect(0,0,w,h);c.restore();
 }
 // Дрожание камеры: у ручной камеры всегда есть медленный дрейф плюс удар.
 function handheld(c,t,amp,hit){
  const a=amp===undefined?1:amp;
  c.translate(Math.sin(t*1.21)*1.6*a+Math.sin(t*19.3)*(hit||0),
              Math.cos(t*0.83)*1.2*a+Math.cos(t*23.7)*(hit||0));
 }

 // -------------------------------------------------------------------------
 // ОБЩИЕ ПОМЕЩЕНИЯ. Одна функция на все планы «вдоль стены»: пол в
 // перспективе, плинтус, стена с обоями/кафелем, потолок и лампы. Раньше
 // каждая сцена рисовала свою комнату по месту, и они не были похожи на
 // одно здание. Здесь общая геометрия, меняется только палитра и реквизит.
 // -------------------------------------------------------------------------
 function sideRoom(c,w,h,t,o){
  o=o||{};
  const FL=o.floorY||h*0.78;
  const pal=o.pal||['#05080a','#0f171b','#18232a','#0a1014'];
  const wall=c.createLinearGradient(0,0,0,FL);
  wall.addColorStop(0,pal[0]);wall.addColorStop(0.55,pal[1]);wall.addColorStop(1,pal[2]);
  c.fillStyle=wall;c.fillRect(0,0,w,FL);
  // кафель по стене: два ряда, шов подсвечен слабым отражением
  if(o.tile){
   c.strokeStyle='rgba(150,178,182,.055)';c.lineWidth=1;
   for(let i=0;i<=16;i++){const x=w*i/16;c.beginPath();c.moveTo(x,FL*0.32);c.lineTo(x,FL);c.stroke();}
   for(let j=0;j<5;j++){const y=FL*(0.34+j*0.16);c.beginPath();c.moveTo(0,y);c.lineTo(w,y);c.stroke();}
  }
  // пол и его блики, сходящиеся к точке схода в середине кадра
  c.fillStyle=pal[3];c.fillRect(0,FL,w,h-FL);
  c.strokeStyle='rgba(140,168,172,.085)';c.lineWidth=1;
  for(let i=-9;i<=9;i++){
   c.beginPath();c.moveTo(w*0.5+i*w*0.075,FL);c.lineTo(w*0.5+i*w*0.30,h);c.stroke();
  }
  for(let j=1;j<5;j++){
   const y=FL+(h-FL)*Math.pow(j/5,1.6);
   c.strokeStyle='rgba(140,168,172,'+(0.05+j*0.012).toFixed(3)+')';
   c.beginPath();c.moveTo(0,y);c.lineTo(w,y);c.stroke();
  }
  // плинтус — без него стена и пол склеивались в одно поле
  c.fillStyle='rgba(6,9,11,.85)';c.fillRect(0,FL-h*0.016,w,h*0.016);
  c.fillStyle='rgba(180,200,204,.05)';c.fillRect(0,FL-h*0.016,w,2);
  // потолок и лампы
  c.fillStyle='rgba(5,8,10,.95)';c.fillRect(0,0,w,h*0.10);
  const lamps=o.lamps===undefined?4:o.lamps;
  for(let i=0;i<lamps;i++){
   const x=w*((i+0.5)/lamps);
   const flick=o.flicker?(0.35+0.65*Math.abs(Math.sin(t*(3.1+i)+i*2.3))*(Math.sin(t*17+i)>-0.75?1:0.15)):1;
   const on=(o.dead&&i===o.dead)?0.06:flick;
   c.fillStyle='#1b2226';c.fillRect(x-w*0.045,h*0.055,w*0.09,h*0.011);
   c.fillStyle='rgba('+(o.warm?'255,224,160':'196,220,226')+','+(0.30*on).toFixed(3)+')';
   c.fillRect(x-w*0.042,h*0.058,w*0.084,h*0.006);
   glow(c,x,h*0.075,h*(0.30+0.05*on),o.warm?'255,214,150':'168,206,214',0.11*on);
   // световое пятно строго под лампой: пол должен читаться как отражающий
   c.save();c.globalCompositeOperation='lighter';c.globalAlpha=0.06*on;
   const p=c.createLinearGradient(0,FL,0,h);
   p.addColorStop(0,o.warm?'rgba(255,214,150,.9)':'rgba(168,206,214,.9)');
   p.addColorStop(1,'rgba(0,0,0,0)');
   c.fillStyle=p;c.beginPath();
   c.moveTo(x-w*0.06,FL);c.lineTo(x+w*0.06,FL);c.lineTo(x+w*0.20,h);c.lineTo(x-w*0.20,h);
   c.closePath();c.fill();c.restore();
  }
  return FL;
 }
 // Проём в стене: чёрный прямоугольник с наличником. В него потом входят
 // аниматроники, и именно он в мрачной концовке закладывается кирпичом.
 function doorway(c,w,h,x,FL,kw,o){
  o=o||{};
  const dw=w*(kw||0.13), dh=(FL-h*0.10)*0.86, dy=FL-dh;
  c.fillStyle='#232c31';c.fillRect(x-dw*0.5-w*0.010,dy-h*0.012,dw+w*0.020,dh+h*0.012);
  c.fillStyle=o.fill||'#04070a';c.fillRect(x-dw*0.5,dy,dw,dh);
  if(o.spill>0){
   glow(c,x,dy+dh*0.5,dw*1.6,o.col||'255,214,150',o.spill*0.30);
  }
  c.fillStyle='rgba(190,210,214,.05)';c.fillRect(x-dw*0.5,dy,2,dh);
  return {x,dw,dh,dy};
 }

 // =========================================================================
 // 1. «РАССВЕТ» — 20.4 с. БЕЗ КОДЫ: после белого света идёт меню.
 // Биты по 3.2 с, кроме финальных — они длиннее ровно на дыхание.
 //  0.0 офис: он поднимается с кресла, слушает
 //  3.2 зал: идёт пригнувшись, аниматроник проходит по дальнему плану
 //  6.4 кухня: прижался к стене, из проёма выглядывает голова и уходит
 //  9.6 коридор: уходит от камеры к выходу, двое провожают его взглядом
 // 12.4 дверь: ручка, дверь открывается — за ней НЕ рассвет, а тьма
 // 14.2 никотиновый флэшбэк от первого лица
 // 17.0 камера отъезжает назад
 // 18.6 белый покой + карточка
 // =========================================================================
 function calm(A,t){
  const c=A.ctx,w=A.w,h=A.h,low=A.low;
  const B=[0,3.2,6.4,9.6,12.4,14.2,17.0,18.6], DUR=20.4;
  A.epiCue(t,0.05,()=>{bed('creep',0.9);sfx('breath',0.42)});
  A.epiCue(t,1.7,()=>sfx('paper',0.20));
  A.epiCue(t,3.3,()=>sfx('switch',0.16));
  A.epiCue(t,4.9,()=>sfx('metalDrag',0.16));
  A.epiCue(t,6.5,()=>sfx('breath',0.34));
  A.epiCue(t,7.9,()=>sfx('drip',0.22));
  A.epiCue(t,9.7,()=>sfx('windHall',0.22));
  A.epiCue(t,12.5,()=>sfx('doorLatch',0.55));
  A.epiCue(t,13.1,()=>sfx('metalGroan',0.26));
  A.epiCue(t,14.2,()=>{sfx('tinnitus',0.60);sfx('nicotine',0.55)});
  A.epiCue(t,15.6,()=>sfx('heartbeat',0.40));
  A.epiCue(t,17.0,()=>sfx('subDrop',0.26));
  A.epiCue(t,18.6,()=>{bed('white',0.8);sfx('whiteCalm',0.85)});

  c.save();
  c.imageSmoothingEnabled=true;

  // ---- БИТ 1: офис. Он поднимается с кресла и слушает коридор. ----
  if(t<B[1]){
   const tc=t-B[0], k=eio(cl(tc/2.1));
   c.save();handheld(c,t,0.8);
   const FL=sideRoom(c,w,h,t,{floorY:h*0.80,lamps:2,flicker:true,dead:1,
     pal:['#04070a','#0d1418','#141d23','#080d11']});
   // стол, монитор и кресло: тот же офис, что и всю игру
   c.fillStyle='#1a2226';c.fillRect(w*0.06,FL-h*0.20,w*0.30,h*0.030);
   c.fillStyle='#121a1e';c.fillRect(w*0.09,FL-h*0.17,w*0.020,h*0.17);
   c.fillStyle='#121a1e';c.fillRect(w*0.32,FL-h*0.17,w*0.020,h*0.17);
   c.fillStyle='#0b1013';c.fillRect(w*0.13,FL-h*0.335,w*0.15,h*0.135);
   c.fillStyle='rgba(96,150,148,.30)';c.fillRect(w*0.137,FL-h*0.328,w*0.136,h*0.118);
   glow(c,w*0.205,FL-h*0.27,w*0.20,'96,168,164',0.10);
   c.fillStyle='#151c21';c.fillRect(w*0.415,FL-h*0.15,w*0.075,h*0.150);
   c.fillStyle='#1d262b';c.fillRect(w*0.408,FL-h*0.33,w*0.090,h*0.19);
   doorway(c,w,h,w*0.845,FL,0.14,{spill:0.20,col:'150,180,190'});
   // он: с кресла на ноги, потом стоит и слушает
   const sc=A.epiGuardScale(h*0.50), gy=FL-A.epiGuardFeet(sc);
   A.drawGuardChar(c,w*0.455,gy+h*0.03*(1-k),sc,{t,
     pose:k<0.45?'sit':(k<0.92?'rise':'stand'),riseK:cl((k-0.45)/0.47),
     face:1,look:0.55,seed:1.7,shadowDir:-1,shadowLen:1.1,
     rim:{dir:1,col:'150,180,190',power:0.18}});
   c.restore();
   cut(c,w,h,tc,0.7);
  }
  // ---- БИТ 2: зал. Он идёт пригнувшись; по дальнему плану проходит один. ----
  else if(t<B[2]){
   const tc=t-B[1], k=eio(cl(tc/2.7));
   c.save();handheld(c,t,0.9);
   const FL=sideRoom(c,w,h,t,{floorY:h*0.79,lamps:5,flicker:true,dead:3,tile:true,
     pal:['#04060a','#101a1f','#1a252c','#090f13']});
   // столы зала: два ряда, дальний ряд мельче — это и даёт глубину
   for(let i=0;i<5;i++){
    const nk=i/4, sx=w*(0.06+i*0.21), sy=FL-h*(0.02+0.06*(1-nk)), sw2=w*0.13*(1-nk*0.35);
    c.fillStyle='rgba(18,26,30,.95)';c.fillRect(sx,sy-h*0.075,sw2,h*0.020);
    c.fillStyle='rgba(12,18,22,.95)';c.fillRect(sx+sw2*0.45,sy-h*0.056,w*0.012,h*0.056);
    c.fillStyle='rgba(140,164,168,.05)';c.fillRect(sx,sy-h*0.075,sw2,2);
   }
   // дальний аниматроник идёт СЛЕВА НАПРАВО по глубине кадра и уходит в проём
   const mk=cl((tc-0.4)/2.4);
   A.epiAnimatron(c,w*(0.20+0.58*mk),FL-h*0.055,A.epiMonScale(h*0.30),t,{
     kind:'main',seed:2.1,face:1,dark:0.94,eye:0.16,head:0.04,
     fog:0.26,fogColor:'12,18,22',shadow:0.22,shadowDir:1,alpha:0.60});
   doorway(c,w,h,w*0.955,FL,0.10,{spill:0.10,col:'130,160,170'});
   // он: крадётся у переднего края, замирает, когда тот проходит близко
   const frz=cl(1-Math.abs(mk-0.52)/0.16);          // 1 в момент максимальной близости
   const dist=w*0.30*k*(1-0.55*frz);
   const sc=A.epiGuardScale(h*0.56), gy=FL+h*0.055-A.epiGuardFeet(sc);
   A.drawGuardChar(c,w*0.16+dist,gy,sc,{t,
     pose:frz>0.55?'brace':'walk',
     phase:A.epiStridePhase(dist,sc,0.34),stride:0.66,
     face:1,look:frz>0.55?0.85:0.22,seed:3.3,dust:frz<0.55,
     shadowDir:-1,shadowLen:1.2,
     rim:{dir:1,col:'150,180,190',power:0.14+0.10*frz}});
   c.restore();
   cut(c,w,h,tc,0.4);
  }
  // ---- БИТ 3: кухня. Прижался к стене, из проёма выглядывает голова. ----
  else if(t<B[3]){
   const tc=t-B[2];
   c.save();handheld(c,t,0.7);
   const FL=sideRoom(c,w,h,t,{floorY:h*0.80,lamps:3,flicker:true,dead:0,tile:true,
     pal:['#040608','#0e1519','#161f24','#080c10']});
   // кухня: стальной стол, вытяжка, полки, капающий кран
   c.fillStyle='#232c31';c.fillRect(w*0.04,FL-h*0.17,w*0.34,h*0.022);
   c.fillStyle='rgba(190,214,220,.07)';c.fillRect(w*0.04,FL-h*0.17,w*0.34,2);
   for(const px of [0.06,0.34]){c.fillStyle='#1a2126';c.fillRect(w*px,FL-h*0.148,w*0.014,h*0.148);}
   c.fillStyle='#1c2429';c.fillRect(w*0.08,FL-h*0.44,w*0.26,h*0.030);
   for(let i=0;i<6;i++){c.fillStyle=i%2?'#2a3339':'#222b31';c.fillRect(w*(0.09+i*0.041),FL-h*0.41,w*0.028,h*0.026);}
   const drip=((t*0.7)%1);
   c.fillStyle='rgba(170,200,210,.55)';
   c.fillRect(w*0.215,FL-h*0.165+ (h*0.16)*drip,1.8,3.2+4*drip);
   // голова в проёме: появляется, ведёт взглядом и уходит — три бита внутри бита
   const peek=cl((tc-0.7)/0.9)-cl((tc-2.2)/0.8);
   const dr=doorway(c,w,h,w*0.80,FL,0.15,{spill:0.14,col:'140,170,180'});
   if(peek>0.01){
    A.epiAnimatron(c,dr.x-dr.dw*0.10,FL-h*0.02,A.epiMonScale(h*0.44),t,{
      kind:'felix',seed:5.7,face:-1,dark:0.90,
      eye:0.30+0.28*peek*Math.abs(Math.sin(t*1.3)),
      head:0.10+0.10*peek,fog:0.20,fogColor:'14,20,24',
      shadow:0.26,shadowDir:-1,alpha:0.55+0.35*peek});
   }
   // он вжался в стену у переднего плана и не дышит
   const sc=A.epiGuardScale(h*0.58), gy=FL+h*0.045-A.epiGuardFeet(sc);
   A.drawGuardChar(c,w*0.315,gy,sc,{t,pose:'brace',face:1,
     look:0.9*peek+0.2,seed:8.1,shadowDir:-1,shadowLen:0.8,
     cold:0.35,rim:{dir:1,col:'150,180,190',power:0.12+0.14*peek}});
   c.restore();
   cut(c,w,h,tc,0.4);
  }
  // ---- БИТ 4: коридор. Он уходит ОТ камеры, двое стоят по сторонам. ----
  else if(t<B[4]){
   const tc=t-B[3], k=eio(cl(tc/2.5));
   c.save();handheld(c,t,1.0);
   // коридор строится в перспективе: стены сходятся к двери в глубине
   const VY=h*0.50, dEnd=w*0.055;
   c.fillStyle='#05080b';c.fillRect(0,0,w,h);
   for(let i=8;i>=0;i--){
    const kk=i/8, sx=w*0.5-(w*0.5-dEnd*0.5)*(1-kk*0.86);
    const yTop=VY-(VY-h*0.11)*(1-kk*0.90), yBot=VY+(h*0.94-VY)*(1-kk*0.90);
    const g=0.05+kk*0.11;
    c.fillStyle='rgba('+Math.round(30+70*g)+','+Math.round(38+82*g)+','+Math.round(44+90*g)+',1)';
    c.fillRect(sx,yTop,w-sx*2,yBot-yTop);
    if(i%2===0){c.fillStyle='rgba(0,0,0,.20)';c.fillRect(sx,yBot-2,w-sx*2,3);}
   }
   // дверь выхода в конце коридора: слабая полоска света по контуру
   const exd={x:w*0.5,y:VY,ww:w*0.085,hh:h*0.20};
   c.fillStyle='#0b1114';c.fillRect(exd.x-exd.ww*0.5,exd.y-exd.hh*0.42,exd.ww,exd.hh);
   c.strokeStyle='rgba(190,214,222,.28)';c.lineWidth=1.4;
   c.strokeRect(exd.x-exd.ww*0.5,exd.y-exd.hh*0.42,exd.ww,exd.hh);
   glow(c,exd.x,exd.y,w*0.14,'170,200,214',0.10);
   // двое по сторонам: они не идут за ним, только провожают
   [[0.175,0.90,-1],[0.842,0.86,1]].forEach((a2,i)=>{
    A.epiAnimatron(c,w*a2[0],h*0.90,A.epiMonScale(h*0.52*a2[1]),t,{
      kind:i?'main':'lav',seed:i*4.3+1.1,face:i?-1:1,dark:0.92,
      eye:0.24+0.16*Math.abs(Math.sin(t*0.8+i*1.7)),head:0.06,
      fog:0.24,fogColor:'12,18,22',shadow:0.28,shadowDir:a2[2],alpha:0.80});
   });
   // фигура уходит в глубину: масштаб падает, шаг считается темпово
   const sc=A.epiGuardScale(h*(0.56-0.30*k)), gy=h*(0.93-0.36*k)-A.epiGuardFeet(sc);
   A.drawGuardChar(c,w*(0.50+0.005*Math.sin(t*1.1)),gy,sc,{t,
     pose:'walk',phase:t*3.4,stride:0.80,face:1,look:0.12,
     back:1,seed:2.9,dust:true,shadowDir:-1,shadowLen:0.9,
     rim:{dir:1,col:'170,200,214',power:0.10+0.14*k}});
   c.restore();
   cut(c,w,h,tc,0.4);
  }
  // ---- БИТ 5: дверь. Он берётся за ручку — и за дверью не утро, а ТЬМА. ----
  else if(t<B[5]){
   const tc=t-B[4], op=eio(cl((tc-0.5)/1.1));
   c.save();handheld(c,t,0.6,op>0.05&&op<0.95?0.5:0);
   c.fillStyle='#05080b';c.fillRect(0,0,w,h);
   const FL=h*0.90;
   // крупный план двери: он стоит спиной, дверь занимает половину кадра
   c.fillStyle='#101619';c.fillRect(0,0,w,FL);
   c.fillStyle='#0a0f12';c.fillRect(0,FL,w,h-FL);
   // V101: стена вокруг двери не должна быть пустым полем — плитка, плинтус,
   // след от таблички. Иначе крупный план двери читается как серый прямоугольник.
   if(!low){
    c.strokeStyle='rgba(150,178,190,.045)';c.lineWidth=1;
    for(let i=1;i<9;i++){c.beginPath();c.moveTo(0,h*0.06*i+h*0.10);c.lineTo(w,h*0.06*i+h*0.10);c.stroke();}
    for(let i=1;i<12;i++){c.beginPath();c.moveTo(w*0.085*i,h*0.10);c.lineTo(w*0.085*i,FL);c.stroke();}
   }
   c.fillStyle='#0c1215';c.fillRect(0,FL-h*0.035,w,h*0.035);   // плинтус
   const dx=w*0.30,dy=h*0.12,dw=w*0.40,dh=FL-h*0.12;
   c.fillStyle='#2b353a';c.fillRect(dx-w*0.02,dy-h*0.02,dw+w*0.04,dh+h*0.02);
   // табличка выхода над проёмом: единственный источник холодного света
   c.fillStyle='#0e1518';c.fillRect(dx+dw*0.34,dy-h*0.075,dw*0.32,h*0.048);
   c.fillStyle='rgba(126,196,168,.55)';c.fillRect(dx+dw*0.355,dy-h*0.066,dw*0.29,h*0.030);
   glow(c,dx+dw*0.5,dy-h*0.050,w*0.13,'120,200,170',0.16);
   // сама дверь отъезжает внутрь: за ней НЕ свет
   c.save();
   c.fillStyle='#000';c.fillRect(dx,dy,dw,dh);
   c.fillStyle='#39444a';c.fillRect(dx,dy,dw*(1-op),dh);
   // V101: у самой дверной створки теперь есть фактура — две филёнки, отбойная
   // полоса внизу и армированное стекло на уровне лица. Раньше створка была
   // однотонным прямоугольником и в крупном плане выглядела как пустое место.
   const pw=dw*(1-op);
   if(pw>w*0.02){
    c.save();c.beginPath();c.rect(dx,dy,pw,dh);c.clip();
    c.strokeStyle='rgba(12,18,21,.85)';c.lineWidth=Math.max(1.5,w*0.0016);
    c.strokeRect(dx+dw*0.06,dy+dh*0.10,dw*0.88,dh*0.30);
    c.strokeRect(dx+dw*0.06,dy+dh*0.46,dw*0.88,dh*0.36);
    c.fillStyle='rgba(255,255,255,.030)';
    c.fillRect(dx+dw*0.06,dy+dh*0.10,dw*0.88,h*0.004);
    c.fillRect(dx+dw*0.06,dy+dh*0.46,dw*0.88,h*0.004);
    c.fillStyle='#2f383d';c.fillRect(dx,dy+dh*0.86,dw,dh*0.14);      // отбойная полоса
    c.fillStyle='rgba(190,214,222,.05)';c.fillRect(dx,dy+dh*0.86,dw,2);
    // стекло: за ним та же тьма, поэтому оно почти чёрное с холодным блеском
    const gx=dx+dw*0.28,gy2=dy+dh*0.16,gw=dw*0.44,gh=dh*0.16;
    c.fillStyle='#070b0e';c.fillRect(gx,gy2,gw,gh);
    c.strokeStyle='rgba(120,150,166,.10)';c.lineWidth=1;
    for(let i=1;i<6;i++){c.beginPath();c.moveTo(gx+gw*i/6,gy2);c.lineTo(gx+gw*i/6,gy2+gh);c.stroke();}
    for(let i=1;i<3;i++){c.beginPath();c.moveTo(gx,gy2+gh*i/3);c.lineTo(gx+gw,gy2+gh*i/3);c.stroke();}
    c.fillStyle='rgba(160,196,210,.06)';c.fillRect(gx,gy2,gw,gh*0.22);
    c.restore();
   }
   c.fillStyle='rgba(190,214,222,.06)';c.fillRect(dx,dy,Math.max(0,pw),3);
   // темнота за дверью не пустая: в ней шевелится глубина
   if(op>0.05){
    c.save();c.globalAlpha=op;
    const vd=c.createLinearGradient(dx+dw*(1-op),0,dx+dw,0);
    vd.addColorStop(0,'rgba(0,0,0,1)');vd.addColorStop(1,'rgba(4,6,8,1)');
    c.fillStyle=vd;c.fillRect(dx+dw*(1-op),dy,dw*op,dh);
    if(!low)for(let i=0;i<10;i++){
     const r=A.epiRnd(i*7.1), yy=dy+dh*((i*0.11+t*0.05)%1);
     c.fillStyle='rgba(26,32,36,'+(0.20+0.30*r).toFixed(3)+')';
     c.fillRect(dx+dw*(1-op)+dw*op*r*0.9,yy,dw*0.06,h*0.004+h*0.01*r);
    }
    c.restore();
   }
   c.restore();
   // ручка: в момент щелчка на ней вспыхивает блик
   const hk=cl((tc-0.35)/0.25)*(1-op*0.6);
   c.fillStyle='#c8bfa6';c.fillRect(dx+dw*0.90,dy+dh*0.48,w*0.028,h*0.012);
   glow(c,dx+dw*0.915,dy+dh*0.486,w*0.05,'255,236,190',0.22*hk);
   // он спиной к нам, крупно, рука на ручке
   const sc=A.epiGuardScale(h*0.66), gy=FL-A.epiGuardFeet(sc);
   A.drawGuardChar(c,w*0.585,gy,sc,{t,pose:'reach',reachK:cl((tc-0.15)/0.5),
     back:1,face:1,look:0.05,seed:4.4,shadowDir:-1,shadowLen:0.7,
     rim:{dir:1,col:'120,150,170',power:0.10+0.10*(1-op)}});
   // темнота из проёма затягивает кадр
   if(op>0.4){
    const vk=cl((op-0.4)/0.6);
    const vg=c.createRadialGradient(w*0.5,h*0.5,w*(0.44-0.22*vk),w*0.5,h*0.5,w*0.86);
    vg.addColorStop(0,'rgba(0,0,0,0)');vg.addColorStop(1,'rgba(0,0,0,'+(0.80*vk).toFixed(3)+')');
    c.fillStyle=vg;c.fillRect(0,0,w,h);
   }
   c.restore();
   cut(c,w,h,tc,0.4);
  }
  // ---- БИТ 6: НИКОТИНОВЫЙ ФЛЭШБЭК от первого лица. ----
  else if(t<B[6]){
   const tc=t-B[5], k=Math.min(1,tc/0.7)*(1-cl((tc-2.2)/0.6));
   c.save();
   // тряска: сильная в накате, гаснет к выходу
   c.translate(Math.sin(t*23.7)*4.2*k+Math.sin(t*7.1)*2.0*k,
               Math.cos(t*19.3)*3.4*k+Math.cos(t*5.3)*1.6*k);
   // за глазами — обрывки прошлых кадров: коридор, лампа, чужая голова.
   // Они не показывают ничего нового, только то, что он уже видел ночью.
   c.fillStyle='#07090b';c.fillRect(0,0,w,h);
   const frag=Math.floor(tc*3.2)%3;
   const fa=(0.30+0.30*Math.abs(Math.sin(tc*6.1)))*k;
   c.save();c.globalAlpha=fa;
   if(frag===0){
    for(let i=6;i>=0;i--){const kk=i/6,sx=w*0.5-w*0.46*(1-kk*0.9);
     c.fillStyle='rgba('+Math.round(24+60*kk)+','+Math.round(30+70*kk)+','+Math.round(36+76*kk)+',1)';
     c.fillRect(sx,h*(0.20+0.24*kk),w-sx*2,h*(0.62-0.42*kk));}
   }else if(frag===1){
    glow(c,w*0.5,h*0.30,w*0.42,'255,236,190',0.50);
    c.fillStyle='rgba(210,226,232,.55)';c.fillRect(w*0.36,h*0.28,w*0.28,h*0.012);
   }else{
    A.epiAnimatron(c,w*0.52,h*0.98,A.epiMonScale(h*0.86),t,{kind:'main',seed:9.1,
      face:1,dark:0.86,eye:0.52,head:0.14,fog:0.30,fogColor:'18,14,10',
      shadow:0,alpha:0.70});
   }
   c.restore();
   // сам субъективный кадр и накат никотина
   window.EndPOV.human(c,w,h,t,{blood:0,tunnel:0.30+0.32*k,lids:0.12+0.20*k,
     run:0,grass:0,hands:0.30*k,breath:0.9});
   window.EndPOV.flashback(c,w,h,t,k);
   c.restore();
   cut(c,w,h,tc,0.5);
  }
  // ---- БИТ 7: камера отъезжает назад. Кадр от первого лица уходит в глубину. ----
  else if(t<B[7]){
   const tc=t-B[6], k=eio(cl(tc/1.6));
   c.save();
   c.fillStyle='#04060a';c.fillRect(0,0,w,h);
   // весь субъективный кадр рисуется в оффскрин-масштабе: он «отъезжает»
   const s=1-0.62*k;
   c.save();
   c.translate(w*0.5,h*0.5);c.scale(s,s);c.translate(-w*0.5,-h*0.5);
   // V101: РУК В ЭТОМ КАДРЕ НЕТ. При отъезде они оказывались у самой нижней
   // кромки и обрезались пополам — читалось как две деревяшки в углу.
   window.EndPOV.human(c,w,h,t,{blood:0,tunnel:0.62-0.30*k,lids:0.32+0.24*k,
     hands:0,breath:0.5*(1-k)});
   window.EndPOV.flashback(c,w,h,t,0.34*(1-k));
   c.restore();
   // V101: КАДР НЕ УХОДИТ В ПУСТОТУ. Раньше вторая половина отъезда была почти
   // полностью чёрной: смотреть было не на что и переход к белому казался
   // склейкой с ничем. Теперь из середины уже здесь начинает расти свет —
   // он и подхватывает следующий бит.
   if(k>0.30){
    const lk=eio(cl((k-0.30)/0.70));
    c.save();c.globalCompositeOperation='lighter';
    const lg=c.createRadialGradient(w*0.5,h*0.48,0,w*0.5,h*0.48,w*(0.06+0.34*lk));
    lg.addColorStop(0,'rgba(255,252,244,'+(0.50*lk).toFixed(3)+')');
    lg.addColorStop(0.45,'rgba(226,232,226,'+(0.20*lk).toFixed(3)+')');
    lg.addColorStop(1,'rgba(226,232,226,0)');
    c.fillStyle=lg;c.fillRect(0,0,w,h);c.restore();
   }
   // рамка вокруг уехавшего кадра — он тонет в темноте, а не висит в пустоте
   c.save();c.globalAlpha=0.85*k;
   const fg=c.createRadialGradient(w*0.5,h*0.5,w*0.28*s,w*0.5,h*0.5,w*0.80);
   fg.addColorStop(0,'rgba(4,6,10,0)');fg.addColorStop(1,'rgba(4,6,10,1)');
   c.fillStyle=fg;c.fillRect(0,0,w,h);c.restore();
   c.restore();
   cut(c,w,h,tc,0.5);
  }
  // ---- БИТ 8: белый покой. Свет раскрывается из середины, и это конец. ----
  else{
   const tc=t-B[7], k=cl(tc/1.4);
   c.fillStyle='#04060a';c.fillRect(0,0,w,h);
   // остаток предыдущего кадра ещё виден под светом
   c.save();c.globalAlpha=Math.max(0,1-k*1.6);
   c.save();c.translate(w*0.5,h*0.5);c.scale(0.38,0.38);c.translate(-w*0.5,-h*0.5);
   window.EndPOV.human(c,w,h,t,{tunnel:0.32,lids:0.56,breath:0});
   c.restore();c.restore();
   window.EndPOV.whiteCalm(c,w,h,t,k);
   // силуэт травы и неба намёком по белому — покой, а не пустая заливка
   if(k>0.55){
    const kk=cl((k-0.55)/0.45);
    c.save();c.globalAlpha=0.16*kk;
    c.fillStyle='#cfd8bc';c.fillRect(0,h*0.72,w,h*0.28);
    c.strokeStyle='rgba(150,168,128,.7)';c.lineWidth=1.4;
    for(let i=0;i<40;i++){
     const r=A.epiRnd(i*3.1),x=w*r;
     c.beginPath();c.moveTo(x,h*(0.99));
     c.quadraticCurveTo(x+Math.sin(t*0.6+i)*6,h*0.86,x+Math.sin(t*0.6+i)*11,h*(0.78-0.06*r));
     c.stroke();
    }
    c.restore();
   }
  }

  // ---- служебные наложения (текста нет, кроме финальной карточки) ----
  A.epiBars(c,w,h,1);
  if(t<B[7])A.epiGrade(c,w,h,t,low,'rgba(10,22,30,.10)',0.34,0.9);
  else A.epiGrade(c,w,h,t,low,null,0.05,0.30);
  // V103: НАЗВАНИЕ ФИНАЛА УБРАНО СОВСЕМ.
  // ПОЧЕМУ ТАК БЫЛО: на белом покое в последние две секунды проявлялась надпись
  // «РАССВЕТ» — единственный текст во всей сцене, и он сообщал игроку название
  // концовки вместо того, чтобы дать кадру закончиться самому.
  // СТАЛО: белый свет держится до конца, никаких букв.
  A.epiSkipHint(c,w,h,t);
  c.restore();
  return true;
 }

 // =========================================================================
 // 2. «ПЕПЕЛ» — 22.0 с, дальше кода. Он побит, за ним идут, он выжигает всё
 // и уходит на своих ногах, но последний кадр видит уже его глазами.
 //  0.0 бег по залу от двоих
 //  3.4 склад: канистра
 //  6.2 льёт бензин
 //  8.4 КРУПНЫЙ план: спичка
 // 10.0 огонь идёт по разлитому
 // 11.8 бег к выходу сквозь огонь
 // 15.0 улица: здание складывается
 // 18.0 первое лицо: он падает на траву
 // =========================================================================
 function burn(A,t){
  const c=A.ctx,w=A.w,h=A.h,low=A.low;
  const B=[0,3.4,6.2,8.4,10.0,11.8,15.0,18.0], DUR=22.0;
  const BLOOD=0.62;
  A.epiCue(t,0.05,()=>{bed('chase',1.0);sfx('breath',0.55)});
  A.epiCue(t,0.9,()=>sfx('clawSwipe',0.45));
  A.epiCue(t,2.1,()=>sfx('grab',0.32));
  A.epiCue(t,3.5,()=>{bed('ash',0.9);sfx('metalDrag',0.34)});
  A.epiCue(t,6.3,()=>sfx('drip',0.42));
  A.epiCue(t,8.5,()=>sfx('matchStrike',0.85));
  A.epiCue(t,10.1,()=>{sfx('ignite',0.60);sfx('fire',0.55)});
  A.epiCue(t,11.9,()=>sfx('breath',0.50));
  A.epiCue(t,15.1,()=>sfx('metalGroan',0.55));
  A.epiCue(t,16.4,()=>sfx('collapse',0.95));
  A.epiCue(t,18.1,()=>sfx('subDrop',0.34));
  A.epiCue(t,19.6,()=>{sfx('bodyFall',0.80);sfx('grass',0.55)});
  A.epiCue(t,20.4,()=>sfx('breath',0.45));

  c.save();c.imageSmoothingEnabled=true;

  // ---- БИТ 1: бег по залу. Двое сзади, он уже в крови. ----
  if(t<B[1]){
   const tc=t-B[0], k=cl(tc/3.2);
   c.save();handheld(c,t,1.4,0.9);
   const FL=sideRoom(c,w,h,t,{floorY:h*0.79,lamps:5,flicker:true,dead:2,tile:true,
     pal:['#05060a','#131319','#1d1c23','#0b0a0e']});
   // ряды столов пролетают мимо: сдвиг по k даёт скорость без смены плана
   for(let i=-1;i<6;i++){
    const sx=w*(0.10+i*0.24)-w*0.55*k, sw2=w*0.15;
    c.fillStyle='rgba(20,20,26,.95)';c.fillRect(sx,FL-h*0.095,sw2,h*0.022);
    c.fillStyle='rgba(14,14,18,.95)';c.fillRect(sx+sw2*0.45,FL-h*0.073,w*0.013,h*0.073);
   }
   // двое сзади: на бегу они отстают, но не сильно
   [[0.02,'main',0.66],[-0.13,'felix',0.60]].forEach((a2,i)=>{
    A.epiAnimatron(c,w*(a2[0]+0.30*k),FL+h*0.045,A.epiMonScale(h*0.54*a2[2]/0.62),t,{
      kind:a2[1],seed:i*3.7,face:1,dark:0.90,alarmed:true,
      eye:0.55+0.35*Math.abs(Math.sin(t*3.1+i)),head:0.16,
      fog:0.24,fogColor:'22,14,14',shadow:0.30,shadowDir:-1,alpha:0.90});
   });
   const sc=A.epiGuardScale(h*0.58), gy=FL+h*0.055-A.epiGuardFeet(sc);
   const dist=w*(0.30+0.34*k);
   A.drawGuardChar(c,dist,gy,sc,{t,pose:'run',phase:A.epiStridePhase(dist,sc,0.62),
     face:1,look:0.30,seed:5.1,dust:true,blood:BLOOD,limp:0.22,
     shadowDir:-1,shadowLen:1.1,
     rim:{dir:-1,col:'255,150,90',power:0.14}});
   c.restore();
   cut(c,w,h,tc,0.5);
  }
  // ---- БИТ 2: склад. Он находит канистру и берёт её. ----
  else if(t<B[2]){
   const tc=t-B[1], k=eio(cl(tc/1.9)), lift=eio(cl((tc-1.7)/0.9));
   c.save();handheld(c,t,0.9);
   const FL=sideRoom(c,w,h,t,{floorY:h*0.81,lamps:2,flicker:true,dead:1,
     pal:['#05060a','#12110f','#1b1913','#0a0908']});
   // стеллажи склада: ящики, ведра, бухты кабеля
   for(let r=0;r<3;r++){
    const ry=FL-h*(0.14+r*0.16);
    c.fillStyle='rgba(30,26,20,.95)';c.fillRect(w*0.04,ry,w*0.44,h*0.016);
    for(let i=0;i<4;i++){
     const bw=w*0.075, bx=w*(0.06+i*0.105);
     c.fillStyle=['#2b2519','#332c1d','#241f16','#302a1c'][(i+r)%4];
     c.fillRect(bx,ry-h*0.085,bw,h*0.085);
     c.fillStyle='rgba(190,178,140,.06)';c.fillRect(bx,ry-h*0.085,bw,2);
    }
   }
   // канистра: она должна ЧИТАТЬСЯ — красный корпус, ручка, крышка, блик
   const canX=w*(0.62-0.03*k), canY=FL-h*0.010-h*0.20*lift;
   const cw=w*0.052, chh=h*0.115;
   c.save();c.translate(canX,canY);c.rotate(-0.5*lift);
   c.fillStyle='#7a1d16';c.fillRect(-cw*0.5,-chh,cw,chh);
   c.fillStyle='#96271d';c.fillRect(-cw*0.5,-chh,cw*0.55,chh);
   c.fillStyle='#521310';c.fillRect(-cw*0.5,-chh*0.30,cw,h*0.008);
   c.fillStyle='#2a2018';c.fillRect(-cw*0.16,-chh-h*0.020,cw*0.32,h*0.022);   // горловина
   c.fillStyle='#c8b268';c.fillRect(-cw*0.12,-chh-h*0.026,cw*0.24,h*0.008);   // крышка
   c.strokeStyle='#2a2018';c.lineWidth=Math.max(2,w*0.006);                    // ручка
   c.beginPath();c.moveTo(-cw*0.34,-chh);c.quadraticCurveTo(0,-chh-h*0.042,cw*0.34,-chh);c.stroke();
   c.fillStyle='rgba(255,220,180,.10)';c.fillRect(-cw*0.42,-chh*0.92,cw*0.10,chh*0.80);
   c.restore();
   const sc=A.epiGuardScale(h*0.60), gy=FL+h*0.04-A.epiGuardFeet(sc);
   A.drawGuardChar(c,w*(0.36+0.16*k),gy,sc,{t,
     pose:lift>0.1?'reach':'walk',reachK:lift,
     phase:A.epiStridePhase(w*0.16*k,sc,0.52),
     face:1,look:0.45,seed:6.3,blood:BLOOD,limp:0.26,dust:lift<0.1,
     shadowDir:-1,shadowLen:1.0,rim:{dir:1,col:'255,180,120',power:0.10}});
   c.restore();
   cut(c,w,h,tc,0.45);
  }
  // ---- БИТ 3: он льёт бензин. Лужа растёт и ловит свет. ----
  else if(t<B[3]){
   const tc=t-B[2], p=cl(tc/2.0);
   c.save();handheld(c,t,0.8);
   const FL=sideRoom(c,w,h,t,{floorY:h*0.80,lamps:3,flicker:true,dead:1,tile:true,
     pal:['#05060a','#12110f','#1b1913','#0a0908']});
   // лужа: не круг, а растекающееся пятно с плёнкой на поверхности
   const pl=c.createRadialGradient(w*0.50,FL+h*0.055,2,w*0.50,FL+h*0.055,w*0.30*p);
   pl.addColorStop(0,'rgba(58,48,26,.85)');pl.addColorStop(0.6,'rgba(44,38,22,.60)');
   pl.addColorStop(1,'rgba(40,34,20,0)');
   c.fillStyle=pl;c.beginPath();
   c.ellipse(w*0.50,FL+h*0.055,w*0.30*p,h*0.052*p,0,0,Math.PI*2);c.fill();
   if(!low){
    c.save();c.globalCompositeOperation='lighter';c.globalAlpha=0.10;
    for(let i=0;i<12;i++){
     const r=A.epiRnd(i*4.1),ang=r*Math.PI*2;
     c.fillStyle=i%2?'rgba(120,160,220,1)':'rgba(220,160,120,1)';
     c.beginPath();c.ellipse(w*0.50+Math.cos(ang)*w*0.24*p*r,FL+h*0.055+Math.sin(ang)*h*0.04*p*r,
       w*0.02*r+2,h*0.006*r+1,ang,0,Math.PI*2);c.fill();
    }
    c.restore();
   }
   // струя из канистры
   const sc=A.epiGuardScale(h*0.60), gy=FL+h*0.03-A.epiGuardFeet(sc);
   const gx=w*(0.30+0.10*p);
   if(p>0.03&&p<0.98){
    c.save();c.strokeStyle='rgba(196,180,120,.42)';c.lineWidth=Math.max(2,w*0.0035);
    c.beginPath();c.moveTo(gx+w*0.055,gy-A.epiGuardFeet(sc)*0.02+h*0.10);
    c.quadraticCurveTo(gx+w*0.10,FL-h*0.02,gx+w*0.115+Math.sin(t*6)*w*0.004,FL+h*0.045);
    c.stroke();c.restore();
   }
   A.drawGuardChar(c,gx,gy,sc,{t,pose:'pour',pourK:p,face:1,look:0.35,
     seed:6.3,blood:BLOOD,shadowDir:-1,shadowLen:1.0,
     rim:{dir:1,col:'255,180,120',power:0.10}});
   c.restore();
   cut(c,w,h,tc,0.45);
  }
  // ---- БИТ 4: КРУПНЫЙ ПЛАН СПИЧКИ. Один предмет на весь кадр. ----
  else if(t<B[4]){
   const tc=t-B[3];
   const drag=cl(tc/0.55);                    // протяг по коробку
   const lit=cl((tc-0.55)/0.20);              // вспышка
   const burn2=cl((tc-0.75)/0.85);            // ровное горение
   c.save();
   c.fillStyle='#07060a';c.fillRect(0,0,w,h);
   // фон крупного плана: расфокусированные ладони и лицо за ними
   c.save();c.globalAlpha=0.55;
   const bgg=c.createRadialGradient(w*0.5,h*0.56,w*0.06,w*0.5,h*0.56,w*0.55);
   bgg.addColorStop(0,'rgba(64,48,36,1)');bgg.addColorStop(1,'rgba(8,7,9,1)');
   c.fillStyle=bgg;c.fillRect(0,0,w,h);
   c.restore();
   // ладонь-щиток снизу и коробок в другой руке
   c.fillStyle='#1b1a1f';
   c.beginPath();c.moveTo(w*0.10,h);c.lineTo(w*0.22,h*0.62);
   c.lineTo(w*0.44,h*0.58);c.lineTo(w*0.40,h);c.closePath();c.fill();
   c.fillStyle='#2a221c';                                        // коробок
   c.save();c.translate(w*0.30,h*0.60);c.rotate(-0.22);
   c.fillRect(-w*0.10,0,w*0.20,h*0.070);
   c.fillStyle='#3a3128';c.fillRect(-w*0.10,0,w*0.20,h*0.014);   // тёрка
   c.fillStyle='rgba(190,170,120,.10)';c.fillRect(-w*0.10,0,w*0.20,2);
   c.restore();
   // сама спичка: древко, головка, зона обугливания
   const mx=w*(0.30+0.20*drag), my=h*(0.60-0.02*drag);
   c.save();c.translate(mx,my);c.rotate(-0.62+0.16*drag);
   const ml=w*0.155, mw=Math.max(3,w*0.0075);
   const woodK=burn2;
   c.fillStyle='#c9b083';c.fillRect(-ml,0,ml,mw);              // древко
   c.fillStyle='#1a1410';c.fillRect(-ml*woodK*0.55,0,ml*woodK*0.55,mw);  // обугленное
   c.fillStyle=lit>0.02?'#3a1a10':'#7d2b22';                    // головка
   c.fillRect(-mw*0.6,-mw*0.5,mw*2.4,mw*2);
   c.restore();
   // искры протяга: летят строго ПРОТИВ хода спички
   if(drag>0.05&&drag<1&&!low){
    c.save();c.globalCompositeOperation='lighter';
    for(let i=0;i<16;i++){
     const r=A.epiRnd(i*7.7+Math.floor(tc*60)*0.3);
     const sx=mx-w*0.02-r*w*0.10, sy=my+h*0.01-r*h*0.05;
     c.globalAlpha=0.30+0.50*r;
     c.fillStyle=r>0.5?'#ffd27a':'#ff8a3a';
     c.fillRect(sx,sy,1.6+2*r,1.6+2*r);
    }
    c.restore();
   }
   // вспышка и пламя на головке
   if(lit>0.02){
    const fx=mx+Math.cos(-0.62+0.16*drag)*0, fy=my;
    const fl=0.55+0.45*Math.abs(Math.sin(t*11.3));
    glow(c,fx,fy,w*(0.10+0.16*lit)*fl,'255,168,72',0.50*lit);
    glow(c,fx,fy,w*0.05*fl,'255,236,190',0.60*lit);
    A.drawFlames(c,fx-w*0.018,fy-h*0.075,w*0.036,h*0.078,t,0.8*lit,3.1);
    // отблеск на ладонях и на лице
    c.save();c.globalCompositeOperation='lighter';c.globalAlpha=0.14*lit*fl;
    const rg=c.createRadialGradient(fx,fy,w*0.02,fx,fy,w*0.60);
    rg.addColorStop(0,'rgba(255,196,120,1)');rg.addColorStop(1,'rgba(255,150,60,0)');
    c.fillStyle=rg;c.fillRect(0,0,w,h);c.restore();
    // дымок от головки, когда спичка уже горит ровно
    if(burn2>0.3&&!low)A.drawSmokeColumn(c,fx-w*0.02,fy-h*0.20,w*0.04,h*0.20,t,0.10*burn2);
   }
   c.restore();
   cut(c,w,h,tc,0.35);
  }
  // ---- БИТ 5: огонь идёт по разлитому и встаёт стеной. ----
  else if(t<B[5]){
   const tc=t-B[4], k=cl(tc/1.5);
   c.save();handheld(c,t,1.1,0.4*k);
   const FL=sideRoom(c,w,h,t,{floorY:h*0.80,lamps:3,warm:true,flicker:true,
     pal:['#0a0605','#1d1210','#2a1a14','#100a08']});
   // фронт огня бежит слева направо по луже
   // V101: ОГОНЬ БЫЛ СЛИШКОМ МЕЛКИЙ. drawFlames растит язык примерно на 0.4 от
   // заданной высоты, поэтому бокс h*0.16 давал полоску в 40 px — «здание горит»
   // из такого не читалось. Теперь два слоя: низкий фронт по луже и высокая
   // стена за ним, плюс отражение на полу и дым до потолка.
   const fx0=w*0.24, fw=w*0.52*k;
   A.drawFlames(c,fx0,FL-h*0.02,fw,h*0.30,t,0.60+0.40*k,1.7);
   A.drawFlames(c,fx0+fw*0.10,FL-h*0.03,fw*0.80,h*0.56,t,(0.40+0.55*k),5.9);
   if(!low){
    A.drawEmbers(c,fx0,FL-h*0.44,fw,h*0.46,t,Math.round(34*k),0.8);
    // отражение пламени на полу: без него огонь висит в воздухе
    c.save();c.globalCompositeOperation='lighter';c.globalAlpha=0.22*k;
    const rf=c.createLinearGradient(0,FL,0,FL+h*0.10);
    rf.addColorStop(0,'rgba(255,150,60,.55)');rf.addColorStop(1,'rgba(255,110,30,0)');
    c.fillStyle=rf;c.fillRect(fx0-w*0.04,FL,fw+w*0.08,h*0.10);c.restore();
   }
   glow(c,fx0+fw*0.5,FL-h*0.10,w*(0.40+0.34*k),'255,140,50',0.34*k);
   if(!low)A.drawSmokeColumn(c,fx0,h*0.02,fw,FL-h*0.24,t,0.26*k);
   const sc=A.epiGuardScale(h*0.60), gy=FL+h*0.03-A.epiGuardFeet(sc);
   A.drawGuardChar(c,w*(0.28-0.06*k),gy,sc,{t,pose:k<0.4?'brace':'walk',
     phase:A.epiStridePhase(w*0.06*k,sc,0.52),face:-1,look:0.7,
     seed:6.3,blood:BLOOD,limp:0.24,
     shadowDir:1,shadowLen:1.3,rim:{dir:1,col:'255,150,60',power:0.42*k}});
   c.restore();
   cut(c,w,h,tc,0.4);
  }
  // ---- БИТ 6: бег к выходу сквозь огонь. ----
  else if(t<B[6]){
   const tc=t-B[5], k=cl(tc/3.0);
   c.save();handheld(c,t,1.5,1.1);
   const FL=sideRoom(c,w,h,t,{floorY:h*0.79,lamps:4,warm:true,flicker:true,
     pal:['#0b0605','#241410','#331d15','#120a08']});
   // огонь по обеим кромкам кадра — коридор из пламени
   // V101: коридор из пламени стал НАСТОЯЩИМ коридором: огонь по обеим кромкам
   // идёт от пола до верха кадра, по потолку тянется огненный слой, а из-под
   // ног бьют низкие языки. Раньше это были два костерка у краёв.
   A.drawFlames(c,0,FL-h*0.02,w*0.26,h*0.90,t,0.95,4.4);
   A.drawFlames(c,w*0.76,FL-h*0.02,w*0.24,h*0.86,t,0.90,7.7);
   A.drawFlames(c,w*0.16,FL-h*0.01,w*0.24,h*0.26,t,0.55,11.3);
   A.drawFlames(c,w*0.52,FL-h*0.01,w*0.22,h*0.22,t,0.50,13.9);
   if(!low){
    // огонь по потолку: пламя идёт вниз, поэтому кадр рисуется отражённым
    c.save();c.translate(0,h*0.30);c.scale(1,-1);
    A.drawFlames(c,w*0.06,0,w*0.88,h*0.34,t,0.62,17.1);
    c.restore();
    A.drawEmbers(c,0,h*0.10,w,FL-h*0.10,t,48,0.9);
    A.drawSmokeColumn(c,w*0.04,0,w*0.92,FL*0.80,t,0.30);
    glow(c,w*0.08,FL-h*0.24,w*0.44,'255,130,40',0.28);
    glow(c,w*0.90,FL-h*0.22,w*0.40,'255,130,40',0.26);
   }
   // падающие сверху обломки: у каждого свой цикл, они не идут строем
   if(!low)for(let i=0;i<5;i++){
    const r=A.epiRnd(i*8.3), per=1.6+r*1.4, kk=((tc+r*2.1)%per)/per;
    const dx2=w*(0.14+0.7*r);
    c.save();c.translate(dx2,h*(0.06+0.80*kk));c.rotate(kk*5.4+r*3);
    c.fillStyle='rgba(40,26,20,.9)';c.fillRect(-w*0.012,-h*0.006,w*0.024,h*0.012);
    c.fillStyle='rgba(255,140,60,'+(0.30*(1-kk)).toFixed(3)+')';c.fillRect(-w*0.012,-h*0.006,w*0.024,3);
    c.restore();
   }
   // дверь выхода справа: прямоугольник дневного сумрака
   const dx=w*0.86,dy=FL-h*0.42,dw=w*0.11,dh=h*0.42;
   c.fillStyle='#2b2320';c.fillRect(dx-w*0.012,dy-h*0.012,dw+w*0.024,dh+h*0.012);
   c.fillStyle='#4a5560';c.fillRect(dx,dy,dw,dh);
   glow(c,dx+dw*0.5,dy+dh*0.4,w*0.16,'150,180,210',0.16);
   const sc=A.epiGuardScale(h*0.60), gy=FL+h*0.05-A.epiGuardFeet(sc);
   const dist=w*(0.22+0.52*k);
   A.drawGuardChar(c,dist,gy,sc,{t,pose:'run',phase:A.epiStridePhase(dist,sc,0.62),
     face:1,look:0.34,seed:5.1,dust:true,blood:BLOOD,limp:0.20,
     shadowDir:-1,shadowLen:1.2,rim:{dir:-1,col:'255,140,60',power:0.50}});
   c.restore();
   cut(c,w,h,tc,0.4);
  }
  // ---- БИТ 7: улица. Здание складывается у него за спиной. ----
  else if(t<B[7]){
   const tc=t-B[6], groan=cl(tc/1.4), fall=eio(cl((tc-1.4)/1.3));
   c.save();handheld(c,t,1.2,2.6*fall*(1-fall)*4);
   // ночное небо с оранжевым отсветом пожара
   const sky=c.createLinearGradient(0,0,0,h*0.70);
   sky.addColorStop(0,'#0a0f18');sky.addColorStop(0.6,'#2a1d1c');sky.addColorStop(1,'#5a2f1c');
   c.fillStyle=sky;c.fillRect(0,0,w,h*0.70);
   glow(c,w*0.56,h*0.56,w*0.60,'255,120,40',0.28+0.16*fall);
   // поле и трава
   // V101: НОЧНАЯ ЗЕМЛЯ, А НЕ ЗЕЛЁНЫЙ ГАЗОН. Прежняя трава была слишком светлой и
   // насыщенной для ночи: под пожаром она выглядела как дневное поле. Теперь это
   // тёмная земля с гравийной полосой у здания и тёплым отсветом от огня.
   c.fillStyle='#0e1410';c.fillRect(0,h*0.68,w,h*0.32);
   const gg=c.createLinearGradient(0,h*0.68,0,h);
   gg.addColorStop(0,'rgba(34,44,26,.85)');gg.addColorStop(1,'rgba(8,12,9,1)');
   c.fillStyle=gg;c.fillRect(0,h*0.68,w,h*0.32);
   c.fillStyle='rgba(52,48,42,.55)';c.fillRect(0,h*0.695,w,h*0.045);
   if(!low){
    c.save();c.globalAlpha=0.5;
    for(let i=0;i<70;i++){
     const r=A.epiRnd(i*2.9);
     c.fillStyle=r>0.5?'rgba(74,68,58,.6)':'rgba(24,30,20,.7)';
     c.fillRect(w*r,h*(0.70+0.28*A.epiRnd(i*7.7)),1.6+2.4*r,1.4+1.6*r);
    }
    c.restore();
   }
   c.save();c.globalCompositeOperation='lighter';c.globalAlpha=0.14+0.10*fall;
   const wg=c.createLinearGradient(0,h*0.68,0,h*0.92);
   wg.addColorStop(0,'rgba(255,130,50,.60)');wg.addColorStop(1,'rgba(255,110,30,0)');
   c.fillStyle=wg;c.fillRect(0,h*0.68,w,h*0.24);c.restore();
   // ЗДАНИЕ: корпус, крыша, окна. Оно проседает и уходит вниз, а не тает.
   const bx=w*0.34, bw=w*0.46, bTop=h*(0.24+0.30*fall), bBot=h*0.72;
   c.save();
   c.translate(0,h*0.02*fall);
   c.fillStyle='#241a16';c.fillRect(bx,bTop,bw,bBot-bTop);
   // V101: у фасада появилась фактура — кладка, цоколь, вход и вывеска.
   // Раньше корпус был одной коричневой заливкой и читался как картонная коробка.
   if(!low){
    c.save();c.globalAlpha=0.5;c.strokeStyle='rgba(0,0,0,.45)';c.lineWidth=1;
    for(let i=1;i<9;i++){const yy=bTop+(bBot-bTop)*i/9;c.beginPath();c.moveTo(bx,yy);c.lineTo(bx+bw,yy);c.stroke();}
    c.restore();
   }
   c.fillStyle='#1a1210';c.fillRect(bx,bBot-h*0.035,bw,h*0.035);          // цоколь
   c.fillStyle='#0d0908';c.fillRect(bx+bw*0.44,bBot-h*0.16,bw*0.14,h*0.16); // вход
   A.drawFlames(c,bx+bw*0.44,bBot-h*0.03,bw*0.14,h*0.30,t,0.6+0.3*fall,21.7);
   c.fillStyle='#2b1c16';c.fillRect(bx+bw*0.16,bTop+h*0.030,bw*0.68,h*0.030);// вывеска
   c.fillStyle='rgba(210,150,90,.18)';c.fillRect(bx+bw*0.17,bTop+h*0.035,bw*0.66,h*0.020);
   // огонь по кромке крыши и дым: горит всё здание, а не пять окон
   A.drawFlames(c,bx,bTop+h*0.004,bw,h*(0.44+0.32*fall),t,0.8+0.2*fall,3.3);
   A.drawFlames(c,bx+bw*0.20,bTop+h*0.10,bw*0.60,h*(0.24+0.20*fall),t,0.5+0.4*fall,27.3);
   if(!low)A.drawSmokeColumn(c,bx-w*0.02,0,bw+w*0.04,bTop,t,0.30+0.20*fall);
   // крыша перекашивается: одна сторона садится сильнее
   c.fillStyle='#2e211a';c.beginPath();
   c.moveTo(bx-w*0.02,bTop);c.lineTo(bx+bw*0.5,bTop-h*(0.09-0.07*fall));
   c.lineTo(bx+bw+w*0.02,bTop+h*0.02*fall);c.lineTo(bx-w*0.02,bTop);c.closePath();c.fill();
   // окна: в них огонь, и с обрушением они лопаются одно за другим
   for(let i=0;i<5;i++){
    const wx=bx+bw*(0.08+i*0.185), wy=bTop+h*0.09, ww2=bw*0.11, wh2=h*0.11;
    const brk=cl((fall-i*0.12)/0.2);
    c.fillStyle='rgba(10,8,8,1)';c.fillRect(wx,wy,ww2,wh2);
    A.drawFlames(c,wx,wy+wh2*0.25,ww2,wh2*0.85,t,0.5+0.5*brk,i*3.3);
    glow(c,wx+ww2*0.5,wy+wh2*0.5,ww2*2.2,'255,150,60',0.22+0.20*brk);
   }
   c.restore();
   // пыль и обломки в момент падения
   if(fall>0.05){
    if(!low)A.drawSmokeColumn(c,bx-w*0.06,h*0.02,bw+w*0.12,bBot-h*0.02,t,0.30*fall);
    c.save();c.globalAlpha=0.7*fall;
    for(let i=0;i<(low?10:30);i++){
     const r=A.epiRnd(i*5.9), kk=cl((fall*1.6)-r*0.6);
     const px=bx+bw*A.epiRnd(i*2.3), py=bTop+ (bBot-bTop)*r - h*0.30*kk + h*0.60*kk*kk;
     c.fillStyle=r>0.6?'rgba(255,150,70,.7)':'rgba(48,34,28,.9)';
     c.fillRect(px,py,w*0.006+w*0.008*r,w*0.006+w*0.006*r);
    }
    c.restore();
    // волна пыли по земле от основания
    const dstK=cl((fall-0.4)/0.6);
    if(dstK>0){
     c.save();c.globalAlpha=0.34*dstK;
     const dg=c.createRadialGradient(bx+bw*0.5,bBot,w*0.02,bx+bw*0.5,bBot,w*0.70*dstK);
     dg.addColorStop(0,'rgba(120,104,88,.9)');dg.addColorStop(1,'rgba(120,104,88,0)');
     c.fillStyle=dg;c.fillRect(0,h*0.40,w,h*0.60);c.restore();
    }
   }
   // он на переднем плане, спиной к зданию — уходит и не оборачивается
   const sc=A.epiGuardScale(h*0.62), gy=h*0.955-A.epiGuardFeet(sc);
   A.drawGuardChar(c,w*(0.16+0.06*groan),gy,sc,{t,
     pose:tc<1.9?'walk':'brace',phase:A.epiStridePhase(w*0.06*groan,sc,0.44),
     face:-1,look:tc<1.9?0.2:0.9,seed:5.1,blood:BLOOD,limp:0.34,
     shadowDir:1,shadowLen:1.5,rim:{dir:1,col:'255,140,60',power:0.55}});
   c.restore();
   cut(c,w,h,tc,0.4);
  }
  // ---- БИТ 8: ОТ ПЕРВОГО ЛИЦА. Он больше не держится и падает на траву. ----
  else{
   const tc=t-B[7];
   const stand=cl(tc/1.2);                 // ещё стоит, дышит
   const fall=eio(cl((tc-1.4)/0.8));       // кадр валится набок
   const down=cl((tc-2.2)/1.0);            // он уже лежит
   // V101: наклон уменьшен с 1.02 до 0.62 рад. При прежнем угле кадр
   // разваливался на две диагональные плиты и небо с землёй читались как
   // абстрактный раскол, а не как «он упал на бок».
   const TILT=0.62;
   c.save();
   // мир из его глаз: поле, за спиной пожар, кадр наклоняется всё сильнее
   c.save();
   c.translate(w*0.5,h*0.5);
   c.rotate(-0.05*stand-TILT*fall);
   c.translate(-w*0.5,-h*0.5+h*0.26*fall);
   const sky=c.createLinearGradient(0,0,0,h*0.62);
   sky.addColorStop(0,'#070b12');sky.addColorStop(0.65,'#231916');sky.addColorStop(1,'#3f2216');
   c.fillStyle=sky;c.fillRect(-w*1.2,-h*1.2,w*3.4,h*2.4);
   glow(c,w*0.72,h*0.50,w*0.72,'255,120,40',0.26-0.10*down);
   // V101: земля в субъективном кадре тоже стала ночной — раньше здесь лежал
   // яркий зелёный газон и падение выглядело как падение днём.
   c.fillStyle='#0c130c';c.fillRect(-w*1.2,h*0.60,w*3.4,h*1.8);
   const gg=c.createLinearGradient(0,h*0.60,0,h*1.1);
   gg.addColorStop(0,'rgba(26,34,20,.85)');gg.addColorStop(1,'rgba(5,8,6,1)');
   c.fillStyle=gg;c.fillRect(-w*1.2,h*0.60,w*3.4,h*0.9);
   // V101: дымка над линией горизонта. Без неё небо и земля стыковались бритвенно
   // ровной чертой и кадр распадался на две плиты.
   const hz=c.createLinearGradient(0,h*0.545,0,h*0.685);
   hz.addColorStop(0,'rgba(70,40,26,0)');hz.addColorStop(0.5,'rgba(96,56,34,.42)');
   hz.addColorStop(1,'rgba(30,26,18,0)');
   c.fillStyle=hz;c.fillRect(-w*1.2,h*0.545,w*3.4,h*0.14);
   // силуэт горящего здания далеко: он уже позади и ниже
   // V101: раньше это был просто чёрный прямоугольник на траве — читался как
   // дырка в кадре. Теперь силуэт стоит НА ЛИНИИ ГОРИЗОНТА, у него есть крыша и
   // светящиеся проёмы, а над ним стоит пламя и дым.
   // V101: здание УМЕНЬШЕНО и отодвинуто: он уже далеко от него, а прежний
   // размер делал корпус ближе, чем сам герой.
   const rbx=w*0.60, rbw=w*0.20, rbB=h*0.605, rbT=h*0.455;
   c.fillStyle='rgba(14,10,9,.94)';c.fillRect(rbx,rbT,rbw,rbB-rbT);
   c.beginPath();c.moveTo(rbx-w*0.014,rbT);c.lineTo(rbx+rbw*0.5,rbT-h*0.055);
   c.lineTo(rbx+rbw+w*0.014,rbT);c.closePath();c.fill();
   for(let i=0;i<4;i++){
    const wx=rbx+rbw*(0.10+i*0.235);
    c.fillStyle='rgba(255,150,60,.55)';c.fillRect(wx,rbT+h*0.035,rbw*0.13,h*0.040);
   }
   A.drawFlames(c,rbx,rbT+h*0.006,rbw,h*0.26,t,0.75,9.1);
   glow(c,rbx+rbw*0.5,rbT,w*0.42,'255,120,40',0.26);
   if(!low)A.drawSmokeColumn(c,rbx-w*0.02,-h*0.10,rbw+w*0.04,rbT+h*0.10,t,0.26);
   if(!low)A.drawEmbers(c,w*0.40,h*0.10,w*0.60,h*0.45,t,22,0.6);
   c.restore();
   // субъективный кадр: кровь, тоннель, руки, трава, тяжёлые веки
   window.EndPOV.human(c,w,h,t,{
     blood:BLOOD*(0.7+0.3*down),
     tunnel:0.22+0.44*down,
     lids:0.10+0.44*down+0.10*Math.sin(t*0.9),
     blink:down>0.5?cl(Math.sin((tc-2.2)*2.6))*0.35:0,
     run:0.30*(1-stand),
     // V101: рук здесь нет. Они попадали в кадр под углом и читались как две
     // светлые дощечки в углах; падение выразительнее без них.
     grass:down,hands:0,breath:0.9});
   // финальное медленное закрытие глаз — конец сцены, дальше кода
   const lastK=cl((tc-3.2)/0.8);
   if(lastK>0){
    c.save();c.globalAlpha=lastK;c.fillStyle='#000';
    c.fillRect(0,0,w,h*0.52*lastK);c.fillRect(0,h-h*0.52*lastK,w,h*0.52*lastK);
    c.restore();
   }
   c.restore();
   cut(c,w,h,tc,0.5);
  }

  A.epiBars(c,w,h,1);
  A.epiGrade(c,w,h,t,low,t<B[6]?'rgba(40,14,6,.14)':'rgba(30,12,8,.10)',0.38,1.0);
  // V103: НАЗВАНИЕ КОНЦОВКИ И СЧЁТЧИК СМЕРТЕЙ УБРАНЫ.
  // ПОЧЕМУ ТАК БЫЛО: финал заканчивался служебной карточкой «КОНЦОВКА: ...» и
  // строкой «СМЕРТЕЙ: N». Это разрушало сцену: только что был кадр, а сразу
  // после — отчёт. СТАЛО: финал уходит в чёрный без подписей.
  // A.epiCard(c,w,h,t,DUR-2.2,2.0,'ПЕПЕЛ','','#f0d8b8');
  A.epiSkipHint(c,w,h,t);
  c.restore();
  return true;
 }

 // =========================================================================
 // 3. «ЕЩЁ ОДИН КОСТЮМ» — 18.2 с, биты РОВНО по 2.6 с, дальше кода.
 //  0.0 он еле поднимается с кресла, весь в крови
 //  2.6 бежит; в проёме его достаёт рука
 //  5.2 коридор: двое по сторонам рвут его на ходу
 //  7.8 почти у двери — проём закладывают кирпичом, он останавливается
 // 10.4 он стоит и дышит, кровь капает на пол
 // 13.0 разворот и шаг назад — КРУПНО, лицо в кадре
 // 15.6 садится в кресло, глаза загораются
 // =========================================================================
 function dark(A,t){
  const c=A.ctx,w=A.w,h=A.h,low=A.low;
  const S=2.6, B=[0,S,S*2,S*3,S*4,S*5,S*6], DUR=18.2;
  const BL=0.85;                                   // сила крови: его уже рвали
  A.epiCue(t,0.05,()=>{bed('hollow',1.0);sfx('breath',0.60)});
  A.epiCue(t,1.4,()=>sfx('bone',0.30));
  A.epiCue(t,2.7,()=>{bed('chase',1.0);sfx('grab',0.42)});
  A.epiCue(t,3.9,()=>sfx('clawSwipe',0.60));
  A.epiCue(t,5.3,()=>sfx('metalDrag',0.42));
  A.epiCue(t,6.4,()=>sfx('clawSwipe',0.50));
  A.epiCue(t,7.9,()=>sfx('bricks',0.90));
  A.epiCue(t,9.4,()=>sfx('metalGroan',0.30));
  A.epiCue(t,10.5,()=>{bed('hollow',0.9);sfx('breath',0.55)});
  A.epiCue(t,11.6,()=>sfx('bloodDrip',0.45));
  A.epiCue(t,12.4,()=>sfx('bloodDrip',0.40));
  A.epiCue(t,13.1,()=>sfx('subDrop',0.34));
  A.epiCue(t,15.7,()=>sfx('paper',0.26));
  A.epiCue(t,16.9,()=>sfx('shimmer',0.34));

  c.save();c.imageSmoothingEnabled=true;
  const OFFICE=['#04060a','#0d1116','#151a20','#080b0f'];

  // Кресло охранника: одна функция, потому что оно нужно в первом и в
  // последнем бите и обязано быть ОДНИМ И ТЕМ ЖЕ предметом.
  function chair(x,FL,k){
   const cw=w*0.085*k, ch2=h*0.30*k;
   c.fillStyle='#12181d';c.fillRect(x-cw*0.5,FL-h*0.020*k,cw*0.14,h*0.020*k);
   c.fillStyle='#1b2329';c.fillRect(x-cw*0.5,FL-ch2*0.42,cw,h*0.022*k);
   c.fillStyle='#151c22';c.fillRect(x-cw*0.5,FL-ch2,cw*0.22,ch2*0.62);
   c.fillStyle='#1d262c';c.fillRect(x-cw*0.5,FL-ch2,cw,h*0.016*k);
   c.fillStyle='rgba(160,184,190,.05)';c.fillRect(x-cw*0.5,FL-ch2*0.42,cw,2);
  }

  // ---- БИТ 1: он еле поднимается с кресла. ----
  if(t<B[1]){
   const tc=t, k=eio(cl(tc/2.3));
   c.save();handheld(c,t,0.7,0.4*(1-k));
   const FL=sideRoom(c,w,h,t,{floorY:h*0.80,lamps:2,flicker:true,dead:0,pal:OFFICE});
   // стол и погасший монитор: офис тот же, но в нём уже нечего смотреть
   c.fillStyle='#161d22';c.fillRect(w*0.05,FL-h*0.20,w*0.30,h*0.028);
   c.fillStyle='#111820';c.fillRect(w*0.075,FL-h*0.172,w*0.018,h*0.172);
   c.fillStyle='#111820';c.fillRect(w*0.315,FL-h*0.172,w*0.018,h*0.172);
   c.fillStyle='#090d10';c.fillRect(w*0.12,FL-h*0.330,w*0.145,h*0.130);
   c.fillStyle='rgba(60,80,84,.20)';c.fillRect(w*0.127,FL-h*0.323,w*0.131,h*0.113);
   chair(w*0.47,FL+h*0.02,1);
   doorway(c,w,h,w*0.855,FL,0.14,{spill:0.06,col:'120,150,164'});
   // он: сидит → тяжело встаёт. Правая рука упирается в подлокотник,
   // корпус завален вперёд — это подъём из последних сил, а не из кресла в кино.
   const sc=A.epiGuardScale(h*0.56), gy=FL+h*0.02-A.epiGuardFeet(sc);
   A.drawGuardChar(c,w*0.472,gy+h*0.035*(1-k),sc,{t,
     pose:k<0.30?'sit':(k<0.95?'rise':'stand'),riseK:cl((k-0.30)/0.62),
     face:1,look:0.42,seed:2.2,blood:BL,slump:0.55*(1-k),limp:0.5,
     shadowDir:-1,shadowLen:1.0,
     rim:{dir:1,col:'120,150,164',power:0.14}});
   // кровь на кресле и на полу под ним: он сидел здесь долго
   c.save();c.globalAlpha=0.55;
   c.fillStyle='rgba(96,10,14,.85)';
   c.fillRect(w*0.452,FL+h*0.012,w*0.030,h*0.006);
   c.beginPath();c.ellipse(w*0.468,FL+h*0.028,w*0.032,h*0.008,0,0,Math.PI*2);c.fill();
   c.restore();
   c.restore();
   cut(c,w,h,tc,0.8);
  }
  // ---- БИТ 2: он бежит, и в проёме его достаёт рука. ----
  else if(t<B[2]){
   const tc=t-B[1], k=cl(tc/2.3), hit=cl((tc-1.2)/0.25)*(1-cl((tc-1.9)/0.5));
   c.save();handheld(c,t,1.5,1.2+3.4*hit);
   const FL=sideRoom(c,w,h,t,{floorY:h*0.79,lamps:4,flicker:true,dead:2,pal:OFFICE});
   const dr=doorway(c,w,h,w*0.72,FL,0.15,{spill:0.04});
   // из проёма выходит рука и корпус: он не успевает проскочить
   const app=cl((tc-0.8)/0.7);
   if(app>0.01){
    A.epiAnimatron(c,dr.x+dr.dw*0.10,FL+h*0.03,A.epiMonScale(h*0.62),t,{
      kind:'main',seed:3.3,face:-1,dark:0.86,alarmed:true,
      eye:0.60+0.35*Math.abs(Math.sin(t*4.1)),head:0.24*app,
      fog:0.24,fogColor:'18,14,16',shadow:0.30,shadowDir:1,alpha:0.55+0.42*app});
   }
   const sc=A.epiGuardScale(h*0.58), gy=FL+h*0.05-A.epiGuardFeet(sc);
   const dist=w*(0.14+0.44*k);
   A.drawGuardChar(c,dist,gy,sc,{t,
     pose:hit>0.4?'brace':'run',phase:A.epiStridePhase(dist,sc,0.62),
     face:1,look:hit>0.4?-0.2:0.32,seed:5.1,dust:hit<0.4,
     blood:BL,limp:0.34,spasm:hit*0.6,
     shadowDir:-1,shadowLen:1.1,rim:{dir:1,col:'120,150,164',power:0.16}});
   // брызги в момент удара — короткая вспышка, а не постоянный слой
   if(hit>0.05&&!low){
    c.save();c.globalAlpha=0.8*hit;
    for(let i=0;i<14;i++){
     const r=A.epiRnd(i*6.1), ang=-0.9+r*1.8;
     const rr=w*0.02+w*0.07*r*hit;
     c.fillStyle=r>0.5?'rgba(150,16,20,.9)':'rgba(96,8,12,.9)';
     c.fillRect(dist+Math.cos(ang)*rr,gy-h*0.16+Math.sin(ang)*rr*0.6,1.8+3*r,1.8+3*r);
    }
    c.restore();
   }
   c.restore();
   cut(c,w,h,tc,0.4);
  }
  // ---- БИТ 3: коридор. Двое по сторонам достают его на ходу. ----
  else if(t<B[3]){
   const tc=t-B[2], k=cl(tc/2.3);
   c.save();handheld(c,t,1.7,1.4);
   // коридор строится в перспективе, дверь выхода в глубине справа
   c.fillStyle='#04070a';c.fillRect(0,0,w,h);
   const VY=h*0.50;
   // V101: ПОЧЕМУ ТАК БЫЛО: кольца коридора начинались с отступом от кромки, и
   // самое светлое кольцо оказывалось прямоугольником внутри тёмной рамки —
   // кадр читался как светлая коробка, наклеенная на чёрный фон. СТАЛО: первое
   // кольцо занимает весь кадр, тон каждого кольца ниже, а по краям идёт
   // виньетка, так что глубина уходит в темноту, а не в серый.
   for(let i=8;i>=0;i--){
    const kk=i/8;
    const sx=(i===8)?0:(w*0.5-(w*0.5-w*0.03)*(1-kk*0.88));
    const yTop=(i===8)?0:(VY-(VY-h*0.11)*(1-kk*0.90));
    const yBot=(i===8)?h:(VY+(h*0.95-VY)*(1-kk*0.90));
    const g=0.02+kk*0.055;
    c.fillStyle='rgba('+Math.round(14+52*g)+','+Math.round(18+58*g)+','+Math.round(22+64*g)+',1)';
    c.fillRect(sx,yTop,w-sx*2,yBot-yTop);
    if(i<8){                                    // тень в стыке между кольцами
     c.strokeStyle='rgba(0,0,0,.28)';c.lineWidth=1;
     c.strokeRect(sx,yTop,w-sx*2,yBot-yTop);
    }
   }
   {const vg=c.createRadialGradient(w*0.5,h*0.5,w*0.16,w*0.5,h*0.5,w*0.72);
    vg.addColorStop(0,'rgba(0,0,0,0)');vg.addColorStop(1,'rgba(0,0,0,.72)');
    c.fillStyle=vg;c.fillRect(0,0,w,h);}
   // они стоят вплотную к его пути и на проходе бьют
   [[0.20,-1,0.94],[0.79,1,0.88]].forEach((a2,i)=>{
    const swipe=cl(Math.sin((tc-0.4-i*0.7)*3.4))*(tc>0.4+i*0.7?1:0);
    A.epiAnimatron(c,w*a2[0],h*0.92,A.epiMonScale(h*0.58*a2[2]),t,{
      kind:i?'felix':'main',seed:i*4.3,face:i?-1:1,dark:0.88,alarmed:true,
      eye:0.55+0.40*Math.abs(Math.sin(t*3.7+i)),head:0.10+0.22*swipe,
      fog:0.24,fogColor:'16,14,18',shadow:0.28,shadowDir:a2[1],alpha:0.92});
    if(swipe>0.35&&!low){
     c.save();c.globalAlpha=0.5*swipe;c.strokeStyle='rgba(190,200,206,.7)';
     c.lineWidth=Math.max(1.6,w*0.0035);
     for(let s2=0;s2<3;s2++){
      c.beginPath();
      c.moveTo(w*(a2[0]+a2[1]*-0.03),h*(0.52+s2*0.035));
      c.lineTo(w*0.5,h*(0.60+s2*0.030));c.stroke();
     }
     c.restore();
    }
   });
   // он бежит на камеру: масштаб растёт, поэтому он не мелкий даже в глубине
   const sc=A.epiGuardScale(h*(0.42+0.20*k)), gy=h*(0.78+0.16*k)-A.epiGuardFeet(sc);
   A.drawGuardChar(c,w*(0.50+0.02*Math.sin(t*3.1)),gy,sc,{t,
     pose:'run',phase:t*5.6,face:1,look:0.24,seed:5.1,dust:true,
     blood:BL,limp:0.30,shadowDir:-1,shadowLen:0.9,
     rim:{dir:1,col:'150,170,180',power:0.18}});
   c.restore();
   cut(c,w,h,tc,0.4);
  }
  // ---- БИТ 4: проём закладывают кирпичом. Он останавливается. ----
  else if(t<B[4]){
   const tc=t-B[3];
   const run2=cl(tc/1.0);                       // добегает
   const lay=cl((tc-0.9)/1.1);                  // кладка растёт снизу вверх
   const stop2=cl((tc-1.05)/0.35);              // он встал
   c.save();handheld(c,t,1.2,2.2*Math.max(0,Math.sin(lay*Math.PI*8))*lay);
   const FL=sideRoom(c,w,h,t,{floorY:h*0.82,lamps:3,flicker:true,dead:1,pal:OFFICE});
   // дверь выхода крупно: она пока ещё дверь
   const dx=w*0.62,dw2=w*0.26,dh2=h*0.52,dy=FL-dh2;
   c.fillStyle='#2a3237';c.fillRect(dx-w*0.016,dy-h*0.016,dw2+w*0.032,dh2+h*0.016);
   c.fillStyle='#111a1e';c.fillRect(dx,dy,dw2,dh2);
   glow(c,dx+dw2*0.5,dy+dh2*0.5,w*0.22,'150,180,200',0.10*(1-lay));
   // КЛАДКА: восемь рядов, кирпичи с перевязкой, шов раствора, крошка.
   // Ряды встают снизу вверх — это и читается как «проём закладывают».
   const rows=8, brH=dh2/rows;
   for(let r=0;r<rows;r++){
    const rk=cl((lay*rows)-r);
    if(rk<=0)continue;
    const ry=FL-brH*(r+1);
    const off=(r%2)?brH*0.9:0;
    for(let i=-1;i<6;i++){
     const bw2=brH*1.8, bx2=dx+off+i*bw2;
     if(bx2+bw2<dx-1||bx2>dx+dw2+1)continue;
     const x0=Math.max(dx,bx2), x1=Math.min(dx+dw2,bx2+bw2);
     if(x1<=x0)continue;
     const sh=A.epiRnd(r*7.1+i*3.3);
     // V101: ПОЧЕМУ ТАК БЫЛО: недоложенный ряд смещался ВВЕРХ (ry-drop), и
     // кирпичи висели над кладкой с чёрной щелью под ними. СТАЛО: ряд
     // поднимается СНИЗУ, из-за уже готовой кладки, и ничего не парит.
     // Плюс тон: прежний кирпич был почти оранжевым и в ночной сцене светился
     // как днём — теперь это тёмный, пыльный кирпич.
     const rise=(1-rk)*brH*1.7;
     const by2=ry+rise;
     if(by2>FL-0.5)continue;                                  // ниже пола не рисуем
     c.fillStyle='rgb('+Math.round(44+20*sh)+','+Math.round(24+12*sh)+','+Math.round(20+9*sh)+')';
     c.fillRect(x0,by2,x1-x0,brH*0.86);
     c.fillStyle='rgba(86,84,76,.26)';                        // раствор
     c.fillRect(x0,by2+brH*0.86,x1-x0,brH*0.14);
     c.fillStyle='rgba(210,196,178,.045)';c.fillRect(x0,by2,x1-x0,1.4);
     c.fillStyle='rgba(0,0,0,.30)';c.fillRect(x0,by2+brH*0.70,x1-x0,brH*0.16);
    }
   }
   // крошка и пыль у основания кладки
   if(lay>0.05&&!low){
    c.save();c.globalAlpha=0.5;
    for(let i=0;i<24;i++){
     const r=A.epiRnd(i*4.7), per=0.7+r*0.6, kk=((tc*1.2+r*2.3)%per)/per;
     c.fillStyle='rgba(120,104,88,'+(0.5*(1-kk)).toFixed(3)+')';
     c.fillRect(dx+dw2*r,FL-dh2*lay*r+kk*h*0.10,1.8+2*r,1.8+2*r);
    }
    c.restore();
    const dg=c.createLinearGradient(0,FL-h*0.10,0,FL+h*0.04);
    dg.addColorStop(0,'rgba(110,98,84,0)');dg.addColorStop(1,'rgba(110,98,84,'+(0.22*lay).toFixed(3)+')');
    c.fillStyle=dg;c.fillRect(dx-w*0.10,FL-h*0.10,dw2+w*0.20,h*0.14);
   }
   // он: добегает и врастает в пол. Никакого отскока — просто стоп.
   const sc=A.epiGuardScale(h*0.62), gy=FL+h*0.03-A.epiGuardFeet(sc);
   const dist=w*(0.16+0.24*run2);
   A.drawGuardChar(c,dist,gy,sc,{t,
     pose:stop2>0.5?'brace':'run',phase:A.epiStridePhase(dist,sc,0.62),
     face:1,look:stop2>0.5?0.85:0.30,seed:5.1,dust:stop2<0.5,
     blood:BL,limp:0.34,shadowDir:-1,shadowLen:1.1,
     rim:{dir:1,col:'150,170,180',power:0.14*(1-lay)}});
   c.restore();
   cut(c,w,h,tc,0.4);
  }
  // ---- БИТ 5: он стоит перед кладкой и дышит. Кровь капает на пол. ----
  else if(t<B[5]){
   const tc=t-B[4];
   c.save();handheld(c,t,0.6);
   const FL=sideRoom(c,w,h,t,{floorY:h*0.82,lamps:3,flicker:true,dead:1,pal:OFFICE});
   // та же кладка, уже готовая, с сырым раствором
   const dx=w*0.62,dw2=w*0.26,dh2=h*0.52,brH=dh2/8;
   c.fillStyle='#2a3237';c.fillRect(dx-w*0.016,FL-dh2-h*0.016,dw2+w*0.032,dh2+h*0.016);
   for(let r=0;r<8;r++){
    const ry=FL-brH*(r+1), off=(r%2)?brH*0.9:0;
    for(let i=-1;i<6;i++){
     const bw2=brH*1.8, bx2=dx+off+i*bw2;
     const x0=Math.max(dx,bx2), x1=Math.min(dx+dw2,bx2+bw2);
     if(x1<=x0)continue;
     const sh=A.epiRnd(r*7.1+i*3.3);
     // V101: тот же тёмный пыльный кирпич, что и в бите закладки — иначе стена
     // меняла цвет между кадрами.
     c.fillStyle='rgb('+Math.round(44+20*sh)+','+Math.round(24+12*sh)+','+Math.round(20+9*sh)+')';
     c.fillRect(x0,ry,x1-x0,brH*0.86);
     c.fillStyle='rgba(86,84,76,.26)';c.fillRect(x0,ry+brH*0.86,x1-x0,brH*0.14);
     c.fillStyle='rgba(0,0,0,.30)';c.fillRect(x0,ry+brH*0.70,x1-x0,brH*0.16);
    }
   }
   // он стоит к нам полуспиной, плечи ходят от дыхания
   const sc=A.epiGuardScale(h*0.64), gy=FL+h*0.03-A.epiGuardFeet(sc);
   A.drawGuardChar(c,w*0.40,gy,sc,{t,pose:'brace',face:1,look:0.75,
     seed:5.1,blood:BL,slump:0.35+0.10*Math.sin(t*1.3),
     shadowDir:-1,shadowLen:1.2,rim:{dir:1,col:'140,160,172',power:0.10}});
   // лужа под ним медленно растёт: время в кадре видно по ней
   const pk=cl(tc/2.4);
   c.save();c.globalAlpha=0.65;
   c.fillStyle='rgba(88,8,12,.9)';
   c.beginPath();c.ellipse(w*0.40,FL+h*0.028,w*(0.012+0.030*pk),h*(0.004+0.009*pk),0,0,Math.PI*2);c.fill();
   c.restore();
   c.restore();
   cut(c,w,h,tc,0.4);
  }
  // ---- БИТ 6: разворот. КРУПНО: он идёт обратно, и его лицо в кадре. ----
  else if(t<B[6]){
   const tc=t-B[5], turn=eio(cl(tc/0.9)), back=eio(cl((tc-0.9)/1.7));
   c.save();
   // камера ближе, чем во всех предыдущих битах: фигура почти во весь кадр
   handheld(c,t,0.5);
   const FL=sideRoom(c,w,h,t,{floorY:h*0.90,lamps:2,flicker:true,dead:0,pal:OFFICE});
   // кладка уходит за спину и размывается — она больше не важна
   c.save();c.globalAlpha=0.55;
   const brH=h*0.06;
   for(let r=0;r<7;r++)for(let i=0;i<4;i++){
    const sh=A.epiRnd(r*3.7+i*5.1);
    c.fillStyle='rgb('+Math.round(52+20*sh)+','+Math.round(28+12*sh)+','+Math.round(22+10*sh)+')';
    c.fillRect(w*(0.70+i*0.085)+((r%2)?w*0.04:0),FL-brH*(r+1),w*0.080,brH*0.86);
   }
   c.restore();
   // он: разворачивается на месте, потом идёт от кладки в глубину офиса
   const sc=A.epiGuardScale(h*(0.86-0.14*back)), gy=FL+h*0.02-A.epiGuardFeet(sc);
   A.drawGuardChar(c,w*(0.60-0.16*back),gy,sc,{t,
     pose:back>0.03?'walk':'stand',
     phase:A.epiStridePhase(w*0.16*back,sc,0.40),stride:0.72,
     face:turn>0.5?-1:1,look:0.1+0.5*(1-turn),
     seed:5.1,blood:BL,limp:0.42,slump:0.30,dust:back>0.03,
     shadowDir:1,shadowLen:1.4,rim:{dir:-1,col:'120,150,164',power:0.12}});
   // тьма сжимается к его силуэту
   const vg=c.createRadialGradient(w*(0.58-0.14*back),h*0.52,w*0.22,w*0.5,h*0.52,w*0.80);
   vg.addColorStop(0,'rgba(0,0,0,0)');vg.addColorStop(1,'rgba(0,0,0,.72)');
   c.fillStyle=vg;c.fillRect(0,0,w,h);
   c.restore();
   cut(c,w,h,tc,0.4);
  }
  // ---- БИТ 7: он садится в то же кресло. Глаза загораются. ----
  else{
   const tc=t-B[6], sit=eio(cl(tc/1.3)), eye=cl((tc-1.5)/0.9);
   c.save();handheld(c,t,0.4);
   const FL=sideRoom(c,w,h,t,{floorY:h*0.86,lamps:2,flicker:true,dead:0,pal:OFFICE});
   c.fillStyle='#161d22';c.fillRect(w*0.02,FL-h*0.22,w*0.32,h*0.030);
   c.fillStyle='#090d10';c.fillRect(w*0.10,FL-h*0.360,w*0.155,h*0.140);
   c.fillStyle='rgba(60,80,84,.16)';c.fillRect(w*0.107,FL-h*0.353,w*0.141,h*0.123);
   // V101: ПОЧЕМУ ТАК БЫЛО: кресло и герой стояли в центре кадра, ровно под
   // титром — надпись ложилась ему на грудь, а кресло целиком пряталось за
   // спиной. СТАЛО: он сидит правее центра, кресло сдвинуто ещё чуть правее,
   // так что видна спинка и подлокотник, а титр падает на пустую темноту.
   const CX=w*0.700;
   // V101: ПОЧЕМУ ТАК БЫЛО: старое кресло рисовалось по своей собственной
   // высоте и не совпадало с посадкой персонажа — сиденье оказывалось ниже
   // бёдер, кресло целиком уходило в тень за спиной, и герой висел в воздухе.
   // СТАЛО: кресло строится ОТ ТОЧКИ ОПОРЫ героя: крестовина на полу, газлифт,
   // сиденье ровно под бёдрами (base-0.16h), спинка за плечами, подлокотник
   // рисуется ПОСЛЕ фигуры — рука ложится на него, и посадка читается.
   const BASE=FL+h*0.01+h*0.030*sit;
   const seatY=BASE-h*0.160, sw2=w*0.115;
   (function office(){
    c.save();
    // крестовина и колёса
    c.fillStyle='#1a2228';
    for(let i=-1;i<=1;i+=1){
     c.save();c.translate(CX,BASE);c.rotate(i*0.42);
     c.fillRect(-w*0.004,-h*0.006,w*0.008,h*0.012);
     c.fillRect(-w*0.052,-h*0.004,w*0.104,h*0.009);
     c.restore();
    }
    c.fillStyle='#0f1519';
    [-1,1].forEach(s2=>{c.beginPath();c.ellipse(CX+s2*w*0.050,BASE+h*0.004,w*0.007,h*0.006,0,0,Math.PI*2);c.fill();});
    // газлифт
    c.fillStyle='#232c33';c.fillRect(CX-w*0.010,seatY+h*0.020,w*0.020,BASE-seatY-h*0.020);
    c.fillStyle='rgba(150,176,186,.10)';c.fillRect(CX-w*0.010,seatY+h*0.020,w*0.004,BASE-seatY-h*0.020);
    // сиденье
    c.fillStyle='#26313a';c.fillRect(CX-sw2*0.5,seatY,sw2,h*0.024);
    c.fillStyle='rgba(160,186,196,.10)';c.fillRect(CX-sw2*0.5,seatY,sw2,2);
    c.fillStyle='rgba(0,0,0,.30)';c.fillRect(CX-sw2*0.5,seatY+h*0.020,sw2,h*0.006);
    // спинка за плечами — сдвинута вправо, чтобы её было видно из-за корпуса
    c.fillStyle='#202a31';c.fillRect(CX+sw2*0.18,BASE-h*0.375,sw2*0.30,h*0.220);
    c.fillStyle='rgba(150,176,186,.08)';c.fillRect(CX+sw2*0.18,BASE-h*0.375,sw2*0.30,2);
    c.restore();
   })();
   // он опускается в кресло: не падает, а садится — как в начале смены
   const sc=A.epiGuardScale(h*0.72), gy=FL+h*0.01-A.epiGuardFeet(sc);
   A.drawGuardChar(c,CX,gy+h*0.030*sit,sc,{t,
     pose:sit>0.75?'sit':'rise',riseK:1-sit,
     face:1,look:0.15,seed:5.1,blood:BL,slump:0.45*sit,
     shadowDir:-1,shadowLen:1.0,rim:{dir:1,col:'120,150,164',power:0.10}});
   // подлокотник перед корпусом: рисуется после фигуры — рука лежит на нём
   if(sit>0.25){
    c.save();c.globalAlpha=Math.min(1,(sit-0.25)/0.4);
    // подлокотник крепится К СИДЕНЬЮ: стойка идёт от кромки сиденья вверх,
    // иначе накладка висела в воздухе слева от кресла
    c.fillStyle='#1d262c';c.fillRect(CX-sw2*0.46,seatY-h*0.052,w*0.008,h*0.056);
    c.fillStyle='#2a353d';c.fillRect(CX-sw2*0.52,seatY-h*0.062,sw2*0.46,h*0.013);
    c.fillStyle='rgba(160,186,196,.10)';c.fillRect(CX-sw2*0.52,seatY-h*0.062,sw2*0.46,2);
    c.restore();
   }
   // глаза: две точки в тени лица. Загораются медленно и ровно.
   if(eye>0.01){
    const ex=CX, ey=gy+h*0.030*sit-h*0.335*(sc/A.epiGuardScale(h*0.72))*0.72;
    for(const s2 of [-1,1]){
     const px=ex+s2*w*0.0125, py=ey;
     glow(c,px,py,w*0.045,'214,238,232',0.28*eye);
     c.fillStyle='rgba(226,244,238,'+(0.85*eye).toFixed(3)+')';
     c.beginPath();c.ellipse(px,py,w*0.0042,w*0.0032,0,0,Math.PI*2);c.fill();
    }
   }
   // кадр гаснет по краям — точка входа в коду
   const vg=c.createRadialGradient(CX,gy-h*0.20,w*0.16,w*0.5,h*0.52,w*0.76);
   vg.addColorStop(0,'rgba(0,0,0,0)');vg.addColorStop(1,'rgba(0,0,0,'+(0.62+0.24*eye).toFixed(3)+')');
   c.fillStyle=vg;c.fillRect(0,0,w,h);
   c.restore();
   cut(c,w,h,tc,0.4);
   fadeOut(c,w,h,t,DUR-0.9,0.9);
  }

  A.epiBars(c,w,h,1);
  A.epiGrade(c,w,h,t,low,'rgba(8,14,20,.16)',0.42,1.0);
  // A.epiCard(c,w,h,t,DUR-2.3,2.0,'ЕЩЁ ОДИН КОСТЮМ','','#d8d2c4');
  A.epiSkipHint(c,w,h,t);
  c.restore();
  return true;
 }

 return {calm,burn,dark};
})();
