// V107: ГЛОБАЛЬНЫЙ ПЕРЕХВАТ ОШИБОК.
// ПОЧЕМУ ТАК БЫЛО: в сборке не было ни window.onerror, ни обработчика
// unhandledrejection. Любая единичная ошибка — заблокированный localStorage в
// iframe площадки, не подгрузившийся звук, отвалившийся вызов SDK — тихо
// обрывала выполнение и превращалась для модерации в «неизвестную ошибку»:
// понять причину со стороны было нельзя.
// СТАЛО: ошибки собираются в кольцевой буфер (последние 30), пишутся в консоль
// одним понятным префиксом и доступны как window.NS_ERRORS.list(). Требование
// 1.14 Яндекс Игр соблюдено: игроку НИЧЕГО не показывается — никаких
// технических сообщений на экране, игра продолжает работать.
// Файл подключается первым в index.html, чтобы ловить и ошибки остальных
// скриптов на этапе загрузки.
window.NS_ERRORS=(()=>{
  const MAX=30;
  const list=[];
  let count=0;

  function push(kind,msg,extra){
    count++;
    const rec={
      kind,
      msg:String(msg||'').slice(0,300),
      at:Math.round((performance?.now?.()||0)),
      ...extra
    };
    list.push(rec);
    if(list.length>MAX) list.shift();
    // Один аккуратный warn вместо падения: видно в консоли черновика и в
    // отчётах тестировщиков, но на игру не влияет.
    try{ console.warn('[NS]',kind,rec.msg,extra||''); }catch(e){}
  }

  try{
    addEventListener('error',ev=>{
      // Ошибки загрузки ресурсов (img/audio/script) приходят без message.
      const t=ev?.target;
      if(t && t!==window && (t.tagName==='IMG'||t.tagName==='AUDIO'||t.tagName==='SCRIPT'||t.tagName==='LINK')){
        push('resource',t.currentSrc||t.src||t.href||t.tagName,{tag:t.tagName});
        return;
      }
      push('error',ev?.message||ev?.error?.message,{
        src:ev?.filename?String(ev.filename).split('/').pop():undefined,
        line:ev?.lineno
      });
    },true);
  }catch(e){}

  try{
    addEventListener('unhandledrejection',ev=>{
      const r=ev?.reason;
      push('promise',r?.message||r);
    });
  }catch(e){}

  return {
    list:()=>list.slice(),
    count:()=>count,
    log:m=>push('note',m)
  };
})();
