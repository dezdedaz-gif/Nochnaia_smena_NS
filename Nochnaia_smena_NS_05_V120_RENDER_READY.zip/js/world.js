window.World=(()=>{
 const rooms=[
  {id:0,name:'Охрана',type:'office'},
  {id:1,name:'Пиццерия',type:'pizza'},
  {id:2,name:'Выход',type:'exit'},
  {id:3,name:'Склад',type:'storage'},
  {id:4,name:'Сцена',type:'stage'},
  {id:5,name:'Служебная',type:'service'},
  {id:6,name:'Коридор А',type:'corridorA'},
  {id:7,name:'Коридор Б',type:'corridorB'}
 ];
 function bg(ctx,W,H){ctx.fillStyle='#0a0d10';ctx.fillRect(0,0,W,H);ctx.fillStyle='#151b20';ctx.fillRect(0,H*.08,W,H*.55);ctx.fillStyle='#0e1317';ctx.fillRect(0,H*.63,W,H*.12);for(let i=0;i<12;i++){ctx.strokeStyle=i%2?'#202930':'#182025';ctx.beginPath();ctx.moveTo(W*i/12,H*.75);ctx.lineTo(W*.5,H*.63);ctx.stroke()}microTexture(ctx,W,H,3)}
 function microTexture(ctx,W,H,seed=1){
   // Dense procedural texture pass: seams, screws, panels, cables and dust.
   ctx.save();
   for(let i=0;i<96;i++){
     const x=((i*83+seed*31)%1000)/1000*W;
     const y=H*(.10+(((i*47+seed*17)%560)/1000));
     const w=4+((i*19)%18), h=1+((i*11)%4);
     ctx.fillStyle=i%7===0?'rgba(190,198,204,.10)':(i%3===0?'rgba(55,68,77,.18)':'rgba(12,16,20,.30)');
     ctx.fillRect(x,y,w,h);
     if(i%11===0){ctx.strokeStyle='rgba(82,94,102,.22)';ctx.strokeRect(x-3,y-3,w+6,h+6);}
   }
   ctx.strokeStyle='rgba(70,82,90,.22)';ctx.lineWidth=2;
   for(let i=0;i<8;i++){const yy=H*(.16+i*.065);ctx.beginPath();ctx.moveTo(0,yy);ctx.lineTo(W,yy);ctx.stroke();}
   ctx.restore();
 }
 function officeDetail(ctx,W,H,t){
   // Security-office dressing: panels, vents, cables, CRTs, warning labels, paperwork and hardware.
   ctx.save();
   ctx.fillStyle='#0b1014';ctx.fillRect(W*.30,H*.10,W*.40,H*.035);
   for(let i=0;i<12;i++){const x=W*(.30+i*.033);ctx.fillStyle=i%3?'#263038':'#12191e';ctx.fillRect(x,H*.10,2,H*.035);}
   // ceiling lamps
   for(let i=0;i<7;i++){const x=W*(.34+i*.055);ctx.fillStyle='#252d32';ctx.fillRect(x,H*.14,42,7);ctx.fillStyle=i%2?'#69706f':'#343a3d';ctx.fillRect(x+7,H*.145,28,3);}
   // upper equipment racks
   for(let i=0;i<5;i++){const x=W*(.32+i*.085),y=H*.22;ctx.fillStyle='#0a0f13';ctx.fillRect(x,y,64,46);ctx.strokeStyle='#39464e';ctx.strokeRect(x,y,64,46);ctx.fillStyle='#1b2a31';ctx.fillRect(x+7,y+8,50,13);ctx.fillStyle=i===2?'#d2a72b':'#3a505a';ctx.fillRect(x+10,y+28,8,4);ctx.fillRect(x+25,y+28,8,4);ctx.fillRect(x+40,y+28,8,4);}
   // wall cables
   ctx.strokeStyle='#26343c';ctx.lineWidth=4;for(let i=0;i<5;i++){ctx.beginPath();ctx.moveTo(W*(.31+i*.09),H*.30);ctx.bezierCurveTo(W*(.28+i*.09),H*.35,W*(.36+i*.08),H*.39,W*(.32+i*.09),H*.47);ctx.stroke();}
   // ventilation panels
   for(let i=0;i<3;i++){const x=W*(.39+i*.10),y=H*.36;ctx.fillStyle='#0a0f12';ctx.fillRect(x,y,58,36);ctx.strokeStyle='#46535b';ctx.strokeRect(x,y,58,36);for(let j=0;j<5;j++){ctx.strokeStyle='#2b363d';ctx.beginPath();ctx.moveTo(x+8,y+8+j*5);ctx.lineTo(x+50,y+8+j*5);ctx.stroke();}}
   // warning signs and small labels
   const signs=[['ОХРАНА',.31,.45],['НЕ ВХОДИТЬ',.62,.43],['NS-04',.50,.34],['ПИТАНИЕ',.40,.45]];
   signs.forEach((q,i)=>{const x=W*q[1],y=H*q[2];ctx.fillStyle=i%2?'#31251b':'#252b2f';ctx.fillRect(x,y,70,22);ctx.strokeStyle='#5b4b2c';ctx.strokeRect(x,y,70,22);text2(ctx,q[0],x+35,y+14,7,i%2?'#d2ad50':'#88939a','center');});
   // desk paperwork, mug, keyboard and control boxes
   // V98: журнал и клавиатура раньше рисовались ЗДЕСЬ, но сразу после
   // officeDetail вся стена и стол перекрываются непрозрачным прямоугольником
   // (0.10h..0.63h) — предметы были не видны ни на одном кадре. Оба предмета
   // перенесены в officeProps, который рисуется поверх.
   ctx.fillStyle='#171b1d';ctx.beginPath();ctx.arc(W*.67,H*.58,11,0,Math.PI*2);ctx.fill();ctx.strokeStyle='#657077';ctx.stroke();
   // floor cables and screw points
   ctx.strokeStyle='#202c33';ctx.lineWidth=3;for(let i=0;i<7;i++){ctx.beginPath();ctx.moveTo(W*(.28+i*.07),H*.63);ctx.bezierCurveTo(W*(.31+i*.06),H*.68,W*(.25+i*.08),H*.72,W*(.20+i*.10),H*.78);ctx.stroke();}
   for(let i=0;i<36;i++){const x=W*(.04+((i*37)%92)/100),y=H*(.64+((i*17)%30)/100);ctx.fillStyle='rgba(180,190,196,.15)';ctx.fillRect(x,y,2,2);}
   ctx.restore();
 }
 function drawVentTunnel(ctx,W,H,t){
   // Large upper-wall ventilation TUNNEL: recessed duct receding into the wall, metal grille, red warning light, drifting shadow/dust.
   ctx.save();
   const x=W*0.345, y=H*0.082, w=W*0.31, h=H*0.072;
   const cx=x+w/2, cy=y+h/2;
   const low=document.body.classList.contains('low-end');
   // soft volumetric shadow cast below the duct on the wall
   const sh=ctx.createLinearGradient(0,y+h,0,y+h+H*0.045);sh.addColorStop(0,'rgba(0,0,0,.50)');sh.addColorStop(1,'rgba(0,0,0,0)');ctx.fillStyle=sh;ctx.fillRect(x-H*0.02,y+h,w+H*0.04,H*0.05);
   // outer metal frame with bevel gradient
   const fr=ctx.createLinearGradient(x,y,x,y+h);fr.addColorStop(0,'#454f57');fr.addColorStop(.5,'#2b343b');fr.addColorStop(1,'#1b2127');
   ctx.fillStyle=fr;ctx.fillRect(x-8,y-8,w+16,h+16);
   ctx.strokeStyle='#5b6770';ctx.lineWidth=2;ctx.strokeRect(x-8,y-8,w+16,h+16);
   ctx.fillStyle='rgba(255,255,255,.06)';ctx.fillRect(x-8,y-8,w+16,3);ctx.fillStyle='rgba(0,0,0,.25)';ctx.fillRect(x-8,y+h+5,w+16,3);
   // recessed dark opening
   ctx.fillStyle='#05080a';ctx.fillRect(x,y,w,h);
   // perspective depth: back opening smaller + converging side/top/bottom walls
   const back=0.42, bx=x+w*(1-back)/2, bw=w*back, by=y+h*(1-back)/2, bh=h*back;
   ctx.fillStyle='#0c1318';
   ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x+w,y);ctx.lineTo(bx+bw,by);ctx.lineTo(bx,by);ctx.closePath();ctx.fill();
   ctx.beginPath();ctx.moveTo(x,y+h);ctx.lineTo(x+w,y+h);ctx.lineTo(bx+bw,by+bh);ctx.lineTo(bx,by+bh);ctx.closePath();ctx.fill();
   ctx.fillStyle='#070b0e';
   ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x,y+h);ctx.lineTo(bx,by+bh);ctx.lineTo(bx,by);ctx.closePath();ctx.fill();
   ctx.beginPath();ctx.moveTo(x+w,y);ctx.lineTo(x+w,y+h);ctx.lineTo(bx+bw,by+bh);ctx.lineTo(bx+bw,by);ctx.closePath();ctx.fill();
   // deep back opening (darkest) with faint red emergency glow
   const flick=0.55+0.45*Math.abs(Math.sin(t*7.0));
   const glow=ctx.createRadialGradient(bx+bw/2,by+bh/2,1,bx+bw/2,by+bh/2,bw*0.7);
   glow.addColorStop(0,`rgba(190,40,40,${0.5*flick})`);glow.addColorStop(.5,`rgba(120,25,25,${0.22*flick})`);glow.addColorStop(1,'rgba(40,8,8,0)');
   ctx.fillStyle='#020405';ctx.fillRect(bx,by,bw,bh);ctx.fillStyle=glow;ctx.fillRect(bx,by,bw,bh);
   // drifting shadow puff travelling through the duct
   const tp=(t*0.22)%1, dp=tp, sxp=bx+bw*0.5+(x+w*0.5-(bx+bw*0.5))*(1-dp); // front->back
   const syp=cy+(dp-0.5)*2*0; ctx.globalAlpha=0.35+0.25*Math.sin(t*3);ctx.fillStyle='rgba(0,0,0,.5)';
   const puffScale=0.4+0.6*(1-dp);ctx.beginPath();ctx.ellipse(sxp,cy,bw*0.5*puffScale,bh*0.7*puffScale,0,0,Math.PI*2);ctx.fill();ctx.globalAlpha=1;
   // front grille: horizontal slats with metallic shading + thin gaps so depth reads through
   const slats=5;
   for(let i=0;i<slats;i++){const gy=y+h*(i+0.5)/slats;
     const sg=ctx.createLinearGradient(0,gy-3,0,gy+3);sg.addColorStop(0,'#5a666e');sg.addColorStop(.5,'#333d44');sg.addColorStop(1,'#1d252b');
     ctx.fillStyle=sg;ctx.fillRect(x,gy-2,w,3.2);
     ctx.fillStyle='rgba(0,0,0,.55)';ctx.fillRect(x,gy+1,w,1.5);
     ctx.fillStyle='rgba(255,255,255,.10)';ctx.fillRect(x,gy-2,w,1);}
   // vertical grille bars
   for(let i=0;i<4;i++){const gx=x+w*(i+0.5)/4;ctx.fillStyle='rgba(60,72,80,.6)';ctx.fillRect(gx-1,y,2,h);}
   // corner bolts
   const bolts=[[x-3,y-3],[x+w+3,y-3],[x-3,y+h+3],[x+w+3,y+h+3]];
   bolts.forEach(b=>{ctx.fillStyle='#1a2026';ctx.beginPath();ctx.arc(b[0],b[1],2.6,0,Math.PI*2);ctx.fill();ctx.fillStyle='#6a7680';ctx.beginPath();ctx.arc(b[0]-0.6,b[1]-0.6,1.1,0,Math.PI*2);ctx.fill();});
   // floating dust near the grille
   if(!low){for(let i=0;i<10;i++){const dx=x+w*((i*53+t*9)%100)/100,dy=y+h*0.5+Math.sin(t*1.3+i)*h*0.3;ctx.globalAlpha=.12+0.12*Math.abs(Math.sin(t*2+i));ctx.fillStyle='#aebcc2';ctx.fillRect(dx,dy,1.4,1.4);}ctx.globalAlpha=1;}
   // label
   
   ctx.restore();
 }
 function cameraDecor(ctx,x,y,s=1){ctx.save();ctx.translate(x,y);ctx.scale(s,s);ctx.fillStyle='#0b1014';ctx.fillRect(-20,-12,40,22);ctx.strokeStyle='#3b454d';ctx.lineWidth=2;ctx.strokeRect(-20,-12,40,22);ctx.fillStyle='#212b31';ctx.fillRect(-12,-7,23,11);ctx.fillStyle='#bc2a36';ctx.fillRect(8,-3,4,6);ctx.fillStyle='#161b20';ctx.beginPath();ctx.moveTo(-3,10);ctx.lineTo(0,24);ctx.lineTo(4,24);ctx.lineTo(2,10);ctx.closePath();ctx.fill();ctx.restore()}
function floorDecor(ctx,x,y,s=1,type='crate'){
 ctx.save();ctx.translate(x,y);ctx.scale(s,s);
 ctx.lineWidth=2;ctx.strokeStyle='#344149';ctx.fillStyle='#141b20';
 if(type==='crate'){
   ctx.fillRect(-22,-16,44,32);ctx.strokeRect(-22,-16,44,32);ctx.strokeStyle='#56636b';ctx.beginPath();ctx.moveTo(-18,-12);ctx.lineTo(18,12);ctx.moveTo(18,-12);ctx.lineTo(-18,12);ctx.stroke();
 }else if(type==='barrel'){
   ctx.beginPath();ctx.ellipse(0,-7,17,7,0,0,Math.PI*2);ctx.fill();ctx.stroke();ctx.fillRect(-17,-7,34,28);ctx.strokeRect(-17,-7,34,28);ctx.beginPath();ctx.ellipse(0,21,17,7,0,0,Math.PI*2);ctx.stroke();ctx.fillStyle='#7f2831';ctx.fillRect(-12,3,24,5);
 }else if(type==='cone'){
   ctx.fillStyle='#a23a2f';ctx.beginPath();ctx.moveTo(0,-28);ctx.lineTo(15,20);ctx.lineTo(-15,20);ctx.closePath();ctx.fill();ctx.stroke();ctx.fillStyle='#d0b44c';ctx.fillRect(-10,-2,20,6);ctx.fillStyle='#222a2e';ctx.fillRect(-20,20,40,7);ctx.strokeRect(-20,20,40,7);
 }else if(type==='toy'){
   ctx.fillStyle='#272d31';ctx.beginPath();ctx.arc(0,-8,15,0,Math.PI*2);ctx.fill();ctx.stroke();ctx.fillStyle='#c22635';ctx.fillRect(-9,-4,18,7);ctx.fillStyle='#0a0d10';ctx.fillRect(-6,4,4,4);ctx.fillRect(2,4,4,4);
 }else if(type==='bin'){
   ctx.fillStyle='#253036';ctx.fillRect(-18,-18,36,38);ctx.strokeRect(-18,-18,36,38);ctx.fillStyle='#4c5960';ctx.fillRect(-12,-24,24,7);ctx.fillStyle='#5b242b';ctx.fillRect(-8,-6,16,8);
 }
 ctx.restore();
}

 // ===== ОБЩАЯ ОБОЛОЧКА КОМНАТЫ =====
 // Потолок, задняя стена с панелями, плинтус, перспективный пол, потолочные лампы
 // и мягкая вигнетка. Возвращает геометрию, к которой привязываются декорации.
 // ============ V81: КЭШ СТАТИЧНОГО ФОНА КОМНАТЫ ============
 // Стены, пол, панели, плитка и микротекстура не меняются от кадра к кадру, но
 // раньше пересчитывались 60 раз в секунду: 3 градиента, 16 панелей, 70 плиток
 // и 96 пятен текстуры на КАЖДЫЙ кадр каждой камеры. Теперь это рисуется один
 // раз в закадровый холст и дальше просто копируется одним вызовом.
 const _shellCache=new Map();
 function shellStatic(W,H,o,hz,vpX,paint){
   const key=W+'x'+H+'|'+(window.I18N?.lang||'ru')+'|'+(o.seed||0)+'|'+(o.horizon||0.42)+'|'+(o.vpX||0.5)+'|'+
     (o.ceil||'')+(o.wall?o.wall.join(''):'')+(o.wainscot||'')+
     (o.floorFar||'')+(o.floorNear||'')+(o.checker?'C'+(o.tileA||'')+(o.tileB||''):'G');
   let cv=_shellCache.get(key);
   if(!cv){
     cv=document.createElement('canvas');cv.width=Math.max(1,W|0);cv.height=Math.max(1,H|0);
     paint(cv.getContext('2d'));
     if(_shellCache.size>14)_shellCache.clear();   // не даём кэшу расти без предела
     _shellCache.set(key,cv);
   }
   return cv;
 }
 // ============ V81: АТМОСФЕРА КОМНАТЫ ============
 // Объёмный свет из-под плафонов, пылинки в луче, блик на полу, дымка у
 // горизонта и паутина по углам. Раньше комнаты были геометрически честными,
 // но воздуха в них не было: свет заканчивался на лампе, пол был матовым
 // листом, а глубина читалась только по линиям разметки.
 function roomAtmos(ctx,W,H,t,o,hz,vpX){
   const tier=(window.__PERF&&window.__PERF.tier)||0;
   const lamps=o.lamps===undefined?3:o.lamps;
   const warm=o.warm||[255,226,160];
   const wc=warm[0]+','+warm[1]+','+warm[2];
   // источники света для пылинок: потолочные плафоны, а если их нет —
   // собственные лампы комнаты (склад, сцена), переданные через o.atmosX
   const lxs=[];
   if(lamps>0){for(let i=0;i<lamps;i++)lxs.push(W*((i+1)/(lamps+1)));}
   else if(o.atmosX){o.atmosX.forEach(v=>lxs.push(W*v));}
   // --- дымка у горизонта: воздух в глубине комнаты не идеально прозрачный
   const hazeA=(o.haze===undefined?0.05:o.haze);
   if(hazeA>0){
     const hg=ctx.createLinearGradient(0,hz-H*0.16,0,hz+H*0.10);
     hg.addColorStop(0,'rgba(150,168,186,0)');
     hg.addColorStop(0.55,'rgba(150,168,186,'+hazeA.toFixed(3)+')');
     hg.addColorStop(1,'rgba(150,168,186,0)');
     ctx.fillStyle=hg;ctx.fillRect(0,hz-H*0.16,W,H*0.26);
   }
   for(let i=0;i<lamps;i++){
     const lx=W*((i+1)/(lamps+1)), ly=hz*0.13+6;
     const fl=o.flicker?(0.55+0.45*Math.abs(Math.sin(t*(5+i)+i))):(0.94+0.06*Math.sin(t*0.9+i));
     // --- объёмный конус света: трапеция от плафона к полу
     ctx.save();ctx.globalCompositeOperation='lighter';
     const cone=ctx.createLinearGradient(0,ly,0,H*0.92);
     cone.addColorStop(0,'rgba('+wc+','+(0.075*fl).toFixed(4)+')');
     cone.addColorStop(0.55,'rgba('+wc+','+(0.030*fl).toFixed(4)+')');
     cone.addColorStop(1,'rgba('+wc+',0)');
     ctx.fillStyle=cone;ctx.beginPath();
     ctx.moveTo(lx-W*0.055,ly);ctx.lineTo(lx+W*0.055,ly);
     ctx.lineTo(lx+W*0.175,H*0.92);ctx.lineTo(lx-W*0.175,H*0.92);
     ctx.closePath();ctx.fill();ctx.restore();
     // --- световое пятно на полу под лампой + его отражение (пол не матовый)
     ctx.save();ctx.globalCompositeOperation='lighter';
     const py=hz+(H-hz)*0.52;
     const pg=ctx.createRadialGradient(lx,py,4,lx,py,W*0.20);
     // V110: блик на полу под лампой теперь тоже слушается настроек СВЕТ/ОТРАЖЕНИЯ.
     pg.addColorStop(0,'rgba('+wc+','+(0.085*fl*(window.GFX?.light??1)*(0.35+0.65*(window.GFX?.reflect??1))).toFixed(4)+')');
     pg.addColorStop(1,'rgba('+wc+',0)');
     ctx.fillStyle=pg;ctx.save();ctx.translate(lx,py);ctx.scale(1,0.34);
     ctx.translate(-lx,-py);ctx.fillRect(lx-W*0.20,py-W*0.20,W*0.40,W*0.40);ctx.restore();
     ctx.restore();
   }
   // --- пылинки: висят в воздухе, медленно сносит вбок, ярче внутри луча
   if(tier<2&&lxs.length>0&&(o.dust===undefined?true:o.dust)){
     const n=tier>=1?18:34;
     ctx.save();ctx.globalCompositeOperation='lighter';
     for(let i=0;i<n;i++){
       const sd=i*2.399963;                        // золотой угол — ровное рассеивание
       const bx=((i*137+29)%1000)/1000;
       const drift=Math.sin(t*0.21+sd)*0.055+Math.sin(t*0.07+sd*2.1)*0.03;
       const x=W*(((bx+drift)%1+1)%1);
       const y0=((i*61+13)%1000)/1000;
       const fall=((y0+t*0.017*(0.6+((i%5)/5)))%1);
       const y=hz*0.16+ (H*0.86-hz*0.16)*fall;
       // яркость: близко к оси лампы пылинка ловит свет, вне луча почти невидима
       let lit=0;
       for(let j=0;j<lxs.length;j++){
         const dx=Math.abs(x-lxs[j])/(W*0.13);
         if(dx<1.6)lit=Math.max(lit,1-dx/1.6);
       }
       const a=(0.05+0.30*lit)*(0.55+0.45*Math.sin(t*1.7+sd*3.3));
       if(a<=0.012)continue;
       const r=(i%7===0?1.7:1.05)*(0.7+0.5*lit);
       ctx.fillStyle='rgba('+wc+','+a.toFixed(3)+')';
       ctx.fillRect(x,y,r,r);
     }
     ctx.restore();
   }
   // --- паутина по верхним углам кадра
   if(tier<2&&(o.web===undefined?true:o.web)){
     ctx.save();ctx.strokeStyle='rgba(196,206,214,.055)';ctx.lineWidth=1;
     for(let s0=0;s0<2;s0++){
       const sx=s0?W:0, dir=s0?-1:1, R=Math.min(W,H)*0.14;
       for(let k=1;k<=4;k++){
         ctx.beginPath();ctx.arc(sx,0,R*k/4,0,Math.PI*0.5*(s0?1:1));
         ctx.stroke();
       }
       for(let k=0;k<=4;k++){
         const a0=Math.PI*0.5*k/4;
         ctx.beginPath();ctx.moveTo(sx,0);
         ctx.lineTo(sx+dir*Math.cos(a0)*R,Math.sin(a0)*R);ctx.stroke();
       }
     }
     ctx.restore();
   }
 }
 function roomShell(ctx,W,H,t,o){
   o=o||{};
   const hz=H*(o.horizon||0.42);              // линия стыка задней стены и пола
   const vpX=W*(o.vpX||0.50), vpY=hz-H*0.015; // точка схода
   const cached=shellStatic(W,H,o,hz,vpX,ctx=>{
   // потолок
   const cg=ctx.createLinearGradient(0,0,0,hz*0.55);
   cg.addColorStop(0,'#04070a');cg.addColorStop(1,o.ceil||'#101820');
   ctx.fillStyle=cg;ctx.fillRect(0,0,W,hz*0.30);
   // потолочные балки в перспективу
   ctx.strokeStyle='rgba(120,140,155,.07)';ctx.lineWidth=2;
   for(let i=0;i<7;i++){const x=W*(i/6);ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(vpX+(x-vpX)*0.30,hz*0.30);ctx.stroke();}
   // задняя стена
   const wg=ctx.createLinearGradient(0,hz*0.16,0,hz);
   wg.addColorStop(0,(o.wall&&o.wall[0])||'#1a232a');wg.addColorStop(1,(o.wall&&o.wall[1])||'#101821');
   ctx.fillStyle=wg;ctx.fillRect(0,hz*0.22,W,hz*0.80);
   // вертикальные панели + стыки
   for(let i=0;i<16;i++){ctx.fillStyle=i%2?'rgba(255,255,255,.014)':'rgba(0,0,0,.12)';ctx.fillRect(W*i/16,hz*0.22,W/16-1,hz*0.80);}
   // нижняя тёмная панель (вагонка) и молдинг
   ctx.fillStyle=o.wainscot||'#0e151a';ctx.fillRect(0,hz*0.70,W,hz*0.32);
   ctx.fillStyle='rgba(255,255,255,.055)';ctx.fillRect(0,hz*0.70,W,2);
   ctx.fillStyle='rgba(0,0,0,.35)';ctx.fillRect(0,hz-4,W,4);
   // пол
   const fg=ctx.createLinearGradient(0,hz,0,H);
   fg.addColorStop(0,o.floorFar||'#151d23');fg.addColorStop(1,o.floorNear||'#080c0f');
   ctx.fillStyle=fg;ctx.fillRect(0,hz,W,H-hz);
   // перспективная разметка пола
   if(o.checker){
     // шахматная плитка (зал): чередование по глубине и ширине
     const rows=7;
     for(let r=0;r<rows;r++){
       const k0=Math.pow(r/rows,1.6), k1=Math.pow((r+1)/rows,1.6);
       const y0=hz+(H-hz)*k0, y1=hz+(H-hz)*k1;
       const sp0=0.10+0.90*k0, sp1=0.10+0.90*k1; // расширение к зрителю
       for(let c=0;c<10;c++){
         const a0=(c/10-0.5), a1=((c+1)/10-0.5);
         const x00=vpX+a0*W*sp0, x01=vpX+a1*W*sp0, x10=vpX+a0*W*sp1, x11=vpX+a1*W*sp1;
         ctx.fillStyle=((r+c)%2)?(o.tileA||'#2a1b1e'):(o.tileB||'#141a1e');
         ctx.beginPath();ctx.moveTo(x00,y0);ctx.lineTo(x01,y0);ctx.lineTo(x11,y1);ctx.lineTo(x10,y1);ctx.closePath();ctx.fill();
       }
     }
   } else {
     ctx.strokeStyle='rgba(90,110,125,.13)';ctx.lineWidth=1;
     for(let i=0;i<=12;i++){const x=W*(i/12);ctx.beginPath();ctx.moveTo(x,H);ctx.lineTo(vpX+(x-vpX)*0.12,hz);ctx.stroke();}
     for(let r=1;r<8;r++){const k=Math.pow(r/8,1.7),y=hz+(H-hz)*k;ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(W,y);ctx.stroke();}
   }
   // корпуса потолочных светильников (статика; свет добавляется поверх кэша)
   {const lampsN=o.lamps===undefined?3:o.lamps;
    for(let i=0;i<lampsN;i++){
      const lx=W*((i+1)/(lampsN+1)), ly=hz*0.13, lw=W*0.13, lh=6;
      ctx.fillStyle='#242c31';ctx.fillRect(lx-lw/2,ly,lw,lh);
      // V81: подвес и рефлектор — плафон больше не висит в пустоте
      ctx.fillStyle='#1b2227';ctx.fillRect(lx-1,0,2,ly);
      ctx.fillStyle='rgba(255,255,255,.05)';ctx.fillRect(lx-lw/2,ly,lw,1);
    }}
   microTexture(ctx,W,H,o.seed||2);
   });
   ctx.drawImage(cached,0,0);
   // --- динамика: мигание плафонов и свечение (кэшировать нельзя)
   const lamps=o.lamps===undefined?3:o.lamps;
   const warm=o.warm||[255,226,160];
   for(let i=0;i<lamps;i++){
     const lx=W*((i+1)/(lamps+1)), ly=hz*0.13, lw=W*0.13, lh=6;
     const fl=o.flicker?(0.55+0.45*Math.abs(Math.sin(t*(5+i)+i))):1;
     ctx.fillStyle=`rgba(${warm[0]},${warm[1]},${warm[2]},${0.55*fl})`;ctx.fillRect(lx-lw/2+2,ly+lh,lw-4,3);
     const gl=ctx.createRadialGradient(lx,ly+lh,2,lx,ly+lh,H*0.34);
     gl.addColorStop(0,`rgba(${warm[0]},${warm[1]},${warm[2]},${0.13*fl})`);gl.addColorStop(1,'rgba(0,0,0,0)');
     ctx.save();ctx.globalCompositeOperation='lighter';ctx.fillStyle=gl;ctx.fillRect(lx-H*0.34,ly,H*0.68,H*0.75);ctx.restore();
   }
   roomAtmos(ctx,W,H,t,o,hz,vpX);
   return {hz,vpX,vpY};
 }
 // Мягкое затемнение краёв кадра — общее для всех камер.
 function roomVignette(ctx,W,H,strength){
   const g=ctx.createRadialGradient(W*0.5,H*0.52,Math.min(W,H)*0.22,W*0.5,H*0.52,Math.max(W,H)*0.72);
   g.addColorStop(0,'rgba(0,0,0,0)');g.addColorStop(1,`rgba(0,0,0,${strength===undefined?0.62:strength})`);
   ctx.fillStyle=g;ctx.fillRect(0,0,W,H);
 }
 // Подпись комнаты в стиле CCTV.
 function roomLabel(ctx,W,H,cam,name){
  // V63: номер и название камеры теперь выводит интерфейс монитора (drawCamHUD),
  // внутри самого сигнала подпись больше не рисуется.
  return;
   // подпись в левом верхнем углу кадра, чтобы не перекрывать вывески и таблички
   const lx0=W*0.025, ly0=H*0.020, lw0=196, lh0=26;
   ctx.fillStyle='rgba(4,6,8,.74)';ctx.fillRect(lx0,ly0,lw0,lh0);
   ctx.strokeStyle='rgba(120,140,155,.22)';ctx.lineWidth=1;ctx.strokeRect(lx0,ly0,lw0,lh0);
   ctx.fillStyle='rgba(220,60,70,.85)';ctx.beginPath();ctx.arc(lx0+15,ly0+lh0/2,5,0,Math.PI*2);ctx.fill();
   text2(ctx,cam+'  '+name,lx0+28,ly0+18,15,'#dfe6ea','left');
 }
 // Столик с праздничной сервировкой (зал).
 function partyTable(ctx,x,y,s,seed){
   ctx.save();ctx.translate(x,y);ctx.scale(s,s);
   ctx.fillStyle='rgba(0,0,0,.45)';ctx.beginPath();ctx.ellipse(0,8,74,17,0,0,Math.PI*2);ctx.fill();
   // V70: нормальные стулья — два по бокам, один спиной к камере, один отодвинут.
   for(let i=-1;i<=1;i+=2){
     ctx.fillStyle='#2a3238';ctx.fillRect(i*60-12,-18,24,26);            // сиденье
     ctx.fillStyle='#20272c';ctx.fillRect(i*60-12,-44,24,24);            // спинка
     ctx.fillStyle='#171d21';ctx.fillRect(i*60-11,8,4,14);ctx.fillRect(i*60+7,8,4,14);
   }
   ctx.fillStyle='#232a30';ctx.fillRect(-16,-6,32,16);ctx.fillStyle='#1a2025';ctx.fillRect(-16,-30,32,22);
   ctx.save();ctx.translate(30,26);ctx.rotate(0.22);                      // отодвинутый стул
   ctx.fillStyle='#262e34';ctx.fillRect(-13,-10,26,14);ctx.fillStyle='#1c2328';ctx.fillRect(-13,-30,26,20);ctx.restore();
   // столешница
   // V98: верх был двумя плоскими алыми эллипсами — на общем плане столы
   // читались как красные пятна. Стало: приглушённый цвет, радиальная
   // подсветка от подвесной лампы и тёмный край.
   ctx.fillStyle='#5c1f26';ctx.beginPath();ctx.ellipse(0,-18,72,23,0,0,Math.PI*2);ctx.fill();
   ctx.fillStyle='#782c34';ctx.beginPath();ctx.ellipse(0,-22,72,23,0,0,Math.PI*2);ctx.fill();
   const topG=ctx.createRadialGradient(-14,-28,4,0,-22,74);
   topG.addColorStop(0,'rgba(255,214,168,.16)');topG.addColorStop(.55,'rgba(255,190,140,.05)');topG.addColorStop(1,'rgba(0,0,0,.30)');
   ctx.fillStyle=topG;ctx.beginPath();ctx.ellipse(0,-22,72,23,0,0,Math.PI*2);ctx.fill();
   ctx.strokeStyle='rgba(0,0,0,.35)';ctx.lineWidth=2;ctx.beginPath();ctx.ellipse(0,-22,72,23,0,0,Math.PI*2);ctx.stroke();
   ctx.fillStyle='#5d1f26';ctx.fillRect(-8,-20,16,34);
   ctx.fillStyle='#3a1418';ctx.beginPath();ctx.ellipse(0,14,26,8,0,0,Math.PI*2);ctx.fill();
   // бумажная скатерть по краю
   ctx.fillStyle='rgba(214,206,190,.10)';ctx.beginPath();ctx.ellipse(0,-16,74,24,0,0,Math.PI*2);ctx.fill();
   // тарелки, стаканы, колпак
   // V98: посуда была набором ярко-белых эллипсов и прямоугольников — рядом друг
   // с другом они сливались в белые закорючки. Стало: у тарелки тень, борт и
   // бортовой блик; стаканчик сужается к низу, у него овальный венчик, тень и
   // блик; колпак получил основание, полосы и помпон.
   [[-38,-24,13],[-8,-27,12],[26,-25,12],[50,-22,11]].forEach(pp=>{
     ctx.fillStyle='rgba(0,0,0,.40)';ctx.beginPath();ctx.ellipse(pp[0]+1.5,pp[1]+2.5,pp[2],pp[2]*0.42,0,0,Math.PI*2);ctx.fill();
     ctx.fillStyle='#9aa2a7';ctx.beginPath();ctx.ellipse(pp[0],pp[1],pp[2],pp[2]*0.42,0,0,Math.PI*2);ctx.fill();
     ctx.fillStyle='#b7bfc4';ctx.beginPath();ctx.ellipse(pp[0],pp[1]-1,pp[2]*0.74,pp[2]*0.30,0,0,Math.PI*2);ctx.fill();
     ctx.strokeStyle='rgba(20,24,26,.45)';ctx.lineWidth=1;ctx.beginPath();ctx.ellipse(pp[0],pp[1],pp[2],pp[2]*0.42,0,0,Math.PI*2);ctx.stroke();
     ctx.fillStyle='rgba(255,236,205,.18)';ctx.beginPath();ctx.ellipse(pp[0]-pp[2]*.35,pp[1]-pp[2]*.16,pp[2]*.28,pp[2]*.10,0,0,Math.PI*2);ctx.fill();
   });
   ctx.fillStyle='rgba(60,20,24,.55)';ctx.beginPath();ctx.ellipse(-8,-27,6,2.6,0,0,Math.PI*2);ctx.fill();  // засохший кусок
   [[-18,-25,8,13],[15.5,-25,7,12],[43.5,-24,7,11]].forEach(cu=>{
     const cx3=cu[0],cy3=cu[1],cw3=cu[2],ch3=cu[3];
     ctx.fillStyle='rgba(0,0,0,.35)';ctx.beginPath();ctx.ellipse(cx3+2,cy3+1.5,cw3*.55,cw3*.24,0,0,Math.PI*2);ctx.fill();
     ctx.fillStyle='#a8b0b5';ctx.beginPath();
     ctx.moveTo(cx3-cw3*.5,cy3-ch3);ctx.lineTo(cx3+cw3*.5,cy3-ch3);
     ctx.lineTo(cx3+cw3*.34,cy3);ctx.lineTo(cx3-cw3*.34,cy3);ctx.closePath();ctx.fill();
     ctx.fillStyle='rgba(255,255,255,.16)';ctx.fillRect(cx3-cw3*.44,cy3-ch3+1,cw3*.20,ch3-2);
     ctx.fillStyle='#c3cbd0';ctx.beginPath();ctx.ellipse(cx3,cy3-ch3,cw3*.5,cw3*.19,0,0,Math.PI*2);ctx.fill();
     ctx.fillStyle='#6f2b30';ctx.beginPath();ctx.ellipse(cx3,cy3-ch3+.6,cw3*.38,cw3*.13,0,0,Math.PI*2);ctx.fill();
   });
   if(seed%2===0){
     ctx.fillStyle='rgba(0,0,0,.35)';ctx.beginPath();ctx.ellipse(53,-24,10,3.4,0,0,Math.PI*2);ctx.fill();
     ctx.fillStyle='#c8a02c';ctx.beginPath();ctx.moveTo(44,-26);ctx.lineTo(52,-49);ctx.lineTo(60,-26);ctx.closePath();ctx.fill();
     ctx.fillStyle='rgba(255,255,255,.16)';ctx.beginPath();ctx.moveTo(50,-30);ctx.lineTo(52,-49);ctx.lineTo(54,-30);ctx.closePath();ctx.fill();
     ctx.fillStyle='#8d2f36';[0,1,2].forEach(k=>{const yy=-31+k*2.6,hw=2.4+k*2.0;ctx.fillRect(52-hw,yy,hw*2,1.6);});
     ctx.fillStyle='#e2dcc6';ctx.beginPath();ctx.arc(52,-50.5,2.2,0,Math.PI*2);ctx.fill();
     ctx.fillStyle='#a8842a';ctx.beginPath();ctx.ellipse(52,-25.5,9,2.6,0,0,Math.PI*2);ctx.fill();
   }
   else {
     // V99: подарок был двумя плоскими квадратами — на камере читался как бежевая
     // заплатка, лежащая на столе. Стало: коробка с тремя гранями, лентой и бантом.
     const gx=-48, gy=-26, gw=17, gh=13, gd=6;   // основание, ширина, высота, глубина
     ctx.fillStyle='rgba(0,0,0,.40)';
     ctx.beginPath();ctx.ellipse(gx+1.5,gy+2,gw*0.62,4,0,0,Math.PI*2);ctx.fill();
     ctx.fillStyle='#7c2a31';ctx.fillRect(gx-gw/2,gy-gh,gw,gh);                       // лицевая грань
     ctx.fillStyle='#5a1c22';ctx.beginPath();                                          // боковая грань
     ctx.moveTo(gx+gw/2,gy-gh);ctx.lineTo(gx+gw/2+gd,gy-gh-gd*0.7);
     ctx.lineTo(gx+gw/2+gd,gy-gd*0.7);ctx.lineTo(gx+gw/2,gy);ctx.closePath();ctx.fill();
     ctx.fillStyle='#93343c';ctx.beginPath();                                          // крышка
     ctx.moveTo(gx-gw/2,gy-gh);ctx.lineTo(gx+gw/2,gy-gh);
     ctx.lineTo(gx+gw/2+gd,gy-gh-gd*0.7);ctx.lineTo(gx-gw/2+gd,gy-gh-gd*0.7);ctx.closePath();ctx.fill();
     ctx.fillStyle='#cfc5a4';                                                          // лента
     ctx.fillRect(gx-1.4,gy-gh,2.8,gh);
     ctx.beginPath();ctx.moveTo(gx-1.4,gy-gh);ctx.lineTo(gx+1.4,gy-gh);
     ctx.lineTo(gx+1.4+gd,gy-gh-gd*0.7);ctx.lineTo(gx-1.4+gd,gy-gh-gd*0.7);ctx.closePath();ctx.fill();
     ctx.fillStyle='rgba(0,0,0,.28)';ctx.fillRect(gx-gw/2,gy-2,gw,2);
     ctx.fillStyle='#e0d7b6';                                                          // бант
     ctx.beginPath();ctx.ellipse(gx+gd*0.5-2.2,gy-gh-gd*0.7,2.6,1.6,-0.4,0,Math.PI*2);ctx.fill();
     ctx.beginPath();ctx.ellipse(gx+gd*0.5+1.4,gy-gh-gd*0.7-0.6,2.4,1.5,0.4,0,Math.PI*2);ctx.fill();
     ctx.fillStyle='rgba(255,240,210,.16)';ctx.fillRect(gx-gw/2,gy-gh,gw,1.4);
   }
   ctx.restore();
 }
 // Гирлянда из флажков.
 function garland(ctx,x0,x1,y,sag,n,t){
   ctx.strokeStyle='rgba(180,195,205,.22)';ctx.lineWidth=2;
   ctx.beginPath();ctx.moveTo(x0,y);ctx.quadraticCurveTo((x0+x1)/2,y+sag,x1,y);ctx.stroke();
   const cols=['#b6323f','#c8a02c','#2f7d8c','#8c5ab6'];
   for(let i=1;i<n;i++){
     const k=i/n, mx=(1-k)*(1-k)*x0+2*(1-k)*k*((x0+x1)/2)+k*k*x1;
     const my=(1-k)*(1-k)*y+2*(1-k)*k*(y+sag)+k*k*y;
     const sw=1+0.12*Math.sin(t*1.6+i);
     ctx.fillStyle=cols[i%4];ctx.beginPath();ctx.moveTo(mx-7*sw,my);ctx.lineTo(mx+7*sw,my);ctx.lineTo(mx,my+16);ctx.closePath();ctx.fill();
   }
 }
 // Тёплое световое пятно (аддитивное) — для лампочек, неона и световых лужиц на полу.
 function glowPool(ctx,x,y,rw,rh,col,a){
   // V110: сила световых пятен берётся из настройки СВЕТ. ПОЧЕМУ ТАК БЫЛО:
   // строка СВЕТ в настройках не читалась нигде и ничего не меняла.
   // СТАЛО: все лампы, неон и лужицы света идут через один множитель.
   a=a*(window.GFX?.light??1);
   ctx.save();ctx.globalCompositeOperation='lighter';ctx.translate(x,y);ctx.scale(1,Math.max(0.01,rh/rw));
   const g=ctx.createRadialGradient(0,0,1,0,0,rw);
   g.addColorStop(0,`rgba(${col},${a})`);g.addColorStop(.5,`rgba(${col},${a*0.34})`);g.addColorStop(1,`rgba(${col},0)`);
   ctx.fillStyle=g;ctx.beginPath();ctx.arc(0,0,rw,0,Math.PI*2);ctx.fill();ctx.restore();
 }
 // Неоновая трубка: яркое ядро + мягкое свечение вокруг.
 function neon(ctx,draw,col,w,glow,alpha){
   ctx.save();ctx.globalCompositeOperation='lighter';ctx.lineCap='round';ctx.lineJoin='round';
   ctx.strokeStyle=`rgba(${col},${(alpha===undefined?1:alpha)*0.30})`;ctx.lineWidth=w+glow;draw();ctx.stroke();
   ctx.strokeStyle=`rgba(${col},${(alpha===undefined?1:alpha)*0.55})`;ctx.lineWidth=w+glow*0.45;draw();ctx.stroke();
   ctx.restore();
   ctx.save();ctx.strokeStyle=`rgba(255,255,255,${(alpha===undefined?1:alpha)*0.85})`;ctx.lineWidth=w;ctx.lineCap='round';draw();ctx.stroke();ctx.restore();
 }
 // Подвесной светильник над столом: абажур, лампа, конус света и лужица на полу.
 function pendantLamp(ctx,x,yTop,yLamp,s,col,t,i){
   const fl=0.92+0.08*Math.sin(t*(2.2+i*0.7)+i);
   ctx.strokeStyle='rgba(190,200,208,.20)';ctx.lineWidth=1.4;ctx.beginPath();ctx.moveTo(x,yTop);ctx.lineTo(x,yLamp-14*s);ctx.stroke();
   ctx.fillStyle='#7a2b34';ctx.beginPath();ctx.moveTo(x-18*s,yLamp);ctx.lineTo(x+18*s,yLamp);ctx.lineTo(x+11*s,yLamp-15*s);ctx.lineTo(x-11*s,yLamp-15*s);ctx.closePath();ctx.fill();
   ctx.fillStyle='rgba(255,255,255,.10)';ctx.beginPath();ctx.moveTo(x-18*s,yLamp);ctx.lineTo(x-6*s,yLamp);ctx.lineTo(x-11*s,yLamp-15*s);ctx.closePath();ctx.fill();
   ctx.fillStyle=`rgba(${col},${0.95*fl})`;ctx.beginPath();ctx.ellipse(x,yLamp+2*s,7*s,4*s,0,0,Math.PI*2);ctx.fill();
   glowPool(ctx,x,yLamp+3*s,34*s,26*s,col,0.30*fl);
   // конус света вниз
   ctx.save();ctx.globalCompositeOperation='lighter';
   const cg=ctx.createLinearGradient(0,yLamp,0,yLamp+130*s);
   cg.addColorStop(0,`rgba(${col},${0.13*fl})`);cg.addColorStop(1,`rgba(${col},0)`);
   ctx.fillStyle=cg;ctx.beginPath();ctx.moveTo(x-15*s,yLamp+4*s);ctx.lineTo(x+15*s,yLamp+4*s);ctx.lineTo(x+52*s,yLamp+130*s);ctx.lineTo(x-52*s,yLamp+130*s);ctx.closePath();ctx.fill();ctx.restore();
 }
 // ===== КАМ 01 — ЗАЛ =====
 function pizza(ctx,W,H,t){
   const g=roomShell(ctx,W,H,t,{horizon:0.44,checker:true,tileA:'#2a1a1e',tileB:'#121820',wall:['#1d222a','#12181f'],wainscot:'#341a1f',warm:[255,196,140],lamps:2,seed:4});
   const hz=g.hz, vpX=g.vpX;
   // ---- задняя стена: узкая тёмно-вишнёвая полоса и кафель понизу ----
   const bandY=hz*0.64, bandH=hz*0.045;
   ctx.fillStyle='#4d1b23';ctx.fillRect(0,bandY,W,bandH);
   ctx.fillStyle='#6b5220';ctx.fillRect(0,bandY+bandH,W,bandH*0.22);
   ctx.fillStyle='rgba(255,255,255,.035)';ctx.fillRect(0,bandY,W,1);
   for(let i=0;i<26;i++){ctx.fillStyle=i%2?'rgba(255,255,255,.02)':'rgba(0,0,0,.14)';ctx.fillRect(W*i/26,hz*0.74,W/26-1,hz*0.28);}
   // ---- арка в сторону сцены (левая стена) + тёплый свет из неё ----
   const arX=W*0.03, arY=hz*0.36, arW=W*0.14, arH=hz*0.64;
   ctx.fillStyle='#06090c';ctx.fillRect(arX,arY,arW,arH);
   const ag=ctx.createLinearGradient(0,arY,0,hz);ag.addColorStop(0,'rgba(255,176,96,.10)');ag.addColorStop(1,'rgba(255,150,66,0)');
   ctx.fillStyle=ag;ctx.fillRect(arX,arY,arW,arH);
   ctx.strokeStyle='#3a2a2e';ctx.lineWidth=3;ctx.strokeRect(arX,arY,arW,arH);
   // слабый световой поток из арки на пол
   ctx.save();ctx.globalCompositeOperation='lighter';
   const sg=ctx.createLinearGradient(arX,hz,arX+arW,H);
   sg.addColorStop(0,'rgba(255,168,92,.055)');sg.addColorStop(1,'rgba(255,168,92,0)');
   ctx.fillStyle=sg;ctx.beginPath();ctx.moveTo(arX,hz);ctx.lineTo(arX+arW,hz);ctx.lineTo(arX+arW*1.9,H);ctx.lineTo(arX-arW*0.4,H);ctx.closePath();ctx.fill();ctx.restore();
   // ---- стойка выдачи справа ----
   const cX=W*0.72, cY=hz*0.50, cW=W*0.26;
   ctx.fillStyle='#151b21';ctx.fillRect(cX,cY,cW,hz*0.50);
   ctx.fillStyle='#232c33';ctx.fillRect(cX,cY-8,cW,10);
   ctx.fillStyle='rgba(255,255,255,.05)';ctx.fillRect(cX,cY-8,cW,1);
   ctx.strokeStyle='#333d45';ctx.lineWidth=2;ctx.strokeRect(cX,cY,cW,hz*0.50);
   // тёплые витрины с приглушённой подсветкой
   for(let i=0;i<3;i++){
     const wx=cX+cW*0.07+i*cW*0.30, wy=cY+hz*0.09, ww=cW*0.24, wh=hz*0.17;
     ctx.fillStyle='#0b0f12';ctx.fillRect(wx,wy,ww,wh);
     const wg2=ctx.createLinearGradient(0,wy,0,wy+wh);wg2.addColorStop(0,'rgba(255,186,104,.18)');wg2.addColorStop(1,'rgba(255,140,60,.03)');
     ctx.fillStyle=wg2;ctx.fillRect(wx,wy,ww,wh);
     ctx.strokeStyle='rgba(255,200,140,.12)';ctx.lineWidth=1;ctx.strokeRect(wx,wy,ww,wh);
     ctx.fillStyle='rgba(16,11,8,.55)';ctx.fillRect(wx+ww*0.12,wy+wh*0.56,ww*0.3,wh*0.3);ctx.fillRect(wx+ww*0.55,wy+wh*0.64,ww*0.3,wh*0.22);
     glowPool(ctx,wx+ww/2,wy+wh,ww*0.8,wh*0.6,'255,170,96',0.07);
   }
   // неоновая вывеска-долька пиццы над стойкой (небольшая, приглушённая)
   const ns=Math.min(W,H)*0.032, nx=cX+cW*0.5, ny=cY-ns*1.5, pulse=0.7+0.3*Math.sin(t*1.5);
   neon(ctx,()=>{ctx.beginPath();ctx.moveTo(nx-ns,ny+ns*0.6);ctx.lineTo(nx,ny-ns*0.7);ctx.lineTo(nx+ns,ny+ns*0.6);ctx.closePath();},'255,116,58',2,7,0.55*pulse);
   [[-0.36,0.34],[0.30,0.32],[0.0,0.0]].forEach(p=>{ctx.save();ctx.globalCompositeOperation='lighter';ctx.fillStyle=`rgba(255,96,80,${0.55*pulse})`;ctx.beginPath();ctx.arc(nx+ns*p[0],ny+ns*p[1],1.8,0,Math.PI*2);ctx.fill();ctx.restore();});
   glowPool(ctx,nx,ny,ns*2.2,ns*1.8,'255,120,66',0.07*pulse);
   // ---- диваны-боксы у левой стены (тёмные, стоят на полу у стены) ----
   for(let i=0;i<2;i++){
     const bw=W*0.095, bx=W*(0.21+i*0.125), bh=hz*0.16, by=hz-bh+2;
     ctx.fillStyle='rgba(0,0,0,.40)';ctx.fillRect(bx-3,by+bh-3,bw+6,5);
     ctx.fillStyle='#3d151b';ctx.fillRect(bx,by,bw,bh);              // спинка
     ctx.fillStyle='#4b1a21';ctx.fillRect(bx,by+bh*0.55,bw,bh*0.45); // сиденье
     ctx.fillStyle='rgba(255,255,255,.035)';ctx.fillRect(bx,by,bw,1);
     ctx.fillStyle='rgba(0,0,0,.30)';ctx.fillRect(bx,by+bh*0.53,bw,2);
   }
   // ---- плакаты на стене ----
   // ==== V93: ПЛАКАТЫ МЕНЯЮТСЯ, КОГДА НА НИХ НЕ СМОТРЯТ ====
   // Было: четыре жёстких цвета в одном и том же порядке всю игру.
   // Стало: порядок зависит от game.posterSeed, который растёт, когда камера
   // уходит с зала. Изредка один плакат оказывается «не тем»: чёрные глаза
   // или содранный угол. Никаких новых файлов — всё рисуется кодом.
   const PBASE=[[0.235,'#5a1f27'],[0.345,'#204650'],[0.455,'#4f401a'],[0.565,'#372046']];
   const pseed=(window.NightShift&&window.NightShift.posterSeed)||0;   // семя живёт в состоянии игры
   const posters=PBASE.map((p,i)=>[p[0],PBASE[(i+pseed)%PBASE.length][1]]);
   // «Не тот» плакат — детерминированно по семени, чтобы не мигал каждый кадр.
   const wrong=(pseed>0&&(pseed*7)%5===0)?(pseed%PBASE.length):-1;
   // V99: было — цветной прямоугольник с бледным кругом посередине: на камере это
   // читалось как выкраска, а не как афиша. Стало: рама с тенью, паспарту, у каждого
   // плаката свой рисунок (медведь, кусок пиццы, торт, заяц), подпись в три строки
   // и полоски скотча по верхним углам.
   posters.forEach((p,i)=>{const x=W*p[0],y=hz*(0.30+(i%2)*0.05),pw=W*0.078,ph=hz*0.25;
     const bad=(i===wrong);
     ctx.fillStyle='rgba(0,0,0,.40)';ctx.fillRect(x-1,y-1,pw+9,ph+9);            // тень на стене
     ctx.fillStyle='#0a0d11';ctx.fillRect(x-4,y-4,pw+8,ph+8);                    // рама
     ctx.strokeStyle='rgba(196,186,166,.14)';ctx.lineWidth=1;ctx.strokeRect(x-3.5,y-3.5,pw+7,ph+7);
     const pg=ctx.createLinearGradient(0,y,0,y+ph);
     pg.addColorStop(0,bad?'#15151a':p[1]);pg.addColorStop(1,'rgba(6,8,11,.92)');
     ctx.fillStyle=pg;ctx.fillRect(x,y,pw,ph);
     ctx.strokeStyle='rgba(226,214,190,.10)';ctx.strokeRect(x+2.5,y+2.5,pw-5,ph-5); // паспарту
     const cxp=x+pw*0.5, cyp=y+ph*0.38, R=Math.min(pw,ph)*0.30, PI2=Math.PI*2;
     const ink=(a)=>`rgba(236,226,206,${a})`, dk=(a)=>`rgba(16,12,12,${a})`;
     if(bad){
       // «не тот» плакат: то же лицо, но глазницы пустые, а угол содран
       ctx.fillStyle=ink(0.14);ctx.beginPath();ctx.arc(cxp,cyp,R,0,PI2);ctx.fill();
       ctx.fillStyle='rgba(0,0,0,.94)';
       ctx.beginPath();ctx.arc(cxp-R*0.36,cyp-R*0.10,R*0.20,0,PI2);ctx.fill();
       ctx.beginPath();ctx.arc(cxp+R*0.36,cyp-R*0.10,R*0.20,0,PI2);ctx.fill();
       ctx.strokeStyle='rgba(0,0,0,.60)';ctx.lineWidth=1.4;
       ctx.beginPath();ctx.arc(cxp,cyp+R*0.46,R*0.34,0.35,Math.PI-0.35);ctx.stroke();
       ctx.fillStyle='rgba(0,0,0,.60)';
       ctx.beginPath();ctx.moveTo(x+pw,y);ctx.lineTo(x+pw,y+ph*0.30);ctx.lineTo(x+pw*0.62,y);ctx.closePath();ctx.fill();
       ctx.fillStyle='rgba(214,204,184,.10)';
       ctx.beginPath();ctx.moveTo(x+pw,y);ctx.lineTo(x+pw*0.62,y);ctx.lineTo(x+pw*0.86,y+ph*0.12);ctx.closePath();ctx.fill();
     } else if(i%4===0){
       // медведь: уши, круглая голова, светлая морда, тёмный нос, улыбка
       ctx.fillStyle=ink(0.20);
       ctx.beginPath();ctx.arc(cxp-R*0.80,cyp-R*0.74,R*0.34,0,PI2);ctx.fill();
       ctx.beginPath();ctx.arc(cxp+R*0.80,cyp-R*0.74,R*0.34,0,PI2);ctx.fill();
       ctx.fillStyle=ink(0.26);ctx.beginPath();ctx.arc(cxp,cyp,R,0,PI2);ctx.fill();
       ctx.fillStyle=ink(0.40);ctx.beginPath();ctx.ellipse(cxp,cyp+R*0.36,R*0.54,R*0.36,0,0,PI2);ctx.fill();
       ctx.fillStyle=dk(0.78);ctx.beginPath();ctx.ellipse(cxp,cyp+R*0.20,R*0.17,R*0.12,0,0,PI2);ctx.fill();
       ctx.beginPath();ctx.arc(cxp-R*0.38,cyp-R*0.18,R*0.12,0,PI2);ctx.fill();
       ctx.beginPath();ctx.arc(cxp+R*0.38,cyp-R*0.18,R*0.12,0,PI2);ctx.fill();
       ctx.strokeStyle=dk(0.55);ctx.lineWidth=1.3;
       ctx.beginPath();ctx.arc(cxp,cyp+R*0.30,R*0.30,0.25,Math.PI-0.25);ctx.stroke();
     } else if(i%4===1){
       // кусок пиццы: тесто, корочка, пепперони
       ctx.save();ctx.translate(cxp,cyp+R*0.10);ctx.rotate(-0.12);
       ctx.fillStyle='rgba(228,182,86,.52)';
       ctx.beginPath();ctx.moveTo(0,R*1.05);ctx.lineTo(-R*0.88,-R*0.60);ctx.quadraticCurveTo(0,-R*0.90,R*0.88,-R*0.60);ctx.closePath();ctx.fill();
       ctx.fillStyle='rgba(196,142,62,.70)';
       ctx.beginPath();ctx.moveTo(-R*0.88,-R*0.60);ctx.quadraticCurveTo(0,-R*0.90,R*0.88,-R*0.60);
       ctx.quadraticCurveTo(0,-R*0.56,-R*0.88,-R*0.60);ctx.closePath();ctx.fill();
       ctx.fillStyle='rgba(178,52,54,.72)';
       [[-R*0.34,-R*0.20,R*0.17],[R*0.30,-R*0.10,R*0.15],[0,R*0.42,R*0.14]].forEach(o=>{
         ctx.beginPath();ctx.ellipse(o[0],o[1],o[2],o[2]*0.78,0,0,PI2);ctx.fill();});
       ctx.restore();
     } else if(i%4===2){
       // торт со свечами
       ctx.fillStyle=ink(0.30);ctx.fillRect(cxp-R*0.86,cyp-R*0.10,R*1.72,R*0.92);
       ctx.fillStyle=ink(0.18);ctx.fillRect(cxp-R*0.86,cyp+R*0.34,R*1.72,R*0.20);
       ctx.fillStyle=ink(0.44);ctx.beginPath();ctx.ellipse(cxp,cyp-R*0.10,R*0.86,R*0.20,0,0,PI2);ctx.fill();
       ctx.fillStyle=dk(0.45);ctx.beginPath();ctx.ellipse(cxp,cyp+R*0.82,R*0.96,R*0.16,0,0,PI2);ctx.fill();
       for(let c=-1;c<=1;c++){
         const cxx=cxp+c*R*0.46;
         ctx.fillStyle=ink(0.52);ctx.fillRect(cxx-R*0.06,cyp-R*0.52,R*0.12,R*0.42);
         ctx.fillStyle='rgba(255,206,120,.72)';
         ctx.beginPath();ctx.ellipse(cxx,cyp-R*0.60,R*0.08,R*0.14,0,0,PI2);ctx.fill();
       }
     } else {
       // заяц: длинные уши, узкая голова
       ctx.fillStyle=ink(0.20);
       [[-1,-0.30],[1,0.30]].forEach(e=>{
         ctx.save();ctx.translate(cxp+e[0]*R*0.34,cyp-R*0.56);ctx.rotate(e[1]);
         ctx.beginPath();ctx.ellipse(0,-R*0.52,R*0.19,R*0.60,0,0,PI2);ctx.fill();
         ctx.fillStyle='rgba(196,132,140,.28)';
         ctx.beginPath();ctx.ellipse(0,-R*0.52,R*0.09,R*0.40,0,0,PI2);ctx.fill();
         ctx.fillStyle=ink(0.20);ctx.restore();});
       ctx.fillStyle=ink(0.26);ctx.beginPath();ctx.ellipse(cxp,cyp,R*0.86,R,0,0,PI2);ctx.fill();
       ctx.fillStyle=ink(0.42);ctx.beginPath();ctx.ellipse(cxp,cyp+R*0.40,R*0.44,R*0.30,0,0,PI2);ctx.fill();
       ctx.fillStyle=dk(0.75);
       ctx.beginPath();ctx.ellipse(cxp,cyp+R*0.26,R*0.12,R*0.09,0,0,PI2);ctx.fill();
       ctx.beginPath();ctx.arc(cxp-R*0.34,cyp-R*0.20,R*0.11,0,PI2);ctx.fill();
       ctx.beginPath();ctx.arc(cxp+R*0.34,cyp-R*0.20,R*0.11,0,PI2);ctx.fill();
       ctx.strokeStyle=dk(0.50);ctx.lineWidth=1;
       ctx.beginPath();ctx.moveTo(cxp-R*0.60,cyp+R*0.30);ctx.lineTo(cxp-R*0.20,cyp+R*0.36);
       ctx.moveTo(cxp+R*0.60,cyp+R*0.30);ctx.lineTo(cxp+R*0.20,cyp+R*0.36);ctx.stroke();
     }
     // подпись: тёмная плашка и три строки разной длины
     ctx.fillStyle='rgba(0,0,0,.44)';ctx.fillRect(x+2.5,y+ph*0.70,pw-5,ph*0.30-2.5);
     ctx.fillStyle='rgba(238,228,208,.17)';ctx.fillRect(x+pw*0.13,y+ph*0.775,pw*0.74,2.2);
     ctx.fillStyle='rgba(238,228,208,.115)';
     ctx.fillRect(x+pw*0.22,y+ph*0.850,pw*0.56,1.8);
     ctx.fillRect(x+pw*0.32,y+ph*0.905,pw*0.36,1.8);
     // скотч по верхним углам
     for(let s=-1;s<=1;s+=2){
       ctx.save();ctx.globalAlpha=0.12;ctx.fillStyle='#e2ebef';
       ctx.translate(s<0?x:x+pw,y);ctx.rotate(s*0.72);ctx.fillRect(-8,-3,17,6);ctx.restore();
     }
   });
   // ---- гирлянды и лампочки под потолком ----
   garland(ctx,W*0.05,W*0.62,hz*0.22,H*0.05,7,t);
   for(let i=0;i<8;i++){
     const k=i/7, bx=W*(0.08+0.84*k), sag=Math.sin(Math.PI*k)*H*0.03, by=hz*0.16+sag;
     const dead=(i===2||i===6);                                  // две лампочки перегорели
     const fl=dead?0.06:(0.30+0.22*Math.sin(t*2.2+i*0.9));
     const col=i%3===0?'255,120,90':i%3===1?'255,198,120':'110,200,215';
     ctx.save();ctx.globalCompositeOperation='lighter';ctx.fillStyle=`rgba(${col},${0.50*fl})`;ctx.beginPath();ctx.arc(bx,by,2.4,0,Math.PI*2);ctx.fill();ctx.restore();
     glowPool(ctx,bx,by,12,12,col,0.07*fl);
   }
   // ---- воздушные шары в углах ----
   [[0.175,0.21,'#8e2731'],[0.205,0.245,'#8a7226'],[0.815,0.20,'#5c3c78'],[0.845,0.235,'#8e2731']].forEach((b,i)=>{
     const bx=W*b[0]+Math.sin(t*0.8+i)*2.5, by=hz*b[1]+Math.cos(t*0.7+i)*2.5;
     ctx.strokeStyle='rgba(190,200,208,.13)';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(bx,by+12);ctx.quadraticCurveTo(bx-5,by+26,bx-2,by+40);ctx.stroke();
     ctx.fillStyle=b[2];ctx.beginPath();ctx.ellipse(bx,by,10,13,0,0,Math.PI*2);ctx.fill();
     ctx.fillStyle='rgba(0,0,0,.30)';ctx.beginPath();ctx.ellipse(bx+4,by+4,5.5,7.5,0,0,Math.PI*2);ctx.fill();
     ctx.fillStyle='rgba(255,255,255,.14)';ctx.beginPath();ctx.ellipse(bx-4,by-5,2.4,3.2,0,0,Math.PI*2);ctx.fill();
   });
   // ---- столики со свисающими лампами и мягкими лужицами света ----
   // V70: столы нормального размера (было слишком мелко) и всего две подвесные лампы.
   const tables=[[0.255,0.735,1.55,0,'255,186,118',true],[0.655,0.775,2.05,1,'255,170,104',false],
                 [0.155,0.94,2.55,2,'255,196,132',false],[0.845,0.90,2.30,3,'255,180,112',true]];
   tables.forEach(tb=>{
     const x=W*tb[0], y=H*tb[1], s=tb[2];
     if(tb[5])pendantLamp(ctx,x,hz*0.06,y-H*0.20*s*0.55,s*0.62,tb[4],t,tb[3]);
     glowPool(ctx,x,y-4,86*s,22*s,tb[4],0.075);
     partyTable(ctx,x,y,s,tb[3]);
     ctx.save();ctx.globalCompositeOperation='lighter';
     const rf=ctx.createLinearGradient(0,y,0,y+40*s);rf.addColorStop(0,`rgba(${tb[4]},.055)`);rf.addColorStop(1,`rgba(${tb[4]},0)`);
     ctx.fillStyle=rf;ctx.fillRect(x-76*s,y,152*s,40*s);ctx.restore();
   });
   // ---- конфетти и мусор на полу ----
   for(let i=0;i<48;i++){
     const k=Math.pow(((i*37)%100)/100,1.5), y=hz+(H-hz)*(0.10+0.90*k);
     const spread=0.10+0.90*k, x=vpX+(((i*53)%100)/100-0.5)*W*spread;
     const cols=['#7d2530','#8a7226','#255f6b','#5c3c78','#9a958a'];
     ctx.save();ctx.globalAlpha=.16+0.28*k;ctx.fillStyle=cols[i%5];
     ctx.translate(x,y);ctx.rotate((i%7)*0.5);ctx.fillRect(0,0,3+3*k,1.5+2*k);ctx.restore();
   }
   ctx.fillStyle='#8a7226';ctx.beginPath();ctx.moveTo(W*0.44,H*0.93);ctx.lineTo(W*0.455,H*0.87);ctx.lineTo(W*0.47,H*0.93);ctx.closePath();ctx.fill();
   floorDecor(ctx,W*0.075,H*0.885,0.95,'crate');
   cameraDecor(ctx,W*0.075,hz*0.28,0.95);
   cameraDecor(ctx,W*0.925,hz*0.28,0.9);
   // ---- V70: страшные детали зала ----
   // тёмные отпечатки ладоней на стене
   ctx.save();ctx.globalAlpha=.20;ctx.fillStyle='#26090c';
   [[0.36,0.60],[0.395,0.635],[0.70,0.585]].forEach((hp,i)=>{
     const hx=W*hp[0],hy=hz*hp[1];
     ctx.beginPath();ctx.ellipse(hx,hy,7,9,0,0,Math.PI*2);ctx.fill();
     for(let f=0;f<4;f++){ctx.beginPath();ctx.ellipse(hx-6+f*4,hy-11,1.8,5,(f-1.5)*0.18,0,Math.PI*2);ctx.fill();}
   });ctx.restore();
   // потёк под плинтусом
   ctx.save();ctx.globalAlpha=.26;ctx.fillStyle='#2c0a0e';
   ctx.beginPath();ctx.moveTo(W*0.505,hz*0.86);ctx.lineTo(W*0.523,hz*0.86);ctx.lineTo(W*0.516,hz*1.02);ctx.lineTo(W*0.508,hz*1.02);ctx.closePath();ctx.fill();
   ctx.beginPath();ctx.ellipse(W*0.512,hz*1.05,10,3.4,0,0,Math.PI*2);ctx.fill();ctx.restore();
   // силуэт в дальнем проёме — появляется и исчезает сам по себе
   const gh=Math.sin(t*0.11)+Math.sin(t*0.047+1.3);
   if(gh>1.24){
     const a=Math.min(0.5,(gh-1.24)*2.2);
     ctx.save();ctx.globalAlpha=a;ctx.fillStyle='#05070a';
     const fx=W*0.50, fy=hz*0.985, fh=hz*0.40;
     ctx.beginPath();ctx.moveTo(fx-fh*0.15,fy);ctx.lineTo(fx+fh*0.15,fy);ctx.lineTo(fx+fh*0.10,fy-fh*0.72);ctx.lineTo(fx-fh*0.10,fy-fh*0.72);ctx.closePath();ctx.fill();
     ctx.beginPath();ctx.ellipse(fx,fy-fh*0.82,fh*0.11,fh*0.13,0,0,Math.PI*2);ctx.fill();
     ctx.globalCompositeOperation='lighter';ctx.fillStyle=`rgba(220,60,50,${(a*0.9).toFixed(2)})`;
     ctx.beginPath();ctx.arc(fx-fh*0.045,fy-fh*0.845,1.6,0,Math.PI*2);ctx.fill();
     ctx.beginPath();ctx.arc(fx+fh*0.045,fy-fh*0.845,1.6,0,Math.PI*2);ctx.fill();
     ctx.restore();
   }
   roomVignette(ctx,W,H,0.72);
   roomLabel(ctx,W,H,'КАМ 01','ЗАЛ');
 }
 // ===== КАМ 02 — ВЫХОД =====
 function exit(ctx,W,H,t){
   const g=roomShell(ctx,W,H,t,{horizon:0.46,wall:['#182028','#0f161c'],wainscot:'#0c1216',floorFar:'#141b21',floorNear:'#080b0e',lamps:2,warm:[190,215,235],flicker:true,seed:6});
   const hz=g.hz;
   // V99: плитка в вестибюле. Было — ровное светлое поле без единого шва:
   // пол не читался как пол и всё, что на нём стоит, висело в пустоте.
   // Шаг поперечных швов сжимается к горизонту (1/z), а не идёт ровной лестницей.
   ctx.save();ctx.beginPath();ctx.rect(0,hz,W,H-hz);ctx.clip();
   ctx.strokeStyle='rgba(150,178,198,.09)';ctx.lineWidth=1;
   for(let i=1;i<=9;i++){
     const z=i/9, yy=hz+(H-hz)*(z*z*0.96+0.04);
     ctx.beginPath();ctx.moveTo(0,yy);ctx.lineTo(W,yy);ctx.stroke();
   }
   const tcx=W*0.50;   // центр вестибюля — дверь ещё не объявлена на этом слое
   for(let i=-6;i<=6;i++){
     ctx.beginPath();ctx.moveTo(tcx+i*W*0.055,hz);ctx.lineTo(tcx+i*W*0.175,H);ctx.stroke();
   }
   // влажный блик от уличного света полосами
   ctx.save();ctx.globalCompositeOperation='lighter';
   for(let i=0;i<4;i++){
     const k=i/4, yy=hz+(H-hz)*(0.18+k*0.62);
     ctx.fillStyle=`rgba(150,190,225,${(0.030-k*0.006).toFixed(3)})`;
     ctx.fillRect(tcx-W*(0.10+k*0.14),yy,W*(0.20+k*0.28),2.4);
   }
   ctx.restore();ctx.restore();
   // двойные стеклянные двери
   const dx=W*0.50, dw=W*0.30, dyTop=hz*0.28, dh=hz*0.72;
   ctx.fillStyle='#070a0d';ctx.fillRect(dx-dw/2-8,dyTop-8,dw+16,dh+8);
   const cold=ctx.createLinearGradient(0,dyTop,0,dyTop+dh);
   cold.addColorStop(0,'#1d2f3d');cold.addColorStop(0.55,'#16242f');cold.addColorStop(1,'#0d1419');
   ctx.fillStyle=cold;ctx.fillRect(dx-dw/2,dyTop,dw,dh);
   // улица за стеклом: фонарь, дождь, силуэты
   ctx.save();ctx.beginPath();ctx.rect(dx-dw/2,dyTop,dw,dh);ctx.clip();
   const lampG=ctx.createRadialGradient(dx+dw*0.28,dyTop+dh*0.22,2,dx+dw*0.28,dyTop+dh*0.22,dw*0.55);
   lampG.addColorStop(0,'rgba(190,225,255,.40)');lampG.addColorStop(1,'rgba(120,170,220,0)');
   ctx.fillStyle=lampG;ctx.fillRect(dx-dw/2,dyTop,dw,dh);
   ctx.fillStyle='rgba(10,16,20,.85)';ctx.fillRect(dx-dw*0.42,dyTop+dh*0.52,dw*0.20,dh*0.48);
   ctx.fillStyle='rgba(8,12,16,.75)';ctx.fillRect(dx+dw*0.10,dyTop+dh*0.60,dw*0.14,dh*0.40);
   ctx.strokeStyle='rgba(190,215,235,.20)';ctx.lineWidth=1;
   for(let i=0;i<26;i++){const rx=dx-dw/2+((i*97+((t*260)%dw))%dw), ry=dyTop+((i*53+((t*520)%dh))%dh);ctx.beginPath();ctx.moveTo(rx,ry);ctx.lineTo(rx-2,ry+11);ctx.stroke();}
   ctx.restore();
   // рамы, створки, ручки
   ctx.strokeStyle='#4c5a63';ctx.lineWidth=4;ctx.strokeRect(dx-dw/2,dyTop,dw,dh);
   ctx.fillStyle='#2c3740';ctx.fillRect(dx-4,dyTop,8,dh);
   ctx.fillStyle='#39454e';ctx.fillRect(dx-dw/2+6,dyTop+dh*0.52,dw*0.42,7);ctx.fillRect(dx+6,dyTop+dh*0.52,dw*0.42,7);
   ctx.fillStyle='rgba(255,255,255,.05)';ctx.fillRect(dx-dw/2+8,dyTop+8,dw*0.20,dh*0.34);
   // табло ВЫХОД над дверью
   // V99: было — аддитивное свечение заливалось прямоугольником в три ширины табло
   // и выбеливало всю вывеску: на камере вместо «ВЫХОД» видно было белое пятно.
   // Стало: корпус с кронштейнами, тёмное стекло, ореол только вокруг табло, буквы сверху.
   // V99: кадр камеры обрезан сверху, поэтому табло над дверью не попадало в
   // видимую область. Теперь оно смонтировано на перекладине двери и видно всегда.
   const sw=W*0.16, sh=hz*0.13, sx=dx-sw/2, sy=dyTop+hz*0.20;
   const flick=0.75+0.25*Math.abs(Math.sin(t*3.1));
   ctx.strokeStyle='#39454e';ctx.lineWidth=2;
   ctx.beginPath();ctx.moveTo(sx+sw*0.22,sy);ctx.lineTo(sx+sw*0.22,sy-6);
   ctx.moveTo(sx+sw*0.78,sy);ctx.lineTo(sx+sw*0.78,sy-6);ctx.stroke();
   ctx.fillStyle='rgba(0,0,0,.55)';ctx.fillRect(sx+2,sy+3,sw,sh);
   const box=ctx.createLinearGradient(0,sy,0,sy+sh);
   box.addColorStop(0,'#2b353b');box.addColorStop(1,'#131a1e');
   ctx.fillStyle=box;ctx.fillRect(sx,sy,sw,sh);
   ctx.strokeStyle='#48555d';ctx.lineWidth=2;ctx.strokeRect(sx,sy,sw,sh);
   ctx.fillStyle='#08130e';ctx.fillRect(sx+3,sy+3,sw-6,sh-6);
   ctx.save();ctx.globalCompositeOperation='lighter';
   const sgIn=ctx.createLinearGradient(0,sy+3,0,sy+sh-3);
   sgIn.addColorStop(0,`rgba(50,220,120,${0.20*flick})`);sgIn.addColorStop(1,`rgba(30,150,80,${0.10*flick})`);
   ctx.fillStyle=sgIn;ctx.fillRect(sx+3,sy+3,sw-6,sh-6);
   const sg=ctx.createRadialGradient(dx,sy+sh/2,sw*0.20,dx,sy+sh/2,sw*0.62);
   sg.addColorStop(0,`rgba(60,255,140,${0.16*flick})`);sg.addColorStop(1,'rgba(30,180,90,0)');
   ctx.fillStyle=sg;ctx.fillRect(sx-sw*0.3,sy-sh*0.5,sw*1.6,sh*2);
   ctx.restore();
   text2(ctx,'ВЫХОД',dx,sy+sh*0.72,Math.max(12,sh*0.62),`rgba(150,255,190,${0.80+0.20*flick})`,'center');
   // ленточное ограждение и коврик
   for(let i=-1;i<=1;i+=2){
     const px=dx+i*dw*0.62;
     ctx.fillStyle='#2b343b';ctx.fillRect(px-4,H*0.60,8,H*0.16);
     ctx.fillStyle='#3d4952';ctx.beginPath();ctx.ellipse(px,H*0.765,16,5,0,0,Math.PI*2);ctx.fill();
     ctx.fillStyle='#5b2a30';ctx.fillRect(px-3,H*0.585,6,7);
   }
   ctx.strokeStyle='#5b2a30';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(dx-dw*0.62,H*0.615);ctx.quadraticCurveTo(dx,H*0.655,dx+dw*0.62,H*0.615);ctx.stroke();
   ctx.fillStyle='#12191e';ctx.beginPath();ctx.moveTo(dx-dw*0.40,H*0.99);ctx.lineTo(dx+dw*0.40,H*0.99);ctx.lineTo(dx+dw*0.26,H*0.80);ctx.lineTo(dx-dw*0.26,H*0.80);ctx.closePath();ctx.fill();
   text2(ctx,'ДО ВСТРЕЧИ',dx,H*0.905,13,'#39444c','center');
   // отблеск от улицы на полу
   const rf=ctx.createLinearGradient(0,hz,0,H);rf.addColorStop(0,'rgba(140,190,230,.13)');rf.addColorStop(1,'rgba(140,190,230,0)');
   ctx.fillStyle=rf;ctx.beginPath();ctx.moveTo(dx-dw*0.5,hz);ctx.lineTo(dx+dw*0.5,hz);ctx.lineTo(dx+dw*0.85,H);ctx.lineTo(dx-dw*0.85,H);ctx.closePath();ctx.fill();
   // растение в кадке и урна
   // V99: было — шесть одинаковых линий без заливки и плоская кадка.
   // Стало: листы-клинья с жилкой и разным наклоном, земля в кадке, обод и тень.
   ctx.save();ctx.translate(W*0.16,H*0.80);
   ctx.fillStyle='rgba(0,0,0,.45)';ctx.beginPath();ctx.ellipse(2,26,22,6,0,0,Math.PI*2);ctx.fill();
   for(let i=0;i<7;i++){
     const lean=-1.15+i*0.38, len=34+((i*7)%3)*9, wdt=5.5+((i*5)%3)*1.6;
     const tipx=Math.sin(lean)*len, tipy=-len*0.92-Math.abs(Math.sin(i))*5;
     ctx.fillStyle=i%2?'#2c4a33':'#223b28';
     ctx.beginPath();ctx.moveTo(-wdt*0.5,2);
     ctx.quadraticCurveTo(tipx*0.45-wdt*0.7,tipy*0.55,tipx,tipy);
     ctx.quadraticCurveTo(tipx*0.45+wdt*0.7,tipy*0.55,wdt*0.5,2);ctx.closePath();ctx.fill();
     ctx.strokeStyle='rgba(150,190,158,.14)';ctx.lineWidth=1;
     ctx.beginPath();ctx.moveTo(0,1);ctx.quadraticCurveTo(tipx*0.45,tipy*0.55,tipx*0.94,tipy*0.96);ctx.stroke();
   }
   const potg=ctx.createLinearGradient(-16,0,16,0);
   potg.addColorStop(0,'#3a2e24');potg.addColorStop(0.45,'#4a3a2c');potg.addColorStop(1,'#251d16');
   ctx.fillStyle=potg;ctx.beginPath();ctx.moveTo(-16,0);ctx.lineTo(16,0);ctx.lineTo(12,26);ctx.lineTo(-12,26);ctx.closePath();ctx.fill();
   ctx.fillStyle='#4f4032';ctx.fillRect(-18,-4,36,7);
   ctx.fillStyle='rgba(255,236,200,.07)';ctx.fillRect(-18,-4,36,2);
   ctx.fillStyle='#171310';ctx.beginPath();ctx.ellipse(0,-2,15,3.4,0,0,Math.PI*2);ctx.fill();
   ctx.restore();
   floorDecor(ctx,W*0.85,H*0.83,0.9,'bin');
   cameraDecor(ctx,W*0.10,hz*0.28,0.95);
   cameraDecor(ctx,W*0.90,hz*0.28,0.9);
   roomVignette(ctx,W,H,0.64);
   roomLabel(ctx,W,H,'КАМ 02','ВЫХОД');
 }
 // ===== КАМ 03 — СКЛАД =====
 function storage(ctx,W,H,t){
   const g=roomShell(ctx,W,H,t,{horizon:0.40,wall:['#161d23','#0d1317'],wainscot:'#0b1013',floorFar:'#131a1f',floorNear:'#070a0d',lamps:0,seed:8,atmosX:[0.50],warm:[255,224,158],haze:0.055});
   const hz=g.hz;
   // трубы под потолком
   for(let i=0;i<3;i++){const y=hz*(0.08+i*0.055);ctx.strokeStyle=i%2?'#2a343b':'#232c32';ctx.lineWidth=7-i;ctx.beginPath();ctx.moveTo(0,y);ctx.bezierCurveTo(W*0.35,y+H*0.012,W*0.65,y-H*0.012,W,y+H*0.008);ctx.stroke();}
   // стеллажи: два по бокам в перспективе + один у задней стены
   function rack(ctx,x,y,rw,rh,shelves,dark){
     ctx.fillStyle=dark?'#0b1013':'#0e141a';ctx.fillRect(x,y,rw,rh);
     ctx.strokeStyle='#3a464f';ctx.lineWidth=2;ctx.strokeRect(x,y,rw,rh);
     for(let i=0;i<shelves;i++){
       const sy=y+rh*((i+1)/(shelves+1));
       ctx.fillStyle='#2b353c';ctx.fillRect(x,sy,rw,4);
       ctx.fillStyle='rgba(0,0,0,.35)';ctx.fillRect(x,sy+4,rw,2);
       // V99: было — прямоугольники вплотную двух цветов: на камере полка
       // читалась как цельная доска с тёмными засечками. Стало: картонные коробки
       // разной высоты с швом створок, полосой скотча, ярлыком и тенью между ними.
       const slot=rh/(shelves+1);
       let bx=x+5, n=0;
       while(bx<x+rw-16){
         const r1=((i*13+n*7)%5)/5, r2=((i*29+n*11)%4)/4, r3=(i*3+n*5)%3;
         const bw=13+Math.round(r1*16), bh=slot*(0.46+0.30*r2);
         const top=sy-bh;
         ctx.fillStyle='rgba(0,0,0,.45)';ctx.fillRect(bx-2,top+2,bw+2,bh-2);   // тень на соседа
         const cb=ctx.createLinearGradient(bx,top,bx+bw,top);
         if(r3===2){cb.addColorStop(0,'#39434a');cb.addColorStop(1,'#232c33');}      // пластиковый ящик
         else{cb.addColorStop(0,'#3e321f');cb.addColorStop(1,'#261e13');}            // картон
         ctx.fillStyle=cb;ctx.fillRect(bx,top,bw,bh);
         ctx.fillStyle='rgba(255,236,200,.055)';ctx.fillRect(bx,top,bw,2);           // блик по верху
         ctx.fillStyle='rgba(0,0,0,.34)';ctx.fillRect(bx,sy-2.5,bw,2.5);            // тень у основания
         if(r3===2){
           for(let g=0;g<3;g++){ctx.fillStyle='rgba(0,0,0,.30)';ctx.fillRect(bx+2,top+3+g*(bh-6)/3,bw-4,1.6);}
         }else{
           ctx.fillStyle='rgba(0,0,0,.38)';ctx.fillRect(bx+bw*0.5-0.8,top,1.6,bh*0.42); // шов створок
           ctx.fillStyle='rgba(214,198,164,.12)';ctx.fillRect(bx,top+bh*0.40,bw,2.6);   // скотч
           if(bw>20){ctx.fillStyle='rgba(226,216,196,.13)';ctx.fillRect(bx+3,top+bh*0.58,bw-9,bh*0.24);} // ярлык
         }
         ctx.strokeStyle='rgba(0,0,0,.55)';ctx.lineWidth=1;ctx.strokeRect(bx+0.5,top+0.5,bw-1,bh-1);
         bx+=bw+3+((n%2)?4:1);n++;
       }
     }
   }
   rack(ctx,W*0.02,hz*0.36,W*0.24,hz*0.62,3,false);
   rack(ctx,W*0.74,hz*0.36,W*0.24,hz*0.62,3,false);
   rack(ctx,W*0.31,hz*0.44,W*0.38,hz*0.54,2,true);
   // запасные головы аниматроников на верхней полке (жутковатая деталь)
   // V99: было — цветной прямоугольник с двумя белыми метками и гребёнкой зубов:
   // на камере они читались как наклеенные стикеры. Стало — силуэт головы:
   // череп, уши, впалые глазницы с точкой блика, челюсть с зубами и тень на полке.
   for(let i=0;i<3;i++){
     const hxx=W*(0.35+i*0.12), hyy=hz*0.62, PI2=Math.PI*2;
     const base=i===1?['#5b3a70','#33204a']:['#7a2a33','#42151c'];
     ctx.fillStyle='rgba(0,0,0,.55)';ctx.beginPath();ctx.ellipse(hxx,hyy-1,15,4,0,0,PI2);ctx.fill();
     // уши (у средней головы длинные, у остальных круглые)
     ctx.fillStyle=base[1];
     if(i===1){
       ctx.beginPath();ctx.ellipse(hxx-7,hyy-24,3.2,8,0.18,0,PI2);ctx.fill();
       ctx.beginPath();ctx.ellipse(hxx+7,hyy-24,3.2,8,-0.18,0,PI2);ctx.fill();
     }else{
       ctx.beginPath();ctx.arc(hxx-10,hyy-16,4.6,0,PI2);ctx.fill();
       ctx.beginPath();ctx.arc(hxx+10,hyy-16,4.6,0,PI2);ctx.fill();
     }
     // череп
     const hg=ctx.createLinearGradient(hxx-12,hyy-20,hxx+12,hyy-2);
     hg.addColorStop(0,base[0]);hg.addColorStop(1,base[1]);
     ctx.fillStyle=hg;ctx.beginPath();ctx.ellipse(hxx,hyy-11,12,11,0,0,PI2);ctx.fill();
     ctx.fillStyle='rgba(255,235,215,.10)';ctx.beginPath();ctx.ellipse(hxx-4,hyy-16,5,3,-0.4,0,PI2);ctx.fill();
     // глазницы
     ctx.fillStyle='rgba(0,0,0,.92)';
     ctx.beginPath();ctx.ellipse(hxx-5,hyy-14,3.4,3.8,0,0,PI2);ctx.fill();
     ctx.beginPath();ctx.ellipse(hxx+5,hyy-14,3.4,3.8,0,0,PI2);ctx.fill();
     ctx.fillStyle='rgba(255,238,200,.75)';
     ctx.fillRect(hxx-6,hyy-15,1.6,1.6);ctx.fillRect(hxx+4,hyy-15,1.6,1.6);
     // челюсть с зубами
     ctx.fillStyle='#0a0c0e';ctx.beginPath();ctx.ellipse(hxx,hyy-4,9,4.6,0,0,PI2);ctx.fill();
     ctx.fillStyle='rgba(214,220,224,.85)';
     for(let k=0;k<5;k++)ctx.fillRect(hxx-7.5+k*3.4,hyy-7.2,2.2,3);
     ctx.fillStyle='rgba(180,188,194,.55)';
     for(let k=0;k<4;k++)ctx.fillRect(hxx-5.6+k*3.4,hyy-2.6,2,2);
   }
   // штабель коробок и накрытая тканью груда
   for(let i=0;i<4;i++){const bx=W*0.13+i%2*W*0.055, by=H*0.94-i*H*0.055, bw=W*0.10, bh=H*0.055;
     ctx.fillStyle=i%2?'#3b3126':'#332a20';ctx.fillRect(bx,by-bh,bw,bh);
     ctx.strokeStyle='rgba(0,0,0,.45)';ctx.lineWidth=2;ctx.strokeRect(bx,by-bh,bw,bh);
     ctx.strokeStyle='rgba(230,220,200,.10)';ctx.beginPath();ctx.moveTo(bx+bw*0.5,by-bh);ctx.lineTo(bx+bw*0.5,by);ctx.stroke();}
   ctx.fillStyle='#0e1418';ctx.beginPath();ctx.moveTo(W*0.63,H*0.99);ctx.lineTo(W*0.62,H*0.80);ctx.lineTo(W*0.72,H*0.74);ctx.lineTo(W*0.86,H*0.82);ctx.lineTo(W*0.88,H*0.99);ctx.closePath();ctx.fill();
   ctx.strokeStyle='rgba(255,255,255,.05)';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(W*0.63,H*0.86);ctx.lineTo(W*0.87,H*0.90);ctx.stroke();
   // предупреждающая табличка
   ctx.fillStyle='#3f3a16';ctx.fillRect(W*0.285,hz*0.16,W*0.085,hz*0.11);
   ctx.strokeStyle='#7d7326';ctx.lineWidth=2;ctx.strokeRect(W*0.285,hz*0.16,W*0.085,hz*0.11);
   text2(ctx,'!',W*0.3275,hz*0.255,15,'#d8cc55','center');
   floorDecor(ctx,W*0.30,H*0.92,0.85,'barrel');
   floorDecor(ctx,W*0.45,H*0.96,0.8,'bin');
   // поддон с мешками ближе к камере
   ctx.fillStyle='#2a2116';ctx.fillRect(W*0.36,H*0.86,W*0.16,H*0.03);
   ctx.fillStyle='#1d2429';for(let i=0;i<3;i++)ctx.fillRect(W*(0.365+i*0.05),H*0.80,W*0.045,H*0.06);
   // качающаяся лампа на шнуре
   const sway=Math.sin(t*1.15)*W*0.012, lx=W*0.50+sway, ly=hz*0.30;
   ctx.strokeStyle='#2c353b';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(W*0.50,0);ctx.lineTo(lx,ly-8);ctx.stroke();
   ctx.fillStyle='#39434a';ctx.beginPath();ctx.moveTo(lx-13,ly-8);ctx.lineTo(lx+13,ly-8);ctx.lineTo(lx+8,ly+3);ctx.lineTo(lx-8,ly+3);ctx.closePath();ctx.fill();
   const bulb=0.72+0.28*Math.abs(Math.sin(t*7.3));
   ctx.fillStyle=`rgba(255,228,160,${0.75*bulb})`;ctx.beginPath();ctx.arc(lx,ly+7,5,0,Math.PI*2);ctx.fill();
   const cone=ctx.createRadialGradient(lx,ly+7,3,lx,ly+7,H*0.55);
   cone.addColorStop(0,`rgba(255,222,150,${0.20*bulb})`);cone.addColorStop(1,'rgba(255,200,110,0)');
   ctx.save();ctx.globalCompositeOperation='lighter';ctx.fillStyle=cone;ctx.fillRect(0,0,W,H);ctx.restore();
   cameraDecor(ctx,W*0.90,hz*0.24,0.9);
   roomVignette(ctx,W,H,0.70);
   roomLabel(ctx,W,H,'КАМ 03','СКЛАД');
 }
 // ===== КАМ 05 — СЛУЖЕБНАЯ =====
 function service(ctx,W,H,t){
   const g=roomShell(ctx,W,H,t,{horizon:0.44,wall:['#151d24','#0d141a'],wainscot:'#0b1115',floorFar:'#131a20',floorNear:'#070a0d',lamps:2,warm:[210,235,245],flicker:true,seed:11});
   const hz=g.hz;
   // кабель-каналы и трубы
   for(let i=0;i<4;i++){const y=hz*(0.10+i*0.045);ctx.strokeStyle='rgba(120,140,155,.10)';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(W,y+H*0.006*i);ctx.stroke();}
   // электрощит слева
   const px=W*0.05, py=hz*0.32, pw=W*0.20, ph=hz*0.52;
   ctx.fillStyle='#101820';ctx.fillRect(px,py,pw,ph);
   ctx.strokeStyle='#48555e';ctx.lineWidth=3;ctx.strokeRect(px,py,pw,ph);
   ctx.fillStyle='#0a0f13';ctx.fillRect(px+8,py+8,pw-16,ph-16);
   for(let r=0;r<3;r++)for(let c=0;c<4;c++){
     const bxx=px+12+c*(pw-24)/4, byy=py+14+r*(ph-28)/3;
     ctx.fillStyle='#2b343b';ctx.fillRect(bxx,byy,(pw-30)/4,ph*0.16);
     const on=((r*4+c)%3)!==0;
     ctx.fillStyle=on?'#4fbf6a':'#7d2b30';ctx.fillRect(bxx+2,byy+2,5,5);
   }
   const led=0.5+0.5*Math.abs(Math.sin(t*4.2));
   ctx.fillStyle=`rgba(90,220,130,${0.4+0.6*led})`;ctx.beginPath();ctx.arc(px+pw-14,py+12,4,0,Math.PI*2);ctx.fill();
   text2(ctx,'ЭЛЕКТРОЩИТ',px+pw/2,py+ph+16,11,'#8b949c','center');
   // верстак с инструментами и перфопанель
   const bx=W*0.33, by=hz*0.60, bw=W*0.34, bh=hz*0.18;
   ctx.fillStyle='#2b2116';ctx.fillRect(bx,by,bw,bh);
   ctx.fillStyle='#38291a';ctx.fillRect(bx,by,bw,6);
   ctx.fillStyle='#1c242a';ctx.fillRect(bx+6,by+bh,10,hz*0.40);ctx.fillRect(bx+bw-16,by+bh,10,hz*0.40);
   // перфопанель с инструментами
   ctx.fillStyle='#141c22';ctx.fillRect(bx,hz*0.24,bw,hz*0.32);
   ctx.strokeStyle='#39444c';ctx.lineWidth=2;ctx.strokeRect(bx,hz*0.24,bw,hz*0.32);
   for(let r=0;r<5;r++)for(let c=0;c<12;c++){ctx.fillStyle='rgba(0,0,0,.45)';ctx.fillRect(bx+8+c*(bw-16)/12,hz*0.26+r*(hz*0.28)/5,3,3);}
   // молоток, разводной ключ, отвёртки, пила
   // V98: инструменты были нарисованы одними светлыми линиями без заливки — на
   // камере они читались как начерченные мелом буквы «Т I /// ▷». Стало: у каждого
   // инструмента силуэт с заливкой, деревянная или цветная рукоять, стальной
   // блик и падающая тень на перфопанель.
   const toolSh=(fn)=>{ctx.save();ctx.translate(2,3);ctx.globalAlpha=.45;ctx.fillStyle='#05080a';fn();ctx.restore();fn();};
   // молоток: боёк с клином и рукоять
   const hmX=bx+bw*0.12;
   toolSh(()=>{
     ctx.fillStyle=ctx.fillStyle==='#05080a'?ctx.fillStyle:'#6b4a28';
     ctx.beginPath();ctx.moveTo(hmX-3,hz*0.295);ctx.lineTo(hmX+3,hz*0.295);ctx.lineTo(hmX+2.4,hz*0.445);ctx.lineTo(hmX-2.4,hz*0.445);ctx.closePath();ctx.fill();
     if(ctx.fillStyle!=='#05080a')ctx.fillStyle='#7f8a92';
     ctx.beginPath();ctx.moveTo(hmX-bw*0.045,hz*0.272);ctx.lineTo(hmX+bw*0.020,hz*0.272);
     ctx.lineTo(hmX+bw*0.046,hz*0.283);ctx.lineTo(hmX+bw*0.020,hz*0.298);ctx.lineTo(hmX-bw*0.045,hz*0.298);
     ctx.quadraticCurveTo(hmX-bw*0.058,hz*0.285,hmX-bw*0.045,hz*0.272);ctx.closePath();ctx.fill();
   });
   ctx.fillStyle='rgba(226,238,246,.30)';ctx.fillRect(hmX-bw*0.042,hz*0.276,bw*0.055,2);
   // разводной ключ: две губки и изогнутая ручка
   const wrX=bx+bw*0.30;
   toolSh(()=>{
     const dark=ctx.fillStyle==='#05080a';
     if(!dark)ctx.fillStyle='#78838b';
     // рожковый ключ: шейка и открытая губка с прорезью, иначе силуэт читался
     // как нож или буква «Т»
     ctx.beginPath();ctx.moveTo(wrX-3.2,hz*0.300);ctx.lineTo(wrX+3.2,hz*0.300);ctx.lineTo(wrX+5.4,hz*0.462);ctx.lineTo(wrX-0.6,hz*0.462);ctx.closePath();ctx.fill();
     ctx.beginPath();
     ctx.moveTo(wrX-9,hz*0.276);ctx.lineTo(wrX-2.6,hz*0.270);ctx.lineTo(wrX-2.0,hz*0.284);
     ctx.lineTo(wrX-6.4,hz*0.288);ctx.lineTo(wrX-6.4,hz*0.296);ctx.lineTo(wrX-1.4,hz*0.300);
     ctx.lineTo(wrX-1.0,hz*0.312);ctx.lineTo(wrX-8.6,hz*0.308);
     ctx.quadraticCurveTo(wrX-12,hz*0.292,wrX-9,hz*0.276);ctx.closePath();ctx.fill();
     ctx.beginPath();
     ctx.moveTo(wrX+2.0,hz*0.446);ctx.lineTo(wrX+8.6,hz*0.452);ctx.quadraticCurveTo(wrX+11.4,hz*0.470,wrX+8.0,hz*0.482);
     ctx.lineTo(wrX+2.6,hz*0.478);ctx.closePath();ctx.fill();
   });
   ctx.fillStyle='rgba(226,238,246,.22)';ctx.fillRect(wrX-3,hz*0.300,2,hz*0.150);
   // три отвёртки: стальное жало и цветная рукоять с юбкой
   for(let i=0;i<3;i++){
     const sx4=bx+bw*(0.48+i*0.05), col=['#b6323f','#c8a02c','#2f7d8c'][i];
     ctx.fillStyle='rgba(5,8,10,.45)';ctx.fillRect(sx4-1.2+2,hz*0.292+3,3.6,hz*0.128);
     ctx.fillStyle='#9aa4ab';ctx.fillRect(sx4-1.6,hz*0.292,3.2,hz*0.130);
     ctx.fillStyle='rgba(240,248,252,.35)';ctx.fillRect(sx4-1.6,hz*0.292,1.2,hz*0.130);
     ctx.fillStyle=col;
     ctx.beginPath();ctx.moveTo(sx4-4.2,hz*0.420);ctx.lineTo(sx4+4.2,hz*0.420);
     ctx.lineTo(sx4+3.2,hz*0.452);ctx.lineTo(sx4-3.2,hz*0.452);ctx.closePath();ctx.fill();
     ctx.fillStyle='rgba(255,255,255,.18)';ctx.fillRect(sx4-3.6,hz*0.424,1.6,hz*0.024);
     ctx.fillStyle='rgba(0,0,0,.30)';ctx.fillRect(sx4-4.2,hz*0.420,8.4,1.6);
   }
   // пила: полотно с зубьями и рукоять
   const saX=bx+bw*0.72, saY=hz*0.30, saX2=bx+bw*0.92;
   toolSh(()=>{
     const dark=ctx.fillStyle==='#05080a';
     if(!dark)ctx.fillStyle='#8f99a0';
     ctx.beginPath();ctx.moveTo(saX,saY);ctx.lineTo(saX2,saY+hz*0.055);
     const teeth=14;
     for(let k=teeth;k>=0;k--){const kk=k/teeth,xx=saX+(saX2-saX)*kk,yy=saY+hz*0.055+hz*0.030*(1-kk)+hz*0.040*kk;
       ctx.lineTo(xx,yy+(k%2?0:hz*0.012));}
     ctx.closePath();ctx.fill();
     if(!dark)ctx.fillStyle='#6b4a28';
     ctx.beginPath();ctx.moveTo(saX-bw*0.045,saY-hz*0.010);ctx.lineTo(saX+bw*0.005,saY);
     ctx.lineTo(saX+bw*0.005,saY+hz*0.058);ctx.lineTo(saX-bw*0.040,saY+hz*0.050);
     ctx.quadraticCurveTo(saX-bw*0.060,saY+hz*0.020,saX-bw*0.045,saY-hz*0.010);ctx.closePath();ctx.fill();
   });
   ctx.fillStyle='rgba(232,242,248,.28)';ctx.beginPath();ctx.moveTo(saX,saY+2);ctx.lineTo(saX2,saY+hz*0.055+1);ctx.lineTo(saX2,saY+hz*0.055+3.5);ctx.lineTo(saX,saY+4.5);ctx.closePath();ctx.fill();
   // на верстаке: ящик с инструментом, канистра, снятая маска
   ctx.fillStyle='#7d2b30';ctx.fillRect(bx+bw*0.06,by-hz*0.09,bw*0.16,hz*0.09);
   ctx.fillStyle='#5c2025';ctx.fillRect(bx+bw*0.06,by-hz*0.09,bw*0.16,4);
   ctx.fillStyle='#2c3b2a';ctx.fillRect(bx+bw*0.30,by-hz*0.10,bw*0.10,hz*0.10);
   ctx.fillStyle='#1e2a1d';ctx.fillRect(bx+bw*0.325,by-hz*0.125,bw*0.05,hz*0.03);
   ctx.fillStyle='#4a2f5c';ctx.fillRect(bx+bw*0.62,by-hz*0.08,bw*0.16,hz*0.08);
   ctx.fillStyle='rgba(255,240,210,.8)';ctx.fillRect(bx+bw*0.66,by-hz*0.062,bw*0.03,hz*0.018);ctx.fillRect(bx+bw*0.715,by-hz*0.062,bw*0.03,hz*0.018);
   // запчасти аниматроника на крюках справа
   ctx.fillStyle='#39444c';ctx.fillRect(W*0.72,hz*0.26,W*0.24,5);
   for(let i=0;i<3;i++){
     const hx=W*(0.755+i*0.075);
     ctx.strokeStyle='#5c666d';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(hx,hz*0.31);ctx.lineTo(hx,hz*0.38);ctx.stroke();
     if(i===1){ // корпус
       ctx.fillStyle='#5c2027';ctx.fillRect(hx-14,hz*0.38,28,hz*0.22);
       ctx.fillStyle='#3a141a';ctx.fillRect(hx-14,hz*0.38,28,6);
     } else { // рука / нога
       ctx.fillStyle='#4a5259';ctx.fillRect(hx-5,hz*0.38,10,hz*0.24);
       ctx.fillStyle='#2f363b';ctx.fillRect(hx-8,hz*0.60,16,hz*0.05);
     }
   }
   // вентилятор на стене
   const fx2=W*0.90, fy2=hz*0.96, fr=Math.min(W,H)*0.045, rot=t*2.2;
   ctx.fillStyle='#0d1216';ctx.beginPath();ctx.arc(fx2,fy2,fr+4,0,Math.PI*2);ctx.fill();
   ctx.strokeStyle='#39444c';ctx.lineWidth=2;ctx.beginPath();ctx.arc(fx2,fy2,fr+4,0,Math.PI*2);ctx.stroke();
   ctx.save();ctx.translate(fx2,fy2);ctx.rotate(rot);
   for(let i=0;i<4;i++){ctx.rotate(Math.PI/2);ctx.fillStyle='rgba(150,165,175,.35)';ctx.beginPath();ctx.ellipse(fr*0.5,0,fr*0.48,fr*0.20,0,0,Math.PI*2);ctx.fill();}
   ctx.restore();
   ctx.strokeStyle='rgba(120,135,145,.25)';ctx.lineWidth=1;
   for(let i=0;i<5;i++){ctx.beginPath();ctx.arc(fx2,fy2,fr*(0.25+i*0.19),0,Math.PI*2);ctx.stroke();}
   floorDecor(ctx,W*0.14,H*0.88,0.9,'barrel');
   floorDecor(ctx,W*0.30,H*0.94,0.85,'crate');
   floorDecor(ctx,W*0.66,H*0.92,0.85,'bin');
   // катушка кабеля и ведро на полу
   ctx.strokeStyle='#2b343b';ctx.lineWidth=3;
   for(let i=0;i<3;i++){ctx.beginPath();ctx.ellipse(W*0.50,H*0.92,26-i*7,9-i*2.5,0,0,Math.PI*2);ctx.stroke();}
   cameraDecor(ctx,W*0.055,hz*0.16,0.9);
   cameraDecor(ctx,W*0.955,hz*0.14,0.85);
   roomVignette(ctx,W,H,0.66);
   roomLabel(ctx,W,H,'КАМ 05','СЛУЖЕБНАЯ');
 }
 // ===== КАМ 04 — СЦЕНА =====
 function stage(ctx,W,H,t){
   const g=roomShell(ctx,W,H,t,{horizon:0.46,wall:['#1d1a22','#12111a'],wainscot:'#241318',floorFar:'#1a1418',floorNear:'#090a0d',lamps:0,seed:14,atmosX:[0.30,0.50,0.70],warm:[255,190,205],haze:0.06,web:false});
   const hz=g.hz;
   // задник: занавес во всю стену
   const cx0=W*0.06, cw=W*0.88, cy=hz*0.16, ch=hz*0.74;
   const cg=ctx.createLinearGradient(0,cy,0,cy+ch);
   cg.addColorStop(0,'#6d1f28');cg.addColorStop(0.6,'#4d151d');cg.addColorStop(1,'#2a0c11');
   ctx.fillStyle=cg;ctx.fillRect(cx0,cy,cw,ch);
   // складки занавеса
   for(let i=0;i<15;i++){
     const fxp=cx0+cw*(i/15)+cw/30;
     const sh=ctx.createLinearGradient(fxp-cw/30,0,fxp+cw/30,0);
     sh.addColorStop(0,'rgba(0,0,0,.34)');sh.addColorStop(0.5,'rgba(255,170,180,.055)');sh.addColorStop(1,'rgba(0,0,0,.34)');
     ctx.fillStyle=sh;ctx.fillRect(fxp-cw/30,cy,cw/15,ch);
   }
   // ламбрекен с фестонами
   ctx.fillStyle='#7d2530';ctx.fillRect(cx0-W*0.02,cy-hz*0.10,cw+W*0.04,hz*0.12);
   for(let i=0;i<9;i++){
     const sx2=cx0+cw*(i/9)+cw/18;
     ctx.fillStyle='#8c2b36';ctx.beginPath();ctx.arc(sx2,cy+hz*0.015,cw/18,0,Math.PI);ctx.fill();
     ctx.fillStyle='#c8a02c';ctx.beginPath();ctx.arc(sx2,cy+hz*0.015+cw/18,4,0,Math.PI*2);ctx.fill();
   }
   ctx.fillStyle='rgba(255,255,255,.05)';ctx.fillRect(cx0-W*0.02,cy-hz*0.10,cw+W*0.04,3);
   // вывеска
   const bwid=W*0.34, bhei=hz*0.13, bxx=W*0.5-bwid/2, byy=cy-hz*0.055;
   ctx.fillStyle='#12161a';ctx.fillRect(bxx,byy,bwid,bhei);
   ctx.strokeStyle='#c8a02c';ctx.lineWidth=2;ctx.strokeRect(bxx,byy,bwid,bhei);
   text2(ctx,'ПИЦЦА-ПАРК',W*0.5,byy+bhei*0.72,Math.max(13,bhei*0.62),'#e7c85b','center');
   // подиум сцены в перспективе
   const sTop=hz*0.94, sFront=H*0.80;
   ctx.fillStyle='#33231f';ctx.beginPath();ctx.moveTo(W*0.10,sFront);ctx.lineTo(W*0.90,sFront);ctx.lineTo(W*0.83,sTop);ctx.lineTo(W*0.17,sTop);ctx.closePath();ctx.fill();
   // доски подиума
   for(let i=0;i<12;i++){
     const k0=i/12,k1=(i+1)/12;
     ctx.fillStyle=i%2?'#3b2a24':'#2f211c';
     ctx.beginPath();
     ctx.moveTo(W*(0.10+0.80*k0),sFront);ctx.lineTo(W*(0.10+0.80*k1),sFront);
     ctx.lineTo(W*(0.17+0.66*k1),sTop);ctx.lineTo(W*(0.17+0.66*k0),sTop);ctx.closePath();ctx.fill();
   }
   // передний торец сцены с полосами
   ctx.fillStyle='#1b1416';ctx.fillRect(W*0.10,sFront,W*0.80,H*0.075);
   for(let i=0;i<16;i++){ctx.fillStyle=i%2?'#7d2530':'#d8cfc4';ctx.fillRect(W*0.10+i*(W*0.80/16),sFront,W*0.80/16,H*0.020);}
   ctx.fillStyle='rgba(255,255,255,.07)';ctx.fillRect(W*0.10,sFront,W*0.80,2);
   // прожекторы с конусами света
   [[0.30,'#ffd27a'],[0.50,'#ff9aa8'],[0.70,'#8fd0ff']].forEach((sp,i)=>{
     const lx=W*sp[0], ly=hz*0.06, pw2=0.72+0.28*Math.abs(Math.sin(t*(1.6+i*0.4)+i));
     ctx.fillStyle='#232b31';ctx.fillRect(lx-11,ly,22,13);
     ctx.fillStyle='#101519';ctx.fillRect(lx-8,ly+13,16,5);
     ctx.save();ctx.globalCompositeOperation='lighter';
     const cone=ctx.createLinearGradient(lx,ly,lx,sTop);
     cone.addColorStop(0,`rgba(255,220,180,${0.13*pw2})`);
     cone.addColorStop(1,'rgba(255,220,180,0)');
     ctx.fillStyle=cone;
     ctx.beginPath();ctx.moveTo(lx-13,ly+16);ctx.lineTo(lx+13,ly+16);ctx.lineTo(lx+W*0.10,sTop+H*0.02);ctx.lineTo(lx-W*0.10,sTop+H*0.02);ctx.closePath();ctx.fill();
     // цветное пятно на подиуме
     const spot=ctx.createRadialGradient(lx,sTop+H*0.015,3,lx,sTop+H*0.015,W*0.12);
     spot.addColorStop(0,sp[1]+'');spot.addColorStop(1,'rgba(0,0,0,0)');
     ctx.globalAlpha=0.13*pw2;ctx.fillStyle=spot;ctx.fillRect(lx-W*0.12,sTop-H*0.05,W*0.24,H*0.12);ctx.globalAlpha=1;
     ctx.restore();
   });
   // инструменты на сцене: барабаны, микрофон, колонки
   // барабанная установка
   // V99: было — алый эллипс с белым яйцом внутри и жёлтый эллипс на палочке:
   // на камере установка читалась как леденец рядом с шаром. Стало: бочка с обечайкой
   // и крепежами, малый барабан на стойке, том на кронштейне и тарелка на треноге.
   const dx2=W*0.36, dy2=sTop+H*0.005, PI2=Math.PI*2;
   ctx.fillStyle='rgba(0,0,0,.50)';ctx.beginPath();ctx.ellipse(dx2,dy2+4,46,10,0,0,PI2);ctx.fill();
   // — тарелка на треноге (сначала стойка, потом бронза)
   const cyx=dx2+34, cyy=dy2-58;
   ctx.strokeStyle='#4a545b';ctx.lineWidth=2.4;
   ctx.beginPath();ctx.moveTo(cyx,cyy+3);ctx.lineTo(cyx,dy2-12);ctx.stroke();
   ctx.lineWidth=1.8;
   ctx.beginPath();ctx.moveTo(cyx,dy2-12);ctx.lineTo(cyx-11,dy2-1);
   ctx.moveTo(cyx,dy2-12);ctx.lineTo(cyx+11,dy2-1);
   ctx.moveTo(cyx,dy2-12);ctx.lineTo(cyx+2,dy2-2);ctx.stroke();
   ctx.save();ctx.translate(cyx,cyy);ctx.rotate(-0.22);
   const cg2=ctx.createLinearGradient(-18,0,18,0);
   cg2.addColorStop(0,'#8a6b1e');cg2.addColorStop(0.45,'#d4ad3c');cg2.addColorStop(1,'#7d611b');
   ctx.fillStyle=cg2;ctx.beginPath();ctx.ellipse(0,0,18,4.4,0,0,PI2);ctx.fill();
   ctx.fillStyle='rgba(255,238,180,.35)';ctx.beginPath();ctx.ellipse(-4,-1.2,7,1.6,0,0,PI2);ctx.fill();
   ctx.fillStyle='#6b5215';ctx.beginPath();ctx.ellipse(0,0,4,1.8,0,0,PI2);ctx.fill();
   ctx.restore();
   // — бочка
   const bg3=ctx.createLinearGradient(dx2-32,dy2-40,dx2+32,dy2-8);
   bg3.addColorStop(0,'#5e1a22');bg3.addColorStop(0.42,'#a83140');bg3.addColorStop(1,'#54171f');
   ctx.fillStyle=bg3;ctx.beginPath();ctx.ellipse(dx2,dy2-24,32,26,0,0,PI2);ctx.fill();
   // обечайка и крепежи
   ctx.strokeStyle='rgba(214,222,228,.55)';ctx.lineWidth=2.2;
   ctx.beginPath();ctx.ellipse(dx2,dy2-24,25,20,0,0,PI2);ctx.stroke();
   for(let k=0;k<8;k++){
     const a=k*PI2/8+0.2;
     ctx.fillStyle='rgba(198,208,214,.60)';
     ctx.fillRect(dx2+Math.cos(a)*28-1.6,dy2-24+Math.sin(a)*23-2.4,3.2,4.8);
   }
   // пластик с логотипом
   const hg2=ctx.createRadialGradient(dx2-7,dy2-31,2,dx2,dy2-24,24);
   hg2.addColorStop(0,'#efe6d4');hg2.addColorStop(1,'#c3b7a2');
   ctx.fillStyle=hg2;ctx.beginPath();ctx.ellipse(dx2,dy2-24,23,18,0,0,PI2);ctx.fill();
   ctx.fillStyle='rgba(122,38,46,.50)';ctx.beginPath();ctx.ellipse(dx2,dy2-24,11,8,0,0,PI2);ctx.fill();
   ctx.fillStyle='rgba(255,255,255,.20)';ctx.beginPath();ctx.ellipse(dx2-9,dy2-31,7,3.4,-0.4,0,PI2);ctx.fill();
   // лапки бочки
   ctx.fillStyle='#2d363c';ctx.fillRect(dx2-30,dy2-6,7,7);ctx.fillRect(dx2+23,dy2-6,7,7);
   // — том на кронштейне
   // V99: том рисовался ДО бочки, и бочка закрывала и кронштейн, и нижнюю половину
   // барабана — на камере он читался как белое пятно, висящее над установкой.
   // Теперь он рисуется после бочки, а кронштейн виден от обечайки до самого тома.
   ctx.strokeStyle='rgba(0,0,0,.45)';ctx.lineWidth=3.4;
   ctx.beginPath();ctx.moveTo(dx2-15,dy2-40);ctx.lineTo(dx2-31,dy2-56);ctx.stroke();
   ctx.strokeStyle='#4d585f';ctx.lineWidth=2.4;
   ctx.beginPath();ctx.moveTo(dx2-15,dy2-40);ctx.lineTo(dx2-31,dy2-56);ctx.stroke();
   ctx.fillStyle='#7d878e';ctx.fillRect(dx2-19,dy2-43,6,5);      // зажим на обечайке
   const tg=ctx.createLinearGradient(dx2-48,dy2-70,dx2-20,dy2-56);
   tg.addColorStop(0,'#96323d');tg.addColorStop(1,'#5c1c24');
   ctx.fillStyle=tg;ctx.beginPath();ctx.ellipse(dx2-34,dy2-62,15,11,0,0,PI2);ctx.fill();
   ctx.strokeStyle='rgba(206,216,222,.45)';ctx.lineWidth=1.6;
   ctx.beginPath();ctx.ellipse(dx2-34,dy2-64,13.5,7.6,0,0,PI2);ctx.stroke();
   ctx.fillStyle='#b9ae99';ctx.beginPath();ctx.ellipse(dx2-34,dy2-65,13,7,0,0,PI2);ctx.fill();
   ctx.fillStyle='rgba(255,255,255,.16)';ctx.beginPath();ctx.ellipse(dx2-39,dy2-67,5,2.4,-0.3,0,PI2);ctx.fill();
   // — малый барабан справа от бочки
   const sxs=dx2+50, sys=dy2-28;
   ctx.strokeStyle='#454f56';ctx.lineWidth=1.8;
   ctx.beginPath();ctx.moveTo(sxs-7,sys+4);ctx.lineTo(sxs-11,dy2-1);
   ctx.moveTo(sxs+7,sys+4);ctx.lineTo(sxs+11,dy2-1);ctx.stroke();
   const sg2=ctx.createLinearGradient(sxs-14,sys,sxs+14,sys);
   sg2.addColorStop(0,'#6f7a82');sg2.addColorStop(0.45,'#a6b0b7');sg2.addColorStop(1,'#5f6a71');
   ctx.fillStyle=sg2;ctx.fillRect(sxs-14,sys-5,28,10);
   ctx.fillStyle='#c6bca9';ctx.beginPath();ctx.ellipse(sxs,sys-5,14,5,0,0,PI2);ctx.fill();
   ctx.strokeStyle='rgba(226,232,236,.40)';ctx.lineWidth=1.2;
   ctx.beginPath();ctx.ellipse(sxs,sys-5,14,5,0,0,PI2);ctx.stroke();
   ctx.fillStyle='rgba(0,0,0,.35)';ctx.fillRect(sxs-14,sys+3,28,2);
   // микрофонная стойка
   // V99: была одной тонкой линией — читалась как проволока, повисшая в воздухе.
   // Стало: тренога, труба с бликом, зажим, головка с сеткой и витой кабель на полу.
   // V99: опущена до высоты певца (была почти до потолка) и получила треногу.
   const mBase=dy2, mx2=W*0.52, mTop=mBase-58;
   ctx.fillStyle='rgba(0,0,0,.45)';ctx.beginPath();ctx.ellipse(mx2,mBase+2,20,5,0,0,PI2);ctx.fill();
   ctx.strokeStyle='#39434a';ctx.lineWidth=3;
   ctx.beginPath();ctx.moveTo(mx2,mBase-2);ctx.lineTo(mx2-17,mBase+1);
   ctx.moveTo(mx2,mBase-2);ctx.lineTo(mx2+17,mBase+1);
   ctx.moveTo(mx2,mBase-2);ctx.lineTo(mx2+3,mBase+3);ctx.stroke();
   const tube=ctx.createLinearGradient(mx2-3,0,mx2+3,0);
   tube.addColorStop(0,'#2f383e');tube.addColorStop(0.45,'#78838b');tube.addColorStop(1,'#2b343a');
   ctx.fillStyle=tube;ctx.fillRect(mx2-2.6,mTop,5.2,mBase-2-mTop);
   ctx.fillStyle='#98a1a8';ctx.fillRect(mx2-4.5,mBase-44,9,5);            // зажим высоты
   ctx.strokeStyle='#6d777e';ctx.lineWidth=3;
   ctx.beginPath();ctx.moveTo(mx2,mTop+1);ctx.quadraticCurveTo(mx2+11,mTop-5,mx2+17,mTop-6);ctx.stroke();
   ctx.save();ctx.translate(mx2+20,mTop-7);ctx.rotate(0.32);
   ctx.fillStyle='#232b31';ctx.fillRect(-4,-1,8,9);
   const mh=ctx.createRadialGradient(-2,-3,1,0,0,7);
   mh.addColorStop(0,'#b9c2c9');mh.addColorStop(1,'#5e686f');
   ctx.fillStyle=mh;ctx.beginPath();ctx.arc(0,0,6,0,PI2);ctx.fill();
   ctx.strokeStyle='rgba(20,26,30,.55)';ctx.lineWidth=0.9;
   for(let k=-1;k<=1;k++){ctx.beginPath();ctx.moveTo(-5,k*2.4);ctx.lineTo(5,k*2.4);ctx.stroke();}
   ctx.restore();
   ctx.strokeStyle='rgba(20,26,30,.75)';ctx.lineWidth=2;
   ctx.beginPath();ctx.moveTo(mx2+2,mBase-1);ctx.bezierCurveTo(mx2+26,mBase+4,mx2+8,mBase+9,mx2+30,mBase+8);ctx.stroke();
   // колонки по краям сцены
   [[0.19,1.0],[0.81,0.95]].forEach(sp=>{
     const sxx=W*sp[0], sww=W*0.085*sp[1], shh=H*0.16*sp[1];
     ctx.fillStyle='#151b20';ctx.fillRect(sxx-sww/2,dy2-shh,sww,shh);
     ctx.strokeStyle='#39444c';ctx.lineWidth=2;ctx.strokeRect(sxx-sww/2,dy2-shh,sww,shh);
     ctx.fillStyle='#0b0f12';ctx.beginPath();ctx.arc(sxx,dy2-shh*0.66,sww*0.28,0,Math.PI*2);ctx.fill();
     ctx.fillStyle='#222b31';ctx.beginPath();ctx.arc(sxx,dy2-shh*0.66,sww*0.14,0,Math.PI*2);ctx.fill();
     ctx.fillStyle='#0b0f12';ctx.beginPath();ctx.arc(sxx,dy2-shh*0.28,sww*0.18,0,Math.PI*2);ctx.fill();
   });
   // пыль в свете прожекторов
   for(let i=0;i<26;i++){
     const px2=(i*137.5+((t*14)%W))%W, py2=hz*0.2+((i*61+(t*9))%(H*0.55));
     ctx.fillStyle=`rgba(255,236,200,${0.05+0.05*Math.abs(Math.sin(t*1.4+i))})`;ctx.fillRect(px2,py2,2,2);
   }
   floorDecor(ctx,W*0.13,H*0.94,0.9,'crate');
   floorDecor(ctx,W*0.87,H*0.95,0.85,'cone');
   cameraDecor(ctx,W*0.08,hz*0.20,0.95);
   cameraDecor(ctx,W*0.92,hz*0.20,0.9);
   roomVignette(ctx,W,H,0.58);
   roomLabel(ctx,W,H,'КАМ 04','СЦЕНА');
 }
 // ==== КОМНАТА ОХРАНЫ — базовая геометрия: бетонная стена, плинтус и кафель в перспективе ====
 function officeShell(ctx,W,H,t,lights){
   ctx.save();
   // стена: вертикальный градиент + пятна сырости
   const wall=ctx.createLinearGradient(0,H*.10,0,H*.63);
   wall.addColorStop(0,'#101720');wall.addColorStop(.55,'#0d1319');wall.addColorStop(1,'#080d11');
   ctx.fillStyle=wall;ctx.fillRect(0,H*.10,W,H*.53);
   for(let i=0;i<14;i++){
     const px=W*((i*137%100)/100), py=H*(.12+((i*53)%40)/100*.9), r=W*.02+((i*29)%40)/1000*W;
     const st=ctx.createRadialGradient(px,py,2,px,py,r);
     st.addColorStop(0,'rgba(24,33,39,.38)');st.addColorStop(1,'rgba(24,33,39,0)');
     ctx.fillStyle=st;ctx.beginPath();ctx.arc(px,py,r,0,Math.PI*2);ctx.fill();
   }
   // горизонтальный отбойный рельс вдоль стены
   ctx.fillStyle='#151d23';ctx.fillRect(0,H*.455,W,H*.016);
   ctx.fillStyle='rgba(255,255,255,.05)';ctx.fillRect(0,H*.455,W,2);
   // V82: облупившаяся краска на отбойном рельсе и тёмные потёки ржавчины
   for(let i=0;i<28;i++){
     const rx=W*((i*73%100)/100), rw=W*.004+((i*31)%30)/1000*W, rh=H*(.008+((i*19)%22)/1000);
     ctx.fillStyle=`rgba(18,12,8,${0.18+((i*7)%10)/50})`;
     ctx.fillRect(rx,H*.455+rh*0.4,rw,rh);
   }
   // трещины в стене: тонкие тёмные линии, расходящиеся от случайных точек
   ctx.strokeStyle='rgba(6,4,3,.20)';ctx.lineWidth=1;
   for(let i=0;i<9;i++){
     const cx=W*((i*211%100)/100), cy=H*(.16+((i*43)%30)/100), len=H*((i*17)%8)/100+.01;
     ctx.beginPath();ctx.moveTo(cx,cy);
     ctx.lineTo(cx+((i%2)?1:-1)*len*.5,cy+len);
     ctx.lineTo(cx+((i%2)?1:-1)*len*.9-len*.2,cy+len*1.6);
     ctx.stroke();
   }
   // V82: тёмные сырые пятна под потолком и у плинтуса (плесень)
   for(let i=0;i<10;i++){
     const mx=W*((i*97%100)/100), my=H*(.14+((i*53)%8)/100), mw=W*.04+((i*29)%30)/1000*W;
     const mg=ctx.createRadialGradient(mx,my,1,mx,my,mw);
     mg.addColorStop(0,'rgba(10,14,8,.34)');mg.addColorStop(1,'rgba(10,14,8,0)');
     ctx.fillStyle=mg;ctx.beginPath();ctx.ellipse(mx,my,mw,mw*.5,0,0,Math.PI*2);ctx.fill();
   }
   // плинтус
   ctx.fillStyle='#0d1316';ctx.fillRect(0,H*.60,W,H*.035);
   ctx.fillStyle='rgba(150,168,178,.10)';ctx.fillRect(0,H*.60,W,2);
   // пол: тёмная кафельная шашка в перспективе
   const fy=H*.635, vpX=W*.5, vpY=H*.44;
   const fl=ctx.createLinearGradient(0,fy,0,H);
   fl.addColorStop(0,'#11161a');fl.addColorStop(.45,'#0c1114');fl.addColorStop(1,'#070a0c');
   ctx.fillStyle=fl;ctx.fillRect(0,fy,W,H-fy);
   ctx.save();ctx.beginPath();ctx.rect(0,fy,W,H-fy);ctx.clip();
   // поперечные швы со сгущением к горизонту
   const rows=9;
   for(let i=0;i<=rows;i++){
     const k=i/rows, yy=fy+(H-fy)*Math.pow(k,1.7);
     ctx.strokeStyle=`rgba(120,140,152,${0.05+0.09*k})`;ctx.lineWidth=1;
     ctx.beginPath();ctx.moveTo(0,yy);ctx.lineTo(W,yy);ctx.stroke();
     // шашка: светлее плиты через одну
     if(i<rows){
       const yy2=fy+(H-fy)*Math.pow((i+1)/rows,1.7), cols=10;
       for(let j=0;j<cols;j++){
         if((i+j)%2)continue;
         const a=(j/cols-.5), b=((j+1)/cols-.5);
         const x1=vpX+a*W*(1+ (yy-vpY)/(H*.5)), x2=vpX+b*W*(1+ (yy-vpY)/(H*.5));
         const x3=vpX+b*W*(1+ (yy2-vpY)/(H*.5)), x4=vpX+a*W*(1+ (yy2-vpY)/(H*.5));
         ctx.fillStyle=`rgba(150,170,182,${0.020+0.020*k})`;
         ctx.beginPath();ctx.moveTo(x1,yy);ctx.lineTo(x2,yy);ctx.lineTo(x3,yy2);ctx.lineTo(x4,yy2);ctx.closePath();ctx.fill();
       }
     }
   }
   // сходящиеся швы
   for(let j=0;j<=10;j++){
     const a=(j/10-.5);
     ctx.strokeStyle='rgba(120,140,152,.07)';ctx.beginPath();
     ctx.moveTo(vpX+a*W*(1+(fy-vpY)/(H*.5)),fy);ctx.lineTo(vpX+a*W*(1+(H-vpY)/(H*.5)),H);ctx.stroke();
   }
   // блики от ламп на мокроватом кафеле
   ['left','right'].forEach(side=>{
     const l=lights&&lights[side];if(!l||!l.on||l.renderOff)return;
     const gx=side==='left'?W*.135:W*.865;
     const g=ctx.createLinearGradient(gx,fy,gx,H*.95);
     g.addColorStop(0,'rgba(255,222,90,.075)');g.addColorStop(1,'rgba(255,200,40,0)');
     ctx.fillStyle=g;ctx.beginPath();ctx.moveTo(gx-W*.05,fy);ctx.lineTo(gx+W*.05,fy);ctx.lineTo(gx+W*.14,H*.95);ctx.lineTo(gx-W*.14,H*.95);ctx.closePath();ctx.fill();
   });
   ctx.restore();
   // V82: мокрые тёмные лужи на полу и разводы грязи по швам кафеля
   ctx.save();
   for(let i=0;i<5;i++){
     const px=W*((i*131%100)/100), py=fy+(H-fy)*(.2+((i*47)%60)/100), pw=W*.05+((i*23)%30)/1000*W;
     const pg=ctx.createRadialGradient(px,py,1,px,py,pw);
     pg.addColorStop(0,'rgba(2,4,5,.40)');pg.addColorStop(.7,'rgba(2,4,5,.12)');pg.addColorStop(1,'rgba(2,4,5,0)');
     ctx.fillStyle=pg;ctx.save();ctx.translate(px,py);ctx.scale(1,.35);ctx.translate(-px,-py);
     ctx.fillRect(px-pw,py-pw*.6,pw*2,pw*1.2);ctx.restore();
   }
   // блик сырой плёнки на полу (лёгкое отражение света)
   // V110: сила блика из настройки ОТРАЖЕНИЯ.
   ctx.globalCompositeOperation='lighter';
   const _rf=(window.GFX?.reflect??1);
   const wg=ctx.createLinearGradient(0,fy,0,H);
   wg.addColorStop(0,'rgba(80,100,112,'+(0.03*_rf).toFixed(4)+')');wg.addColorStop(1,'rgba(80,100,112,0)');
   ctx.fillStyle=wg;ctx.fillRect(0,fy,W,H-fy);
   ctx.restore();
   ctx.restore();
 }
 // ==== КОМНАТА ОХРАНЫ — обстановка: пробковая доска, вентилятор, лампа, кружка, трубы ====
// V114: РИСУНОК ИГРОКА КЭШИРУЕТСЯ В ОТДЕЛЬНЫЙ ХОЛСТ.
// Офис перерисовывается каждый кадр (карандаш качается, рамка дышит), поэтому
// прогонять до 60 штрихов по 400 точек шестьдесят раз в секунду было бы
// заметной просадкой на слабых машинах. Рисунок собирается один раз и потом
// просто копируется одной операцией. Пересборка — только когда меняется
// G.sketch.rev (новый штрих, очистка, загрузка из сохранения) или размер окна.
let _pskCanvas=null,_pskRev=-1,_pskW=0,_pskH=0;
function playerSketchCanvas(dw,dh){
 const G=window.NightShift;
 const sk=(G&&G.sketch&&G.sketch.strokes)||[];
 const rev=(G&&G.sketch&&G.sketch.rev)|0;
 const w=Math.max(4,Math.round(dw)),h=Math.max(4,Math.round(dh));
 if(_pskRev===rev&&_pskW===w&&_pskH===h)return _pskCanvas;
 _pskRev=rev;_pskW=w;_pskH=h;
 if(!sk.length){_pskCanvas=null;return null}
 let c=_pskCanvas;
 if(!c||c.width!==w||c.height!==h){c=document.createElement('canvas');c.width=w;c.height=h;}
 const g=c.getContext('2d');
 g.clearRect(0,0,w,h);
 g.lineCap='round';g.lineJoin='round';
 // Толщина уменьшена пропорционально: листок на стене в разы меньше рабочего
 // листа, иначе любой штрих превращался бы в кляксу.
 const k=Math.max(.28,w/260);
 for(let i=0;i<sk.length;i++){
  const st=sk[i];if(!st||!st.pts||!st.pts.length)continue;
  g.strokeStyle=st.color||'#3a3a34';
  g.lineWidth=Math.max(.7,(st.size||3)*k);
  g.beginPath();
  const p0=st.pts[0];g.moveTo(p0[0]*w,p0[1]*h);
  if(st.pts.length===1)g.lineTo(p0[0]*w+.6,p0[1]*h+.6);
  else for(let j=1;j<st.pts.length;j++)g.lineTo(st.pts[j][0]*w,st.pts[j][1]*h);
  g.stroke();
 }
 _pskCanvas=c;return c;
}
 function officeProps(ctx,W,H,t){
   const low=document.body.classList.contains('low-end');
   ctx.save();
   // трубы под потолком с вентилями
   ctx.fillStyle='#1a2328';ctx.fillRect(0,H*.165,W,H*.018);
   ctx.fillStyle='rgba(255,255,255,.06)';ctx.fillRect(0,H*.165,W,2);
   [W*.14,W*.32,W*.50,W*.68,W*.86].forEach(px=>{ctx.fillStyle='#212b31';ctx.fillRect(px,H*.160,8,H*.024);ctx.fillStyle='#141c20';ctx.fillRect(px+2,H*.180,4,H*.010);});
   // пробковая доска с бумагами и детским рисунком
   const bx=W*.315, by=H*.250, bw=W*.036, bh=H*.092;
   ctx.fillStyle='#4a3a24';ctx.fillRect(bx-4,by-4,bw+8,bh+8);
   ctx.fillStyle='#6e5636';ctx.fillRect(bx,by,bw,bh);
   ctx.fillStyle='rgba(0,0,0,.18)';for(let i=0;i<40;i++)ctx.fillRect(bx+((i*67)%100)/100*bw,by+((i*41)%100)/100*bh,2,2);
   // три листка
   const sheets=[[.06,.10,.34,.42,-0.05],[.44,.07,.30,.36,0.06],[.14,.58,.36,.32,0.02]];
   sheets.forEach(s=>{
     ctx.save();ctx.translate(bx+bw*s[0],by+bh*s[1]);ctx.rotate(s[4]);
     ctx.fillStyle='rgba(0,0,0,.35)';ctx.fillRect(2,3,bw*s[2],bh*s[3]);
     ctx.fillStyle='#cdc7b6';ctx.fillRect(0,0,bw*s[2],bh*s[3]);
     ctx.fillStyle='rgba(60,60,55,.45)';for(let r=0;r<4;r++)ctx.fillRect(bw*s[2]*.12,bh*s[3]*(.22+r*.18),bw*s[2]*.72,1.5);
     ctx.fillStyle='#b03a44';ctx.beginPath();ctx.arc(bw*s[2]*.5,-2,3,0,Math.PI*2);ctx.fill();
     ctx.restore();
   });
   // V114: НА ЛИСТКЕ ТЕПЕРЬ РИСУНОК САМОГО ИГРОКА.
   // ПОЧЕМУ ТАК БЫЛО: здесь всегда были нарисованы три человечка и солнце, а то,
   // что игрок рисовал на этой же доске, не появлялось нигде — рисование ни на
   // что не влияло.
   // СТАЛО: сюда переносятся штрихи из G.sketch.strokes (нормализованные [0..1]
   // координаты листа масштабируются в dw x dh). Если игрок нажал «ОЧИСТИТЬ» и
   // ничего не нарисовал — на кнопке остаётся просто чистый лист, никаких
   // человечков. Кнопка на самом деле стирает картинку, как и просили.
   ctx.save();ctx.translate(bx+bw*.60,by+bh*.52);ctx.rotate(-0.04);
   const dw=bw*.34,dh=bh*.40;
   ctx.fillStyle='rgba(0,0,0,.35)';ctx.fillRect(2,3,dw,dh);
   ctx.fillStyle='#e6dfc9';ctx.fillRect(0,0,dw,dh);
   {
    const c=playerSketchCanvas(dw,dh);
    if(c)ctx.drawImage(c,0,0,dw,dh);
   }
   ctx.fillStyle='#b03a44';ctx.beginPath();ctx.arc(dw*.5,-2,3,0,Math.PI*2);ctx.fill();
   ctx.restore();
   // V113: КАРАНДАШ НА ВЕРЁВОЧКЕ под доской — намёк, что доска кликабельна
   // и на ней можно рисовать. Едва заметно покачивается, как от сквозняка
   // ночного офиса, плюс лёгкая тёплая подсветка рамки, чтобы глаз зацепился.
   {
    const pinX=bx+bw*.5, pinY=by+bh+3;
    const sw=Math.sin(t*.85)*.09+Math.sin(t*.47)*.05; // угол качания
    const sl=H*.026; // длина верёвочки
    const ex=pinX+Math.sin(sw)*sl, ey=pinY+Math.cos(sw)*sl;
    ctx.strokeStyle='#8d7b57';ctx.lineWidth=1;
    ctx.beginPath();ctx.moveTo(pinX,pinY);ctx.lineTo(ex,ey);ctx.stroke();
    ctx.save();ctx.translate(ex,ey);ctx.rotate(sw*.6);
    const pl=Math.max(26,bw*.62); // длина карандаша
    ctx.fillStyle='rgba(0,0,0,.30)';ctx.fillRect(-pl*.5-1,1,pl+6,5); // тень
    ctx.fillStyle='#c9995a';ctx.fillRect(-pl*.5,-2.4,pl,4.8); // корпус
    ctx.fillStyle='#a8813f';ctx.fillRect(-pl*.5,-2.4,pl*.10,4.8); // ребро
    ctx.fillStyle='#e8d9b0';ctx.fillRect(pl*.5-6,-2.4,6,4.8); // дерево у грифеля
    ctx.fillStyle='#3a3430';ctx.beginPath();ctx.moveTo(pl*.5,-2.4);ctx.lineTo(pl*.5+5,0);ctx.lineTo(pl*.5,2.4);ctx.closePath();ctx.fill(); // грифель
    ctx.fillStyle='#a33f3f';ctx.fillRect(-pl*.5,-2.4,pl*.14,4.8); // ластик
    ctx.restore();
    // тёплое дыхание рамки — очень слабое, чтобы не ломать мрак смены
    const pulse=.5+.5*Math.sin(t*1.6);
    ctx.strokeStyle=`rgba(217,169,58,${(.06+.09*pulse).toFixed(3)})`;
    ctx.lineWidth=2;ctx.strokeRect(bx-5,by-5,bw+10,bh+10);
   }
   // настенные часы без цифр
   const cx=W*.645, cy=H*.275, cr=Math.min(W*.008,H*.030);
   ctx.fillStyle='#0c1114';ctx.beginPath();ctx.arc(cx,cy,cr+4,0,Math.PI*2);ctx.fill();
   ctx.fillStyle='#20282d';ctx.beginPath();ctx.arc(cx,cy,cr,0,Math.PI*2);ctx.fill();
   ctx.strokeStyle='#57646c';ctx.lineWidth=2;ctx.beginPath();ctx.arc(cx,cy,cr,0,Math.PI*2);ctx.stroke();
   ctx.strokeStyle='#93a4ad';ctx.lineWidth=2;
   ctx.beginPath();ctx.moveTo(cx,cy);ctx.lineTo(cx+Math.sin(t*.05)*cr*.55,cy-Math.cos(t*.05)*cr*.55);ctx.stroke();
   ctx.strokeStyle='#cfd9de';ctx.lineWidth=1.5;
   ctx.beginPath();ctx.moveTo(cx,cy);ctx.lineTo(cx+Math.sin(t*.6)*cr*.8,cy-Math.cos(t*.6)*cr*.8);ctx.stroke();
   ctx.fillStyle='#c1332f';ctx.beginPath();ctx.arc(cx,cy,2.5,0,Math.PI*2);ctx.fill();
   // вентилятор на стене — лопасти крутятся
   const fx2=W*.425, fy3=H*.295, fr=Math.min(W*.009,H*.032);
   ctx.fillStyle='#0b1013';ctx.beginPath();ctx.arc(fx2,fy3,fr+5,0,Math.PI*2);ctx.fill();
   ctx.save();ctx.translate(fx2,fy3);ctx.rotate(t*2.2);
   ctx.fillStyle='#39464d';for(let i=0;i<4;i++){ctx.rotate(Math.PI/2);ctx.beginPath();ctx.ellipse(fr*.5,0,fr*.5,fr*.20,0,0,Math.PI*2);ctx.fill();}
   ctx.restore();
   ctx.strokeStyle='#4d5a61';ctx.lineWidth=1;for(let i=1;i<=3;i++){ctx.beginPath();ctx.arc(fx2,fy3,fr*(i/3),0,Math.PI*2);ctx.stroke();}
   ctx.fillStyle='#5c6a71';ctx.beginPath();ctx.arc(fx2,fy3,3,0,Math.PI*2);ctx.fill();
   // настольная лампа с тёплым конусом света на стол
   const lx=W*.672, ly=H*.525;
   ctx.strokeStyle='#232d33';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(lx,ly);ctx.lineTo(lx-W*.005,ly-H*.030);ctx.lineTo(lx+W*.007,ly-H*.048);ctx.stroke();
   ctx.fillStyle='#2a363e';ctx.beginPath();ctx.moveTo(lx+W*.002,ly-H*.046);ctx.lineTo(lx+W*.017,ly-H*.040);ctx.lineTo(lx+W*.013,ly-H*.028);ctx.lineTo(lx-W*.002,ly-H*.035);ctx.closePath();ctx.fill();
   ctx.fillStyle='#ffe9a8';ctx.beginPath();ctx.ellipse(lx+W*.007,ly-H*.032,W*.004,H*.004,0,0,Math.PI*2);ctx.fill();
   // V98: конус света был ОДНИМ многоугольником с альфой 0.22 и градиентом
   // только по вертикали. Боковые кромки оставались резкими, и на тёмном столе
   // это читалось как плоский бежевый клин, приставленный к вентилятору, а не
   // как свет. Стало: три вложенных конуса разной ширины с альфой 0.07 —
   // их наложение даёт мягкий спад к краям, — и отдельное свечение у самой
   // лампочки.
   ctx.save();ctx.globalCompositeOperation='lighter';
   for(const cw of [[1.00,.055],[0.72,.060],[0.44,.065]]){
     const kx=cw[0];
     const lampCone=ctx.createLinearGradient(lx+W*.007,ly-H*.032,lx+W*.010,ly+H*.045);
     lampCone.addColorStop(0,'rgba(255,226,140,'+cw[1].toFixed(3)+')');
     lampCone.addColorStop(0.65,'rgba(255,214,110,'+(cw[1]*0.45).toFixed(3)+')');
     lampCone.addColorStop(1,'rgba(255,200,60,0)');
     ctx.fillStyle=lampCone;ctx.beginPath();
     ctx.moveTo(lx-W*.001,ly-H*.030);
     ctx.lineTo(lx+W*.015,ly-H*.028);
     ctx.lineTo(lx+W*(.007+.029*kx),ly+H*.045);
     ctx.lineTo(lx+W*(.007-.027*kx),ly+H*.045);
     ctx.closePath();ctx.fill();
   }
   {const bulb=ctx.createRadialGradient(lx+W*.007,ly-H*.032,1,lx+W*.007,ly-H*.032,W*.016);
    bulb.addColorStop(0,'rgba(255,238,180,.35)');bulb.addColorStop(1,'rgba(255,200,60,0)');
    ctx.fillStyle=bulb;ctx.beginPath();ctx.arc(lx+W*.007,ly-H*.032,W*.016,0,Math.PI*2);ctx.fill();}
   const pool=ctx.createRadialGradient(lx+W*.008,ly+H*.030,2,lx+W*.008,ly+H*.030,W*.030);
   pool.addColorStop(0,'rgba(255,224,130,.18)');pool.addColorStop(1,'rgba(255,200,60,0)');
   ctx.fillStyle=pool;ctx.beginPath();ctx.ellipse(lx+W*.008,ly+H*.030,W*.030,H*.016,0,0,Math.PI*2);ctx.fill();
   ctx.restore();
   // кружка с паром
   const mx=W*.300, my=H*.565;
   ctx.fillStyle='#20282d';ctx.fillRect(mx,my,W*.008,H*.020);
   ctx.fillStyle='#2c363c';ctx.fillRect(mx,my,W*.008,H*.004);
   ctx.strokeStyle='#20282d';ctx.lineWidth=2;ctx.beginPath();ctx.arc(mx+W*.009,my+H*.008,H*.006,-1.2,1.2);ctx.stroke();
   if(!low){
     ctx.strokeStyle='rgba(200,214,220,.16)';ctx.lineWidth=2;
     for(let i=0;i<2;i++){
       ctx.beginPath();
       for(let s=0;s<=6;s++){
         const yy=my-s*H*.006, xx=mx+W*.004+Math.sin(t*1.4+s*.9+i*2)*W*.003;
         s?ctx.lineTo(xx,yy):ctx.moveTo(xx,yy);
       }
       ctx.stroke();
     }
   }
   // ---- вещи на столешнице перед мониторами ----
   // стопка бумаг
   [[.345,.586,-0.06],[.353,.592,0.06],[.341,.596,0.01]].forEach(p=>{
     ctx.save();ctx.translate(W*p[0],H*p[1]);ctx.rotate(p[2]);
     ctx.fillStyle='rgba(0,0,0,.5)';ctx.fillRect(2,2,W*.015,H*.020);
     ctx.fillStyle='#8b8879';ctx.fillRect(0,0,W*.015,H*.020);
     ctx.fillStyle='rgba(40,42,40,.40)';for(let r=0;r<3;r++)ctx.fillRect(W*.002,H*.004+r*H*.005,W*.011,1.1);
     ctx.restore();
   });
   // V98: журнал смены был одним бежевым прямоугольником 56x38 с тремя
   // полосками — на кадре это плоская картонка без толщины и тени. Стало:
   // три листа с разным поворотом, тень под стопкой, строки записей, скрепка и
   // подпись от руки на верхнем листе.
   ctx.save();ctx.translate(W*.263,H*.600);
   ctx.fillStyle='rgba(0,0,0,.45)';ctx.fillRect(-26,-16,58,40);
   [[-3,4,-0.05,'#9c9483'],[2,2,0.04,'#aaa291'],[0,0,0.00,'#c3bba8']].forEach(sh=>{
     ctx.save();ctx.translate(sh[0],sh[1]);ctx.rotate(sh[2]);
     ctx.fillStyle=sh[3];ctx.fillRect(-27,-18,54,37);
     ctx.fillStyle='rgba(0,0,0,.18)';ctx.fillRect(-27,17,54,2);
     ctx.restore();
   });
   ctx.fillStyle='rgba(60,60,55,.55)';                       // строки записей
   for(let r=0;r<6;r++)ctx.fillRect(-21,-12+r*5,r%2?36:42,1.4);
   ctx.strokeStyle='rgba(40,44,44,.55)';ctx.lineWidth=1.2;   // подпись от руки
   ctx.beginPath();ctx.moveTo(-18,13);
   for(let k=1;k<=8;k++)ctx.lineTo(-18+k*3.4,13+Math.sin(k*1.7)*2.4);
   ctx.stroke();
   ctx.strokeStyle='#8d979c';ctx.lineWidth=1.6;              // скрепка
   ctx.beginPath();ctx.moveTo(12,-20);ctx.lineTo(12,-9);ctx.lineTo(17,-9);ctx.lineTo(17,-18);ctx.stroke();
   ctx.restore();
   // V98: клавиатура была прямоугольником с двенадцатью квадратиками в два
   // ряда. Стало: корпус с фаской и тенью, четыре ряда клавиш с пробелом,
   // светодиоды и провод, уходящий к столу.
   {const kx=W*.300,ky=H*.606,kw=70,kh=24;
    ctx.fillStyle='rgba(0,0,0,.45)';ctx.fillRect(kx+2,ky+kh-2,kw,4);
    const kb=ctx.createLinearGradient(kx,ky,kx,ky+kh);
    kb.addColorStop(0,'#2b343a');kb.addColorStop(.45,'#1d252a');kb.addColorStop(1,'#12181b');
    ctx.fillStyle=kb;ctx.fillRect(kx,ky,kw,kh);
    ctx.fillStyle='rgba(255,255,255,.07)';ctx.fillRect(kx,ky,kw,1.5);
    for(let r=0;r<3;r++){
      const n=r===0?12:11, ox=kx+4+(r===1?2:r===2?4:0);
      for(let i=0;i<n;i++){
        ctx.fillStyle=(r+i)%2?'#59656d':'#4b565e';
        ctx.fillRect(ox+i*5.2,ky+4+r*5,4.0,3.7);
        ctx.fillStyle='rgba(255,255,255,.10)';ctx.fillRect(ox+i*5.2,ky+4+r*5,4.0,1.0);
      }
    }
    ctx.fillStyle='#5a666e';ctx.fillRect(kx+18,ky+19.5,34,3.0);    // пробел
    ctx.fillStyle='rgba(255,255,255,.10)';ctx.fillRect(kx+18,ky+19.5,34,0.9);
    ctx.fillStyle='#63d08e';ctx.fillRect(kx+kw-9,ky+1.8,2.4,1.8);  // светодиоды
    ctx.fillStyle='#3f6a7a';ctx.fillRect(kx+kw-5,ky+1.8,2.4,1.8);
    ctx.strokeStyle='#20282d';ctx.lineWidth=2;                     // провод
    ctx.beginPath();ctx.moveTo(kx+kw*.5,ky);
    ctx.bezierCurveTo(kx+kw*.6,ky-H*.012,kx+kw*.2,ky-H*.016,kx-W*.006,ky-H*.006);ctx.stroke();}
   // коробка пиццы с приподнятой крышкой
   const pz=W*.648, pzy=H*.588, pzw=W*.026, pzh=H*.017;
   ctx.fillStyle='rgba(0,0,0,.5)';ctx.fillRect(pz+2,pzy+3,pzw,pzh);
   ctx.fillStyle='#7d603c';ctx.fillRect(pz,pzy,pzw,pzh);
   ctx.fillStyle='#8f6f46';ctx.beginPath();
   ctx.moveTo(pz,pzy);ctx.lineTo(pz+pzw,pzy);ctx.lineTo(pz+pzw*.92,pzy-pzh*.85);ctx.lineTo(pz+pzw*.10,pzy-pzh*.85);ctx.closePath();ctx.fill();
   ctx.strokeStyle='rgba(0,0,0,.40)';ctx.lineWidth=1;ctx.strokeRect(pz+.5,pzy+.5,pzw-1,pzh-1);
   ctx.fillStyle='rgba(176,58,68,.55)';ctx.beginPath();ctx.ellipse(pz+pzw*.5,pzy-pzh*.42,pzw*.16,pzh*.16,0,0,Math.PI*2);ctx.fill();
   // рация с мигающим диодом
   const rx=W*.620, ry=H*.582;
   ctx.fillStyle='rgba(0,0,0,.5)';ctx.fillRect(rx+2,ry+3,W*.008,H*.022);
   ctx.fillStyle='#1c2429';ctx.fillRect(rx,ry,W*.008,H*.022);
   ctx.fillStyle='#2b353b';ctx.fillRect(rx+W*.001,ry+H*.003,W*.006,H*.006);
   ctx.fillStyle='#141a1e';ctx.fillRect(rx+W*.003,ry-H*.011,W*.0016,H*.011);
   const led=.30+.70*Math.pow(Math.max(0,Math.sin(t*2.4)),4);
   ctx.fillStyle=`rgba(80,220,120,${led.toFixed(2)})`;ctx.beginPath();ctx.arc(rx+W*.004,ry+H*.015,1.8,0,Math.PI*2);ctx.fill();
   // ручки
   ctx.strokeStyle='#2a3238';ctx.lineWidth=2;
   ctx.beginPath();ctx.moveTo(W*.372,H*.600);ctx.lineTo(W*.384,H*.603);ctx.stroke();
   ctx.strokeStyle='#3a444b';ctx.beginPath();ctx.moveTo(W*.374,H*.607);ctx.lineTo(W*.387,H*.604);ctx.stroke();
   // следы от кружки
   ctx.strokeStyle='rgba(90,70,45,.26)';ctx.lineWidth=1.4;
   [[.396,.606,.006],[.410,.598,.0045],[.600,.608,.005]].forEach(c=>{
     ctx.beginPath();ctx.ellipse(W*c[0],H*c[1],W*c[2],H*c[2]*.45,0,0,Math.PI*2);ctx.stroke();
   });
   // кабели, уходящие со стола вниз
   ctx.strokeStyle='rgba(10,14,17,.85)';ctx.lineWidth=2.2;
   [[.366,.410],[.606,.664]].forEach(c=>{
     ctx.beginPath();ctx.moveTo(W*c[0],H*.575);
     ctx.bezierCurveTo(W*(c[0]+.01),H*.612,W*(c[1]-.01),H*.606,W*c[1],H*.628);ctx.stroke();
   });
   // V82: царапины и потёртости на столешнице
   ctx.strokeStyle='rgba(10,14,17,.30)';ctx.lineWidth=1;
   for(let i=0;i<16;i++){
     const sx=W*(.30+((i*79)%36)/100), sy=H*(.575+((i*43)%30)/1000), len=W*.006+((i*17)%12)/1000*W;
     ctx.beginPath();ctx.moveTo(sx,sy);ctx.lineTo(sx+len,sy+((i%2)?1:-1)*1.2);ctx.stroke();
   }
   // потемневшие пятна от пролитого кофе на столе
   for(let i=0;i<6;i++){
     const sx=W*(.33+((i*97)%34)/100), sy=H*(.585+((i*53)%14)/1000), sr=W*.004+((i*29)%8)/1000*W;
     const sg=ctx.createRadialGradient(sx,sy,1,sx,sy,sr);
     sg.addColorStop(0,'rgba(40,24,10,.42)');sg.addColorStop(1,'rgba(40,24,10,0)');
     ctx.fillStyle=sg;ctx.beginPath();ctx.ellipse(sx,sy,sr,sr*.5,0,0,Math.PI*2);ctx.fill();
   }
   // пыль в воздухе
   if(!low){
     for(let i=0;i<26;i++){
       const seed=i*7.13, sx=(W*((i*61)%100)/100+Math.sin(t*.25+seed)*W*.012)%W;
       const sy=H*.20+((i*37)%100)/100*H*.42+Math.cos(t*.19+seed)*H*.012;
       ctx.fillStyle=`rgba(200,214,222,${0.05+0.05*Math.abs(Math.sin(t*.6+seed))})`;
       ctx.fillRect(sx,sy,2,2);
     }
   }
   ctx.restore();
 }
 // V82: густая паутина по верхним углам комнаты охраны
 function officeWebs(ctx,W,H){
   ctx.save();ctx.strokeStyle='rgba(196,206,214,.06)';ctx.lineWidth=1;
   [[0,0,1,1],[W,0,-1,1],[0,H,1,-1],[W,H,-1,-1]].forEach(([sx,sy,dx,dy])=>{
     const R=Math.min(W,H)*0.16;
     for(let k=1;k<=5;k++){ctx.beginPath();ctx.arc(sx,sy,R*k/5,0,Math.PI*2);ctx.stroke();}
     for(let a=0;a<6;a++){
       const ang=a*Math.PI/3+(dx<0?Math.PI:0)+(dy<0?Math.PI:0);
       ctx.beginPath();ctx.moveTo(sx,sy);ctx.lineTo(sx+Math.cos(ang)*R,sy+Math.sin(ang)*R);ctx.stroke();
     }
   });
   ctx.restore();
 }
 // ==== КОМНАТА ОХРАНЫ — дополнительная обстановка на стенах ====
 function officeWallProps(ctx,W,H,t){
   const low=document.body.classList.contains('low-end');
   ctx.save();
   // предупреждающая штриховка узкой полосой по отбойному рельсу
   ctx.save();ctx.beginPath();ctx.rect(0,H*.455,W,H*.016);ctx.clip();
   for(let i=0;i<Math.ceil(W/(W*.012))+2;i++){
     ctx.fillStyle=i%2?'rgba(196,166,54,.10)':'rgba(14,19,23,.35)';
     ctx.save();ctx.translate(i*W*.012,H*.455);ctx.transform(1,0,-0.5,1,0,0);
     ctx.fillRect(0,0,W*.006,H*.016);ctx.restore();
   }
   ctx.restore();
   // технический щиток на стене
   const bx2=W*.545, by2=H*.330, bw2=W*.042, bh2=H*.070;
   ctx.fillStyle='rgba(0,0,0,.40)';ctx.fillRect(bx2+3,by2+4,bw2,bh2);
   const bg2=ctx.createLinearGradient(bx2,by2,bx2+bw2,by2+bh2);bg2.addColorStop(0,'#232d34');bg2.addColorStop(1,'#141c22');
   ctx.fillStyle=bg2;ctx.fillRect(bx2,by2,bw2,bh2);
   ctx.strokeStyle='rgba(150,170,182,.14)';ctx.lineWidth=1;ctx.strokeRect(bx2+.5,by2+.5,bw2-1,bh2-1);
   ctx.strokeStyle='rgba(0,0,0,.45)';ctx.beginPath();ctx.moveTo(bx2+bw2*.5,by2);ctx.lineTo(bx2+bw2*.5,by2+bh2);ctx.stroke();
   ctx.fillStyle='#3a464e';ctx.fillRect(bx2+bw2*.44,by2+bh2*.45,bw2*.12,bh2*.10);
   [['#48c06a',0],['#c9a12b',.9],['#b8443c',1.8]].forEach((p,i)=>{
     const on=.35+.65*Math.abs(Math.sin(t*1.1+p[1]));
     ctx.fillStyle=p[0];ctx.globalAlpha=on;ctx.beginPath();
     ctx.arc(bx2+bw2*.18,by2+bh2*(.22+i*.22),2.2,0,Math.PI*2);ctx.fill();ctx.globalAlpha=1;
   });
   // предупреждающий треугольник на стене
   const tgx=W*.612, tgy=H*.250, tgs=H*.038;
   ctx.fillStyle='rgba(0,0,0,.35)';ctx.beginPath();
   ctx.moveTo(tgx+2,tgy-tgs*.55+3);ctx.lineTo(tgx+tgs*.6+2,tgy+tgs*.55+3);ctx.lineTo(tgx-tgs*.6+2,tgy+tgs*.55+3);ctx.closePath();ctx.fill();
   ctx.fillStyle='rgba(196,166,54,.32)';ctx.beginPath();
   ctx.moveTo(tgx,tgy-tgs*.55);ctx.lineTo(tgx+tgs*.6,tgy+tgs*.55);ctx.lineTo(tgx-tgs*.6,tgy+tgs*.55);ctx.closePath();ctx.fill();
   ctx.fillStyle='rgba(12,16,18,.75)';ctx.fillRect(tgx-tgs*.05,tgy-tgs*.24,tgs*.10,tgs*.44);
   ctx.beginPath();ctx.arc(tgx,tgy+tgs*.34,tgs*.06,0,Math.PI*2);ctx.fill();
   ctx.restore();
   // светящиеся аварийные табло-пиктограммы над проёмами (без текста)
   [[W*.316,-1],[W*.684,1]].forEach(([ex,dir])=>{
     const ew=W*.026, eh=H*.028, ey=H*.205;
     ctx.fillStyle='#0a1210';ctx.fillRect(ex-ew/2-2,ey-2,ew+4,eh+4);
     const eg=ctx.createLinearGradient(0,ey,0,ey+eh);eg.addColorStop(0,'#123024');eg.addColorStop(1,'#0a1c13');
     ctx.fillStyle=eg;ctx.fillRect(ex-ew/2,ey,ew,eh);
     const pulse=.82+.18*Math.sin(t*1.7+dir);
     ctx.save();ctx.shadowColor='rgba(70,235,150,.85)';ctx.shadowBlur=12*pulse;
     ctx.fillStyle=`rgba(140,255,190,${(.70*pulse).toFixed(2)})`;
     // бегущий человечек
     const hx=ex-ew*.16, hy=ey+eh*.5, u=eh*.26;
     ctx.beginPath();ctx.arc(hx,hy-u*1.05,u*.26,0,Math.PI*2);ctx.fill();
     ctx.lineWidth=Math.max(1.4,u*.22);ctx.strokeStyle=ctx.fillStyle;
     ctx.beginPath();ctx.moveTo(hx,hy-u*.75);ctx.lineTo(hx+u*.18,hy+u*.05);
     ctx.moveTo(hx+u*.18,hy+u*.05);ctx.lineTo(hx+u*.55,hy+u*.75);
     ctx.moveTo(hx+u*.18,hy+u*.05);ctx.lineTo(hx-u*.45,hy+u*.70);
     ctx.moveTo(hx-u*.05,hy-u*.50);ctx.lineTo(hx+u*.55,hy-u*.25);
     ctx.stroke();
     // стрелка направления
     const axx=ex+ew*.24;
     ctx.beginPath();ctx.moveTo(axx-u*.35*dir,hy);ctx.lineTo(axx+u*.20*dir,hy);ctx.stroke();
     ctx.beginPath();ctx.moveTo(axx+u*.45*dir,hy);ctx.lineTo(axx+u*.05*dir,hy-u*.30);ctx.lineTo(axx+u*.05*dir,hy+u*.30);ctx.closePath();ctx.fill();
     ctx.restore();
     const wash=ctx.createRadialGradient(ex,ey+eh,4,ex,ey+eh,W*.055);
     wash.addColorStop(0,`rgba(60,230,150,${(.075*pulse).toFixed(3)})`);wash.addColorStop(1,'rgba(60,230,150,0)');
     ctx.fillStyle=wash;ctx.fillRect(ex-W*.06,ey-H*.02,W*.12,H*.16);
   });
   ctx.textAlign='left';ctx.textBaseline='alphabetic';
   // аптечка
   const ax=W*.372, ay=H*.243, aw=W*.019, ah=H*.052;
   ctx.fillStyle='rgba(0,0,0,.45)';ctx.fillRect(ax+3,ay+4,aw,ah);
   const ag=ctx.createLinearGradient(ax,ay,ax+aw,ay+ah);ag.addColorStop(0,'#cfd6d4');ag.addColorStop(1,'#8d9794');
   ctx.fillStyle=ag;ctx.fillRect(ax,ay,aw,ah);
   ctx.strokeStyle='rgba(0,0,0,.35)';ctx.lineWidth=1;ctx.strokeRect(ax+.5,ay+.5,aw-1,ah-1);
   ctx.fillStyle='#b3242f';ctx.fillRect(ax+aw*.42,ay+ah*.22,aw*.16,ah*.46);ctx.fillRect(ax+aw*.27,ay+ah*.37,aw*.46,ah*.16);
   ctx.fillStyle='rgba(0,0,0,.30)';ctx.fillRect(ax,ay+ah*.52,aw,1.5);
   // календарь с оторванными листами
   const kx=W*.478, ky=H*.232, kw=W*.026, kh=H*.062;
   ctx.fillStyle='rgba(0,0,0,.40)';ctx.fillRect(kx+3,ky+4,kw,kh);
   ctx.fillStyle='#cdc6b3';ctx.fillRect(kx,ky,kw,kh);
   ctx.fillStyle='#8e2b33';ctx.fillRect(kx,ky,kw,kh*.26);
   ctx.fillStyle='rgba(60,60,55,.35)';
   for(let r=0;r<4;r++)for(let c=0;c<5;c++)ctx.fillRect(kx+kw*(.10+c*.18),ky+kh*(.38+r*.15),kw*.09,kh*.06);
   ctx.fillStyle='#8e2b33';ctx.fillRect(kx+kw*.62,ky+kh*.66,kw*.12,kh*.09);
   ctx.strokeStyle='rgba(200,210,215,.25)';ctx.lineWidth=1;
   ctx.beginPath();ctx.moveTo(kx+kw*.5,ky);ctx.lineTo(kx+kw*.5,ky-H*.012);ctx.stroke();
   // аварийная лампа-мигалка на стене
   const dx=W*.520, dy=H*.196, dr=Math.min(W*.008,H*.020);
   const blink=Math.pow(Math.max(0,Math.sin(t*1.25)),3);
   ctx.fillStyle='#171f24';ctx.fillRect(dx-dr*1.2,dy+dr*.5,dr*2.4,dr*.8);
   const dg=ctx.createLinearGradient(dx,dy-dr,dx,dy+dr);
   dg.addColorStop(0,`rgba(255,${Math.round(60+80*blink)},70,${(.55+.45*blink).toFixed(2)})`);dg.addColorStop(1,'rgba(120,16,24,.9)');
   ctx.save();ctx.shadowColor='rgba(255,50,60,.9)';ctx.shadowBlur=6+26*blink;
   ctx.fillStyle=dg;ctx.beginPath();ctx.arc(dx,dy,dr,Math.PI,Math.PI*2);ctx.fill();ctx.restore();
   const dw2=ctx.createRadialGradient(dx,dy,3,dx,dy,W*.085);
   dw2.addColorStop(0,`rgba(220,40,52,${(.04+.13*blink).toFixed(3)})`);dw2.addColorStop(1,'rgba(220,40,52,0)');
   ctx.fillStyle=dw2;ctx.fillRect(dx-W*.09,dy-H*.05,W*.18,H*.28);
   // свисающие провода
   [[W*.283,H*.055],[W*.604,H*.075]].forEach(([cx2,len],i)=>{
     const swy=Math.sin(t*.8+i*1.7)*W*.004;
     ctx.strokeStyle='rgba(18,24,28,.95)';ctx.lineWidth=2.5;
     ctx.beginPath();ctx.moveTo(cx2,H*.183);
     ctx.bezierCurveTo(cx2+swy,H*.183+len*.5,cx2-swy*1.4,H*.183+len*.8,cx2+swy*.6,H*.183+len);ctx.stroke();
     ctx.fillStyle='#2a343a';ctx.beginPath();ctx.arc(cx2+swy*.6,H*.183+len,3,0,Math.PI*2);ctx.fill();
   });
   // трещины на бетоне
   ctx.strokeStyle='rgba(0,0,0,.42)';ctx.lineWidth=1.4;
   const crk=(x0,y0,dirx,steps)=>{ctx.beginPath();ctx.moveTo(x0,y0);let x=x0,y=y0;
     for(let i=0;i<steps;i++){x+=dirx*W*.004*(1+((i*7)%3)*.4);y+=H*.010;ctx.lineTo(x,y);}ctx.stroke();};
   crk(W*.706,H*.212,1,9);crk(W*.716,H*.262,-1,5);crk(W*.256,H*.300,-1,7);
   // паутина в верхних углах стены
   if(!low){
     [[W*.258,1],[W*.744,-1]].forEach(([wx,dir])=>{
       ctx.strokeStyle='rgba(190,205,212,.10)';ctx.lineWidth=1;
       for(let r=1;r<=4;r++){ctx.beginPath();ctx.arc(wx,H*.112,W*.008*r,dir>0?0:Math.PI*.5,dir>0?Math.PI*.5:Math.PI);ctx.stroke();}
       for(let a=0;a<=4;a++){const an=(dir>0?0:Math.PI*.5)+(Math.PI*.5)*(a/4);
         ctx.beginPath();ctx.moveTo(wx,H*.112);ctx.lineTo(wx+Math.cos(an)*W*.032,H*.112+Math.sin(an)*W*.032);ctx.stroke();}
     });
   }
   // полка с папками и старой кружкой
   const shx=W*.408, shy=H*.392, shw=W*.048;
   ctx.fillStyle='rgba(0,0,0,.45)';ctx.fillRect(shx+2,shy+4,shw,H*.008);
   ctx.fillStyle='#242e34';ctx.fillRect(shx,shy,shw,H*.007);
   ctx.fillStyle='rgba(255,255,255,.06)';ctx.fillRect(shx,shy,shw,1.5);
   ctx.fillStyle='#1a2227';ctx.fillRect(shx+W*.002,shy+H*.007,W*.004,H*.010);ctx.fillRect(shx+shw-W*.006,shy+H*.007,W*.004,H*.010);
   [['#5c4a3a',.004,.030],['#3f4a58',.013,.034],['#54413f',.022,.028],['#3d4a44',.031,.032]].forEach(b=>{
     ctx.fillStyle='rgba(0,0,0,.45)';ctx.fillRect(shx+shw*0+W*b[1]+2,shy-H*b[2]+2,W*.008,H*b[2]);
     ctx.fillStyle=b[0];ctx.fillRect(shx+W*b[1],shy-H*b[2],W*.008,H*b[2]);
     ctx.fillStyle='rgba(220,225,215,.16)';ctx.fillRect(shx+W*b[1]+W*.001,shy-H*b[2]+H*.004,W*.006,H*.005);
   });
   ctx.fillStyle='#2b3439';ctx.fillRect(shx+W*.041,shy-H*.013,W*.006,H*.013);
   ctx.strokeStyle='#2b3439';ctx.lineWidth=1.6;ctx.beginPath();ctx.arc(shx+W*.048,shy-H*.007,H*.004,-1.2,1.2);ctx.stroke();
   // огнетушитель на стене
   const ox=W*.700, oy=H*.470, ow=W*.011, oh=H*.058;
   ctx.fillStyle='rgba(0,0,0,.45)';ctx.fillRect(ox+3,oy+4,ow,oh);
   const og=ctx.createLinearGradient(ox,oy,ox+ow,oy);
   og.addColorStop(0,'#8e2a26');og.addColorStop(.45,'#c1382f');og.addColorStop(1,'#6d1f1c');
   ctx.fillStyle=og;ctx.fillRect(ox,oy+oh*.14,ow,oh*.86);
   ctx.fillStyle='#2a3238';ctx.fillRect(ox+ow*.30,oy,ow*.40,oh*.16);
   ctx.fillStyle='#3c464d';ctx.fillRect(ox+ow*.05,oy+oh*.04,ow*.35,oh*.05);
   ctx.strokeStyle='#1a2024';ctx.lineWidth=1.6;
   ctx.beginPath();ctx.moveTo(ox+ow*.75,oy+oh*.10);ctx.bezierCurveTo(ox+ow*1.6,oy+oh*.30,ox+ow*1.2,oy+oh*.60,ox+ow*.85,oy+oh*.66);ctx.stroke();
   ctx.fillStyle='rgba(240,240,235,.16)';ctx.fillRect(ox+ow*.18,oy+oh*.40,ow*.30,oh*.22);
   ctx.fillStyle='#171e22';ctx.fillRect(ox-W*.001,oy+oh*.34,ow+W*.002,H*.004);
   // труба с капелью и лужа на полу
   const px2=W*.290;
   ctx.fillStyle='#161e23';ctx.fillRect(px2,H*.183,W*.006,H*.415);
   ctx.fillStyle='rgba(255,255,255,.05)';ctx.fillRect(px2,H*.183,2,H*.415);
   ctx.fillStyle='#1e272c';ctx.fillRect(px2-W*.002,H*.36,W*.010,H*.014);
   const cyc=(t*.55)%1;
   if(cyc<.7){const dy2=H*.375+(H*.225)*(cyc/.7)*(cyc/.7);
     ctx.fillStyle='rgba(170,205,220,.55)';ctx.beginPath();ctx.ellipse(px2+W*.003,dy2,2.2,3.6,0,0,Math.PI*2);ctx.fill();}
   const pud=ctx.createRadialGradient(px2+W*.003,H*.655,2,px2+W*.003,H*.655,W*.032);
   pud.addColorStop(0,'rgba(120,160,180,.14)');pud.addColorStop(1,'rgba(120,160,180,0)');
   ctx.fillStyle=pud;ctx.beginPath();ctx.ellipse(px2+W*.003,H*.655,W*.032,H*.014,0,0,Math.PI*2);ctx.fill();
   if(cyc>.72&&cyc<.92){const rr=(cyc-.72)/.20;
     ctx.strokeStyle=`rgba(180,215,230,${(.22*(1-rr)).toFixed(3)})`;ctx.lineWidth=1;
     ctx.beginPath();ctx.ellipse(px2+W*.003,H*.655,W*.006+W*.018*rr,H*.003+H*.008*rr,0,0,Math.PI*2);ctx.stroke();}
   // V112: ЗАПИСНАЯ ДОСКА на стене — кликабельный планшет для рисования.
   // Сверху прищепка, лист бумаги с лёгкой сштриховкой и парой черновых линий,
   // чтобы намекнуть, что тут можно рисовать.
   const cbx=W*.635, cby=H*.300, cbw=W*.052, cbh=H*.072;
   ctx.fillStyle='rgba(0,0,0,.40)';ctx.fillRect(cbx+3,cby+4,cbw,cbh);
   const cbg=ctx.createLinearGradient(cbx,cby,cbx+cbw,cby+cbh);cbg.addColorStop(0,'#5a4632');cbg.addColorStop(1,'#3a2c1e');
   ctx.fillStyle=cbg;ctx.fillRect(cbx,cby,cbw,cbh);
   ctx.strokeStyle='rgba(0,0,0,.45)';ctx.lineWidth=1;ctx.strokeRect(cbx+.5,cby+.5,cbw-1,cbh-1);
   // лист бумаги
   const px=cbx+cbw*.10, py=cby+cbh*.16, pw=cbw*.80, ph=cbh*.74;
   ctx.fillStyle='#d9d3c0';ctx.fillRect(px,py,pw,ph);
   ctx.fillStyle='rgba(60,60,50,.18)';
   for(let r=0;r<6;r++)ctx.fillRect(px+pw*.08,py+ph*(.12+r*.15),pw*.84,1);
   // пара черновых штрихов — намёк, что кто-то уже рисовал
   ctx.strokeStyle='rgba(160,40,40,.40)';ctx.lineWidth=1.4;
   ctx.beginPath();ctx.moveTo(px+pw*.12,py+ph*.66);ctx.bezierCurveTo(px+pw*.3,py+ph*.5,px+pw*.55,py+ph*.8,px+pw*.82,py+ph*.6);ctx.stroke();
   // прищепка сверху
   ctx.fillStyle='#7a6a42';ctx.fillRect(cbx+cbw*.42,cby-cbh*.05,cbw*.16,cbh*.10);
   ctx.fillStyle='#9a8a5a';ctx.fillRect(cbx+cbw*.44,cby-cbh*.05,cbw*.04,cbh*.10);
   ctx.restore();
 }
 // ==== КОМНАТА ОХРАНЫ — атмосфера: свет, дымка, объём ====
 function officeAtmos(ctx,W,H,t,lights){
   const low=document.body.classList.contains('low-end');
   // V84: уровень нагрузки. tier 0 — всё, 1 — без пылевых шахт и половины пыли,
   // 2 — только базовый свет и затемнение. Раньше комната охраны рисовала
   // 46 частиц пыли, 3 слоя дымки и 2 световые шахты на КАЖДОМ кадре панорамы.
   const tier=(window.__PERF&&window.__PERF.tier)||0;
   // мерцание дежурной лампы: спокойное с редкими просадками
   const n1=Math.sin(t*8.3)+Math.sin(t*13.7)*.6+Math.sin(t*31.1)*.25;
   const dip=Math.sin(t*.43)>.986?.42:1;
   const f=Math.max(.35,Math.min(1,(.90+.08*n1)*dip));
   // вторая лампа над левым проёмом почти сдохла — резкие стробы
   const g2=Math.sin(t*3.1)>.55?(Math.sin(t*47)>0?1:.15):.10;
   ctx.save();
   ctx.globalCompositeOperation='lighter';
   // основной светильник над столом
   const cone=ctx.createLinearGradient(0,H*.128,0,H*.60);
   cone.addColorStop(0,`rgba(214,232,248,${(.115*f).toFixed(3)})`);
   cone.addColorStop(.45,`rgba(176,206,230,${(.038*f).toFixed(3)})`);
   cone.addColorStop(1,'rgba(150,185,215,0)');
   ctx.fillStyle=cone;ctx.beginPath();
   ctx.moveTo(W*.305,H*.128);ctx.lineTo(W*.695,H*.128);ctx.lineTo(W*.795,H*.60);ctx.lineTo(W*.205,H*.60);ctx.closePath();ctx.fill();
   // светящаяся трубка
   ctx.fillStyle=`rgba(232,244,255,${(.80*f).toFixed(2)})`;ctx.fillRect(W*.335,H*.139,W*.33,4);
   const halo=ctx.createRadialGradient(W*.5,H*.145,4,W*.5,H*.145,W*.14);
   halo.addColorStop(0,`rgba(214,234,250,${(.155*f).toFixed(3)})`);halo.addColorStop(1,'rgba(210,232,250,0)');
   ctx.fillStyle=halo;ctx.fillRect(W*.34,H*.10,W*.32,H*.14);
   // лужа света на полу
   const pool=ctx.createRadialGradient(W*.5,H*.72,4,W*.5,H*.72,W*.20);
   pool.addColorStop(0,`rgba(194,218,238,${(.062*f).toFixed(3)})`);pool.addColorStop(1,'rgba(190,214,236,0)');
   ctx.fillStyle=pool;ctx.beginPath();ctx.ellipse(W*.5,H*.72,W*.20,H*.085,0,0,Math.PI*2);ctx.fill();
   // умирающая лампа слева
   ctx.fillStyle=`rgba(216,234,248,${(.55*g2).toFixed(2)})`;ctx.fillRect(W*.115,H*.138,W*.11,3.5);
   const c2=ctx.createLinearGradient(0,H*.140,0,H*.62);
   c2.addColorStop(0,`rgba(182,208,234,${(.085*g2).toFixed(3)})`);c2.addColorStop(1,'rgba(160,190,220,0)');
   ctx.fillStyle=c2;ctx.beginPath();
   ctx.moveTo(W*.110,H*.140);ctx.lineTo(W*.230,H*.140);ctx.lineTo(W*.285,H*.62);ctx.lineTo(W*.055,H*.62);ctx.closePath();ctx.fill();
   ctx.fillStyle=`rgba(216,234,248,${(.42*(1-g2*.6)).toFixed(2)})`;ctx.fillRect(W*.775,H*.138,W*.11,3.5);
   const c3=ctx.createLinearGradient(0,H*.140,0,H*.62);
   c3.addColorStop(0,'rgba(182,208,234,.058)');c3.addColorStop(1,'rgba(160,190,220,0)');
   ctx.fillStyle=c3;ctx.beginPath();
   ctx.moveTo(W*.770,H*.140);ctx.lineTo(W*.890,H*.140);ctx.lineTo(W*.945,H*.62);ctx.lineTo(W*.715,H*.62);ctx.closePath();ctx.fill();
   // холодное свечение мониторов на стол и стену
   const mg=ctx.createLinearGradient(0,H*.56,0,H*.40);
   mg.addColorStop(0,'rgba(96,190,205,.052)');mg.addColorStop(1,'rgba(96,190,205,0)');
   ctx.fillStyle=mg;ctx.fillRect(W*.29,H*.40,W*.40,H*.16);
   // тёплый свет включённых дверных ламп на стену
   ['left','right'].forEach(side=>{
     const l=lights&&lights[side];if(!l||!l.on||l.renderOff)return;
     const gx=side==='left'?W*.135:W*.865;
     const wg2=ctx.createRadialGradient(gx,H*.40,6,gx,H*.40,W*.16);
     wg2.addColorStop(0,'rgba(255,206,112,.062)');wg2.addColorStop(1,'rgba(255,214,120,0)');
     ctx.fillStyle=wg2;ctx.fillRect(gx-W*.17,H*.14,W*.34,H*.52);
   });
   // световые шахты в пыли (V84: тяжёлый проход — только при полном запасе кадров)
   if(!low&&tier===0){
     [[W*.40,W*.34],[W*.58,W*.66]].forEach(([xa,xb],i)=>{
       const a=(.019+.009*Math.sin(t*.6+i))*f;
       const sg=ctx.createLinearGradient(0,H*.14,0,H*.62);
       sg.addColorStop(0,`rgba(206,228,248,${a.toFixed(3)})`);sg.addColorStop(1,'rgba(206,228,248,0)');
       ctx.fillStyle=sg;ctx.beginPath();
       ctx.moveTo(xa-W*.012,H*.14);ctx.lineTo(xa+W*.012,H*.14);ctx.lineTo(xb+W*.045,H*.62);ctx.lineTo(xb-W*.045,H*.62);ctx.closePath();ctx.fill();
     });
   }
   // отблеск на столешнице и подсвеченная кромка стола
   const deskG=ctx.createLinearGradient(0,H*.525,0,H*.635);
   deskG.addColorStop(0,`rgba(200,216,232,${(.036*f).toFixed(3)})`);deskG.addColorStop(1,'rgba(200,216,232,0)');
   ctx.fillStyle=deskG;ctx.fillRect(W*.25,H*.525,W*.50,H*.11);
   ctx.fillStyle=`rgba(214,230,244,${(.10*f).toFixed(3)})`;ctx.fillRect(W*.25,H*.530,W*.50,1.6);
   ctx.restore();
   // ---- затемнение и дымка ----
   ctx.save();
   // слои дымки у пола
   if(!low&&tier<2){
     const FL=tier===0?3:1;
     for(let i=0;i<FL;i++){
       const fy=H*(.60+i*.075), fa=.018+.008*Math.sin(t*.4+i*1.3);
       const fg=ctx.createLinearGradient(0,fy-H*.05,0,fy+H*.06);
       fg.addColorStop(0,'rgba(150,175,195,0)');fg.addColorStop(.5,`rgba(150,175,195,${fa.toFixed(3)})`);fg.addColorStop(1,'rgba(150,175,195,0)');
       ctx.fillStyle=fg;ctx.fillRect(0,fy-H*.05,W,H*.12);
     }
     // крупная пыль в свете лампы, с параллаксом (V84: 46 -> 22 / 10 частиц)
     const DUST=tier===0?22:10;
     for(let i=0;i<DUST;i++){
       const seed=i*3.77;
       const x=(W*.20+((i*137)%100)/100*W*.60+Math.sin(t*.30+seed)*W*.010);
       const y=H*.16+((i*53)%100)/100*H*.46+Math.cos(t*.22+seed)*H*.016;
       const a=(.035+.06*Math.abs(Math.sin(t*.7+seed)))*f;
       ctx.fillStyle=`rgba(214,230,242,${a.toFixed(3)})`;
       ctx.beginPath();ctx.arc(x,y,i%7===0?1.9:1.2,0,Math.PI*2);ctx.fill();
     }
   }
   // тёмные углы комнаты и тяжёлый низ
   const edgeL=ctx.createLinearGradient(0,0,W*.11,0);
   edgeL.addColorStop(0,'rgba(2,4,6,.60)');edgeL.addColorStop(1,'rgba(2,4,6,0)');
   ctx.fillStyle=edgeL;ctx.fillRect(0,0,W*.11,H);
   const edgeR=ctx.createLinearGradient(W,0,W*.89,0);
   edgeR.addColorStop(0,'rgba(2,4,6,.60)');edgeR.addColorStop(1,'rgba(2,4,6,0)');
   ctx.fillStyle=edgeR;ctx.fillRect(W*.89,0,W*.11,H);
   const top=ctx.createLinearGradient(0,H*.06,0,H*.26);
   top.addColorStop(0,'rgba(2,4,6,.66)');top.addColorStop(1,'rgba(2,4,6,0)');
   ctx.fillStyle=top;ctx.fillRect(0,H*.06,W,H*.22);
   const bot=ctx.createLinearGradient(0,H*.72,0,H);
   bot.addColorStop(0,'rgba(2,4,6,0)');bot.addColorStop(1,'rgba(2,4,6,.80)');
   ctx.fillStyle=bot;ctx.fillRect(0,H*.72,W,H*.28);
   // общая ночная цветокоррекция: холодные тени, чуть теплее у стола
   const grade=ctx.createLinearGradient(0,H*.10,0,H);
   grade.addColorStop(0,'rgba(7,14,26,.42)');grade.addColorStop(.55,'rgba(6,12,21,.26)');grade.addColorStop(1,'rgba(3,6,11,.46)');
   ctx.fillStyle=grade;ctx.fillRect(0,0,W,H);
   ctx.restore();
 }

 // ==== V70: комната охраны меняется от смены к смене и реагирует на предметы,
 // которые охранник может трогать (лампа, вентилятор, кружка). ====
 function officeShift(ctx,W,H,t){
   const st=window.__NS_OFFICE||{};
   const n=Math.max(1,Math.min(5,st.night||1));
   // --- настольная лампа (интерактив) ---
   const lx=W*.325, ly=H*.578;
   ctx.save();
   // основание, штанга и абажур
   ctx.fillStyle='#1b2328';ctx.beginPath();ctx.ellipse(lx,ly+H*.044,W*.012,H*.005,0,0,Math.PI*2);ctx.fill();
   ctx.strokeStyle='#2a343a';ctx.lineWidth=3.4;ctx.beginPath();ctx.moveTo(lx,ly+H*.044);ctx.quadraticCurveTo(lx-W*.004,ly+H*.020,lx+W*.003,ly+H*.010);ctx.stroke();
   ctx.fillStyle='#33434b';ctx.beginPath();ctx.moveTo(lx-W*.015,ly+H*.012);ctx.lineTo(lx+W*.021,ly+H*.012);ctx.lineTo(lx+W*.013,ly-H*.010);ctx.lineTo(lx-W*.006,ly-H*.010);ctx.closePath();ctx.fill();
   ctx.fillStyle='#212b31';ctx.fillRect(lx-W*.006,ly-H*.013,W*.019,H*.004);
   if(st.lamp){
     const fl=0.90+0.10*Math.sin(t*7.3)+(n>=4?0.12*Math.sin(t*23):0);
     ctx.fillStyle=`rgba(255,230,168,${(0.9*fl).toFixed(2)})`;ctx.beginPath();ctx.ellipse(lx+W*.003,ly+H*.013,W*.016,H*.005,0,0,Math.PI*2);ctx.fill();
     glowPool(ctx,lx+W*.003,ly+H*.030,W*.085,H*.045,'255,214,140',0.24*fl);
     const cg=ctx.createLinearGradient(0,ly+H*.013,0,ly+H*.09);
     cg.addColorStop(0,`rgba(255,214,140,${(0.13*fl).toFixed(3)})`);cg.addColorStop(1,'rgba(255,214,140,0)');
     ctx.save();ctx.globalCompositeOperation='lighter';ctx.fillStyle=cg;
     ctx.beginPath();ctx.moveTo(lx-W*.016,ly+H*.014);ctx.lineTo(lx+W*.022,ly+H*.014);ctx.lineTo(lx+W*.062,ly+H*.09);ctx.lineTo(lx-W*.055,ly+H*.09);ctx.closePath();ctx.fill();ctx.restore();
   } else {
     ctx.fillStyle='rgba(44,52,56,.95)';ctx.beginPath();ctx.ellipse(lx+W*.003,ly+H*.013,W*.016,H*.005,0,0,Math.PI*2);ctx.fill();
   }
   ctx.restore();
   // --- вентилятор (интерактив) ---
   const fx=W*.688, fy=H*.500, fr=W*.020;
   ctx.save();
   ctx.fillStyle='#161c21';ctx.fillRect(fx-W*.004,fy+fr*0.9,W*.008,H*.030);
   ctx.fillStyle='#1c242a';ctx.beginPath();ctx.arc(fx,fy,fr,0,Math.PI*2);ctx.fill();
   const spin=st.fan?t*7.5:(st.fanCoast||0);
   ctx.strokeStyle=st.fan?'rgba(150,170,180,.55)':'rgba(110,125,135,.35)';ctx.lineWidth=3;
   for(let b=0;b<3;b++){
     const a=spin+b*Math.PI*2/3;
     ctx.beginPath();ctx.moveTo(fx,fy);ctx.lineTo(fx+Math.cos(a)*fr*0.85,fy+Math.sin(a)*fr*0.85);ctx.stroke();
   }
   ctx.strokeStyle='rgba(120,140,150,.30)';ctx.lineWidth=1;
   for(let r=fr*0.35;r<fr;r+=fr*0.3){ctx.beginPath();ctx.arc(fx,fy,r,0,Math.PI*2);ctx.stroke();}
   ctx.fillStyle='#39434a';ctx.beginPath();ctx.arc(fx,fy,fr*0.16,0,Math.PI*2);ctx.fill();
   ctx.restore();
   // --- кружка (интерактив): пустеет с каждым глотком ---
   const mx=W*.596, my=H*.612, lvl=Math.max(0,Math.min(3,st.mug===undefined?3:st.mug));
   ctx.save();
   ctx.fillStyle='rgba(0,0,0,.5)';ctx.beginPath();ctx.ellipse(mx+3,my+H*.016,W*.013,H*.005,0,0,Math.PI*2);ctx.fill();
   // ручка (за корпусом, вплотную)
   ctx.strokeStyle='#b9c0c4';ctx.lineWidth=4.2;ctx.beginPath();ctx.arc(mx+W*.0098,my+H*.001,H*.0105,-1.35,1.35);ctx.stroke();
   // корпус со сужением к низу
   const grd=ctx.createLinearGradient(mx-W*.012,0,mx+W*.012,0);
   grd.addColorStop(0,'#9ea6ab');grd.addColorStop(.35,'#d8dde0');grd.addColorStop(1,'#a7aeb3');
   ctx.fillStyle=grd;ctx.beginPath();
   ctx.moveTo(mx-W*.011,my-H*.016);ctx.lineTo(mx+W*.011,my-H*.016);ctx.lineTo(mx+W*.0092,my+H*.015);ctx.lineTo(mx-W*.0092,my+H*.015);ctx.closePath();ctx.fill();
   ctx.fillStyle='#eef2f4';ctx.beginPath();ctx.ellipse(mx,my-H*.016,W*.011,H*.0045,0,0,Math.PI*2);ctx.fill();
   ctx.fillStyle='#7f868a';ctx.beginPath();ctx.ellipse(mx,my-H*.016,W*.0092,H*.0036,0,0,Math.PI*2);ctx.fill();
   if(lvl>0){
     const dark=lvl>=3?'#3b2317':lvl===2?'#33200f':'#2a1a0c';
     ctx.fillStyle=dark;ctx.beginPath();ctx.ellipse(mx,my-H*.016+(3-lvl)*H*.003,W*.0086,H*.0032,0,0,Math.PI*2);ctx.fill();
     ctx.save();ctx.globalAlpha=.15;ctx.fillStyle='#e6eef2';
     for(let i=0;i<3;i++){const sy=my-H*.022-i*H*.009;ctx.beginPath();ctx.ellipse(mx+Math.sin(t*1.3+i*1.4)*4,sy,3.4,1.7,0,0,Math.PI*2);ctx.fill();}
     ctx.restore();
   } else {
     ctx.fillStyle='rgba(30,22,16,.6)';ctx.beginPath();ctx.ellipse(mx,my-H*.014,W*.0086,H*.0030,0,0,Math.PI*2);ctx.fill();
   }
   ctx.restore();
   // --- изменения по сменам ---
   if(n>=2){ // приколотая записка «НЕ ОТКРЫВАЙ»
     ctx.save();ctx.translate(W*.262,H*.435);ctx.rotate(-0.05);
     ctx.fillStyle='#c9c2a6';ctx.fillRect(0,0,W*.034,H*.030);
     ctx.fillStyle='#5d4a2c';ctx.font=Math.round(H*.011)+'px "JetBrains Mono",monospace';ctx.fillText('НЕ ОТКРЫВАЙ',2,H*.014);
     ctx.fillStyle='#b03a44';ctx.beginPath();ctx.arc(W*.017,H*.003,2.2,0,Math.PI*2);ctx.fill();ctx.restore();
   }
   if(n>=3){ // детский рисунок: жёлтый в футболке LAV
     ctx.save();ctx.translate(W*.726,H*.398);
     ctx.fillStyle='#cfc9ad';ctx.fillRect(0,0,W*.042,H*.052);
     ctx.fillStyle='#d8bb2f';ctx.fillRect(W*.014,H*.008,W*.014,H*.012);
     ctx.fillStyle='#2b3a6b';ctx.fillRect(W*.012,H*.021,W*.018,H*.014);
     ctx.fillStyle='#efeee6';ctx.font=Math.round(H*.010)+'px "JetBrains Mono",monospace';ctx.fillText('LAV',W*.014,H*.031);
     ctx.strokeStyle='#3a3226';ctx.lineWidth=1.4;
     ctx.beginPath();ctx.moveTo(W*.012,H*.026);ctx.lineTo(W*.004,H*.036);ctx.moveTo(W*.030,H*.026);ctx.lineTo(W*.038,H*.036);
     ctx.moveTo(W*.017,H*.035);ctx.lineTo(W*.015,H*.048);ctx.moveTo(W*.025,H*.035);ctx.lineTo(W*.027,H*.048);ctx.stroke();
     ctx.strokeStyle='#8a2b33';ctx.lineWidth=1.2;
     if(n>=5){ctx.beginPath();ctx.moveTo(2,2);ctx.lineTo(W*.040,H*.050);ctx.moveTo(W*.040,2);ctx.lineTo(2,H*.050);ctx.stroke();}
     ctx.restore();
     // царапины на стене
     ctx.save();ctx.strokeStyle='rgba(180,190,195,.13)';ctx.lineWidth=1.2;
     for(let i=0;i<7;i++){const sx=W*(.155+i*.006);ctx.beginPath();ctx.moveTo(sx,H*.300);ctx.lineTo(sx+W*.004,H*.360+i*2);ctx.stroke();}
     ctx.restore();
   }
   if(n>=4){ // потёки на стене и разбитый монитор
     ctx.save();ctx.globalAlpha=.30;ctx.fillStyle='#2a080c';
     [[.196,.250,.052],[.208,.256,.038],[.792,.240,.046]].forEach(b=>{
       ctx.beginPath();ctx.moveTo(W*b[0],H*b[1]);ctx.lineTo(W*(b[0]+.006),H*b[1]);ctx.lineTo(W*(b[0]+.004),H*(b[1]+b[2]));ctx.lineTo(W*(b[0]+.001),H*(b[1]+b[2]));ctx.closePath();ctx.fill();
       ctx.beginPath();ctx.ellipse(W*(b[0]+.003),H*(b[1]+b[2]),5,2,0,0,Math.PI*2);ctx.fill();
     });ctx.restore();
     ctx.save();ctx.strokeStyle='rgba(230,240,245,.22)';ctx.lineWidth=1;
     const bx=W*.595,by=H*.50,bw=W*.075,bh=H*.06;
     for(let i=0;i<9;i++){ctx.beginPath();ctx.moveTo(bx+bw*.5,by+bh*.5);ctx.lineTo(bx+bw*((i*37%100)/100),by+bh*((i*61%100)/100));ctx.stroke();}
     ctx.restore();
   }
   if(n>=5){ // аварийный красный свет и упавший стул
     // V84: раньше аварийный красный шёл радиусом H*0.9 от потолка и заливал
     // ВЕСЬ кадр — после 5-й смены картинка превращалась в розовый засвет.
     // Теперь это два локальных источника у аварийных плафонов над проёмами
     // плюс очень слабая общая подмесь. Пульсация мягче (1.4 -> 0.9).
     const pulse=.5+.5*Math.sin(t*0.9);
     ctx.save();ctx.globalCompositeOperation='lighter';
     [[W*.14,H*.145],[W*.86,H*.145]].forEach(([rx,ry])=>{
       const rg=ctx.createRadialGradient(rx,ry,4,rx,ry,H*.30);
       rg.addColorStop(0,`rgba(214,46,50,${(0.20+0.10*pulse).toFixed(3)})`);
       rg.addColorStop(.45,`rgba(186,32,38,${(0.055+0.030*pulse).toFixed(3)})`);
       rg.addColorStop(1,'rgba(0,0,0,0)');
       ctx.fillStyle=rg;ctx.fillRect(rx-H*.32,ry-H*.20,H*.64,H*.56);
       // сам плафон
       ctx.fillStyle=`rgba(255,120,110,${(0.45+0.35*pulse).toFixed(2)})`;
       ctx.fillRect(rx-W*.011,ry-H*.006,W*.022,4);
     });
     // общая подмесь: едва заметная, только в тенях у пола
     const flr=ctx.createLinearGradient(0,H*.58,0,H);
     flr.addColorStop(0,'rgba(150,26,30,0)');
     flr.addColorStop(1,`rgba(150,26,30,${(0.030+0.016*pulse).toFixed(3)})`);
     ctx.fillStyle=flr;ctx.fillRect(0,H*.58,W,H*.42);
     ctx.restore();
     ctx.save();ctx.translate(W*.30,H*.70);ctx.rotate(1.35);
     ctx.fillStyle='#1e262b';ctx.fillRect(-W*.020,0,W*.040,H*.016);ctx.fillStyle='#161d21';ctx.fillRect(-W*.020,-H*.034,W*.012,H*.034);ctx.restore();
   }
   // остановившиеся часы: со 4-й смены стрелки не двигаются
   const cx=W*.500, cy=H*.318, cr=H*.030;
   ctx.save();
   ctx.fillStyle='#141a1e';ctx.beginPath();ctx.arc(cx,cy,cr,0,Math.PI*2);ctx.fill();
   ctx.strokeStyle='rgba(160,175,185,.35)';ctx.lineWidth=1.6;ctx.beginPath();ctx.arc(cx,cy,cr,0,Math.PI*2);ctx.stroke();
   ctx.fillStyle='#cdd6da';ctx.font=Math.round(H*.012)+'px "JetBrains Mono",monospace';ctx.textAlign='center';ctx.fillText(n>=4?'--:--':'0'+n+':00',cx,cy+H*.005);
   const ha=n>=4?2.4:(t*0.4);
   ctx.strokeStyle='rgba(210,220,225,.55)';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(cx,cy);ctx.lineTo(cx+Math.cos(ha)*cr*.6,cy+Math.sin(ha)*cr*.6);ctx.stroke();
   ctx.textAlign='left';ctx.restore();
 }
 function office(ctx,W,H,mouse,doors,lights,monitorOpen,monsters=[],screamer={active:false,power:0},officeMonitors=[false,false,false,false]){bg(ctx,W,H);officeDetail(ctx,W,H,performance.now()/1000);ctx.fillStyle='#11171c';ctx.fillRect(0,H*.10,W,H*.53);officeShell(ctx,W,H,performance.now()/1000,lights);for(let i=0;i<8;i++){ctx.strokeStyle='#202a31';ctx.beginPath();ctx.moveTo(0,H*(.17+i*.06));ctx.lineTo(W,H*(.17+i*.06));ctx.stroke()}for(let i=0;i<6;i++){ctx.fillStyle=i%2?'#202a30':'#1a2228';ctx.fillRect(W*(.04+i*.17),H*.18,88,58);}
 // left/right door recesses
 // V83: если игра передала прогресс анимации (doors.leftA / rightA), створка
 // рисуется в промежуточном положении, иначе — по старому булеву значению.
 drawDoorBay(ctx,W*.02,H*.20,W*.23,H*.38,doors.leftA!==undefined?doors.leftA:doors.left,0,lights.left,monsters,'left');
 drawDoorBay(ctx,W*.75,H*.20,W*.23,H*.38,doors.rightA!==undefined?doors.rightA:doors.right,1,lights.right,monsters,'right');
 drawLightSwitch(ctx,W*.235,H*.62,'left',lights.left.on);
 drawLightSwitch(ctx,W*.765,H*.62,'right',lights.right.on);
 // extra office detail: ceiling fixtures, cables, warning labels and desk equipment.
 ctx.fillStyle='#0b0f12';ctx.fillRect(W*.30,H*.12,W*.40,6);
 for(let i=0;i<5;i++){ctx.fillStyle=i%2?'#3a4248':'#242c31';ctx.fillRect(W*(.34+i*.075),H*.14,52,8);}
 ctx.strokeStyle='#29333a';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(W*.30,H*.30);ctx.bezierCurveTo(W*.40,H*.24,W*.56,H*.36,W*.70,H*.27);ctx.stroke();
 ctx.fillStyle='#7c6a32';ctx.fillRect(W*.27,H*.39,36,20);
 ctx.fillStyle='#11161a';ctx.fillRect(W*.46,H*.47,86,12);ctx.fillStyle='#354149';ctx.fillRect(W*.48,H*.45,14,20);ctx.fillRect(W*.55,H*.45,14,20);
 // central desk and tablet
 ctx.fillStyle='#242b30';ctx.fillRect(W*.25,H*.53,W*.50,H*.10);ctx.fillStyle='#0a0d10';ctx.fillRect(W*.29,H*.49,W*.42,H*.075);for(let i=0;i<5;i++){ctx.fillStyle=i%2?'#26333b':'#151d23';ctx.fillRect(W*(.31+i*.075),H*.50,45,32)}(()=>{ // V98: планшет был плоским прямоугольником с обводкой в один пиксель —
  // на кадре он читался как проволочная рамка, начерченная на столешнице.
  // Стало: тень, корпус с фаской, утопленное стекло с сеткой развёртки,
  // отблеск по диагонали и дежурный светодиод.
  const tx=W*.43,ty=H*.58,tw=W*.14,th=H*.09;
  ctx.fillStyle='rgba(0,0,0,.45)';ctx.fillRect(tx+4,ty+6,tw,th);
  const tb=ctx.createLinearGradient(tx,ty,tx,ty+th);
  tb.addColorStop(0,'#333d44');tb.addColorStop(.35,'#222b31');tb.addColorStop(1,'#141a1e');
  ctx.fillStyle=tb;ctx.fillRect(tx,ty,tw,th);
  ctx.fillStyle='rgba(255,255,255,.07)';ctx.fillRect(tx,ty,tw,2);
  ctx.fillStyle='rgba(0,0,0,.35)';ctx.fillRect(tx,ty+th-2,tw,2);
  ctx.fillStyle='#080c0f';ctx.fillRect(tx+tw*.06,ty+th*.10,tw*.88,th*.72);
  ctx.strokeStyle='rgba(90,120,120,.10)';ctx.lineWidth=1;
  for(let i=1;i<6;i++){const yy=ty+th*.10+th*.72*i/6;ctx.beginPath();ctx.moveTo(tx+tw*.06,yy);ctx.lineTo(tx+tw*.94,yy);ctx.stroke();}
  const tg=ctx.createLinearGradient(tx,ty,tx+tw*.6,ty+th);
  tg.addColorStop(0,'rgba(200,225,235,.07)');tg.addColorStop(.5,'rgba(200,225,235,0)');
  ctx.fillStyle=tg;ctx.beginPath();ctx.moveTo(tx,ty);ctx.lineTo(tx+tw*.5,ty);ctx.lineTo(tx,ty+th*.8);ctx.closePath();ctx.fill();
  ctx.strokeStyle='rgba(90,104,112,.55)';ctx.lineWidth=1;ctx.strokeRect(tx+.5,ty+.5,tw-1,th-1);
  ctx.fillStyle='#2f6a55';ctx.beginPath();ctx.arc(tx+tw*.955,ty+th*.90,2.2,0,Math.PI*2);ctx.fill();
})();cameraDecor(ctx,W*.31,H*.18,.95,-.1);cameraDecor(ctx,W*.69,H*.18,.95,.1);ctx.fillStyle='#c12a36';ctx.fillRect(W*.49,H*.605,10,5);
 // Four physical CCTV monitors on the desk. One is an original art feed.
 // V98: блок настольных мониторов перенесён НИЖЕ, после officeWallProps и
 // officeProps: раньше стенная предупреждающая штриховка (0.455h) рисовалась
 // поверх экранов и как будто просвечивала сквозь корпус.

 officeWallProps(ctx,W,H,performance.now()/1000);
 officeProps(ctx,W,H,performance.now()/1000);
 // V98: экраны имели пропорции 144x25 (почти 6:1) — на кадре это были не
 // мониторы, а узкие щели. Ширина уменьшена, высота увеличена: пропорции
 // близки к 4:3, как у служебного ЭЛТ. Зоны нажатия в game.js приведены к тем
 // же числам.
 const mons=[{x:.3255,label:'КАМ 01',type:'cam'},{x:.4205,label:'КАМ 02',type:'cam'},{x:.5155,label:'АРТ',type:'art'},{x:.6105,label:'КАМ 04',type:'cam'}];
 // V98: корпус монитора был чёрным прямоугольником с обводкой в два пикселя —
 // ни толщины, ни стойки, ни стекла. Четыре таких прямоугольника читались как
 // проволочные рамки, нарисованные поверх стены, а не как аппаратура на столе.
 // Стало: тень на столешнице, стойка с ножкой, корпус с фаской и градиентом,
 // утопленное стекло с внутренней тенью и косым отблеском, индикатор питания.
 mons.forEach((m,i)=>{const x=W*m.x,y=H*.455,w=W*.044,h=H*.105,on=!!officeMonitors[i];ctx.save();
  const bxw=w+16,bxh=h+14,bx0=x-8,by0=y-8;
  ctx.fillStyle='rgba(0,0,0,.45)';                                  // тень на столешнице
  ctx.beginPath();ctx.ellipse(x+w*.5,by0+bxh+6,w*.60,H*.008,0,0,Math.PI*2);ctx.fill();
  ctx.fillStyle='#141b1f';                                          // стойка и ножка
  ctx.fillRect(x+w*.5-w*.07,by0+bxh-2,w*.14,H*.012);
  ctx.fillStyle='#1b2429';ctx.fillRect(x+w*.5-w*.20,by0+bxh+H*.008,w*.40,H*.006);
  ctx.fillStyle='rgba(255,255,255,.05)';ctx.fillRect(x+w*.5-w*.20,by0+bxh+H*.008,w*.40,1);
  const body=ctx.createLinearGradient(bx0,by0,bx0,by0+bxh);         // корпус
  body.addColorStop(0,'#39444b');body.addColorStop(.18,'#2a333a');
  body.addColorStop(.75,'#1a2226');body.addColorStop(1,'#101619');
  ctx.fillStyle=body;ctx.fillRect(bx0,by0,bxw,bxh);
  ctx.fillStyle='rgba(255,255,255,.08)';ctx.fillRect(bx0,by0,bxw,2);
  ctx.fillStyle='rgba(0,0,0,.35)';ctx.fillRect(bx0,by0+bxh-2,bxw,2);
  ctx.fillStyle='rgba(255,255,255,.04)';ctx.fillRect(bx0,by0,2,bxh);
  ctx.strokeStyle=on?'rgba(200,180,71,.55)':'rgba(74,86,94,.55)';ctx.lineWidth=1;
  ctx.strokeRect(bx0+.5,by0+.5,bxw-1,bxh-1);
  ctx.fillStyle='#0a0e11';ctx.fillRect(x-2,y-2,w+4,h+4);            // утопленное стекло
  ctx.fillStyle=on?'#102126':'#11161a';ctx.fillRect(x,y,w,h);if(on){if(m.type==='art'){const g=ctx.createRadialGradient(x+w*.5,y+h*.45,2,x+w*.5,y+h*.5,w*.6);g.addColorStop(0,'#6b2436');g.addColorStop(.35,'#21131d');g.addColorStop(1,'#030507');ctx.fillStyle=g;ctx.fillRect(x,y,w,h);ctx.fillStyle='#e9e9e4';ctx.fillRect(x+w*.32,y+h*.32,4,3);ctx.fillRect(x+w*.60,y+h*.32,4,3);ctx.fillStyle='#0a0a0b';ctx.beginPath();ctx.ellipse(x+w*.5,y+h*.62,w*.24,h*.16,0,0,Math.PI*2);ctx.fill();}else{ctx.fillStyle='#17272c';ctx.fillRect(x,y,w,h);ctx.fillStyle='#b8d1b8';ctx.font='7px "JetBrains Mono",monospace';ctx.fillText(m.label,x+5,y+11);ctx.fillStyle='rgba(200,220,220,.14)';for(let sy=y+4;sy<y+h;sy+=5)ctx.fillRect(x,sy,w,1);if(Math.random()<.12){ctx.fillStyle='rgba(220,30,45,.22)';ctx.fillRect(x+Math.random()*w,y+Math.random()*h,w*.7,2);}}}else{const dk=ctx.createLinearGradient(x,y,x,y+h);dk.addColorStop(0,'#0a0f12');dk.addColorStop(1,'#040708');
   ctx.fillStyle=dk;ctx.fillRect(x,y,w,h);
   ctx.fillStyle='#222b30';ctx.font='7px "JetBrains Mono",monospace';ctx.fillText('OFF',x+5,y+11);}
  // внутренняя тень по кромке стекла и косой отблеск на стекле
  ctx.strokeStyle='rgba(0,0,0,.55)';ctx.lineWidth=2;ctx.strokeRect(x+1,y+1,w-2,h-2);
  const gl=ctx.createLinearGradient(x,y,x+w*.7,y+h);
  gl.addColorStop(0,'rgba(210,230,240,'+(on?.10:.06)+')');
  gl.addColorStop(.42,'rgba(210,230,240,0)');
  ctx.fillStyle=gl;ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x+w*.55,y);ctx.lineTo(x,y+h*.85);ctx.closePath();ctx.fill();
  ctx.fillStyle=on?'#d5bd45':'#3c4449';                             // индикатор питания
  ctx.beginPath();ctx.arc(x+w*.5,by0+bxh-H*.008,2.2,0,Math.PI*2);ctx.fill();
  if(on){ctx.save();ctx.globalCompositeOperation='lighter';
   const sp=ctx.createRadialGradient(x+w*.5,y+h*.5,2,x+w*.5,y+h*.5,w*.9);
   sp.addColorStop(0,'rgba(120,200,190,.10)');sp.addColorStop(1,'rgba(120,200,190,0)');
   ctx.fillStyle=sp;ctx.beginPath();ctx.arc(x+w*.5,y+h*.5,w*.9,0,Math.PI*2);ctx.fill();ctx.restore();}
  ctx.restore();});
 officeShift(ctx,W,H,performance.now()/1000);
 officeAtmos(ctx,W,H,performance.now()/1000,lights);
 officeWebs(ctx,W,H);
 drawVentTunnel(ctx,W,H,performance.now()/1000);
} 
 // V72: глаза в темноте. Ни фигуры, ни тени — только две тусклые точки, которые
 // моргают и слабо плывут. Единственный намёк на то, что в проёме кто-то стоит.
 function eyesInDark(ctx,cx,feetY,m,sc){
   if(!m)return false;
   const t=performance.now()/1000, s=Math.max(0.25,sc||1);
   const kind=m.kind||'main';
   const eye=kind==='exo'?'214,246,255':kind==='felix'?'255,196,228':kind==='lav'?'255,240,176':'255,116,126';
   const seed=(kind.length*0.7+(kind.charCodeAt(0)%7)*0.31);
   // редкое медленное моргание
   const ph=(t*0.34+seed)%1;
   if(ph>0.955)return true;
   const danger=m.state==='preparingAttack';
   const br=danger?(0.62+0.38*Math.abs(Math.sin(t*5.2))):(0.42+0.30*Math.abs(Math.sin(t*1.35+seed)));
   const eyeY=feetY-118*s;
   const sway=Math.sin(t*0.55+seed)*2.4*s;
   const gap=13*s, ew=Math.max(1,6*s), eh=Math.max(1,3.4*s);
   ctx.save();ctx.globalCompositeOperation='lighter';ctx.translate(cx+sway,eyeY);
   const gr=ctx.createRadialGradient(0,0,1,0,0,30*s);
   gr.addColorStop(0,`rgba(${eye},${(0.30*br).toFixed(3)})`);
   gr.addColorStop(0.45,`rgba(${eye},${(0.10*br).toFixed(3)})`);
   gr.addColorStop(1,`rgba(${eye},0)`);
   ctx.fillStyle=gr;ctx.fillRect(-32*s,-26*s,64*s,52*s);
   ctx.fillStyle=`rgba(${eye},${Math.min(1,0.42+0.5*br).toFixed(3)})`;
   ctx.fillRect(-gap-ew,-eh/2,ew,eh);ctx.fillRect(gap,-eh/2,ew,eh);
   ctx.restore();
   return true;
 }
 // V83: створка ЕЗДИТ. Раньше аргумент был булевым, и дверь мгновенно
 // «телепортировалась» между открытым и закрытым состоянием. Теперь принимается
 // прогресс 0..1 (булево значение по-прежнему работает), и панель съезжает вниз
 // по направляющим с видимой нижней кромкой.
 function drawDoorBay(ctx,x,y,w,h,doorState,side,light,monsters=[],doorSide='left'){
  const prog=typeof doorState==='number'?Math.max(0,Math.min(1,doorState)):(doorState?1:0);
  const closed=prog>0.55;
  ctx.save();
  const active=!!light.on && !light.renderOff;
  const tNow=performance.now()/1000;
  const tier=(window.__PERF&&window.__PERF.tier)||0;
  // Кто уже стоит в этом проёме — нужно знать заранее: от этого зависит плотность темноты.
  const at=monsters.filter(m=>m&&m.room===0&&m.doorSide===doorSide&&(m.state==='atDoor'||m.state==='preparingAttack'||m.state==='attacking'));
  // «дыхание» темноты, когда кто-то подошёл к двери охраны
  const prox=at.length?(0.55+0.45*Math.abs(Math.sin(tNow*0.8))):0;
  // Deep doorway recess.
  ctx.fillStyle='#030507';ctx.fillRect(x,y,w,h);
  // Corridor floor with perspective lines.
  const floorY=y+h*.64;
  ctx.fillStyle=active?'#242a2d':'#060809';ctx.beginPath();ctx.moveTo(x+w*.20,floorY);ctx.lineTo(x+w*.80,floorY);ctx.lineTo(x+w*.96,y+h);ctx.lineTo(x+w*.04,y+h);ctx.closePath();ctx.fill();
  ctx.strokeStyle=active?'#596268':'#101418';ctx.lineWidth=1;
  for(let i=0;i<6;i++){const yy=floorY+(h*.36)*(i/6);ctx.beginPath();ctx.moveTo(x+w*.05,yy);ctx.lineTo(x+w*.95,yy);ctx.stroke();}
  for(let i=0;i<7;i++){const xx=x+w*(.08+i*.14);ctx.beginPath();ctx.moveTo(x+w*.5,floorY);ctx.lineTo(xx,y+h);ctx.stroke();}
  // Side walls and ceiling.
  ctx.fillStyle=active?'#1b2226':'#05070a';ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x+w*.24,y);ctx.lineTo(x+w*.34,floorY);ctx.lineTo(x,floorY);ctx.closePath();ctx.fill();ctx.beginPath();ctx.moveTo(x+w,y);ctx.lineTo(x+w*.76,y);ctx.lineTo(x+w*.66,floorY);ctx.lineTo(x+w,floorY);ctx.closePath();ctx.fill();
  ctx.fillStyle=active?'#343b3e':'#080b0e';ctx.beginPath();ctx.moveTo(x+w*.24,y);ctx.lineTo(x+w*.76,y);ctx.lineTo(x+w*.66,floorY);ctx.lineTo(x+w*.34,floorY);ctx.closePath();ctx.fill();
  // === V84: ЖЁЛТЫЙ СВЕТ В ПРОЁМЕ — БЕЗ ЗАСВЕТА ===
  // Раньше здесь лежала плоская жёлтая плита на весь проём («lighter» + «screen»
  // поверх друг друга), из-за которой коридор превращался в светящийся
  // прямоугольник без глубины. Теперь свет строится физично: узкий конус от
  // плафона с честным затуханием, отдельный отблеск на полу и компактный ореол.
  // Все альфы снижены в 2–4 раза, режим наложения только один — 'lighter'.
  if(active){
    // лёгкое общее подсвечивание коридора: очень слабое, только чтобы стены
    // перестали быть чёрными — форму даёт уже сам конус ниже
    ctx.save();
    ctx.globalCompositeOperation='lighter';
    ctx.fillStyle='rgba(255,214,96,0.030)';
    ctx.beginPath();
    ctx.moveTo(x+w*.30,y+h*.05); ctx.lineTo(x+w*.70,y+h*.05);
    ctx.lineTo(x+w*.94,y+h*.94); ctx.lineTo(x+w*.06,y+h*.94);
    ctx.closePath(); ctx.fill();
    // основной конус: яркое ядро у плафона, к полу почти гаснет
    const cone=ctx.createLinearGradient(x+w*.5,y+h*.07,x+w*.5,y+h*.90);
    cone.addColorStop(0,'rgba(255,246,196,0.15)');
    cone.addColorStop(.22,'rgba(255,226,120,0.070)');
    cone.addColorStop(.58,'rgba(255,206,64,0.026)');
    cone.addColorStop(1,'rgba(255,190,30,0)');
    ctx.fillStyle=cone;
    ctx.beginPath();ctx.moveTo(x+w*.40,y+h*.07);ctx.lineTo(x+w*.60,y+h*.07);
    ctx.lineTo(x+w*.86,y+h*.90);ctx.lineTo(x+w*.14,y+h*.90);ctx.closePath();ctx.fill();
    ctx.restore();
    // плафон: лампа сама остаётся яркой точкой — источник должен читаться
    ctx.save();
    ctx.fillStyle='#fff6cf';ctx.shadowColor='#ffdf5a';ctx.shadowBlur=14;ctx.fillRect(x+w*.40,y+h*.048,w*.20,7);
    ctx.fillStyle='#ffe45c';ctx.shadowBlur=8;ctx.fillRect(x+w*.42,y+h*.052,w*.16,4);ctx.restore();
    // компактный ореол вокруг плафона (радиус вдвое меньше прежнего)
    ctx.save();
    ctx.globalCompositeOperation='lighter';
    const halo=ctx.createRadialGradient(x+w*.5,y+h*.085,2,x+w*.5,y+h*.085,w*.26);
    halo.addColorStop(0,'rgba(255,250,205,0.18)');
    halo.addColorStop(.30,'rgba(255,226,96,0.065)');
    halo.addColorStop(1,'rgba(255,190,20,0)');
    ctx.fillStyle=halo; ctx.fillRect(x+w*.18,y,w*.64,h*.26);
    ctx.restore();
    // отблеск на полу коридора: тёплое пятно с мягкой границей
    ctx.save();ctx.globalCompositeOperation='lighter';
    const pool=ctx.createRadialGradient(x+w*.5,y+h*.80,2,x+w*.5,y+h*.80,w*.40);
    pool.addColorStop(0,'rgba(255,214,96,0.060)');
    pool.addColorStop(1,'rgba(255,200,60,0)');
    ctx.fillStyle=pool;ctx.beginPath();ctx.ellipse(x+w*.5,y+h*.80,w*.40,h*.11,0,0,Math.PI*2);ctx.fill();
    ctx.restore();
    // затемнение по краям проёма: без него свет всё равно кажется «плитой»
    const eg=ctx.createRadialGradient(x+w*.5,y+h*.50,w*.14,x+w*.5,y+h*.50,w*.72);
    eg.addColorStop(0,'rgba(2,3,5,0)');
    eg.addColorStop(.70,'rgba(2,3,5,0.30)');
    eg.addColorStop(1,'rgba(1,2,4,0.68)');
    ctx.fillStyle=eg;ctx.fillRect(x,y,w,h);
  } else {
    // === V72: НАСТОЯЩАЯ ТЕМНОТА В ПРОЁМЕ ===
    // Лампа погашена: коридор тонет в черноте. Остаются только намёки на глубину —
    // далёкая аварийная полоска в конце коридора, холодная дымка у пола и редкая
    // пыль в воздухе. Когда кто-то подошёл к двери, темнота становится плотнее.
    ctx.fillStyle='#191c1e';ctx.fillRect(x+w*.42,y+h*.055,w*.16,5);   // погашенный плафон
    ctx.save();ctx.globalCompositeOperation='lighter';
    // далёкая аварийная полоска — единственный источник в глубине
    const far=0.055+0.045*Math.abs(Math.sin(tNow*0.63))-prox*0.02;
    if(far>0){ctx.fillStyle=`rgba(104,132,158,${far.toFixed(3)})`;ctx.fillRect(x+w*.36,floorY-h*.022,w*.28,2);}
    // холодное свечение у пола: пол чуть светлее стен, глубина читается
    const fh=ctx.createRadialGradient(x+w*.5,floorY+h*.02,2,x+w*.5,floorY+h*.02,w*.55);
    fh.addColorStop(0,`rgba(70,98,124,${(0.055+0.03*prox).toFixed(3)})`);
    fh.addColorStop(1,'rgba(56,84,112,0)');
    ctx.fillStyle=fh;ctx.fillRect(x,floorY-h*.16,w,h*.40);
    // пыль в воздухе (при просадке кадров выключается)
    if(tier<2){
      const N=tier===0?9:5;
      for(let i=0;i<N;i++){
        const sd=i*1.7+1.1;
        const px=x+w*(0.22+0.56*((Math.sin(sd*2.3)+1)/2)+0.05*Math.sin(tNow*0.35+sd));
        const py=y+h*(0.18+0.62*(((tNow*0.045+i*0.11)%1)));
        ctx.fillStyle=`rgba(150,172,190,${(0.05+0.05*Math.abs(Math.sin(tNow*1.1+sd))).toFixed(3)})`;
        ctx.fillRect(px,py,1.5,1.5);
      }
    }
    ctx.restore();
    // плотная тьма от краёв проёма к центру
    const vg=ctx.createRadialGradient(x+w*.5,y+h*.56,w*.06,x+w*.5,y+h*.56,w*.80);
    vg.addColorStop(0,`rgba(2,3,5,${(0.30+0.18*prox).toFixed(3)})`);
    vg.addColorStop(0.55,`rgba(1,2,4,${(0.62+0.14*prox).toFixed(3)})`);
    vg.addColorStop(1,`rgba(0,0,1,${(0.90+0.06*prox).toFixed(3)})`);
    ctx.fillStyle=vg;ctx.fillRect(x,y,w,h);
  }
  // Back wall details visible only in the corridor.
  if(active){
    ctx.strokeStyle='#687278';ctx.lineWidth=2;ctx.strokeRect(x+w*.34,y+h*.18,w*.32,h*.40);
    ctx.fillStyle='#5d686c';ctx.fillRect(x+w*.46,y+h*.27,w*.08,5);ctx.fillRect(x+w*.42,y+h*.47,w*.16,3);
  }
  // Door frame.
  ctx.fillStyle='#171d21';ctx.fillRect(x,y,w*.045,h);ctx.fillRect(x+w*.955,y,w*.045,h);ctx.fillStyle='#3d474d';ctx.fillRect(x,y,w*.045,5);ctx.fillRect(x+w*.955,y,w*.045,5);
  // Proper segmented security door, slides vertically like a heavy industrial shutter.
  {
    const doorTop=y+h*.05,doorH=h*.72;
    // Поднятая створка в кожухе над проёмом: чем ниже опустилась дверь, тем
    // меньше её видно сверху.
    const raised=h*.13*(1-prog);
    if(raised>1.5){
      ctx.fillStyle='#2d353b';ctx.fillRect(x+w*.035,y,w*.93,raised);ctx.strokeStyle='#59656d';ctx.lineWidth=2;ctx.strokeRect(x+w*.035,y,w*.93,raised);
      for(let i=0;i<4;i++){const yy=y+h*(.02+i*.028);if(yy<y+raised-2){ctx.fillStyle=i%2?'#1f272c':'#384148';ctx.fillRect(x+w*.07,yy,w*.86,4);}}
    }
    if(prog>0.004){
      const ph=doorH*prog;
      ctx.save();ctx.beginPath();ctx.rect(x+w*.035,doorTop,w*.93,ph);ctx.clip();
      ctx.fillStyle='#30383e';ctx.fillRect(x+w*.035,doorTop,w*.93,doorH);ctx.strokeStyle='#59656d';ctx.lineWidth=2;ctx.strokeRect(x+w*.035,doorTop,w*.93,doorH);
      for(let i=0;i<9;i++){const yy=doorTop+i*(doorH/9);ctx.fillStyle=i%2?'#262e34':'#323a40';ctx.fillRect(x+w*.045,yy,w*.91,doorH/9-2);ctx.strokeStyle='#14191d';ctx.beginPath();ctx.moveTo(x+w*.045,yy);ctx.lineTo(x+w*.955,yy);ctx.stroke();}
      // bolts / vertical rails
      ctx.fillStyle='#667078';for(let i=0;i<5;i++){ctx.beginPath();ctx.arc(x+w*(.14+i*.18),doorTop+doorH*.50,2.5,0,Math.PI*2);ctx.fill();}
      ctx.restore();
      // Нижняя кромка створки — по ней и читается движение.
      ctx.fillStyle='#8d979f';ctx.fillRect(x+w*.035,doorTop+ph-3,w*.93,3);
      ctx.fillStyle='rgba(0,0,0,.55)';ctx.fillRect(x+w*.035,doorTop+ph,w*.93,Math.min(7,doorH-ph));
    }
    ctx.fillStyle='#b72b36';ctx.fillRect(side?x-18:x+w+10,y+h*.39,7,20);
  }
  // === V84: ФИНАЛЬНЫЙ ПРОХОД СВЕТА (полностью переписан) ===
  // Здесь стояли ДВА прохода 'source-over' с альфой до 0.96 на весь проём
  // («FINAL LIGHT PASS» и «v20 guaranteed visible light»). Именно они превращали
  // освещённый коридор в плоскую жёлтую плиту и давали засвет всего экрана.
  // Теперь остаётся один аккуратный проход: тёплый градиент малой плотности
  // в режиме 'lighter', яркий плафон и короткие лучи только у самой лампы.
  if(active && !closed){
    ctx.save();
    ctx.globalCompositeOperation='lighter';
    const wash=ctx.createLinearGradient(x+w*.5,y+h*.09,x+w*.5,y+h*.94);
    wash.addColorStop(0,'rgba(255,246,178,0.13)');
    wash.addColorStop(.20,'rgba(255,230,110,0.060)');
    wash.addColorStop(.58,'rgba(255,208,60,0.022)');
    wash.addColorStop(1,'rgba(255,190,20,0)');
    ctx.fillStyle=wash;
    ctx.beginPath();
    ctx.moveTo(x+w*.33,y+h*.09);ctx.lineTo(x+w*.67,y+h*.09);
    ctx.lineTo(x+w*.90,y+h*.94);ctx.lineTo(x+w*.10,y+h*.94);
    ctx.closePath();ctx.fill();
    // отблеск на полу коридора
    const pool=ctx.createRadialGradient(x+w*.5,y+h*.84,2,x+w*.5,y+h*.84,w*.44);
    pool.addColorStop(0,'rgba(255,238,132,0.10)');
    pool.addColorStop(.40,'rgba(255,216,64,0.034)');
    pool.addColorStop(1,'rgba(255,190,20,0)');
    ctx.fillStyle=pool;ctx.beginPath();ctx.ellipse(x+w*.5,y+h*.84,w*.44,h*.11,0,0,Math.PI*2);ctx.fill();
    // короткие лучи у плафона: гаснут на трети высоты проёма
    ctx.lineWidth=2;
    for(let i=0;i<7;i++){
      ctx.strokeStyle=`rgba(255,228,96,${(0.045-i*0.006).toFixed(3)})`;
      ctx.beginPath();ctx.moveTo(x+w*.5,y+h*.09);ctx.lineTo(x+w*(.20+i*.10),y+h*.44);ctx.stroke();
    }
    ctx.restore();
    // сам плафон рисуется без наложения — источник должен быть самым ярким пятном
    ctx.save();
    ctx.fillStyle='#fffbe0';ctx.shadowColor='#ffe14a';ctx.shadowBlur=18;
    ctx.fillRect(x+w*.36,y+h*.030,w*.28,11);
    ctx.fillStyle='#ffdc3f';ctx.shadowBlur=10;ctx.fillRect(x+w*.39,y+h*.048,w*.22,6);
    ctx.shadowBlur=0;ctx.restore();
  }
  // === V72: КТО СТОИТ В ПРОЁМЕ ===
  // Свет выключен — не видно ни фигуры, ни тени: только глаза, и только у ОДНОГО
  // (того, кто подошёл первым). Остальные проявляются лишь при включённой лампе.
  if(at.length && !closed && !active){
    eyesInDark(ctx,x+w*.50,y+h*.755,at[0],1);
  }
  if(at.length && !closed && active){
    // ============ V102: С 4-Й СМЕНЫ В ПРОЁМЕ ВИДНО ХУЖЕ ============
    // ПОЧЕМУ ТАК БЫЛО: лампа всегда показывала подошедшего одинаково ясно —
    // на пятой смене проверить дверь было так же безопасно, как на первой.
    // СТАЛО: с четвёртой смены свет в проёме сажает фигуру в полутень
    // (видно силуэт и глаза, но не понять сразу, кто это), с пятой — почти
    // ничего, кроме контура. Смены 6 и 7 идут по пятой.
    // Значение приходит из game.js (doorVisPenalty): 0 / 0.38 / 0.72.
    const vis=Math.max(0,Math.min(1,window.__doorVis||0));
    at.forEach((m,i)=>{
      ctx.save();
      if(vis>0)ctx.globalAlpha=1-0.62*vis;
      // если у одной двери столпилось несколько аниматроников — разводим их по ширине проёма
      const spread=at.length>1?(i-(at.length-1)/2)*w*.17:0;
      // Ступни ставятся точно на пол проёма, следующие стоят глубже и мельче — фигуры
      // читаются стоящими в коридоре, а не наклеенными поверх проёма.
      const depth=i*0.07, sc=1-depth, fy=y+h*(.755-depth*.85);
      // мягкая контактная тень под ногами
      const cw=w*.20*sc, ch=h*.032*sc;
      ctx.save();ctx.translate(x+w*.50+spread,fy);ctx.scale(1,ch/cw);
      const cg2=ctx.createRadialGradient(0,0,1,0,0,cw);
      cg2.addColorStop(0,'rgba(0,0,0,.78)');cg2.addColorStop(.55,'rgba(0,0,0,.32)');cg2.addColorStop(1,'rgba(0,0,0,0)');
      ctx.fillStyle=cg2;ctx.fillRect(-cw,-cw,cw*2,cw*2);ctx.restore();
      ctx.save();ctx.translate(x+w*.50+spread,fy);ctx.scale(sc,sc);
      drawDoorMonster(ctx,0,-70,m,false,vis>0.6);
      ctx.restore();
      ctx.restore();
    });
    // общая пелена темноты поверх фигур: свет как будто не достаёт до них
    if(vis>0){
      ctx.save();
      ctx.fillStyle='rgba(3,5,8,'+(0.58*vis).toFixed(3)+')';
      ctx.fillRect(x,y+h*0.20,w,h*0.80);
      ctx.restore();
    }
  }

  // Small physical yellow lamp switch next to each doorway.
  ctx.fillStyle='#0c1013';ctx.fillRect(side?x-48:x+w+18,y+h*.63,30,44);ctx.strokeStyle='#665d20';ctx.strokeRect(side?x-48:x+w+18,y+h*.63,30,44);
  ctx.fillStyle=active?'#f1d23a':'#75691b';ctx.shadowColor=active?'#ffe55b':'transparent';ctx.shadowBlur=active?15:0;ctx.fillRect(side?x-41:x+w+25,y+h*.68,16,16);ctx.shadowBlur=0;
  ctx.restore();
 }
 function drawDoorMonster(ctx,x,y,m,behindDoor=false,darkMode=false){
   const felix=m.kind==='felix',exo=m.kind==='exo',t=performance.now()/1000;
   const main=exo?'#5f7d8b':felix?'#7a38a8':'#a52332',dark=exo?'#0e171c':felix?'#1b0b28':'#24070b',mid=exo?'#3d5b68':felix?'#5b267d':'#6f1723',hi=exo?'#79ecff':felix?'#d06cff':'#ff4658',eye=exo?'#e6feff':felix?'#f0a0ff':'#ff6672';
   const glitch=Math.floor(t*12)%7===0;
   ctx.save();ctx.translate(x,y);ctx.scale(felix?1.02:exo?1.05:.99,felix?1.02:exo?1.05:.99);ctx.imageSmoothingEnabled=false;
   if(darkMode){
     // Shadow-only silhouette: body is nearly swallowed by darkness, eyes remain barely visible.
     ctx.fillStyle='rgba(0,0,0,.96)';ctx.fillRect(-25,-62,50,132);ctx.fillRect(-42,-15,14,62);ctx.fillRect(28,-10,14,62);
     ctx.fillStyle=eye;ctx.shadowColor=hi;ctx.shadowBlur=6;ctx.globalAlpha=.72;ctx.fillRect(-17,-47,7,4);ctx.fillRect(10,-47,7,4);ctx.shadowBlur=0;
     if(Math.floor(t*9)%5===0){ctx.globalAlpha=.18;ctx.fillStyle=hi;ctx.fillRect(-28,-30,56,2);}
     ctx.restore(); return;
   }
   ctx.globalAlpha=behindDoor?.72:1;
   ctx.fillStyle='rgba(0,0,0,.8)';ctx.fillRect(-32,70,64,7);ctx.fillRect(-43,73,86,3);
   // Pixel body: deliberately blocky, asymmetrical and glitchy.
   ctx.fillStyle=dark;ctx.fillRect(-25,26,14,46);ctx.fillRect(10,27,15,45);ctx.fillRect(-31,-18,62,50);
   ctx.fillStyle=main;ctx.fillRect(-25,43,19,11);ctx.fillRect(8,45,21,11);ctx.fillRect(-24,-14,48,38);ctx.fillRect(-18,-21,36,8);
   ctx.fillStyle=mid;ctx.fillRect(-14,-4,28,26);ctx.fillStyle=dark;ctx.fillRect(-8,-1,16,29);
   for(let i=0;i<4;i++){ctx.fillStyle=hi;ctx.fillRect(-5,3+i*7,10,3);}
   ctx.fillStyle=dark;ctx.fillRect(-40,-12,12,44);ctx.fillRect(28,-8,12,47);ctx.fillStyle=main;ctx.fillRect(-43,6,15,10);ctx.fillRect(28,10,16,10);
   ctx.fillStyle=hi;ctx.fillRect(-43,25,8,4);ctx.fillRect(36,28,8,4);ctx.fillStyle=dark;ctx.fillRect(-45,32,10,13);ctx.fillRect(35,35,10,13);
   for(let i=0;i<3;i++){ctx.fillStyle=hi;ctx.fillRect(-46+i*4,44,2,8);ctx.fillRect(38+i*3,46,2,8);}
   ctx.fillStyle=dark;ctx.fillRect(-31,-63,62,43);ctx.fillRect(-25,-70,50,9);ctx.fillRect(-39,-55,8,25);ctx.fillRect(31,-54,8,25);ctx.fillRect(-23,-76,10,8);ctx.fillRect(12,-79,11,10);
   ctx.fillStyle=mid;ctx.fillRect(-25,-58,50,30);ctx.fillRect(-18,-66,36,8);ctx.fillStyle='#09070b';ctx.fillRect(-22,-51,15,11);ctx.fillRect(7,-51,15,11);
   ctx.fillStyle=eye;ctx.shadowColor=hi;ctx.shadowBlur=12;ctx.fillRect(-18,-48,9,5);ctx.fillRect(10,-48,9,5);ctx.shadowBlur=0;
   ctx.fillStyle='#030204';ctx.fillRect(-23,-27,46,17);ctx.fillStyle=exo?'#cfe9f2':felix?'#f0d4ff':'#ffe2e5';for(let i=0;i<7;i++)ctx.fillRect(-20+i*6,-25+(i%2),3,7);
   // EXO: визор-щель, открытые рёбра, антенна.
   if(exo){
     ctx.fillStyle='#050b0e';ctx.fillRect(-27,-49,54,7);
     ctx.fillStyle=hi;ctx.shadowColor=hi;ctx.shadowBlur=16;ctx.fillRect(-24,-47,48,3);ctx.shadowBlur=0;
     ctx.fillStyle='#7d8f98';for(let i=0;i<5;i++)ctx.fillRect(-20+i*9,-20+i%2,4,26);
     ctx.fillStyle=dark;ctx.fillRect(-3,-84,3,14);ctx.fillStyle=hi;ctx.fillRect(-4,-88,5,5);
   }
   ctx.fillStyle=hi;ctx.fillRect(-30,-36,4,12);ctx.fillRect(26,-40,4,16);ctx.fillRect(-4,25,8,5);
   if(glitch){ctx.globalAlpha=.72;ctx.fillStyle=hi;ctx.fillRect(-45,-12,90,3);ctx.fillRect(-34,18,68,2);ctx.globalAlpha=behindDoor?.72:1;}
   if(m.state==='preparingAttack'&&(m.warning||0)>0){
     // Без текста и таймера: только тревожное свечение вокруг фигуры (чем меньше времени, тем ярче).
     const remain=Math.max(0,m.warning),danger=remain<=1.6,pulse=.55+.45*Math.abs(Math.sin(performance.now()/(danger?90:150)));
     const col=exo?'87,216,245':felix?'199,92,255':'255,36,56';
     ctx.save();ctx.globalCompositeOperation='lighter';
     const hg=ctx.createRadialGradient(0,-30,4,0,-30,120);
     hg.addColorStop(0,`rgba(${col},${(danger?.30:.18)*pulse})`);hg.addColorStop(1,`rgba(${col},0)`);
     ctx.fillStyle=hg;ctx.beginPath();ctx.arc(0,-30,120,0,Math.PI*2);ctx.fill();ctx.restore();
   }
   ctx.restore();
 }
 function drawLightSwitch(ctx,x,y,side,on){
   ctx.save();ctx.translate(x,y);ctx.fillStyle='#17191b';ctx.fillRect(-24,-16,48,34);ctx.strokeStyle='#6d5f19';ctx.lineWidth=2;ctx.strokeRect(-24,-16,48,34);ctx.fillStyle=on?'#e4cf35':'#8b7b1a';ctx.shadowColor=on?'#ffe34b':'transparent';ctx.shadowBlur=on?16:0;ctx.fillRect(-12,-8,24,16);ctx.shadowBlur=0;ctx.fillStyle='#17120a';ctx.font='9px "Inter",Arial,sans-serif';ctx.textAlign='center';ctx.fillText(side==='left'?'L':'R',0,4);ctx.restore();
 }
 function text2(ctx,s,x,y,size,fill='#eee',align='left'){ctx.font=`${size}px "Inter",Arial,sans-serif`;ctx.fillStyle=fill;ctx.textAlign=align;ctx.fillText(String(s),x,y)}
 // ---- Corridor rooms (6 and 7): the only approaches to the security office ----
 // A long perspective corridor receding toward the office door. The far doorway is the
 // ОХРАНА entrance, always visible on these cameras. Red emergency lighting flickers.
 function corridorCore(ctx,W,H,t,label,doorOnLeft,alert,state){
   // state = {closed, lightOn, renderOff, flicker} — реальное состояние двери охраны и
   // света с этой стороны: коридор А связан с ЛЕВОЙ дверью, коридор Б — с ПРАВОЙ.
   const st=state||{};
   const doorClosed=!!st.closed;
   const lightOn=!!st.lightOn && !st.renderOff;
   bg(ctx,W,H);
   // alert: 0 — коридор пуст (красный круг ПОГАШЕН), 1 — аниматроник в коридоре,
   // 2 — аниматроник уже у двери охраны (маяк бьёт в полную силу).
   const AL=Math.max(0,Math.min(2,alert||0));
   const alarm=AL>0?0.5+0.5*Math.abs(Math.sin(t*(AL>1?9:5))):0;
   const alevel=AL>1?1:AL>0?0.62:0;
   const vpX=W*0.50+(doorOnLeft?W*0.04:-W*0.04), vpY=H*0.42;
   const hw=W*0.20; // half-width of the far opening
   const flick=0.55+0.45*Math.abs(Math.sin(t*6.5+ (doorOnLeft?1.3:0)));
   // ceiling
   ctx.fillStyle='#0b1116';ctx.beginPath();ctx.moveTo(0,0);ctx.lineTo(W,0);ctx.lineTo(vpX+hw,vpY);ctx.lineTo(vpX-hw,vpY);ctx.closePath();ctx.fill();
   // upper wall slats (left + right) receding
   for(let s=0;s<2;s++){const dir=s?1:-1;ctx.fillStyle='#10171c';ctx.beginPath();ctx.moveTo(dir<0?0:W,0);ctx.lineTo(dir<0?0:W,H*0.75);ctx.lineTo(vpX+dir*hw,vpY+H*0.30);ctx.lineTo(vpX+dir*hw,vpY);ctx.closePath();ctx.fill();}
   // floor
   const fg=ctx.createLinearGradient(0,vpY,0,H);fg.addColorStop(0,'#141c23');fg.addColorStop(1,'#0a0e12');
   ctx.fillStyle=fg;ctx.beginPath();ctx.moveTo(0,H);ctx.lineTo(W,H);ctx.lineTo(vpX+hw,vpY+H*0.02);ctx.lineTo(vpX-hw,vpY+H*0.02);ctx.closePath();ctx.fill();
   // perspective floor tiles
   // V99: было — шесть поперечных швов с ровным шагом (yy=H*(1-k*0.56)):
   // плитка не сжималась к горизонту и пол читался как лестница, а не как даль.
   // Стало: шаг по 1/z — у камеры широкий, у двери почти слитный.
   const fy0=vpY+H*0.02;
   ctx.strokeStyle='rgba(96,116,128,.22)';ctx.lineWidth=1;
   for(let i=1;i<=9;i++){
     const z=i/9, k=1-z*z, yy=fy0+(H-fy0)*k;
     const x0=(vpX-hw)*(1-k);
     const x1=(vpX+hw)+(W-(vpX+hw))*k;
     ctx.beginPath();ctx.moveTo(x0,yy);ctx.lineTo(x1,yy);ctx.stroke();
   }
   for(let i=0;i<9;i++){const xx=W*(i/8);ctx.beginPath();ctx.moveTo(xx,H);ctx.lineTo(vpX+(xx-W*0.5)*0.18,fy0);ctx.stroke();}
   // side wall panels + cables
   // V99: все четыре панели сходились в ОДНУ и ту же дальнюю полоску (y1 не зависел
   // от i) — то есть лежали друг на друге, и стена выглядела плоской чёрной заливкой.
   // Стало: у каждого яруса свой дальний край, плюс вертикальные стыки и плинтус.
   for(let s=0;s<2;s++){const dir=s?1:-1;
     const xN=dir<0?0:W, xF=vpX+dir*hw;
     const yFtop=vpY, yFbot=vpY+H*0.30;                 // дальние границы стены
     const yNtop=0, yNbot=H*0.78;                       // ближние границы
     const TIERS=4;
     for(let i=0;i<TIERS;i++){
       const a=i/TIERS, b=(i+1)/TIERS;
       const nA=yNtop+(yNbot-yNtop)*a, nB=yNtop+(yNbot-yNtop)*b;
       const fA=yFtop+(yFbot-yFtop)*a, fB=yFtop+(yFbot-yFtop)*b;
       ctx.fillStyle=i%2?'#232f39':'#131b22';
       ctx.beginPath();ctx.moveTo(xN,nA);ctx.lineTo(xN,nB);ctx.lineTo(xF,fB);ctx.lineTo(xF,fA);ctx.closePath();ctx.fill();
       ctx.strokeStyle='rgba(0,0,0,.45)';ctx.lineWidth=1;
       ctx.beginPath();ctx.moveTo(xN,nB);ctx.lineTo(xF,fB);ctx.stroke();
     }
     // вертикальные стыки панелей — шаг сжимается к дальнему концу
     for(let j=1;j<=5;j++){
       const z=j/6, k=1-z*z;
       const xx=xF+(xN-xF)*k;
       const yTop=yFtop+(yNtop-yFtop)*k, yBot=yFbot+(yNbot-yFbot)*k;
       ctx.strokeStyle=`rgba(112,132,146,${(0.14+0.10*k).toFixed(3)})`;ctx.lineWidth=1;
       ctx.beginPath();ctx.moveTo(xx,yTop);ctx.lineTo(xx,yBot);ctx.stroke();
     }
     // плинтус: стена и пол больше не сливаются в одно чёрное поле
     ctx.fillStyle='#27323a';
     ctx.beginPath();ctx.moveTo(xN,yNbot);ctx.lineTo(xF,yFbot);ctx.lineTo(xF,yFbot-H*0.012);ctx.lineTo(xN,yNbot-H*0.045);ctx.closePath();ctx.fill();
     ctx.strokeStyle='rgba(150,170,186,.10)';ctx.lineWidth=1;
     ctx.beginPath();ctx.moveTo(xN,yNbot-H*0.045);ctx.lineTo(xF,yFbot-H*0.012);ctx.stroke();
     // V99: кабель раньше был просто дугой в пустоте. Теперь он идёт по стене
     // на видимых хомутах — читается как проводка, а не как случайная линия.
     {
       const P0=[dir<0?0:W,H*0.10], P1=[vpX+dir*hw*0.6,H*0.20],
             P2=[vpX+dir*hw*0.9,H*0.30], P3=[vpX+dir*hw*0.7,H*0.40];
       const bez=(u)=>{const m=1-u;return [
         m*m*m*P0[0]+3*m*m*u*P1[0]+3*m*u*u*P2[0]+u*u*u*P3[0],
         m*m*m*P0[1]+3*m*m*u*P1[1]+3*m*u*u*P2[1]+u*u*u*P3[1]];};
       ctx.strokeStyle='rgba(0,0,0,.40)';ctx.lineWidth=5;
       ctx.beginPath();ctx.moveTo(P0[0],P0[1]+3);ctx.bezierCurveTo(P1[0],P1[1]+3,P2[0],P2[1]+3,P3[0],P3[1]+3);ctx.stroke();
       ctx.strokeStyle='#2b3841';ctx.lineWidth=3.2;
       ctx.beginPath();ctx.moveTo(P0[0],P0[1]);ctx.bezierCurveTo(P1[0],P1[1],P2[0],P2[1],P3[0],P3[1]);ctx.stroke();
       ctx.strokeStyle='rgba(160,180,196,.14)';ctx.lineWidth=1;
       ctx.beginPath();ctx.moveTo(P0[0],P0[1]-1);ctx.bezierCurveTo(P1[0],P1[1]-1,P2[0],P2[1]-1,P3[0],P3[1]-1);ctx.stroke();
       for(let c=1;c<=3;c++){
         const pt=bez(c/4), sz=6-c*1.1;
         ctx.fillStyle='#39434a';ctx.fillRect(pt[0]-sz/2,pt[1]-sz/2-1,sz,sz+2);
         ctx.fillStyle='rgba(200,212,220,.22)';ctx.fillRect(pt[0]-sz/2,pt[1]-sz/2-1,sz,1);
       }
     }
   }
   // ceiling light strips receding toward the door
   // V72: потолочные плафоны в коридорах почти мёртвые: пока охранник не включит
   // свою лампу, коридор остаётся тёмным.
   for(let i=0;i<4;i++){const k=i/4;const lx=W*0.5+(vpX-W*0.5)*k;const ly=H*0.05+vpY*k*0.6;const lw=W*0.34*(1-k*0.55);ctx.fillStyle=i%2?(lightOn?'#2a3338':'#141a1e'):(lightOn?'#1a2227':'#0e1418');ctx.fillRect(lx-lw/2,ly,lw,5);const strip=lightOn?(0.14+0.08*flick*(1-k)):(0.040+0.022*flick*(1-k));ctx.fillStyle=`rgba(255,236,150,${strip.toFixed(3)})`;ctx.fillRect(lx-lw/2,ly+5,lw,3);}
   // FAR OFFICE DOOR — the ОХРАНА entrance, always visible at the end of the corridor.
   const dx=vpX, dy=vpY+H*0.02, dw=hw*1.7, dh=H*0.30;
   // V99: было — дверной проём обозначала одна светлая рамка в 6px, и в тёмном
   // коридоре она читалась как контур, начерченный по черноте. Стало: тень на стене,
   // боковые откосы разной светлоты, перекладина и порог на полу с заклёпками.
   ctx.fillStyle='rgba(0,0,0,.45)';ctx.fillRect(dx-dw/2-12,dy-dh-12,dw+24,dh+18);
   const fr=ctx.createLinearGradient(0,dy-dh,0,dy);fr.addColorStop(0,'#465058');fr.addColorStop(1,'#1c242a');
   ctx.fillStyle=fr;ctx.fillRect(dx-dw/2-6,dy-dh-6,dw+12,dh+12);
   // откосы: левый светлее, правый в тени — проём получает толщину
   ctx.fillStyle='#525d65';ctx.beginPath();
   ctx.moveTo(dx-dw/2-6,dy-dh-6);ctx.lineTo(dx-dw/2,dy-dh);ctx.lineTo(dx-dw/2,dy);ctx.lineTo(dx-dw/2-6,dy+6);ctx.closePath();ctx.fill();
   ctx.fillStyle='#232c33';ctx.beginPath();
   ctx.moveTo(dx+dw/2+6,dy-dh-6);ctx.lineTo(dx+dw/2,dy-dh);ctx.lineTo(dx+dw/2,dy);ctx.lineTo(dx+dw/2+6,dy+6);ctx.closePath();ctx.fill();
   ctx.fillStyle='#5a656d';ctx.beginPath();
   ctx.moveTo(dx-dw/2-6,dy-dh-6);ctx.lineTo(dx+dw/2+6,dy-dh-6);ctx.lineTo(dx+dw/2,dy-dh);ctx.lineTo(dx-dw/2,dy-dh);ctx.closePath();ctx.fill();
   ctx.strokeStyle='#4e585f';ctx.lineWidth=2;ctx.strokeRect(dx-dw/2-6,dy-dh-6,dw+12,dh+12);
   ctx.fillStyle='#05080b';ctx.fillRect(dx-dw/2,dy-dh,dw,dh);
   // порог
   ctx.fillStyle='#39434a';ctx.beginPath();
   ctx.moveTo(dx-dw/2-6,dy);ctx.lineTo(dx+dw/2+6,dy);ctx.lineTo(dx+dw/2+13,dy+7);ctx.lineTo(dx-dw/2-13,dy+7);ctx.closePath();ctx.fill();
   ctx.fillStyle='rgba(214,224,230,.18)';ctx.fillRect(dx-dw/2-6,dy,dw+12,1.6);
   ctx.fillStyle='rgba(0,0,0,.45)';ctx.fillRect(dx-dw/2-13,dy+6,dw+26,2);
   ctx.fillStyle='rgba(190,202,210,.30)';
   for(let i=0;i<6;i++)ctx.fillRect(dx-dw*0.40+i*(dw*0.80/5),dy+2.5,2,2);
   // === СВЕТ ОТ ДВЕРИ ОХРАНЫ ===
   // Луч из проёма виден ТОЛЬКО когда охранник включил свет с этой стороны.
   // Мигание лампы (flicker) передаётся из состояния игры.
   const lampFl=(st.flicker||0)>0?(0.40+0.60*Math.abs(Math.sin(t*19))):(0.88+0.12*Math.abs(Math.sin(t*3.1)));
   const lit=lightOn?lampFl:0;
   if(lit>0){
     ctx.save();ctx.globalCompositeOperation='lighter';
     // тёплая трапеция света, расходящаяся от двери к камере
     const spill=ctx.createLinearGradient(0,dy-dh*0.9,0,H);
     spill.addColorStop(0,`rgba(255,214,120,${(doorClosed?0.05:0.12)*lit})`);
     spill.addColorStop(0.55,`rgba(255,190,80,${(doorClosed?0.02:0.05)*lit})`);
     spill.addColorStop(1,'rgba(255,180,40,0)');
     ctx.fillStyle=spill;
     ctx.beginPath();ctx.moveTo(dx-dw*0.55,dy-dh);ctx.lineTo(dx+dw*0.55,dy-dh);ctx.lineTo(dx+dw*1.45,H);ctx.lineTo(dx-dw*1.45,H);ctx.closePath();ctx.fill();
     // ореол вокруг проёма
     const halo=ctx.createRadialGradient(dx,dy-dh*0.45,4,dx,dy-dh*0.45,dw*1.6);
     halo.addColorStop(0,`rgba(255,222,150,${(doorClosed?0.05:0.10)*lit})`);halo.addColorStop(1,'rgba(255,180,60,0)');
     ctx.fillStyle=halo;ctx.fillRect(dx-dw*1.7,dy-dh*2.0,dw*3.4,dh*3.0);
     ctx.restore();
   }
   if(doorClosed){
     // === ДВЕРЬ ЗАКРЫТА === опущенная створка с рёбрами
     ctx.fillStyle='#141b20';ctx.fillRect(dx-dw/2+4,dy-dh+4,dw-8,dh-8);
     const ribs=9;
     for(let i=0;i<ribs;i++){const rh=(dh-16)/ribs;ctx.fillStyle=i%2?'#1e272d':'#121a1f';ctx.fillRect(dx-dw/2+6,dy-dh+8+i*rh,dw-12,rh-1);ctx.fillStyle='rgba(0,0,0,.30)';ctx.fillRect(dx-dw/2+6,dy-dh+8+i*rh+rh-2,dw-12,1);}
     ctx.strokeStyle='#3c464e';ctx.lineWidth=2;ctx.strokeRect(dx-dw/2+4,dy-dh+4,dw-8,dh-8);
     // жёлто-чёрная полоса по низу створки
     for(let i=0;i<12;i++){ctx.fillStyle=i%2?'#57501f':'#15191c';ctx.fillRect(dx-dw/2+6+i*(dw-12)/12,dy-16,(dw-12)/12,8);}
     if(lit>0){ // тонкая полоска света из щели под створкой
       ctx.save();ctx.globalCompositeOperation='lighter';ctx.fillStyle=`rgba(255,214,130,${0.55*lit})`;ctx.fillRect(dx-dw/2+6,dy-6,dw-12,3);ctx.restore();
     }
   } else {
     // === ДВЕРЬ ОТКРЫТА === сквозь проём видно пост охраны
     const ig=ctx.createLinearGradient(0,dy-dh,0,dy);
     if(lit>0){ig.addColorStop(0,`rgba(74,60,38,${0.55+0.45*lit})`);ig.addColorStop(1,`rgba(40,32,22,${0.55+0.45*lit})`);}
     else{ig.addColorStop(0,'#0a0e12');ig.addColorStop(1,'#05080b');}
     ctx.fillStyle=ig;ctx.fillRect(dx-dw/2+4,dy-dh+4,dw-8,dh-8);
     // силуэт стола охраны и свечение мониторов (видно даже при выключенном свете)
     const mg=0.45+0.25*Math.abs(Math.sin(t*1.7));
     ctx.save();ctx.beginPath();ctx.rect(dx-dw/2+4,dy-dh+4,dw-8,dh-8);ctx.clip();
     ctx.fillStyle=`rgba(90,170,210,${0.16*mg})`;ctx.fillRect(dx-dw*0.30,dy-dh*0.62,dw*0.24,dh*0.20);
     ctx.fillStyle=`rgba(120,200,235,${0.30*mg})`;ctx.fillRect(dx-dw*0.28,dy-dh*0.60,dw*0.20,dh*0.16);
     ctx.fillStyle=lit>0?'#2b2318':'#0c1013';ctx.fillRect(dx-dw*0.40,dy-dh*0.34,dw*0.80,dh*0.16);
     ctx.fillStyle=lit>0?'#1d1810':'#080b0e';ctx.fillRect(dx-dw*0.36,dy-dh*0.18,dw*0.10,dh*0.18);ctx.fillRect(dx+dw*0.26,dy-dh*0.18,dw*0.10,dh*0.18);
     ctx.fillStyle=`rgba(255,220,150,${0.22*lit})`;ctx.fillRect(dx-dw*0.40,dy-dh*0.34,dw*0.80,2);
     ctx.restore();
     // створки, откатившиеся к краям проёма
     for(let sIdx=0;sIdx<2;sIdx++){
       const dirp=sIdx?1:-1, lw2=dw*0.17;
       const lx2=dx+dirp*(dw/2-lw2*0.5)-lw2/2;
       ctx.fillStyle='#1b242b';ctx.fillRect(lx2,dy-dh+6,lw2,dh-12);
       ctx.strokeStyle='#3c464e';ctx.lineWidth=2;ctx.strokeRect(lx2,dy-dh+6,lw2,dh-12);
       ctx.fillStyle='rgba(255,255,255,.05)';ctx.fillRect(lx2+2,dy-dh+8,lw2-4,3);
       // V99: ручка была плашкой #8b939a — в тёмном кадре читалась как белый брусок.
       const hxx=lx2+(dirp<0?lw2-8:4);
       ctx.fillStyle='rgba(0,0,0,.55)';ctx.fillRect(hxx-1,dy-dh*0.48-1,6,16);
       ctx.fillStyle='#5f676e';ctx.fillRect(hxx,dy-dh*0.48,4,14);
       ctx.fillStyle='rgba(214,224,230,.28)';ctx.fillRect(hxx,dy-dh*0.48,1.4,14);
     }
   }
   // Табличка состояния убрана — дверь и свет читаются визуально.
   // ОХРАНА sign mounted ON the top of the door frame (inside, so it never collides with the room label)
   ctx.fillStyle='#2a2118';ctx.fillRect(dx-dw*0.42,dy-dh+5,dw*0.84,20);ctx.strokeStyle='#6b572c';ctx.lineWidth=2;ctx.strokeRect(dx-dw*0.42,dy-dh+5,dw*0.84,20);
   text2(ctx,'ОХРАНА',dx,dy-dh+18,14,'#e0b94a','center');
   // wall pipes + warning stripes near the door
   // V99: труба вдоль стены получила тень, блик сверху и кронштейны.
   ctx.strokeStyle='rgba(0,0,0,.45)';ctx.lineWidth=6;ctx.beginPath();ctx.moveTo(0,H*0.30+3);ctx.bezierCurveTo(W*0.3,H*0.26+3,vpX-hw*1.4,H*0.34+3,vpX-hw,H*0.40+3);ctx.stroke();
   ctx.strokeStyle='#2f3c45';ctx.lineWidth=4.5;ctx.beginPath();ctx.moveTo(0,H*0.30);ctx.bezierCurveTo(W*0.3,H*0.26,vpX-hw*1.4,H*0.34,vpX-hw,H*0.40);ctx.stroke();
   ctx.strokeStyle='rgba(176,194,208,.16)';ctx.lineWidth=1.2;ctx.beginPath();ctx.moveTo(0,H*0.30-1.4);ctx.bezierCurveTo(W*0.3,H*0.26-1.4,vpX-hw*1.4,H*0.34-1.4,vpX-hw,H*0.40-1.4);ctx.stroke();
   {
     const q0=[0,H*0.30],q1=[W*0.3,H*0.26],q2=[vpX-hw*1.4,H*0.34],q3=[vpX-hw,H*0.40];
     const bz=(u)=>{const m=1-u;return [m*m*m*q0[0]+3*m*m*u*q1[0]+3*m*u*u*q2[0]+u*u*u*q3[0],
                                        m*m*m*q0[1]+3*m*m*u*q1[1]+3*m*u*u*q2[1]+u*u*u*q3[1]];};
     for(let c=1;c<=3;c++){const pt=bz(c/4),sz=9-c*1.6;
       ctx.fillStyle='#414c54';ctx.fillRect(pt[0]-sz/2,pt[1]-sz/2-2,sz,sz+4);
       ctx.fillStyle='rgba(206,218,226,.20)';ctx.fillRect(pt[0]-sz/2,pt[1]-sz/2-2,sz,1.2);}
   }
   // V99: было — три оливковые полоски 5px прямо на стене: на камере они читались
   // как случайный жёлтый мазок. Стало — предупреждающая табличка с рамкой,
   // тенью и косыми полосами; в тревоге полосы краснеют.
   {
     const pwd=Math.max(16,hw*0.20), phd=H*0.115, pxx=vpX-hw*1.16, pyy=dy-dh*0.10;
     ctx.fillStyle='rgba(0,0,0,.50)';ctx.fillRect(pxx+2,pyy+3,pwd,phd);
     ctx.fillStyle='#1a1f24';ctx.fillRect(pxx,pyy,pwd,phd);
     ctx.save();ctx.beginPath();ctx.rect(pxx+2,pyy+2,pwd-4,phd-4);ctx.clip();
     const warm=AL>0?'#7a2a30':'#6b6126';
     for(let i=-3;i<7;i++){
       ctx.fillStyle=i%2?warm:'#14181c';
       ctx.beginPath();ctx.moveTo(pxx+i*7,pyy+phd);ctx.lineTo(pxx+i*7+5,pyy+phd);
       ctx.lineTo(pxx+i*7+5+phd*0.5,pyy);ctx.lineTo(pxx+i*7+phd*0.5,pyy);ctx.closePath();ctx.fill();
     }
     ctx.restore();
     ctx.strokeStyle='#4a5259';ctx.lineWidth=1.5;ctx.strokeRect(pxx+0.75,pyy+0.75,pwd-1.5,phd-1.5);
     ctx.fillStyle='rgba(210,220,228,.35)';
     ctx.fillRect(pxx+2,pyy+2,2,2);ctx.fillRect(pxx+pwd-4,pyy+2,2,2);
     ctx.fillRect(pxx+2,pyy+phd-4,2,2);ctx.fillRect(pxx+pwd-4,pyy+phd-4,2,2);
   }
   // a security camera watching the corridor
   cameraDecor(ctx,W*0.10,H*0.20,1);
   // floor props
   floorDecor(ctx,W*0.16,H*0.86,0.9,'crate');
   floorDecor(ctx,W*0.84,H*0.86,0.85,doorOnLeft?'barrel':'cone');
   // === V72: КОРИДОР ПО-НАСТОЯЩЕМУ ТЁМНЫЙ ===
   // Камеры 06 и 07 смотрят в неосвещённые подходы к охране: пока лампа с этой
   // стороны выключена, видны только общие объёмы, а фигура у прохода тонет в темноте.
   // Включённый свет — единственный способ разглядеть, кто там стоит.
   {
     const tier2=(window.__PERF&&window.__PERF.tier)||0;
     const dark=lightOn?0.18:0.46;
     // Грейд УМНОЖАЮЩИЙ, а не чёрная заливка: кадр гаснет и холодеет, но объёмы
     // и текстура стен не превращаются в ровное пятно (раньше камера вытягивала его в розовое).
     const mul=(k)=>{const f=1-dark*k;return `rgb(${Math.round(255*f*0.86)},${Math.round(255*f*0.94)},${Math.round(255*f*1.0)})`};
     ctx.save();ctx.globalCompositeOperation='multiply';
     const dg=ctx.createLinearGradient(0,vpY-H*0.14,0,H);
     dg.addColorStop(0,mul(0.72));
     dg.addColorStop(0.42,mul(0.90));
     dg.addColorStop(1,mul(1.0));
     ctx.fillStyle=dg;ctx.fillRect(0,0,W,H);
     ctx.restore();
     // тяжёлая виньетка: стены уходят в черноту, взгляд тянет к дальнему проходу
     const vg2=ctx.createRadialGradient(vpX,vpY+H*0.04,W*0.06,vpX,vpY+H*0.04,W*0.62);
     vg2.addColorStop(0,'rgba(0,0,0,0)');
     vg2.addColorStop(0.55,`rgba(0,1,2,${(dark*0.45).toFixed(3)})`);
     vg2.addColorStop(1,`rgba(0,0,1,${Math.min(0.9,dark*1.35).toFixed(3)})`);
     ctx.fillStyle=vg2;ctx.fillRect(0,0,W,H);
     // холодная дымка у пола и пыль в воздухе — воздух живой, а не чёрная заливка
     ctx.save();ctx.globalCompositeOperation='lighter';
     const hz2=ctx.createLinearGradient(0,H*0.62,0,H);
     hz2.addColorStop(0,'rgba(58,84,108,0)');
     hz2.addColorStop(1,`rgba(58,84,108,${lightOn?0.050:0.032})`);
     ctx.fillStyle=hz2;ctx.fillRect(0,H*0.62,W,H*0.38);
     if(tier2<2){
       const N=tier2===0?14:7;
       for(let i=0;i<N;i++){
         const sd=i*2.11+0.7;
         const px=W*(0.06+0.88*((Math.sin(sd*3.1)+1)/2)+0.02*Math.sin(t*0.4+sd));
         const py=H*(0.30+0.62*(((t*0.035+i*0.07)%1)));
         ctx.fillStyle=`rgba(158,178,196,${(0.045+0.05*Math.abs(Math.sin(t*1.3+sd))).toFixed(3)})`;
         ctx.fillRect(px,py,1.6,1.6);
       }
     }
     ctx.restore();
   }
   // red emergency beacon beside the door: тускло горит в норме, ярко пульсирует, когда
   // аниматроник подошёл к двери охраны в этом коридоре (alert).
   const bx=dx+dw*0.5+6, by=dy-dh*0.55;
   const lamp=alevel*(0.55+0.45*alarm);
   const rad=AL>0?(26+24*alarm*alevel):0;
   ctx.fillStyle='#0a0d10';ctx.beginPath();ctx.arc(bx,by,AL>0?11:9,0,Math.PI*2);ctx.fill();ctx.strokeStyle=AL>0?'#7d2530':'#2c343a';ctx.lineWidth=2;ctx.stroke();
   if(AL>0){
     const bg2=ctx.createRadialGradient(bx,by,1,bx,by,rad);bg2.addColorStop(0,`rgba(255,40,50,${0.95*lamp})`);bg2.addColorStop(0.4,`rgba(190,30,40,${0.45*lamp})`);bg2.addColorStop(1,'rgba(120,15,20,0)');
     ctx.save();ctx.globalCompositeOperation='lighter';ctx.fillStyle=bg2;ctx.fillRect(bx-rad,by-rad,rad*2,rad*2);ctx.restore();
     ctx.fillStyle=`rgba(255,40,52,${0.35+0.65*lamp})`;ctx.beginPath();ctx.arc(bx,by,5.5,0,Math.PI*2);ctx.fill();
   } else {
     // погашенный плафон — тёмное стекло без свечения
     ctx.fillStyle='#3a2126';ctx.beginPath();ctx.arc(bx,by,4,0,Math.PI*2);ctx.fill();
   }
   if(AL>1){
     // мигающая рамка двери охраны + подпись ТРЕВОГА над дверью
     ctx.strokeStyle=`rgba(255,45,60,${0.35+0.55*alarm})`;ctx.lineWidth=3+2*alarm;ctx.strokeRect(dx-dw/2-8,dy-dh-8,dw+16,dh+16);
   }
   // faint red ambient wash over the whole corridor so it reads as "on alert"
   // V72: в темноте красный налёт слабее — иначе он заливал весь тёмный кадр ровным розовым.
   const wash=(AL>0?(0.05+0.05*alarm*alevel):0.012)*(lightOn?1:0.5);
   ctx.save();ctx.globalCompositeOperation='lighter';ctx.fillStyle=`rgba(150,20,28,${wash.toFixed(4)})`;ctx.fillRect(0,0,W,H);ctx.restore();
   roomLabel(ctx,W,H,doorOnLeft?'КАМ 06':'КАМ 07',label);
 }
 function corridorA(ctx,W,H,t,alert,state){corridorCore(ctx,W,H,t,'КОРИДОР А',true,alert,state)}
 function corridorB(ctx,W,H,t,alert,state){corridorCore(ctx,W,H,t,'КОРИДОР Б',false,alert,state)}
 // Точка у двери охраны в коридоре — сюда игра ставит аниматроника, подошедшего к двери.
 function corridorDoorAnchor(W,H,doorOnLeft){const vpX=W*0.50+(doorOnLeft?W*0.04:-W*0.04),vpY=H*0.42;return {x:vpX,y:vpY+H*0.055};}
 return {rooms,pizza,exit,storage,stage,service,office,corridorA,corridorB,corridorDoorAnchor,text2,eyesInDark};
})();
