window.PhoneSystem=(()=>{
 const contacts={
  '101':{name:'Диспетчер',msg:'Линия диспетчерской. Смена подтверждена. Не покидайте пост.'},
  '202':{name:'Техник',msg:'Если услышишь три удара — проверь левую дверь.'},
  '303':{name:'Архив',msg:'В архиве есть запись, которой не должно существовать.'},
  '404':{name:'Неизвестный',msg:'Абонент молчит. В трубке только металлический гул и чей-то счёт.',sound:'metal_bellow',dark:'exo'},
  '505':{name:'Кухня',msg:'Кухня закрыта. Если увидишь там свет — не входи.'},
  '606':{name:'Старший смены',msg:'Камера четыре иногда показывает будущее. Или прошлое.'},
  '707':{name:'Автоответчик',msg:'Сообщение записано до начала твоей смены.'},
  '808':{name:'Техслужба',msg:'Система вентиляции работает нестабильно. Не отвечай на стук.'},
  '909':{name:'DEZZZZ DEZZZ — ФЕЛИКС',msg:'Ты тоже это слышишь? Не смотри в окно. Не смотри.',sound:'phone_whisper',dark:'felix'},
  '111':{name:'Кассир',msg:'В холодильной комнате снова включился свет. Я его не включал.'},
  '222':{name:'Кухонная линия',msg:'За стеной кто-то ходит. Но кухня заперта.'},
  '333':{name:'Служебный автоответчик',msg:'Три коротких сигнала. После них линия обычно отключается.'},
  '777':{name:'Старая смена',msg:'Если увидишь красный силуэт на четвёртой камере — не приближайся к планшету.'},
  '666':{name:'Неизвестный сигнал',msg:'Кто-то дышит в трубку и повторяет твоё имя. Твоё имя. Твоё.',sound:'number666',dark:'lav'},
  '1488':{name:'СЛУЖЕБНЫЙ КОД',msg:'КОД НЕ РАСПОЗНАН. ЛИНИЯ ЗАБЛОКИРОВАНА.',sound:'number1488',blocked:true},
  // V89: скрытая линия. Одиннадцать цифр — единственный номер такой длины,
  // остальные линии трёх- и четырёхзначные. Обычной репликой не отвечает:
  // передаёт управление скримеру (js/screamer.js).
  // V114: экстренная линия. Отвечает не строкой в панели связи, а целой
  // сценой: см. js/call911.js. В contacts запись нужна, чтобы номер попал в
  // архив звонков и отображался там по-человечески.
  '911':{name:'911 · EMERGENCY',msg:'Экстренная линия. Диспетчер принял вызов.',emergency:true},
  '79503843858':{name:'СТЁПА',msg:'ЛИНИЯ ОТКЛЮЧЕНА ОТ СЕТИ В 2003 ГОДУ.',screamer:true}
 };
 // ==== V85: реплики бывшего охранника. Раньше он говорил сухими философскими
 // фразами и звучал пусто. Теперь это живой человек: усталый, виноватый,
 // перебивающий себя, с конкретными советами по игре. Ночь 5 готовит концовку «ПРАВДА».
 // Тексты совпадают с записанными дорожками guard_n1..guard_n5.
 const incoming={
  1:'Алло? Алло... Ладно. Я просто буду говорить, а ты слушай. Я сидел в этом кресле до тебя. Шесть смен. Слушай сюда: двери держи закрытыми только когда правда надо — питание уходит быстрее, чем кажется. И... эй. Если услышишь шаги в коридоре — не открывай. Просто не открывай, ладно? У меня всё. До утра.',
  2:'Ты выжил. Честно — я не был уверен. Слушай, вторая ночь другая. Их теперь двое, и один из них не ходит. Он ждёт. Не смотри в одну камеру дольше пяти секунд, он это чувствует. И если увидишь, что свет на кухне сам—',
  3:'Это опять я. Не спрашивай, откуда у меня твой номер. Слушай: на третью ночь запись начинает отставать. Ты смотришь на пустой коридор, а его там уже нет. Он у тебя за спиной. Не верь пустому экрану. Верь звуку. И... прости меня. Прости, что я вообще дал им твоё имя.',
  4:'Я не спал две ночи. Всё думаю про тебя. На четвёртую там появляется ещё один — его нет ни в одном документе, я проверял. Высокий. Жёлтый. Поёт. Если он запоёт — выключи радио и не дыши. Он идёт на звук. И если линия оборвётся... не перезванивай. Пожалуйста.',
  5:'Последняя. Слушай меня очень внимательно, у меня мало времени. Сегодня система будет вести себя иначе — она больше не защищает тебя. Она их считает. Под залом есть архив. Второй ящик слева. Кассета девяносто третьего года. Забери её. Забери и уходи через парковку, не через зал. Я... я так и не забрал. Удачи, парень.'
 };
 function ring(game){if(game.phone.state!=='idle'||game.note.open||game.phone.callTriggered)return;const msg=incoming[Math.min(5,game.night)];game.phone.state='ringing';game.phone.active=true;game.phone.timer=20;game.phone.line=msg;game.phone.currentCall='night-'+game.night;game.phone.callTriggered=true;game.phone.callPlayed=true;game.phone.subtitle='';AudioFX.play('phone',.9,{group:'phone'});}
 // V83: браузерный синтезатор больше не используется — у охранника есть настоящая
 // запись на каждую смену (плёнка + телефонная линия). Функции ниже оставлены
 // как аварийный путь, если дорожка не проигралась.
 function pickRussianVoice(){try{const vs=speechSynthesis.getVoices();return vs.find(v=>/^ru(-|_)?RU$/i.test(v.lang)&&/google|microsoft|yandex|pavel|dmitri|male/i.test(v.name))||vs.find(v=>/^ru/i.test(v.lang))||null}catch(e){return null}}
 function speakNatural(text){try{speechSynthesis.cancel();const parts=text.split(/(?<=[.!?…])\s+/).filter(Boolean);let i=0;const next=()=>{if(i>=parts.length)return;const u=new SpeechSynthesisUtterance(parts[i++]);u.lang='ru-RU';u.rate=.86;u.pitch=.9;u.volume=1;const v=pickRussianVoice();if(v)u.voice=v;u.onend=()=>setTimeout(next,180);speechSynthesis.speak(u)};next();return true}catch(e){return false}}
 function answer(game){if(game.phone.state!=='ringing')return;
  // V83: длительность звонка подгоняется под длину записи, чтобы связь не
  // обрывалась на середине фразы и не висела в тишине после её конца.
  const vd=window.VoiceLines?.guardDuration?.(game.night,game.night===2)||0;
  game.phone.state='connected';game.phone.timer=game.night===2?(vd?vd+1.1:9.5):(vd?vd+1.6:12);game.phone.night2Cutoff=game.night===2;game.phone.night2CutoffTimer=game.night===2?(vd?vd+0.8:9.2):0;game.phone.subtitle=(game.night===2?'Ты выжил. Честно — я не был уверен. Их теперь двое, и один не ходит. Он ждёт. Не смотри в одну камеру дольше пяти секунд, он это чувст—':incoming[Math.min(5,game.night)]);game.phone.subtitleMax=game.phone.timer;game.phone.subtitleTimer=game.phone.timer;game.ach('call_answered');
  // ==== V93: НА ПОЗДНИХ СМЕНАХ ЗАПИСЬ ОБРЫВАЕТСЯ РАНЬШЕ ====
  // Было: обрыв на полуслове был только на второй смене. Стало: с четвёртой
  // линия тоже рвётся — в случайной точке, и совет дослушать не дают.
  if(game.night>=4&&Math.random()<0.78){
    game.phone.night2Cutoff=true;
    game.phone.night2CutoffTimer=Math.max(3.0,game.phone.timer*(0.42+Math.random()*0.26));
  }
  try{speechSynthesis?.cancel?.()}catch(e){}AudioFX.unlock();
  // V83: голос охранника есть на ВСЕХ пяти сменах. Раньше на сменах 3–5 трубка
  // молчала, а на второй читал синтезатор браузера.
  const spoke=window.VoiceLines?.playGuard?.(game.night,'phone',{short:game.night===2});
  if(!spoke){
    if(game.night===2){if(!speakNatural(game.phone.subtitle))AudioFX.play('guardVoice',1,{group:'phone'});}
    else AudioFX.play('guard_night1_phone',1,{group:'phone'});
  }}
 function stop(game,reason='ended'){if(game.phone.state==='idle')return;try{speechSynthesis?.cancel?.()}catch(e){}try{window.VoiceLines?.stop?.()}catch(e){}game.phone.state='idle';game.phone.active=false;game.phone.timer=0;game.phone.subtitle='';game.phone.subtitleTimer=0;game.phone.night2Cutoff=false;game.phone.night2CutoffTimer=0;if(reason==='skipped')game.phone.subtitle=''}
 // V71: экранные подсказки отключены, поэтому ответ линии показываем прямо в панели связи —
 // раньше при неизвестном номере и на заблокированном коде 1488 не появлялось вообще ничего.
 function showLine(game,title,text,timer){game.phone.state='connected';game.phone.active=true;game.phone.timer=timer;game.phone.line=title;game.phone.subtitle=text;game.phone.subtitleMax=timer;game.phone.subtitleTimer=timer;game.phone.night2Cutoff=false;game.phone.night2CutoffTimer=0;}
 function dial(game,number){const c=contacts[number];
  // V114: 911 перехватывается до всей обычной логики — вместо реплики в панели
  // связи запускается кат-сцена с кадром работника и озвученным разговором.
  if(c&&c.emergency){
   if(!game.phone.archive.includes(number))game.phone.archive.push(number);
   stop(game,'ended');
   if(window.Call911){window.Call911.start(game);return}
   showLine(game,c.name+' // '+c.msg,c.msg,4); // аварийный путь, если модуль не загрузился
   return}
  // V89: скрытая линия перехватывает набор до всей обычной логики звонка.
  if(c&&c.screamer){if(!game.phone.archive.includes(number))game.phone.archive.push(number);
   // V111: достижение за звонок на длинный номер, который запускает скример.
   try{game.ach?.('stepa_call')}catch(e){}
   stop(game,'ended');window.Screamer?.trigger?.(game,number);return}
  if(!c){showLine(game,'ЛИНИЯ '+number+' // НЕТ ОТВЕТА','ЛИНИЯ '+number+' НЕ НАЙДЕНА',3);AudioFX.play('phone_line',.5,{group:'phone'});return}if(c.blocked){showLine(game,c.name+' // '+c.msg,c.msg,3.5);AudioFX.play(c.sound,.8,{group:'phone'});return}game.phone.state='connected';game.phone.active=true;game.phone.timer=c.sound==='industrial20'?20:16;game.phone.currentCall=number;game.phone.line=c.name+' // '+c.msg;game.phone.subtitle=c.name+': '+c.msg;game.phone.subtitleMax=game.phone.timer;game.phone.subtitleTimer=game.phone.timer;game.phone.night2Cutoff=false;game.phone.night2CutoffTimer=0;if(!game.phone.archive.includes(number))game.phone.archive.push(number);AudioFX.play(c.sound||'phone_line',.55,{group:'phone'});
  // V70: на этих линиях отвечает не человек — реплику произносит мрачный голос.
  // V71: без красной строки поверх экрана — текст уже виден в панели связи,
  // поэтому у монстра берём только голос (третий аргумент = не показывать субтитр).
  if(c.dark)game.monSay?.(c.msg.replace(/[«»]/g,''),c.dark,{subtitle:false});
  game.ach('call_answered')}
 function playArchive(game,i){const key=(game.phone.archive||[])[i];if(!key)return;if(String(key).startsWith('night-')){const n=Number(String(key).split('-')[1]);game.phone.line='Архив ночи '+n+': '+(incoming[n]||'');game.phone.subtitle='Архив ночи '+n+': '+(incoming[n]||'');if(!window.VoiceLines?.playGuard?.(n,'phone',{short:n===2}))AudioFX.play('guardVoice',1,{group:'phone'});}else{const c=contacts[key];if(c){game.phone.line=c.name+' // '+c.msg;game.phone.subtitle=c.name+': '+c.msg;AudioFX.play(c.sound||'phone_line',.4,{group:'phone'})}}game.phone.state='connected';game.phone.active=true;game.phone.timer=10;game.phone.subtitleMax=game.phone.timer;game.phone.subtitleTimer=game.phone.timer;game.phone.night2Cutoff=false;game.phone.night2CutoffTimer=0}
 function setBackgroundMode(game){if(game.phone.state==='connected'){game.phone.state='idle';game.phone.active=false;game.say('Звонок переведён в фон',1.2)}}
 function update(game,dt){if(game.phone.state==='ringing'||game.phone.state==='connected'){game.phone.timer-=dt;
  // ==== V93: ЛИНИЯ ЗАИКАЕТСЯ ====
  // Было: телефонная строка всегда была чистой. Стало: с третьей смены
  // плёнка жуёт слова: в субтитре появляется сор, а в трубке — срыв ленты.
  if((game.night||1)>=3&&game.phone.state==='connected'&&game.phone.subtitle&&game.phone.subtitle.length>8&&Math.random()<dt*0.5){
    const s=game.phone.subtitle,junk='▓▒#%/\\|—';
    const i=2+Math.floor(Math.random()*(s.length-4));
    const n=1+Math.floor(Math.random()*3);
    let j='';for(let q=0;q<n;q++)j+=junk[Math.floor(Math.random()*junk.length)];
    game.phone.subtitle=s.slice(0,i)+j+s.slice(i+n);
    try{window.MonsterAudio?.tape((game.night||1)>=4)}catch(e){}
  }
  if(game.phone.night2Cutoff){game.phone.night2CutoffTimer-=dt;if(game.phone.night2CutoffTimer<=0){try{speechSynthesis?.cancel?.()}catch(e){}try{window.VoiceLines?.stop?.()}catch(e){}game.phone.night2Cutoff=false;game.phone.night2CutoffTimer=0;game.phone.state='idle';game.phone.active=false;game.phone.timer=0;game.say('СВЯЗЬ ОБОРВАНА',1.5);AudioFX.play('monster_heavy',1.25,{group:'monster'});AudioFX.play('phone_line',1,{group:'phone'});return}}if(game.phone.timer<=0)stop(game);return}if(game.note.open)return;if(game.phone.callDelay>0){game.phone.callDelay-=dt;if(game.phone.callDelay<=0)ring(game);return}if(!game.phone.callTriggered && Math.random()<dt*(.0015+.0005*game.night))ring(game)}
 return {ring,answer,stop,dial,playArchive,setBackgroundMode,update,contacts};
})();
