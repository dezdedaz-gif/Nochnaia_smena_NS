// ===========================================================================
// НОЧНАЯ СМЕНА — V94. КОДЫ ФИНАЛОВ: пятая, последняя сцена каждой концовки.
//
// ПОЧЕМУ ТАК БЫЛО. Все пять финалов заканчивались одинаково по драматургии:
// последняя картинка застывала, поверх наезжала карточка, экран уходил в
// чёрный. Ни одна концовка не показывала ПОСЛЕДСТВИЕ — что стало утром, кто
// пришёл после, чем всё это кончилось для пиццерии. Из-за этого финалы читались
// как пять вариантов одной и той же точки, а не как пять разных исходов.
//
// СТАЛО. После старого финала идёт монтажный СТЫК в новую сцену — коду:
//   РАССВЕТ            → остановка на рассвете и окно пиццерии за его спиной;
//   ПЕПЕЛ             → утро на выгоревшем пятне, синие мигалки, голова кролика;
//   ЕЩЁ ОДИН КОСТЮМ    → тот же офис в 06:00 и НОВЫЙ охранник в дверях;
//   КОСТЮМ-ЛОВУШКА     → вечер, сцена под прожекторами, пятый на сцене;
//   ПРАВДА             → стол с уликами 1993 года и шестое имя в списке.
// Каждая кода — 8 секунд: вход из чёрного, один сюжетный удар, новая карточка.
// Все помощники приходят через объект A, как в endings_truth.js: game.js лежит
// в одной большой функции, и держать раскадровки внутри неё нечитаемо.
// ===========================================================================
window.EndCoda=(function(){
  const cl=v=>Math.min(1,Math.max(0,v));
  const eio=x=>x<.5?2*x*x:1-Math.pow(-2*x+2,2)/2;
  const eo=x=>1-Math.pow(1-x,3);

  // Вход из чёрного и уход в чёрный — стык между старым финалом и кодой.
  function veil(c,w,h,tc,dur){
    const inK=1-cl(tc/0.85), outK=cl((tc-(dur-1.05))/1.05);
    const a=Math.max(inK,outK);
    if(a<=0.001)return;
    c.save();c.globalAlpha=Math.min(1,a);c.fillStyle='#000';c.fillRect(0,0,w,h);c.restore();
  }
  // Мягкое световое пятно (фонарь, мигалка, прожектор) — только «lighter».
  function glow(c,x,y,r,col,a){
    if(a<=0.002)return;
    c.save();c.globalCompositeOperation='lighter';
    const g=c.createRadialGradient(x,y,1,x,y,r);
    g.addColorStop(0,'rgba('+col+','+a.toFixed(3)+')');
    g.addColorStop(0.55,'rgba('+col+','+(a*0.30).toFixed(3)+')');
    g.addColorStop(1,'rgba('+col+',0)');
    c.fillStyle=g;c.fillRect(x-r,y-r,r*2,r*2);c.restore();
  }
  // V94: у код свои звуковые метки. epiCue помнит сработавшие метки по ключу
  // «вариант@время», а время коды идёт заново с нуля и пересекалось бы с
  // метками основного финала — поэтому метки коды сдвинуты на +1000 секунд.
  function mkCue(A,tc){return (at,fn)=>A.epiCue(tc+1000,1000+at,fn);}
  // Два бледных глаза в темноте — общий мотив трёх код.
  function eyes(c,x,y,r,a,col){
    if(a<=0.002)return;
    for(const s of[-1,1]){
      c.fillStyle='rgba('+(col||'232,238,236')+','+a.toFixed(3)+')';
      c.beginPath();c.ellipse(x+s*r*2.1,y,r*1.15,r,0,0,Math.PI*2);c.fill();
      glow(c,x+s*r*2.1,y,r*6,col||'232,238,236',a*0.35);
    }
  }

  // =========================================================================
  // 1. РАССВЕТ. Остановка на шоссе, он ждёт автобус. За его спиной, далеко,
  //    ещё стоит пиццерия — и в одном её окне кто-то есть. Свет фар сметает
  //    кадр, и окно уже пустое. Он ничего не увидел. Мы увидели.
  // =========================================================================
  function calm(A,tc){
    const c=A.ctx,w=A.w,h=A.h,low=A.low,DUR=8.1;
    const cue=mkCue(A,tc);
    const seeK=eio(cl((tc-2.3)/1.1));          // в окне появляются глаза
    const busK=eio(cl((tc-4.3)/1.3));          // автобус: свет фар идёт по кадру
    const goneK=cl((tc-5.5)/0.5);              // окно опустело
    const riseK=eio(cl((tc-6.0)/1.4));         // он выходит к автобусу
    cue(0.15,()=>window.AudioFX.synth?.('breath',.42));
    cue(2.3,()=>window.AudioFX.synth?.('sting',.20));
    cue(4.3,()=>window.AudioFX.synth?.('rumble',.30));
    cue(6.0,()=>window.AudioFX.synth?.('paper',.22));
    c.save();
    // небо рассвета
    const HOR=h*0.685;                          // линия горизонта = уровень шоссе
    const sky=c.createLinearGradient(0,0,0,HOR);
    sky.addColorStop(0,'#1b2c42');sky.addColorStop(0.45,'#63647a');
    sky.addColorStop(0.80,'#c4966d');sky.addColorStop(1,'#eec089');
    c.fillStyle=sky;c.fillRect(0,0,w,HOR);
    glow(c,w*0.86,HOR-h*0.01,h*0.60,'255,206,140',0.34);
    // лес на горизонте
    // V97: было — сорок треугольников одинаковой ширины (0.036w) с шагом ровно
    // 0.0256w, поставленных в один ряд на линию горизонта. На светлом рассветном
    // небе это читалось как зубья пилы или частокол, а не как лес. Стало: два
    // плана с разным шагом, шириной и высотой; у ближнего плана есть ствол и
    // второй ярус ветвей, между планами лежит рассветная дымка, а несколько
    // деревьев выбиваются из строя по высоте.
    for(const pl of [[0.062,'#243141',0.0175,0.78],[0.100,'#101a1a',0.0250,1.0]]){
      c.fillStyle=pl[1];
      const stepT=pl[2], N=Math.ceil(1/stepT)+1;
      for(let i=0;i<N;i++){
        const r1=A.epiRnd(i*2.7+pl[0]*100), r2=A.epiRnd(i*5.3+pl[0]*50);
        const bx=w*(i*stepT+(r2-0.5)*stepT*0.8);
        const bh=h*pl[0]*(0.45+0.95*r1)*(r2>0.93?1.5:1);   // редкие высокие
        const bwT=w*stepT*(0.75+0.5*r2);
        c.beginPath();
        c.moveTo(bx-bwT,HOR);
        c.lineTo(bx-bwT*0.42,HOR-bh*0.52);                  // нижний ярус ветвей
        c.lineTo(bx-bwT*0.60,HOR-bh*0.54);
        c.lineTo(bx,HOR-bh);
        c.lineTo(bx+bwT*0.60,HOR-bh*0.54);
        c.lineTo(bx+bwT*0.42,HOR-bh*0.52);
        c.lineTo(bx+bwT,HOR);
        c.closePath();c.fill();
        if(pl[3]===1&&r1>0.55){                              // ствол у ближних
          c.fillRect(bx-Math.max(0.6,w*0.0012),HOR-bh*0.12,Math.max(1.2,w*0.0024),bh*0.12);
        }
      }
      if(pl[3]!==1){                                         // дымка между планами
        const hz=c.createLinearGradient(0,HOR-h*0.075,0,HOR);
        hz.addColorStop(0,'rgba(238,192,137,0)');hz.addColorStop(1,'rgba(238,192,137,.34)');
        c.fillStyle=hz;c.fillRect(0,HOR-h*0.075,w,h*0.075);
      }
    }
    // пиццерия далеко справа: низкая коробка, мёртвая вывеска, одно окно
    const px=w*0.815,pw=w*0.145,phh=h*0.125,py=HOR-phh;
    c.fillStyle='#1c2024';c.fillRect(px,py,pw,phh);
    c.fillStyle='#161a1e';c.fillRect(px-w*0.006,py-h*0.014,pw+w*0.012,h*0.016);
    c.fillStyle='#262b30';c.fillRect(px+pw*0.18,py-h*0.048,pw*0.64,h*0.032);
    c.fillStyle='rgba(150,120,90,.40)';
    c.font='600 '+Math.round(h*0.019)+'px "Oswald",Impact,sans-serif';
    c.textAlign='center';c.fillText('PIZZA',px+pw*0.5,py-h*0.024);c.textAlign='left';
    const wx=px+pw*0.22,wy=py+phh*0.30,ww=pw*0.30,wh2=phh*0.36;
    c.fillStyle='#0a0d10';c.fillRect(wx,wy,ww,wh2);
    if(seeK>0&&goneK<1)eyes(c,wx+ww*0.5,wy+wh2*0.40,Math.max(1.2,h*0.0040),0.75*seeK*(1-goneK));
    // шоссе и разметка
    const road=c.createLinearGradient(0,HOR,0,h);
    road.addColorStop(0,'#31353a');road.addColorStop(1,'#15181b');
    c.fillStyle=road;c.fillRect(0,HOR,w,h-HOR);
    c.fillStyle='rgba(226,222,196,.16)';c.fillRect(0,HOR,w,2);
    c.fillStyle='rgba(226,222,196,.26)';
    for(let i=0;i<7;i++)c.fillRect(w*(0.02+i*0.155),h*0.905,w*0.070,3);
    // ОСТАНОВКА. Стоит на обочине, её опоры доходят до земли ровно там, где
    // стоит он сам — иначе навес «висел» в воздухе (см. FIXES_V94).
    // V96: уровень земли поднят с 0.885h до 0.845h. На кадре его ботинки
    // уходили под нижнюю чёрную полосу кадра — фигура выглядела обрезанной
    // по голени. Вся остановка (навес, опоры, скамья, сумка) считается от gy,
    // поэтому она поднимается вместе с ним и ничего не отрывается от земли.
    const gy=h*0.845, gsc=0.72;                 // уровень его ног и его масштаб
    // V96: раньше остановка была двумя столбами и перекладиной — на кадре
    // это читалось как футбольные ворота: стекло задней стенки почти не было
    // видно. Теперь есть глухая нижняя панель, стекло с рассветным бликом и
    // раскладкой, боковая стенка, тень под навесом и табличка с маршрутом.
    const sw=w*0.30, sx=w*0.155, sTop=h*0.415;
    const sGl=sTop+h*0.030, sGb=gy-h*0.055;     // верх и низ задней стенки
    const pTop=sGl+(sGb-sGl)*0.64;              // граница стекло / глухая панель
    const gGl=c.createLinearGradient(0,sGl,0,pTop);
    gGl.addColorStop(0,'rgba(196,214,220,.20)');
    gGl.addColorStop(1,'rgba(255,206,150,.13)');
    c.fillStyle=gGl;c.fillRect(sx+sw*0.06,sGl,sw*0.88,pTop-sGl);
    c.fillStyle='#232a30';                      // глухая нижняя панель
    c.fillRect(sx+sw*0.06,pTop,sw*0.88,sGb-pTop);
    c.fillStyle='rgba(255,214,160,.06)';
    c.fillRect(sx+sw*0.06,pTop,sw*0.88,h*0.006);
    c.strokeStyle='rgba(180,206,214,.16)';c.lineWidth=1; // раскладка остекления
    c.strokeRect(sx+sw*0.06,sGl,sw*0.88,sGb-sGl);
    for(const k of[0.36,0.65]){c.beginPath();
      c.moveTo(sx+sw*k,sGl);c.lineTo(sx+sw*k,sGb);c.stroke();}
    c.beginPath();c.moveTo(sx+sw*0.06,pTop);c.lineTo(sx+sw*0.94,pTop);c.stroke();
    c.fillStyle='#1b2126';                      // боковая стенка слева
    c.fillRect(sx+sw*0.02,sGl,sw*0.05,sGb-sGl);
    c.fillStyle='rgba(150,178,186,.08)';
    c.fillRect(sx+sw*0.02,sGl,sw*0.05,(sGb-sGl)*0.52);
    c.fillStyle='#20262b';                      // навес с свесом
    c.fillRect(sx-w*0.012,sTop,sw+w*0.024,h*0.022);
    c.fillStyle='#161b1f';
    c.fillRect(sx-w*0.012,sTop+h*0.022,sw+w*0.024,h*0.008);
    const und=c.createLinearGradient(0,sTop+h*0.030,0,sTop+h*0.090);
    und.addColorStop(0,'rgba(0,0,0,.34)');und.addColorStop(1,'rgba(0,0,0,0)');
    c.fillStyle=und;c.fillRect(sx+sw*0.02,sTop+h*0.030,sw*0.94,h*0.060);
    c.fillStyle='rgba(226,222,196,.10)';        // табличка с маршрутом под навесом
    c.fillRect(sx+sw*0.66,sTop+h*0.034,sw*0.24,h*0.030);
    c.fillStyle='rgba(40,46,52,.75)';
    c.fillRect(sx+sw*0.68,sTop+h*0.040,sw*0.20,h*0.007);
    c.fillRect(sx+sw*0.68,sTop+h*0.051,sw*0.13,h*0.006);
    c.fillStyle='#1b2126';                      // две опоры до земли
    c.fillRect(sx+sw*0.02,sTop,w*0.011,gy-sTop);
    c.fillRect(sx+sw*0.94,sTop,w*0.011,gy-sTop);
    c.fillStyle='rgba(255,214,160,.10)';        // рассвет скользит по кромке опор
    c.fillRect(sx+sw*0.02,sTop,w*0.0035,gy-sTop);
    c.fillRect(sx+sw*0.94,sTop,w*0.0035,gy-sTop);
    // скамья: сиденье и две ножки, стоит на той же земле
    const benchY=gy-h*0.085;
    // V96: сиденье светлее глухой панели за ним — иначе скамья сливалась со стенкой.
    c.fillStyle='#3c454d';c.fillRect(sx+sw*0.12,benchY,sw*0.76,h*0.016);
    c.fillStyle='rgba(255,220,170,.10)';c.fillRect(sx+sw*0.12,benchY,sw*0.76,h*0.004);
    c.fillStyle='#232a2f';
    c.fillRect(sx+sw*0.18,benchY+h*0.016,w*0.008,gy-benchY-h*0.016);
    c.fillRect(sx+sw*0.76,benchY+h*0.016,w*0.008,gy-benchY-h*0.016);
    // сумка у скамьи
    c.fillStyle='#1d2226';c.fillRect(sx+sw*0.60,gy-h*0.030,w*0.032,h*0.030);
    c.fillStyle='#161a1e';c.fillRect(sx+sw*0.62,gy-h*0.040,w*0.014,h*0.012);
    // ОН САМ. V94: раньше здесь стояла поза 'sit' — на кадре она читалась как
    // «висит в воздухе перед скамьёй», потому что поза считает переданный y
    // уровнем ступней, а не сиденья. Теперь он просто ЖДЁТ стоя (замёрз, руки
    // опущены), а на автобус делает пару шагов вправо — это читается сразу.
    const step=w*0.085*riseK;
    A.drawGuardChar(c,sx+sw*0.42+step,gy,gsc,{t:A.t,
      pose:(riseK>0.02&&riseK<0.98)?'walk':'stand',
      phase:A.epiStridePhase(step,gsc,0.46),
      face:1,seed:3.1,cold:0.55-0.35*riseK,look:0.34,
      shadowDir:1,shadowLen:1.0,shadowAlpha:0.30,
      rim:{dir:1,col:'255,214,150',power:0.32}});
    // автобус: фары выметают кадр слева
    if(busK>0){
      const bx=-w*0.25+w*1.35*busK;
      glow(c,bx,HOR+h*0.02,h*0.55,'255,240,200',0.55*Math.sin(Math.PI*Math.min(1,busK)));
      c.save();c.globalCompositeOperation='lighter';
      c.fillStyle='rgba(255,246,214,'+(0.10*Math.sin(Math.PI*Math.min(1,busK))).toFixed(3)+')';
      c.fillRect(0,HOR-h*0.06,w,h*0.32);c.restore();
    }
    A.epiGrade(c,w,h,A.t,low,'rgba(60,44,30,0.05)',0.30,1);
    c.restore();
    A.epiBars(c,w,h,1);
  // V103: НАЗВАНИЕ КОНЦОВКИ И СЧЁТЧИК СМЕРТЕЙ УБРАНЫ.
  // ПОЧЕМУ ТАК БЫЛО: финал заканчивался служебной карточкой «КОНЦОВКА: ...» и
  // строкой «СМЕРТЕЙ: N». Это разрушало сцену: только что был кадр, а сразу
  // после — отчёт. СТАЛО: финал уходит в чёрный без подписей.
    // A.epiCard(c,w,h,tc,4.9,3.0,'РАССВЕТ','ОН НЕ ОБЕРНУЛСЯ. ЗРЯ.','#f6ecd2');
    A.epiTimecode(c,w,h,'NS-04 · 06:41 · ШОССЕ',0.36);
    veil(c,w,h,tc,DUR);
  }

  // =========================================================================
  // 2. ПЕПЕЛ. Утро на выгоревшем пятне. Пожарные, мигалки, пар от воды. В
  //    переднем плане из пепла торчит обгоревшая голова кролика — и её глаз
  //    один раз загорается. Огонь забрал здание, но не то, что было внутри.
  // =========================================================================
  function burn(A,tc){
    const c=A.ctx,w=A.w,h=A.h,low=A.low,DUR=8.0;
    const cue=mkCue(A,tc);
    const eyeK=Math.max(0,Math.sin((tc-4.1)*2.4))*(tc>4.1&&tc<5.5?1:0);
    const closeK=eio(cl((tc-3.0)/2.6));       // «камера» подъезжает к голове
    cue(0.2,()=>window.AudioFX.synth?.('rumble',.26));
    cue(1.5,()=>window.AudioFX.synth?.('drip',.34));
    cue(4.1,()=>window.AudioFX.synth?.('sting',.34));
    cue(6.2,()=>window.AudioFX.synth?.('metalDrag',.22));
    c.save();
    const HOR=h*0.615;
    // дымное утро: небо ниже к горизонту грязно-жёлтое от гари
    const sky=c.createLinearGradient(0,0,0,HOR);
    sky.addColorStop(0,'#3f464c');sky.addColorStop(0.55,'#6d6a64');sky.addColorStop(1,'#9d8d78');
    c.fillStyle=sky;c.fillRect(0,0,w,HOR);
    // выгоревшая земля: тёмная, с пятнами золы и лужами воды
    const ash=c.createLinearGradient(0,HOR,0,h);
    ash.addColorStop(0,'#2b2724');ash.addColorStop(0.5,'#1c1917');ash.addColorStop(1,'#0f0e0d');
    c.fillStyle=ash;c.fillRect(0,HOR,w,h-HOR);
    // V94: пятна золы рисуются вытянутыми полосами разной прозрачности —
    // одинаковые овалы читались как «горошек» на полу, а не как пепел.
    for(let i=0;i<22;i++){
      const ax=w*A.epiRnd(i*3.1),ay=HOR+(h-HOR)*A.epiRnd(i*5.7);
      const aw=w*(0.03+0.11*A.epiRnd(i*1.7)),ah=h*(0.004+0.010*A.epiRnd(i*2.3));
      c.fillStyle=(i%4===0)?'rgba(160,168,170,'+(0.020+0.030*A.epiRnd(i*4.9)).toFixed(3)+')'
                           :'rgba(0,0,0,'+(0.10+0.18*A.epiRnd(i*6.1)).toFixed(3)+')';
      c.beginPath();c.ellipse(ax,ay,aw,ah,0.04*(A.epiRnd(i*7.3)-0.5),0,Math.PI*2);c.fill();
    }
    // ОСТАТКИ ЗДАНИЯ: обломок стены с проёмом окна, за ним пустота
    c.fillStyle='#141313';
    c.beginPath();
    c.moveTo(w*0.085,HOR);c.lineTo(w*0.085,h*0.375);c.lineTo(w*0.215,h*0.345);
    c.lineTo(w*0.245,h*0.430);c.lineTo(w*0.310,h*0.470);c.lineTo(w*0.330,HOR);
    c.closePath();c.fill();
    c.fillStyle='#070707';c.fillRect(w*0.125,h*0.430,w*0.070,h*0.090);   // проём окна
    c.fillStyle='#1b1a19';                                               // копоть над проёмом
    c.fillRect(w*0.118,h*0.405,w*0.084,h*0.022);
    // торчащие балки и опоры
    // V96: торчащие балки шли от 0.34w до 0.81w — то есть ровно поверх трёх
    // пожарных и пожарной машины. На кадре наклонные балки проходили
    // людям через пояс — будто их насквозь прошило жердью. Теперь все
    // обломки остаются в зоне руины, слева от оцепления.
    c.fillStyle='#131211';
    for(let i=0;i<8;i++){const bx=w*(0.075+i*0.032),bh=h*(0.025+0.075*A.epiRnd(i*4.1));
      c.fillRect(bx,HOR-bh,Math.max(2,w*0.009),bh);}
    c.strokeStyle='#0d0c0b';c.lineWidth=Math.max(2,h*0.007);
    for(let i=0;i<3;i++){const bx=w*(0.100+i*0.070);
      c.beginPath();c.moveTo(bx,HOR);c.lineTo(bx+w*0.060,HOR-h*(0.045+0.03*A.epiRnd(i)));c.stroke();}
    // ПОЖАРНАЯ МАШИНА справа: кабина, кузов, проблесковые маячки
    // V94: раньше кузов был длинным и с рядом «окон» — на кадре это читалось
    // как городской автобус. Теперь короткая машина: высокий отсечный кузов,
    // отдельная кабина спереди, лестница сверху, маячковая балка на крыше.
    const fx=w*0.655,fy=HOR-h*0.150;
    c.fillStyle='#3a1418';c.fillRect(fx,fy+h*0.040,w*0.150,h*0.108);      // кузов с отсеками
    // V96: три тёмных прямоугольника на борту читались как окна, и вся
    // машина по-прежнему выглядела автобусом. Теперь это светлые
    // рольставни с горизонтальными рёбрами и ручкой — отсеки для инструмента.
    for(let i=0;i<3;i++){
      const cxx=fx+w*0.010+i*w*0.046;
      c.fillStyle='#3d454b';c.fillRect(cxx,fy+h*0.062,w*0.038,h*0.052);
      c.fillStyle='rgba(12,14,16,.55)';
      for(let j=0;j<5;j++)c.fillRect(cxx,fy+h*(0.066+j*0.010),w*0.038,Math.max(1,h*0.004));
      c.fillStyle='#5a646b';c.fillRect(cxx+w*0.013,fy+h*0.106,w*0.012,Math.max(1.5,h*0.006));
    }
    c.fillStyle='rgba(226,236,240,.22)';                                  // косая разметка на задней стенке
    for(let i=0;i<3;i++)c.fillRect(fx+w*0.001+i*w*0.006,fy+h*0.044,w*0.003,h*0.016);
    c.fillStyle='rgba(226,236,240,.16)';                                  // светоотражающая полоса
    c.fillRect(fx,fy+h*0.124,w*0.150,h*0.008);
    c.fillStyle='#43181c';c.fillRect(fx+w*0.150,fy+h*0.056,w*0.062,h*0.092);// кабина
    c.fillStyle='rgba(160,196,214,.20)';c.fillRect(fx+w*0.160,fy+h*0.064,w*0.042,h*0.030);
    c.fillStyle='#2c1216';c.fillRect(fx+w*0.150,fy+h*0.030,w*0.062,h*0.026);// крыша кабины
    c.strokeStyle='#4d565c';c.lineWidth=Math.max(1.5,h*0.004);            // лестница на кузове
    c.beginPath();c.moveTo(fx+w*0.014,fy+h*0.036);c.lineTo(fx+w*0.140,fy+h*0.036);c.stroke();
    for(let i=0;i<5;i++){c.beginPath();
      c.moveTo(fx+w*(0.018+i*0.030),fy+h*0.030);c.lineTo(fx+w*(0.018+i*0.030),fy+h*0.042);c.stroke();}
    c.fillStyle='#0c0f11';                                                // два колеса
    for(const k of[0.030,0.120]){c.beginPath();c.arc(fx+w*k,HOR-h*0.004,Math.max(4,h*0.022),0,Math.PI*2);c.fill();}
    c.beginPath();c.arc(fx+w*0.185,HOR-h*0.004,Math.max(4,h*0.022),0,Math.PI*2);c.fill();
    c.fillStyle='#181c1f';
    for(const k of[0.030,0.120,0.185]){c.beginPath();c.arc(fx+w*k,HOR-h*0.004,Math.max(2,h*0.009),0,Math.PI*2);c.fill();}
    // маячковая балка на кабине: два такта в секунду, синий отблеск по пеплу
    const bl=(Math.sin(A.t*7.4)>0.35?1:0)*0.9+(Math.sin(A.t*7.4+2.1)>0.7?0.4:0);
    c.fillStyle='#14171a';c.fillRect(fx+w*0.152,fy+h*0.018,w*0.058,h*0.012);
    c.fillStyle='rgba(120,170,255,'+(0.30+0.60*bl).toFixed(3)+')';
    c.fillRect(fx+w*0.156,fy+h*0.020,w*0.022,h*0.008);
    c.fillStyle='rgba(255,110,100,'+(0.25+0.55*(1-bl)).toFixed(3)+')';
    c.fillRect(fx+w*0.184,fy+h*0.020,w*0.022,h*0.008);
    glow(c,fx+w*0.166,fy+h*0.024,h*0.46,'90,150,255',0.30*bl);
    glow(c,fx+w*0.196,fy+h*0.024,h*0.26,'255,90,90',0.14*(1-bl));
    c.save();c.globalCompositeOperation='lighter';
    c.fillStyle='rgba(90,140,240,'+(0.05*bl).toFixed(3)+')';c.fillRect(0,HOR,w,h-HOR);c.restore();
    // ПОЖАРНЫЕ: силуэты в касках, один держит ствол, рукав лежит по земле
    // V96: раньше рука была одним отрезком, торчащим в сторону, ноги стояли
    // вплотную, а ствола не было вовсе — на кадре три фигуры читались как
    // палочные человечки. Теперь: две руки, разведённые ноги, тень под ногами,
    // у первого в руках ствол, у остальных — опущенные руки и лёгкое дыхание.
    const fire=(bx,by,sc,arm,ph,noz)=>{
      const br=Math.sin(A.t*1.4+ph)*0.012;                               // дыхание
      c.fillStyle='rgba(0,0,0,.30)';                                     // тень под ногами
      c.beginPath();c.ellipse(bx,by+sc*0.03,sc*0.34,sc*0.09,0,0,Math.PI*2);c.fill();
      c.fillStyle='#0e1114';
      c.fillRect(bx-sc*0.17,by-sc*(1.05+br),sc*0.34,sc*0.62);            // корпус в куртке
      c.fillStyle='#0a0d10';                                             // ноги врозь
      c.save();c.translate(bx,by-sc*0.45);
      c.rotate(-0.07);c.fillRect(-sc*0.17,0,sc*0.12,sc*0.46);c.restore();
      c.save();c.translate(bx,by-sc*0.45);
      c.rotate(0.06);c.fillRect(sc*0.05,0,sc*0.12,sc*0.46);c.restore();
      c.fillStyle='#0b0e11';                                             // сапоги
      c.fillRect(bx-sc*0.23,by-sc*0.05,sc*0.17,sc*0.06);
      c.fillRect(bx+sc*0.06,by-sc*0.05,sc*0.17,sc*0.06);
      c.fillStyle='#12171b';                                             // голова в подшлемнике
      c.beginPath();c.arc(bx,by-sc*(1.16+br),sc*0.15,0,Math.PI*2);c.fill();
      c.fillStyle='#1b2025';                                             // каска с козырьком
      c.beginPath();c.arc(bx,by-sc*(1.20+br),sc*0.19,Math.PI,0);c.fill();
      c.fillRect(bx-sc*0.22,by-sc*(1.21+br),sc*0.44,sc*0.05);
      c.fillStyle='rgba(226,236,240,.10)';                               // блик по каске
      c.fillRect(bx-sc*0.13,by-sc*(1.31+br),sc*0.17,sc*0.04);
      c.fillStyle='rgba(214,226,232,.16)';                               // полосы на куртке
      c.fillRect(bx-sc*0.17,by-sc*(0.80+br),sc*0.34,sc*0.05);
      c.fillStyle='rgba(214,226,232,.10)';
      c.fillRect(bx-sc*0.17,by-sc*(0.60+br),sc*0.34,sc*0.035);
      // руки: дальняя вдоль корпуса, ближняя — вперёд, к стволу или к рации
      c.strokeStyle='#0c0f12';c.lineWidth=Math.max(2,sc*0.095);
      c.beginPath();c.moveTo(bx-sc*0.14,by-sc*(0.98+br));
      c.lineTo(bx-sc*(0.20+0.04*arm),by-sc*(0.62+br));c.stroke();
      c.beginPath();c.moveTo(bx+sc*0.14,by-sc*(0.98+br));
      c.lineTo(bx+arm*sc*0.36,by-sc*(0.74+br));c.stroke();
      if(noz){                                                           // ствол в руках
        c.strokeStyle='#161c20';c.lineWidth=Math.max(2,sc*0.085);
        c.beginPath();c.moveTo(bx+arm*sc*0.20,by-sc*(0.60+br));
        c.lineTo(bx+arm*sc*0.62,by-sc*(0.86+br));c.stroke();
        c.fillStyle='#2b3339';
        c.beginPath();c.arc(bx+arm*sc*0.62,by-sc*(0.86+br),sc*0.055,0,Math.PI*2);c.fill();
      }
    };
    // V96: второй и третий стояли на 0.455w и 0.545w — ровно там, где выходит
    // титр концовки, и подзаголовок проходил им по головам. Разведены по
    // сторонам от центра: один ближе к руине, второй — к машине.
    fire(w*0.360,HOR+h*0.030,h*0.115,-1,0.0,true);
    fire(w*0.408,HOR+h*0.016,h*0.100,-1,1.9,false);
    fire(w*0.612,HOR+h*0.006,h*0.092,1,3.4,false);
    c.strokeStyle='#141b1e';c.lineWidth=Math.max(2,h*0.008);             // рукав
    c.beginPath();c.moveTo(w*0.395,HOR+h*0.028);
    c.quadraticCurveTo(w*0.52,HOR+h*0.075,w*0.66,HOR+h*0.055);c.stroke();
    // струя воды по углям и пар от неё
    // V96: струя начиналась в пустоте справа от первого пожарного. Теперь
    // её начало привязано к концу ствола, и в точке падения есть пар.
    const nzx=w*0.360-h*0.115*0.62, nzy=HOR+h*0.030-h*0.115*0.86;
    const wex=w*0.185, wey=HOR+h*0.070;
    c.strokeStyle='rgba(198,214,222,.22)';c.lineWidth=Math.max(1.5,h*0.005);
    c.beginPath();c.moveTo(nzx,nzy);
    c.quadraticCurveTo(w*0.27,nzy+h*0.014,wex,wey);c.stroke();
    c.strokeStyle='rgba(214,228,234,.10)';c.lineWidth=Math.max(2.5,h*0.011);
    c.beginPath();c.moveTo(nzx,nzy);
    c.quadraticCurveTo(w*0.27,nzy+h*0.016,wex,wey);c.stroke();
    for(let i=0;i<5;i++){                                                // пар в точке падения
      const sk=((A.t*0.55+i*0.2)%1);
      c.fillStyle='rgba(206,216,220,'+(0.10*(1-sk)).toFixed(3)+')';
      c.beginPath();c.ellipse(wex-w*0.012+w*0.02*A.epiRnd(i*3.7),wey-h*0.10*sk,
        w*(0.016+0.030*sk),h*(0.012+0.026*sk),0,0,Math.PI*2);c.fill();
    }
    if(!low)for(let i=0;i<7;i++)A.drawSmokeColumn(c,w*(0.10+i*0.12),h*0.26,w*0.10,h*0.36,A.t+i*1.7,0.11);
    // ПЕРЕДНИЙ ПЛАН: обгоревшая голова кролика в пепле, крупно
    const hx=w*0.235+w*0.02*closeK, hy=h*0.820-h*0.015*closeK, hs=(h*0.145)*(1+0.22*closeK);
    c.save();c.translate(hx,hy);
    c.fillStyle='rgba(0,0,0,.35)';                                        // она лежит в золе
    c.beginPath();c.ellipse(0,hs*0.48,hs*0.90,hs*0.20,0,0,Math.PI*2);c.fill();
    // V94: обгоревший пластик стал светлее фона, а провалы — чернее. Раньше
    // голова была чуть темнее пепла и сливалась с ним в неразличимое пятно.
    c.fillStyle='#302a23';                                                // уши: одно обломано
    c.save();c.rotate(-0.20);c.fillRect(-hs*0.36,-hs*1.24,hs*0.28,hs*0.90);
    c.fillStyle='#1a1512';c.fillRect(-hs*0.31,-hs*1.16,hs*0.17,hs*0.70);c.restore();
    c.fillStyle='#2a251f';
    c.save();c.rotate(0.36);c.fillRect(hs*0.08,-hs*0.98,hs*0.27,hs*0.58);
    c.fillStyle='#171310';c.fillRect(hs*0.12,-hs*0.94,hs*0.17,hs*0.40);c.restore();
    c.fillStyle='#37312a';                                                // череп
    c.beginPath();c.ellipse(0,0,hs*0.64,hs*0.54,0,0,Math.PI*2);c.fill();
    c.fillStyle='#221d18';                                                // копоть по нижней половине
    c.beginPath();c.ellipse(0,hs*0.22,hs*0.62,hs*0.34,0,0,Math.PI*2);c.fill();
    c.strokeStyle='#100d0b';c.lineWidth=Math.max(1,hs*0.030);             // трещины
    for(let i=0;i<5;i++){const a0=-1.1+i*0.55;
      c.save();c.rotate(a0);c.beginPath();c.moveTo(hs*0.08,0);c.lineTo(hs*0.52,-hs*0.05);c.stroke();c.restore();}
    c.fillStyle='#443c33';                                                // морда
    c.beginPath();c.ellipse(0,hs*0.20,hs*0.42,hs*0.27,0,0,Math.PI*2);c.fill();
    c.fillStyle='#161210';                                                // нос
    c.beginPath();c.ellipse(0,hs*0.10,hs*0.09,hs*0.07,0,0,Math.PI*2);c.fill();
    c.fillStyle='#0a0908';                                                // пустые глазницы
    for(const s2 of[-1,1]){c.beginPath();c.ellipse(s2*hs*0.27,-hs*0.11,hs*0.145,hs*0.125,0,0,Math.PI*2);c.fill();}
    c.fillStyle='#0c0a09';                                                // оскал: зубы в чёрном провале
    c.fillRect(-hs*0.28,hs*0.28,hs*0.56,hs*0.13);
    c.fillStyle='#8e8676';
    for(let i=0;i<5;i++)c.fillRect(-hs*0.25+i*hs*0.105,hs*0.29,hs*0.062,hs*0.075);
    if(eyeK>0){                                                           // и один глаз загорается
      c.fillStyle='rgba(255,168,72,'+(0.92*eyeK).toFixed(3)+')';
      c.beginPath();c.ellipse(-hs*0.27,-hs*0.11,hs*0.078,hs*0.068,0,0,Math.PI*2);c.fill();
      glow(c,-hs*0.27,-hs*0.11,hs*1.6,'255,150,60',0.55*eyeK);
    }
    c.restore();
    if(!low)A.drawEmbers(c,0,HOR-h*0.02,w,h*0.40,A.t,10,0.35);
    A.epiGrade(c,w,h,A.t,low,'rgba(30,26,22,0.07)',0.34,1);
    c.restore();
    A.epiBars(c,w,h,1);
    // A.epiCard(c,w,h,tc,4.7,3.1,'ПЕПЕЛ','ОГОНЬ ЗАБРАЛ ДОМ. НЕ ЖИЛЬЦОВ.','#f0b784');
    A.epiTimecode(c,w,h,'NS-04 · 07:12 · ПОЖАРИЩЕ',0.40);
    veil(c,w,h,tc,DUR);
  }

  // =========================================================================
  // 3. ЕЩЁ ОДИН КОСТЮМ. Тот же офис, 06:00. В кресле — то, что от него
  //    осталось. Автоответчик крутит инструктаж уже ЕГО голосом, и в дверях
  //    стоит новый охранник с фонарём. Смена не кончилась, сменился человек.
  // =========================================================================
  function dark(A,tc){
    const c=A.ctx,w=A.w,h=A.h,low=A.low,DUR=8.0;
    const cue=mkCue(A,tc);
    const tapeK=cl((tc-1.4)/0.4);              // включается запись
    const doorK=eio(cl((tc-3.4)/1.5));         // открывается дверь
    const stepK=eio(cl((tc-5.2)/1.8));         // новый заходит внутрь
    cue(0.2,()=>window.AudioFX.synth?.('fan',.28));
    cue(1.4,()=>window.AudioFX.synth?.('switch',.40));
    cue(3.4,()=>window.AudioFX.synth?.('metalDrag',.26));
    cue(5.2,()=>window.AudioFX.synth?.('breath',.34));
    c.save();
    // офис: холодный монитор слева, тёплый коридор справа
    const FLOOR=h*0.665;
    const room=c.createLinearGradient(0,0,0,h);
    room.addColorStop(0,'#05080a');room.addColorStop(0.62,'#0d1418');room.addColorStop(1,'#161d20');
    c.fillStyle=room;c.fillRect(0,0,w,h);
    c.fillStyle='#0a1013';c.fillRect(0,FLOOR,w,h-FLOOR);
    c.strokeStyle='rgba(120,145,148,.07)';c.lineWidth=1;
    for(let i=-8;i<=8;i++){c.beginPath();c.moveTo(w*0.5+i*w*0.07,FLOOR);c.lineTo(w*0.5+i*w*0.26,h);c.stroke();}
    // стол, монитор, автоответчик
    const dx=w*0.075,dy=h*0.520,dw=w*0.395,dh=h*0.028;
    c.fillStyle='#1b2226';c.fillRect(dx,dy,dw,dh);
    c.fillStyle='#131a1d';c.fillRect(dx+w*0.02,dy+dh,w*0.016,FLOOR-dy-dh+h*0.055);
    c.fillRect(dx+dw-w*0.036,dy+dh,w*0.016,FLOOR-dy-dh+h*0.055);
    const mx=dx+dw*0.06,my=dy-h*0.135;
    c.fillStyle='#0b1114';c.fillRect(mx,my,w*0.140,h*0.128);
    c.fillStyle='rgba(96,156,142,.22)';c.fillRect(mx+3,my+3,w*0.140-6,h*0.128-6);
    for(let i=0;i<9;i++){c.fillStyle='rgba(150,220,200,'+(0.05+0.02*((i+Math.floor(A.t*3))%3)).toFixed(3)+')';
      c.fillRect(mx+6,my+8+i*h*0.013,(w*0.128)*(0.3+0.6*A.epiRnd(i*3.3+Math.floor(A.t))),2);}
    glow(c,mx+w*0.070,my+h*0.064,h*0.30,'120,200,180',0.14);
    // автоответчик: он говорит уже его голосом
    const ax=dx+dw*0.66,ay=dy-h*0.028;
    c.fillStyle='#22282c';c.fillRect(ax,ay,w*0.075,h*0.028);
    c.fillStyle='#0e1214';c.fillRect(ax+w*0.008,ay+h*0.006,w*0.030,h*0.016);
    const rec=tapeK*(0.45+0.55*(Math.sin(A.t*5.2)>0?1:0));
    c.fillStyle='rgba(226,72,72,'+rec.toFixed(3)+')';
    c.beginPath();c.arc(ax+w*0.060,ay+h*0.014,Math.max(1.6,w*0.0045),0,Math.PI*2);c.fill();
    if(tapeK>0)glow(c,ax+w*0.060,ay+h*0.014,h*0.06,'226,72,72',0.22*rec);
    // V94: КРЕСЛО И ТО, ЧТО В НЁМ ОСТАЛОСЬ. Раньше здесь звали drawGuardChar
    // с позой 'sit' — фигура выходила «стоящей», не попадала в кресло и
    // упиралась в нижний край кадра. Теперь силуэт рисуется вручную: он
    // осел в кресле, голова набок, рука свисает, под креслом натекло масло.
    // V94: масштаб увеличен почти вдвое — на первом прогоне фигура в кресле
    // выходила мелким красным пятном рядом с новым охранником в дверях.
    const chx=w*0.300, chy=FLOOR+h*0.170;      // основание кресла (передний план)
    const U=h*0.062;                            // единица тела
    c.fillStyle='rgba(0,0,0,.30)';              // масляная лужа
    c.beginPath();c.ellipse(chx,chy+U*0.25,U*2.5,U*0.55,0,0,Math.PI*2);c.fill();
    c.fillStyle='#12171a';                      // крестовина и колёса
    c.fillRect(chx-U*1.9,chy,U*3.8,U*0.30);
    for(const k of[-1.7,0,1.7]){c.beginPath();c.arc(chx+U*k,chy+U*0.36,U*0.24,0,Math.PI*2);c.fill();}
    c.fillStyle='#141a1e';c.fillRect(chx-U*0.22,chy-U*2.0,U*0.44,U*2.0);   // газлифт
    c.fillStyle='#232c32';c.fillRect(chx-U*1.5,chy-U*2.4,U*3.0,U*0.45);    // сиденье
    c.fillStyle='rgba(150,210,190,.06)';c.fillRect(chx-U*1.5,chy-U*2.4,U*3.0,U*0.08);
    c.save();c.translate(chx+U*0.62,chy-U*2.4);c.rotate(0.10);             // спинка (наклонена)
    c.fillStyle='#232c32';c.fillRect(0,-U*3.5,U*1.05,U*3.5);
    c.fillStyle='rgba(150,210,190,.07)';c.fillRect(U*0.92,-U*3.5,U*0.13,U*3.5);
    c.restore();
    c.fillStyle='#1d252a';c.fillRect(chx-U*1.9,chy-U*2.05,U*0.55,U*0.22);  // подлокотник
    // тело: осевший корпус в форме, кисть свисает с подлокотника
    c.save();c.translate(chx,chy-U*2.4);
    c.fillStyle='#5a1f24';                                                // куртка охраны, выцветшая
    c.beginPath();
    c.moveTo(-U*1.05,0);c.lineTo(-U*0.80,-U*2.35);c.lineTo(U*0.95,-U*2.55);
    c.lineTo(U*1.15,0);c.closePath();c.fill();
    c.fillStyle='rgba(0,0,0,.35)';c.fillRect(-U*1.05,-U*1.30,U*2.20,U*0.22);// тень поперёк груди
    // V96: штанины и ботинки заканчивались примерно на полторы единицы
    // выше пола — ноги висели в воздухе над крестовиной кресла.
    // Теперь они достают до пола (сиденье на 2.4U выше основания кресла).
    c.fillStyle='#2a2e36';                                                // штанины, сползли с сиденья
    c.fillRect(-U*0.95,0,U*0.80,U*2.05);c.fillRect(U*0.15,0,U*0.80,U*1.95);
    c.fillStyle='#0d1114';                                                // ботинки на полу
    c.fillRect(-U*1.10,U*1.95,U*1.05,U*0.46);c.fillRect(U*0.08,U*1.85,U*1.05,U*0.46);
    c.fillStyle='rgba(150,210,190,.05)';                                  // блик по носкам
    c.fillRect(-U*1.10,U*1.95,U*1.05,U*0.08);c.fillRect(U*0.08,U*1.85,U*1.05,U*0.08);
    // голова набок: высохшее лицо, глаза — две тёмные щели
    // V96: раньше голова была ровным светлым квадратом без теней и без
    // фуражки — на кадре она читалась как надетая картонная коробка, а не
    // как его лицо. Добавлены фуражка NS, впавшие виски, тень под челюстью,
    // тёмные глазницы вокруг щелей и шея.
    c.save();c.translate(U*0.10,-U*2.95);c.rotate(0.42);
    c.fillStyle='#4a3f34';                                                // шея в тени
    c.fillRect(-U*0.34,U*0.30,U*0.68,U*0.42);
    c.fillStyle='#6d6455';c.fillRect(-U*0.70,-U*0.85,U*1.40,U*1.35);      // голова
    c.fillStyle='rgba(0,0,0,.20)';                                        // впавшие виски
    c.fillRect(-U*0.70,-U*0.50,U*0.16,U*0.50);c.fillRect(U*0.54,-U*0.50,U*0.16,U*0.50);
    c.fillStyle='rgba(0,0,0,.26)';c.fillRect(-U*0.70,U*0.26,U*1.40,U*0.24);// тень под челюстью
    c.fillStyle='#3a3128';                                                // глазницы
    c.fillRect(-U*0.52,-U*0.46,U*0.46,U*0.34);c.fillRect(U*0.06,-U*0.46,U*0.46,U*0.34);
    c.fillStyle='#0a0c0d';
    c.fillRect(-U*0.46,-U*0.34,U*0.34,U*0.16);c.fillRect(U*0.10,-U*0.34,U*0.34,U*0.16);
    c.fillStyle='#1a1512';c.fillRect(-U*0.30,U*0.10,U*0.62,U*0.14);       // приоткрытый рот
    c.fillStyle='rgba(150,210,190,.10)';c.fillRect(-U*0.70,-U*0.85,U*0.22,U*1.35);
    c.fillStyle='#161a1f';                                                // фуражка: тулья
    c.fillRect(-U*0.78,-U*1.24,U*1.56,U*0.40);
    c.fillStyle='#0f1216';c.fillRect(-U*0.92,-U*0.90,U*1.84,U*0.13);      // козырёк
    c.fillStyle='#5a1f24';c.fillRect(-U*0.78,-U*0.95,U*1.56,U*0.09);      // кант
    c.fillStyle='rgba(196,164,72,.55)';                                   // тусклая кокарда
    c.fillRect(-U*0.14,-U*1.16,U*0.28,U*0.18);
    c.fillStyle='rgba(150,210,190,.07)';c.fillRect(-U*0.78,-U*1.24,U*1.56,U*0.07);
    c.restore();
    // рука свисает вниз, пальцы почти касаются лужи
    c.strokeStyle='#5a1f24';c.lineWidth=Math.max(2,U*0.42);
    c.beginPath();c.moveTo(-U*0.85,-U*2.00);c.lineTo(-U*1.35,-U*0.55);c.stroke();
    c.fillStyle='#6d6455';
    c.beginPath();c.ellipse(-U*1.38,-U*0.35,U*0.24,U*0.30,0,0,Math.PI*2);c.fill();
    c.restore();
    glow(c,chx,chy-U*3.0,h*0.22,'150,210,190',0.07);
    // дверь справа: коридорный свет и новый охранник в проёме
    const gx=w*0.775,gy=h*0.245,gw=w*0.150,gh=FLOOR+h*0.055-h*0.245;
    // V97: проём был двумя прямоугольниками — светлая рамка #2b3337 вокруг
    // чёрной дырки. В тёмном кадре рамка оказывалась самым светлым объектом и
    // читалась как нарисованный контур, а не как дверь. Стало: наличник с
    // тенью и подсветкой по краям, порог, закрытая створка с двумя филёнками,
    // армированное стекло с сеткой и ручка.
    c.fillStyle='#161c1f';c.fillRect(gx-14,gy-12,gw+28,gh+18);          // наличник
    c.fillStyle='#22292d';c.fillRect(gx-14,gy-12,gw+28,4);              // верхняя фаска
    c.fillStyle='#0d1113';c.fillRect(gx-14,gy-12,4,gh+18);              // левая тень
    c.fillStyle='#1e2529';c.fillRect(gx+gw+10,gy-12,4,gh+18);           // правый блик
    c.fillStyle='#080c0e';c.fillRect(gx,gy,gw,gh);                      // проём
    c.fillStyle='#131a1d';c.fillRect(gx,gy+gh-6,gw,6);                  // порог
    {const dpx=gx+gw*0.06,dpw=gw*0.88,dph=gh-8;                         // створка
     c.fillStyle='#191f22';c.fillRect(dpx,gy+4,dpw,dph);
     c.fillStyle='#212a2e';c.fillRect(dpx,gy+4,dpw,3);
     const glw=dpw*0.62,glh=dph*0.26;                                   // стекло
     const glx=dpx+(dpw-glw)*0.5,gly=gy+4+dph*0.10;
     c.fillStyle='#0b1113';c.fillRect(glx,gly,glw,glh);
     c.strokeStyle='rgba(150,170,166,.16)';c.lineWidth=1;
     for(let i=1;i<4;i++){c.beginPath();c.moveTo(glx+glw*i/4,gly);c.lineTo(glx+glw*i/4,gly+glh);c.stroke();}
     for(let i=1;i<3;i++){c.beginPath();c.moveTo(glx,gly+glh*i/3);c.lineTo(glx+glw,gly+glh*i/3);c.stroke();}
     c.strokeStyle='rgba(150,170,166,.22)';c.strokeRect(glx,gly,glw,glh);
     c.strokeStyle='rgba(120,140,138,.14)';                             // две филёнки
     for(const q of[0.46,0.74]){c.strokeRect(dpx+dpw*0.14,gy+4+dph*q,dpw*0.72,dph*0.20);}
     c.fillStyle='#3c4348';                                             // ручка
     c.fillRect(dpx+dpw*0.06,gy+4+dph*0.40,dpw*0.09,Math.max(2,h*0.006));}
    if(doorK>0){
      c.fillStyle='rgba(255,226,168,'+(0.16*doorK).toFixed(3)+')';
      c.fillRect(gx,gy,gw*doorK,gh);
      glow(c,gx+gw*0.5,gy+gh*0.5,gw*1.9,'255,214,150',0.30*doorK);
    }
    if(stepK>0){
      const nx=gx+gw*0.5-w*0.030*stepK, ny=gy+gh-h*0.004;
      A.drawGuardChar(c,nx,ny,0.70+0.06*stepK,{t:A.t,
        pose:stepK<0.85?'walk':'stand',
        phase:A.epiStridePhase(w*0.030*stepK,0.70,0.50),face:-1,seed:8.2,
        dark:0.30*(1-stepK),look:-0.30,prop:'flashlight',
        shadowDir:-1,shadowLen:1.2,shadowAlpha:0.34,
        rim:{dir:1,col:'255,222,160',power:0.42}});
    }
    A.epiGrade(c,w,h,A.t,low,'rgba(20,30,32,0.05)',0.36,1);
    c.restore();
    A.epiBars(c,w,h,1);
    // A.epiCard(c,w,h,tc,4.9,3.1,'ЕЩЁ ОДИН КОСТЮМ','ИНСТРУКТАЖ ЧИТАЕТ ЕГО ГОЛОС','#e08a92');
    A.epiTimecode(c,w,h,'NS-04 · 06:00 · СМЕНА 1/5',0.40);
    veil(c,w,h,tc,DUR);
  }

  // =========================================================================
  // 4. КОСТЮМ-ЛОВУШКА. Следующий вечер. Сцена, прожекторы, четверо на своих
  //    местах — и пятый, новый. Из-под маски идёт масло. Загорается вывеска
  //    «ОТКРЫТО», и в зале уже слышны дети.
  // =========================================================================
  function trap(A,tc){
    const c=A.ctx,w=A.w,h=A.h,low=A.low,DUR=7.8;
    const cue=mkCue(A,tc);
    const litK=eio(cl((tc-0.9)/1.4));         // прожекторы разогреваются
    const tearK=cl((tc-3.1)/1.6);             // масляная капля из-под маски
    const openK=eio(cl((tc-4.4)/1.0));        // вывеска «ОТКРЫТО»
    const turnK=eio(cl((tc-5.6)/1.4));        // он доворачивает голову в зал
    cue(0.9,()=>window.AudioFX.synth?.('switch',.42));
    cue(3.1,()=>window.AudioFX.synth?.('drip',.32));
    cue(4.4,()=>window.AudioFX.synth?.('ignite',.22));
    cue(5.6,()=>window.AudioFX.synth?.('laugh',.20));
    c.save();
    const room=c.createLinearGradient(0,0,0,h);
    room.addColorStop(0,'#0a0710');room.addColorStop(0.6,'#150f16');room.addColorStop(1,'#221722');
    c.fillStyle=room;c.fillRect(0,0,w,h);
    // занавес за сценой
    c.fillStyle='#2a1220';
    for(let i=0;i<16;i++){const bx=w*(0.06+i*0.056);
      c.globalAlpha=0.55+0.30*A.epiRnd(i*2.3);c.fillRect(bx,h*0.16,w*0.040,h*0.46);}
    c.globalAlpha=1;
    // помост
    c.fillStyle='#2a2028';c.fillRect(w*0.06,h*0.615,w*0.88,h*0.030);
    c.fillStyle='#17121a';c.fillRect(w*0.06,h*0.645,w*0.88,h*0.055);
    c.fillStyle='#0d0a10';c.fillRect(0,h*0.70,w,h*0.30);
    // пол зала с блеском
    c.fillStyle='rgba(255,196,120,.03)';c.fillRect(0,h*0.70,w,h*0.30);
    // два прожектора сверху
    for(const s of[0.32,0.68]){
      c.save();c.globalCompositeOperation='lighter';
      const g=c.createLinearGradient(w*s,h*0.10,w*s,h*0.70);
      g.addColorStop(0,'rgba(255,226,150,'+(0.20*litK).toFixed(3)+')');
      g.addColorStop(1,'rgba(255,200,110,0)');
      c.fillStyle=g;
      c.beginPath();c.moveTo(w*s-w*0.03,h*0.10);c.lineTo(w*s+w*0.03,h*0.10);
      c.lineTo(w*s+w*0.18,h*0.70);c.lineTo(w*s-w*0.18,h*0.70);c.closePath();c.fill();c.restore();
      glow(c,w*s,h*0.12,h*0.16,'255,226,150',0.35*litK);
    }
    // четверо старых — на своих местах, живут по-разному
    const base=h*0.645, sc=1.02;
    const dk=0.34-0.24*litK;
    A.epiAnimatron(c,w*0.185,base,sc*0.96,A.t,     {kind:'main', dark:dk,face:1, eye:0.85,shadow:0.5});
    A.epiAnimatron(c,w*0.335,base,sc*0.99,A.t+1.3,{kind:'felix',dark:dk,face:1, eye:1.00,shadow:0.5});
    A.epiAnimatron(c,w*0.665,base,sc*0.97,A.t+2.6,{kind:'exo',  dark:dk,face:-1,eye:0.70,shadow:0.5});
    A.epiAnimatron(c,w*0.815,base,sc*0.95,A.t+3.9,{kind:'lav',  dark:dk,face:-1,eye:0.90,shadow:0.5});
    // пятый — его костюм, в середине и чуть ниже прочих: он ещё «оседает».
    // Голова медленно доворачивается в зал — единственное его движение.
    const sx=w*0.50, sy=base+h*0.006;
    // V96: добавлены тень на помосте и такое же затемнение, как у остальных
    // четырёх, но вдвое слабее — он стоит под самым прожектором.
    A.epiWornSuit(c,sx,sy,sc*1.04,A.t,{k:1,face:1,
      yaw:-0.12+0.62*turnK,lean:0.04,tilt:0.03*Math.sin(A.t*0.6),
      bob:0.30*Math.sin(A.t*0.9),shadow:0.55,dark:dk*0.55});
    // масло из-под маски
    if(tearK>0){
      const dy2=h*0.052*Math.min(1,tearK*1.5);
      c.fillStyle='rgba(24,20,16,.85)';
      c.beginPath();c.ellipse(sx-w*0.012,sy-h*0.205+dy2,Math.max(1.2,w*0.0035),Math.max(2.0,h*0.010),0,0,Math.PI*2);c.fill();
      c.fillStyle='rgba(255,220,160,.10)';
      c.fillRect(sx-w*0.014,sy-h*0.205,Math.max(1,w*0.004),dy2);
      if(tearK>0.9){c.fillStyle='rgba(20,16,12,.55)';
        c.beginPath();c.ellipse(sx-w*0.012,sy-h*0.004,w*0.012,h*0.005,0,0,Math.PI*2);c.fill();}
    }
    // вывеска «ОТКРЫТО» в глубине зала
    const ox=w*0.055,oy=h*0.815;
    c.fillStyle='#1a1218';c.fillRect(ox,oy,w*0.135,h*0.055);
    c.textAlign='center';
    c.font='700 '+Math.round(h*0.030)+'px "Oswald",Impact,sans-serif';
    c.fillStyle='rgba(255,90,80,'+(0.20+0.75*openK).toFixed(3)+')';
    c.fillText('ОТКРЫТО',ox+w*0.0675,oy+h*0.040);
    c.textAlign='left';
    if(openK>0)glow(c,ox+w*0.0675,oy+h*0.028,h*0.16,'255,90,70',0.30*openK);
    A.epiGrade(c,w,h,A.t,low,'rgba(40,20,26,0.06)',0.34,1);
    c.restore();
    A.epiBars(c,w,h,1);
    // V96: титр опущен на пол зала — в центре кадра стоит он сам, и заголовок
    // закрывал ему маску и глаза (единственное, что важно в этом кадре).
    // A.epiCard(c,w,h,tc,4.4,3.1,'КОСТЮМ-ЛОВУШКА','В ПЯТНИЦУ ОНИ ОТКРЫВАЮТСЯ СНОВА','#efc08a',h*0.235);
    A.epiTimecode(c,w,h,'NS-04 · 18:30 · ЗАЛ',0.40);
    veil(c,w,h,tc,DUR);
  }

  // =========================================================================
  // 5. ПРАВДА. Стол с уликами. Кассета в пакете, папка 1993 года, список
  //    пропавших — пять имён. Нажимают PLAY, и в списке появляется шестое.
  // =========================================================================
  function truth(A,tc){
    const c=A.ctx,w=A.w,h=A.h,low=A.low,DUR=8.0;
    const cue=mkCue(A,tc);
    const lampK=eio(cl(tc/1.0));
    const playK=cl((tc-2.5)/0.35);            // нажали PLAY
    const rollK=cl((tc-2.9)/4.0);             // счётчик крутится
    const sixK=eio(cl((tc-4.5)/1.0));         // шестое имя
    cue(0.2,()=>window.AudioFX.synth?.('fan',.22));
    cue(2.5,()=>window.AudioFX.synth?.('switch',.46));
    cue(2.9,()=>window.AudioFX.synth?.('fan',.26));
    cue(4.5,()=>window.AudioFX.synth?.('sting',.30));
    c.save();
    const room=c.createLinearGradient(0,0,0,h);
    room.addColorStop(0,'#05080b');room.addColorStop(0.55,'#0b1014');room.addColorStop(1,'#12181c');
    c.fillStyle=room;c.fillRect(0,0,w,h);
    // лампа на шнуре над столом
    c.strokeStyle='#1a2024';c.lineWidth=Math.max(1,h*0.004);
    c.beginPath();c.moveTo(w*0.50,0);c.lineTo(w*0.50,h*0.145);c.stroke();
    c.fillStyle='#23292d';
    c.beginPath();c.moveTo(w*0.455,h*0.185);c.lineTo(w*0.545,h*0.185);c.lineTo(w*0.522,h*0.145);c.lineTo(w*0.478,h*0.145);c.closePath();c.fill();
    c.fillStyle='rgba(255,238,196,'+(0.85*lampK).toFixed(3)+')';
    c.beginPath();c.ellipse(w*0.50,h*0.190,w*0.016,h*0.010,0,0,Math.PI*2);c.fill();
    glow(c,w*0.50,h*0.20,h*0.62,'255,232,180',0.36*lampK);
    // стол
    const ty=h*0.60;
    const tg=c.createLinearGradient(0,ty,0,h);
    tg.addColorStop(0,'#4a4034');tg.addColorStop(1,'#241f1a');
    c.fillStyle=tg;c.fillRect(0,ty,w,h-ty);
    c.fillStyle='rgba(255,238,190,.05)';c.fillRect(0,ty,w,h*0.012);
    // папка с делом
    // V94: лист поднят и увеличен — раньше пятая и шестая строки уходили
    // за нижний край листа и за нижний край кадра, и главное (шестое имя)
    // было не видно. Теперь весь список с запасом лежит внутри листа.
    c.save();c.translate(w*0.225,ty+h*0.105);c.rotate(-0.05);
    c.fillStyle='#b9a887';c.fillRect(-w*0.125,-h*0.115,w*0.250,h*0.230);
    c.fillStyle='#9c8b6c';c.fillRect(-w*0.125,-h*0.115,w*0.250,h*0.020);
    c.fillStyle='#2a241c';
    c.font='600 '+Math.round(h*0.019)+'px "JetBrains Mono",monospace';
    c.fillText('ДЕЛО 93-114',-w*0.108,-h*0.076);
    c.strokeStyle='rgba(60,52,38,.35)';c.lineWidth=1;
    c.beginPath();c.moveTo(-w*0.108,-h*0.064);c.lineTo(w*0.108,-h*0.064);c.stroke();
    c.font='600 '+Math.round(h*0.0165)+'px "JetBrains Mono",monospace';
    c.fillStyle='#3a3327';
    const names=['1. ДЖ. К.','2. М. Ф.','3. С. Р.','4. А. Т.','5. Б. Л.'];
    for(let i=0;i<names.length;i++)c.fillText(names[i],-w*0.108,-h*0.036+i*h*0.0245);
    if(sixK>0){                              // шестое имя вписано только что
      c.globalAlpha=sixK;
      c.fillStyle='#12233a';                 // свежие чернила темнее машинописи
      c.fillText('6. ОХР. NS-04',-w*0.108,-h*0.036+5*h*0.0245);
      c.globalAlpha=1;
    }
    c.restore();
    // кассета в пакете для улик
    c.save();c.translate(w*0.665,ty+h*0.065);c.rotate(0.05);
    c.fillStyle='rgba(206,220,226,.14)';c.fillRect(-w*0.085,-h*0.058,w*0.170,h*0.116);
    c.strokeStyle='rgba(226,238,244,.30)';c.lineWidth=1;c.strokeRect(-w*0.085,-h*0.058,w*0.170,h*0.116);
    c.fillStyle='#1a1a1c';c.fillRect(-w*0.062,-h*0.034,w*0.124,h*0.068);
    c.fillStyle='#c9c2ad';c.fillRect(-w*0.052,-h*0.026,w*0.104,h*0.020);
    c.fillStyle='#2b2b2e';c.fillRect(-w*0.040,-h*0.006,w*0.080,h*0.030);
    for(const s of[-1,1]){c.fillStyle='#0c0c0e';
      c.beginPath();c.arc(s*w*0.020,h*0.010,Math.max(2,w*0.008),0,Math.PI*2);c.fill();
      c.fillStyle='#5a544a';
      c.beginPath();c.arc(s*w*0.020,h*0.010,Math.max(1,w*0.003),0,Math.PI*2);c.fill();}
    c.fillStyle='#231f18';
    c.font='600 '+Math.round(h*0.0135)+'px "JetBrains Mono",monospace';
    c.textAlign='center';c.fillText('11.1993',0,-h*0.011);c.textAlign='left';
    c.restore();
    // магнитофон: индикатор PLAY и счётчик
    // V96: раньше это был тёмный прямоугольник с цифрами и большой зелёный
    // треугольник — на кадре он читался как кнопка интерфейса, а не как вещь
    // на столе. Теперь есть корпус с тенью, окошко с крутящимися бобинами,
    // ряд механических клавиш (нажата именно PLAY), сетка динамика и лампа уровня.
    c.save();c.translate(w*0.435,ty+h*0.185);
    const dW=w*0.115, dH=h*0.052;
    c.fillStyle='rgba(0,0,0,.32)';                                    // тень на столе
    c.beginPath();c.ellipse(0,dH*0.98,dW*1.10,dH*0.24,0,0,Math.PI*2);c.fill();
    c.fillStyle='#1a2024';c.fillRect(-dW,-dH,dW*2,dH*2);              // корпус
    c.fillStyle='#262d32';c.fillRect(-dW,-dH,dW*2,dH*0.20);           // верхняя кромка
    c.fillStyle='rgba(226,238,244,.10)';c.fillRect(-dW,-dH,dW*2,dH*0.06);
    c.fillStyle='#101418';c.fillRect(-dW,dH*0.78,dW*2,dH*0.22);       // ножки
    // окошко кассеты: стекло, кассета и две крутящиеся бобины
    const wx=-dW*0.86, wy=-dH*0.62, ww=dW*0.92, wh=dH*0.84;
    c.fillStyle='#0a0d10';c.fillRect(wx,wy,ww,wh);
    c.fillStyle='#191c1f';c.fillRect(wx+ww*0.08,wy+wh*0.16,ww*0.84,wh*0.68);
    const spin=rollK*14.0;
    for(const s of[0.30,0.70]){
      const rx=wx+ww*s, ry=wy+wh*0.52, rr=Math.min(ww*0.19,wh*0.28);
      c.fillStyle='#2c3136';c.beginPath();c.arc(rx,ry,rr,0,Math.PI*2);c.fill();
      c.fillStyle='#0d1013';c.beginPath();c.arc(rx,ry,rr*0.42,0,Math.PI*2);c.fill();
      c.strokeStyle='rgba(214,226,232,.30)';c.lineWidth=Math.max(1,rr*0.14);
      for(let i=0;i<3;i++){const a=spin+i*2.094;
        c.beginPath();c.moveTo(rx,ry);c.lineTo(rx+Math.cos(a)*rr*0.9,ry+Math.sin(a)*rr*0.9);c.stroke();}
    }
    c.fillStyle='rgba(190,220,232,.10)';c.fillRect(wx,wy,ww,wh*0.30); // блик по стеклу
    c.strokeStyle='rgba(226,238,244,.18)';c.lineWidth=1;c.strokeRect(wx,wy,ww,wh);
    // счётчик и лампа уровня
    c.fillStyle='#0d1114';c.fillRect(dW*0.10,-dH*0.56,dW*0.52,dH*0.44);
    c.fillStyle='#8ad0b8';
    c.font='600 '+Math.round(h*0.018)+'px "JetBrains Mono",monospace';
    const cnt=String(Math.floor(rollK*247)).padStart(4,'0');
    c.fillText(cnt,dW*0.16,-dH*0.22);
    const lvl=playK*(0.45+0.55*Math.abs(Math.sin(A.t*6.1)));
    c.fillStyle='rgba(226,90,70,'+(0.25+0.60*lvl).toFixed(3)+')';
    c.beginPath();c.arc(dW*0.80,-dH*0.34,Math.max(1.4,dW*0.042),0,Math.PI*2);c.fill();
    // сетка динамика справа
    c.fillStyle='rgba(12,16,18,.85)';c.fillRect(dW*0.10,dH*0.10,dW*0.80,dH*0.58);
    c.fillStyle='rgba(150,168,176,.16)';
    for(let i=0;i<7;i++)for(let j=0;j<4;j++)
      c.fillRect(dW*(0.15+i*0.10),dH*(0.16+j*0.13),Math.max(1,dW*0.035),Math.max(1,dH*0.06));
    // клавиши транспорта: третья — PLAY, она вдавлена
    for(let i=0;i<4;i++){
      const kx=wx+ww*0.02+i*dW*0.24, isP=(i===2), dn=isP?playK*dH*0.09:0;
      c.fillStyle='#0e1215';c.fillRect(kx,dH*0.32,dW*0.19,dH*0.44);
      c.fillStyle=isP&&playK>0?'#39424a':'#2a3238';
      c.fillRect(kx,dH*0.32+dn,dW*0.19,dH*0.38);
      c.fillStyle='rgba(226,238,244,.12)';c.fillRect(kx,dH*0.32+dn,dW*0.19,dH*0.05);
      if(isP){
        c.fillStyle=playK>0?'rgba(120,226,150,.95)':'rgba(80,100,90,.55)';
        c.beginPath();c.moveTo(kx+dW*0.06,dH*0.42+dn);c.lineTo(kx+dW*0.06,dH*0.62+dn);
        c.lineTo(kx+dW*0.15,dH*0.52+dn);c.closePath();c.fill();
      }else{
        c.fillStyle='rgba(180,196,204,.40)';
        c.fillRect(kx+dW*0.06,dH*0.46,dW*0.07,dH*0.11);
      }
    }
    if(playK>0)glow(c,wx+ww*0.02+2*dW*0.24+dW*0.10,dH*0.52,h*0.09,'120,226,150',0.22);
    c.restore();
    // отражение лампы на столе и мелкая пыль в свете
    glow(c,w*0.50,ty+h*0.03,h*0.34,'255,232,180',0.14*lampK);
    if(!low)for(let i=0;i<26;i++){
      const px=w*(0.30+0.40*A.epiRnd(i*5.1)), py=h*(0.22+0.34*((A.epiRnd(i*2.9)+A.t*0.03)%1));
      c.fillStyle='rgba(255,240,206,'+(0.05+0.06*A.epiRnd(i*7.7)).toFixed(3)+')';
      c.fillRect(px,py,1.4,1.4);
    }
    A.epiGrade(c,w,h,A.t,low,'rgba(30,30,24,0.05)',0.38,1);
    c.restore();
    A.epiBars(c,w,h,1);
    // A.epiCard(c,w,h,tc,4.7,3.1,'ПРАВДА','В СПИСКЕ ПОЯВИЛОСЬ ШЕСТОЕ ИМЯ','#9ed6e4');
    A.epiTimecode(c,w,h,'ДЕЛО 93-114 · УЛИКА №7',0.42);
    veil(c,w,h,tc,DUR);
  }

  return {calm,burn,dark,trap,truth,DUR:{calm:8.1,burn:8.0,dark:8.0,trap:7.8,truth:8.0}};
})();
