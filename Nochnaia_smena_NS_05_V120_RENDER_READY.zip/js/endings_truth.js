// ===========================================================================
// НОЧНАЯ СМЕНА — V85. Пятая концовка «ПРАВДА» (архив под залом и парковка).
//
// Почему отдельным файлом: game.js целиком лежит в одной большой функции, и
// раскадровка раздувала её ещё сильнее, хотя во время смены не нужна вообще.
// Вынос наружу ничего не ускоряет сам по себе (проверено замером — разницы в
// стоимости кадра нет), но держит игровой файл читаемым и позволяет править
// сцену, не трогая боевой код. Все нужные помощники приходят через объект A.
//
// ЧТО ИЗМЕНИЛОСЬ В V85 (по замечаниям к V84):
//  1. Кадр был ПУСТОЙ. Архив состоял из одной стены стеллажей, ровного пола и
//     двух предметов; верх кадра и правая треть не были заняты ничем, и сцена
//     читалась как тестовая заготовка. Теперь у помещения есть потолок с
//     балками и трубами, качающаяся лампа в решётке, дальняя стена с
//     подтёками и щитком, уходящий в глубину боковой стеллаж, коробки, стул,
//     ведро, кабели и лужа с отражением. Плюс передний план (труба сверху и
//     колонна слева) — он замыкает кадр и задаёт глубину.
//  2. Масштаб подобран под персонажа: охранник в V85 крупнее, поэтому
//     стеллажи, шкаф и монитор пересчитаны так, чтобы человек был соразмерен
//     мебели, а не терялся между полками.
//  3. Убраны субтитры. Раньше поверх финала шли семь строк текста, которые
//     пересказывали то, что и так происходит в кадре. Смысл теперь несут
//     свет, движение и звук; из надписей остались только титульная карточка
//     главы и карточка концовки.
//  4. Сцена стала длиннее (26 → 30 с) и в неё добавлены живые паузы: он
//     сдувает пыль с кассеты, лампа качается от его шага, четверо за спиной
//     ведут себя ПО-РАЗНОМУ (один кивает, второй дёргается, третий стоит
//     мёртво, четвёртый медленно доворачивает голову).
//  5. Парковка перестала быть пустым асфальтом: забор, фонарь со конусом
//     света, мёртвая вывеска пиццерии, бак, деревья на горизонте, лужи с
//     отражением мигалки и фигура возле машины — его там наконец ждут.
// ===========================================================================
window.EndingTruth=function(A,t){

  const ctx=A.ctx,w=A.w,h=A.h,low=A.low;
  const {epiCue,epiRnd,epiStridePhase,epiAnimatron,drawGuardChar,epiCard,epiGrade,epiBars,epiTimecode,epiSkipHint}=A;
  const cl=v=>Math.min(1,Math.max(0,v));
  const eio=x=>x<.5?2*x*x:1-Math.pow(-2*x+2,2)/2;

  // ---- раскадровка (30 секунд) ----
  const walkP=eio(cl((t-1.4)/3.8));      // идёт по архиву к шкафу
  const drawerP=eio(cl((t-5.8)/1.5));    // выдвигает ящик
  const tapeP=eio(cl((t-7.6)/1.0));      // кассета в руке
  const blowP=cl((t-8.8)/1.2);           // сдувает пыль с кассеты
  const crtP=eio(cl((t-10.6)/1.6));      // монитор включается
  const reportP=cl((t-12.2)/3.2);        // строки отчёта
  const backP=eio(cl((t-16.4)/2.0));     // четверо за спиной
  const exitP=eio(cl((t-21.0)/2.4));     // уход к выходу
  const outP=eio(cl((t-23.2)/2.0));      // парковка и мигалки
  const finalK=cl((t-27.4)/2.2);

  epiCue(t,1.4,()=>window.AudioFX.synth?.('breath',.5));
  epiCue(t,5.8,()=>window.AudioFX.synth?.('switch',.45));
  epiCue(t,8.8,()=>window.AudioFX.synth?.('breath',.34));
  // V95: было synth('static') — такого звука в синтезаторе нет, и включение
  // монитора было НЕМЫМ. Стало: щелчок клавиши, загрузка ленты и гул кинескопа.
  epiCue(t,10.4,()=>{try{window.MonsterAudio?.tape(true)}catch(e){}});
  epiCue(t,10.6,()=>{window.AudioFX.synth?.('switch',.45);window.AudioFX.synth?.('rumble',.26);});
  epiCue(t,16.4,()=>window.AudioFX.synth?.('sting',.30));
  // V95: было synth('step') — тоже несуществующий ключ. Стало: он выключает
  // магнитофон и забирает кассету — слышно реле и выброс ленты.
  epiCue(t,21.0,()=>{try{window.MonsterAudio?.relay(true)}catch(e){}window.AudioFX.synth?.('paper',.26);});
  epiCue(t,23.2,()=>window.AudioFX.synth?.('switch',.35));

  ctx.save();
  ctx.imageSmoothingEnabled=true;
  // ровное дыхание камеры: без рывков, чистый плавный доворот
  ctx.translate(Math.sin(t*0.5)*1.6,Math.cos(t*0.37)*1.1);

  if(outP<1){
    // ======================= АРХИВ ПОД ЗАЛОМ =======================
    ctx.save();
    // медленный проезд камеры вслед за ним, затем отъезд к выходу
    const camX=-w*0.10*walkP-w*0.16*exitP, z=1.04+0.05*crtP;
    ctx.translate(w*0.5,h*0.5);ctx.scale(z,z);ctx.translate(-w*0.5+camX,-h*0.5);

    // ---- воздух помещения ----
    const room=ctx.createLinearGradient(0,0,0,h);
    room.addColorStop(0,'#03070a');room.addColorStop(.34,'#0a141b');
    room.addColorStop(.62,'#0b161d');room.addColorStop(1,'#050a0e');
    ctx.fillStyle=room;ctx.fillRect(-w*0.35,0,w*1.7,h);

    // ---- ДАЛЬНЯЯ СТЕНА: краска сходит пластами, подтёки, щиток ----
    ctx.fillStyle='#0a1116';ctx.fillRect(-w*0.35,h*0.16,w*1.7,h*0.60);
    // пласты облупившейся краски (детерминированный шум, кадр не «кипит»)
    for(let i=0;i<34;i++){
      const px2=-w*0.3+epiRnd(i*1.7)*w*1.6, py2=h*(0.18+epiRnd(i*2.9)*0.50);
      const pw2=w*(0.010+epiRnd(i*3.3)*0.030), ph2=h*(0.012+epiRnd(i*4.1)*0.045);
      ctx.fillStyle=epiRnd(i*5.5)>0.5?'rgba(28,42,50,.30)':'rgba(8,14,18,.42)';
      ctx.fillRect(px2,py2,pw2,ph2);
    }
    // сырые подтёки сверху вниз — вода идёт из зала над головой
    for(let i=0;i<9;i++){
      const sx2=-w*0.2+epiRnd(i*7.1)*w*1.4, sw2=w*(0.012+epiRnd(i*9.3)*0.022);
      const gr=ctx.createLinearGradient(0,h*0.17,0,h*0.62);
      gr.addColorStop(0,'rgba(30,48,54,.34)');gr.addColorStop(1,'rgba(30,48,54,0)');
      ctx.fillStyle=gr;ctx.fillRect(sx2,h*0.17,sw2,h*0.45);
    }
    // электрощиток с предупреждением
    {
      const bx=w*0.955,by=h*0.30,bw=w*0.048,bh=h*0.10;
      ctx.fillStyle='#11191f';ctx.fillRect(bx,by,bw,bh);
      ctx.fillStyle='#1b262d';ctx.fillRect(bx+2,by+2,bw-4,bh-4);
      ctx.fillStyle='#0a1014';ctx.fillRect(bx+bw*0.18,by+bh*0.18,bw*0.64,bh*0.30);
      ctx.fillStyle='rgba(226,180,70,.55)';ctx.fillRect(bx+bw*0.18,by+bh*0.60,bw*0.64,bh*0.16);
      ctx.fillStyle='#8f9aa3';ctx.fillRect(bx+bw*0.44,by+bh*0.50,bw*0.12,bh*0.08);
    }

    // ---- ПОТОЛОК: балки, трубы, кабельный лоток ----
    {
      ctx.fillStyle='#050a0d';ctx.fillRect(-w*0.35,0,w*1.7,h*0.17);
      // поперечные балки уходят к горизонту
      for(let b=0;b<6;b++){
        const bx2=-w*0.2+b*w*0.26;
        ctx.fillStyle='#0b1216';ctx.fillRect(bx2,0,w*0.035,h*0.17);
        ctx.fillStyle='rgba(0,0,0,.4)';ctx.fillRect(bx2+w*0.035,0,w*0.008,h*0.17);
      }
      // две трубы вдоль всего помещения + муфты
      [0.085,0.128].forEach((py3,pi)=>{
        const pg=ctx.createLinearGradient(0,h*py3,0,h*(py3+0.022));
        pg.addColorStop(0,pi?'#243036':'#2b3238');pg.addColorStop(1,'#0d1317');
        ctx.fillStyle=pg;ctx.fillRect(-w*0.35,h*py3,w*1.7,h*0.022);
        for(let m=0;m<8;m++){ctx.fillStyle='#323b41';
          ctx.fillRect(-w*0.3+m*w*0.20,h*(py3-0.004),w*0.018,h*0.030);}
      });
      // кабельный лоток и провисающие провода
      ctx.strokeStyle='rgba(14,20,24,.9)';ctx.lineWidth=Math.max(2,h*0.005);
      for(let c2=0;c2<5;c2++){
        ctx.beginPath();
        const x0=-w*0.2+c2*w*0.30;
        ctx.moveTo(x0,h*0.155);
        ctx.quadraticCurveTo(x0+w*0.15,h*(0.185+0.02*((c2%3)/2)),x0+w*0.30,h*0.155);
        ctx.stroke();
      }
    }

    // ---- ЛАМПА В РЕШЁТКЕ: качается от его шагов ----
    const lampX=w*0.40, lampY=h*0.235;
    const swing=Math.sin(t*1.15)*0.055*(0.35+0.65*walkP);
    {
      ctx.save();ctx.translate(lampX,h*0.13);ctx.rotate(swing);
      ctx.strokeStyle='#1a2328';ctx.lineWidth=Math.max(1.5,h*0.003);
      ctx.beginPath();ctx.moveTo(0,0);ctx.lineTo(0,h*0.105);ctx.stroke();
      const r=h*0.026;
      ctx.fillStyle='#0e1418';ctx.beginPath();ctx.arc(0,h*0.105,r*1.25,0,Math.PI*2);ctx.fill();
      // сама колба
      ctx.fillStyle='rgba(255,238,200,.92)';
      ctx.beginPath();ctx.arc(0,h*0.105,r*0.62,0,Math.PI*2);ctx.fill();
      // решётка
      ctx.strokeStyle='rgba(20,28,32,.95)';ctx.lineWidth=Math.max(1,h*0.0022);
      for(let g=0;g<6;g++){
        ctx.beginPath();ctx.arc(0,h*0.105,r*(0.5+g*0.16),Math.PI*0.05,Math.PI*0.95);ctx.stroke();
      }
      for(let g=-2;g<=2;g++){
        ctx.beginPath();ctx.moveTo(g*r*0.42,h*0.105-r*0.2);ctx.lineTo(g*r*0.62,h*0.105+r*1.15);ctx.stroke();
      }
      ctx.restore();
    }
    // конус света от лампы + пыль в нём
    const lx2=lampX+Math.sin(swing)*h*0.105, ly2=lampY;
    ctx.save();ctx.globalCompositeOperation='lighter';
    const cone=ctx.createRadialGradient(lx2,ly2,4,lx2,ly2,w*0.42);
    cone.addColorStop(0,'rgba(255,236,196,.55)');
    cone.addColorStop(0.18,'rgba(252,228,186,.20)');
    cone.addColorStop(0.55,'rgba(240,214,170,.07)');
    cone.addColorStop(1,'rgba(230,200,160,0)');
    ctx.fillStyle=cone;ctx.fillRect(lx2-w*0.5,0,w*1.0,h);
    // световое пятно под лампой — лампа теперь действительно освещает пол
    const pool=ctx.createRadialGradient(lx2,h*0.83,4,lx2,h*0.83,w*0.20);
    pool.addColorStop(0,'rgba(255,232,188,.16)');pool.addColorStop(1,'rgba(255,232,188,0)');
    ctx.fillStyle=pool;
    ctx.beginPath();ctx.ellipse(lx2,h*0.845,w*0.17,h*0.055,0,0,Math.PI*2);ctx.fill();
    // конус читается геометрией, а не только засветом
    const beam=ctx.createLinearGradient(0,ly2,0,h*0.86);
    beam.addColorStop(0,'rgba(255,232,190,.09)');beam.addColorStop(1,'rgba(255,232,190,0)');
    ctx.fillStyle=beam;
    ctx.beginPath();ctx.moveTo(lx2-w*0.030,ly2);ctx.lineTo(lx2+w*0.030,ly2);
    ctx.lineTo(lx2+w*0.18,h*0.86);ctx.lineTo(lx2-w*0.18,h*0.86);ctx.closePath();ctx.fill();
    if(!low){
      for(let i=0;i<44;i++){
        const a2=epiRnd(i*3.1)*Math.PI*2, rr=epiRnd(i*5.7)*w*0.16;
        const dx3=lx2+Math.cos(a2+t*0.10)*rr, dy3=ly2+Math.sin(a2*1.7+t*0.16)*rr*0.55+h*0.09;
        ctx.fillStyle='rgba(255,242,214,'+(0.05+0.09*epiRnd(i*7.3)).toFixed(3)+')';
        ctx.fillRect(dx3,dy3,1.5,1.5);
      }
    }
    ctx.restore();

    // ---- ПОЛ: бетон, стыки плит, кабели, лужа ----
    ctx.fillStyle='#080d11';ctx.fillRect(-w*0.35,h*0.72,w*1.7,h*0.28);
    ctx.strokeStyle='rgba(120,150,160,.07)';ctx.lineWidth=1;
    for(let i=-6;i<=10;i++){ctx.beginPath();ctx.moveTo(w*0.5+i*w*0.09,h*0.72);ctx.lineTo(w*0.5+i*w*0.26,h);ctx.stroke();}
    ctx.strokeStyle='rgba(150,175,185,.05)';
    for(let i=0;i<3;i++){ctx.beginPath();ctx.moveTo(-w*0.3,h*(0.79+i*0.06));ctx.lineTo(w*1.3,h*(0.79+i*0.06));ctx.stroke();}
    // кабель змеится по полу
    ctx.strokeStyle='rgba(10,15,18,.95)';ctx.lineWidth=Math.max(2,h*0.0055);
    ctx.beginPath();ctx.moveTo(-w*0.1,h*0.955);
    ctx.bezierCurveTo(w*0.25,h*0.90,w*0.55,h*0.99,w*1.05,h*0.93);ctx.stroke();
    // лужа под подтёком: отражает лампу
    {
      const px3=w*0.235,py3=h*0.905,pw3=w*0.15,ph3=h*0.030;
      ctx.save();
      ctx.fillStyle='rgba(90,130,150,.13)';
      ctx.beginPath();ctx.ellipse(px3,py3,pw3*0.5,ph3*0.5,0,0,Math.PI*2);ctx.fill();
      ctx.globalCompositeOperation='lighter';
      const rf=ctx.createLinearGradient(px3,py3-ph3*0.5,px3,py3+ph3*0.5);
      rf.addColorStop(0,'rgba(255,232,190,.11)');rf.addColorStop(1,'rgba(255,232,190,0)');
      ctx.fillStyle=rf;
      ctx.beginPath();ctx.ellipse(px3+Math.sin(t*0.9)*3,py3,pw3*0.22,ph3*0.42,0,0,Math.PI*2);ctx.fill();
      ctx.restore();
    }

    // ---- СТЕЛЛАЖИ ВДОЛЬ СТЕНЫ (масштаб под крупного персонажа) ----
    for(let q=0;q<7;q++){
      const sx=w*(0.02+q*0.155), sw=w*0.118, sy=h*0.235, sh2=h*0.505;
      ctx.fillStyle='#0d151b';ctx.fillRect(sx,sy,sw,sh2);
      ctx.fillStyle='#111c23';ctx.fillRect(sx,sy,sw,h*0.013);
      // стойки каркаса
      ctx.fillStyle='#141f26';ctx.fillRect(sx,sy,w*0.006,sh2);ctx.fillRect(sx+sw-w*0.006,sy,w*0.006,sh2);
      for(let r=0;r<5;r++){
        const ry2=sy+h*0.021+r*h*0.097;
        ctx.fillStyle='#0a1116';ctx.fillRect(sx+2,ry2,sw-4,h*0.086);
        for(let b=0;b<6;b++){
          const bh3=h*0.064+((q*7+r*3+b)%3)*h*0.007;
          ctx.fillStyle=['#2a3a44','#38302a','#243039','#3a3630'][(q+r+b)%4];
          ctx.fillRect(sx+4+b*(sw-8)/6,ry2+h*0.086-bh3,(sw-8)/6-1.5,bh3);
          // корешок с рукописной меткой — намёк, что папок тут тысячи
          if((q+r+b)%5===0){ctx.fillStyle='rgba(226,216,186,.30)';
            ctx.fillRect(sx+5+b*(sw-8)/6,ry2+h*0.086-bh3+h*0.008,(sw-8)/6-4,1.5);}
        }
        // тень от полки
        ctx.fillStyle='rgba(0,0,0,.30)';ctx.fillRect(sx+2,ry2+h*0.086-2,sw-4,2.5);
      }
      ctx.fillStyle='rgba(0,0,0,.35)';ctx.fillRect(sx+sw-3,sy,3,sh2);
    }

    // ---- БОКОВОЙ СТЕЛЛАЖ, УХОДЯЩИЙ В ГЛУБИНУ (дальний правый угол) ----
    // Оставлены три секции и сдвинуты за правый край: раньше пять полупрозрачных
    // секций накладывались на монитор и вся правая треть кадра выглядела затуманенной.
    {
      ctx.save();
      const bx=w*1.12, by=h*0.21, bh=h*0.54;
      for(let d=0;d<3;d++){
        const k=d/3, xx=bx-d*w*0.055, ww=w*0.052*(1-k*0.16);
        const yy=by+k*h*0.040, hh=bh*(1-k*0.08);
        ctx.fillStyle='rgba(8,13,17,1)';ctx.fillRect(xx,yy,ww,hh);
        ctx.fillStyle='rgba(18,29,36,1)';ctx.fillRect(xx,yy,ww,h*0.010);
        for(let r=0;r<4;r++){
          ctx.fillStyle='rgba(30,41,48,'+(0.90-k*0.18).toFixed(2)+')';
          ctx.fillRect(xx+2,yy+h*0.03+r*hh*0.24,ww-4,hh*0.15);
        }
        ctx.fillStyle='rgba(0,0,0,.45)';ctx.fillRect(xx-3,yy,3,hh);
      }
      ctx.restore();
    }

    // ---- ПРОЁМ ВЫХОДА СЛЕВА ----
    {
      const dx2=-w*0.015, dw2=w*0.092, dy2=h*0.285, dh2=h*0.445;
      ctx.fillStyle='#0a1015';ctx.fillRect(dx2-8,dy2-10,dw2+16,dh2+18);
      ctx.fillStyle='#16222a';ctx.fillRect(dx2,dy2,dw2,dh2);
      ctx.fillStyle='#0c141a';ctx.fillRect(dx2+dw2*0.12,dy2+dh2*0.06,dw2*0.76,dh2*0.88);
      // лестница наверх читается ступенями в проёме
      for(let s=0;s<5;s++){
        ctx.fillStyle='rgba(120,150,170,'+(0.05+s*0.012).toFixed(3)+')';
        ctx.fillRect(dx2+dw2*0.14,dy2+dh2*(0.30+s*0.11),dw2*0.72,h*0.010);
      }
      ctx.save();ctx.globalCompositeOperation='lighter';
      const dg=ctx.createRadialGradient(dx2+dw2*0.5,dy2+dh2*0.5,4,dx2+dw2*0.5,dy2+dh2*0.5,w*0.18);
      dg.addColorStop(0,'rgba(150,190,215,0.18)');dg.addColorStop(1,'rgba(150,190,215,0)');
      ctx.fillStyle=dg;ctx.fillRect(dx2-w*0.1,dy2-h*0.1,w*0.3,dh2+h*0.2);ctx.restore();
      ctx.fillStyle='rgba(206,220,230,.45)';
      ctx.font='600 '+Math.round(h*0.014)+'px "JetBrains Mono",monospace';
      ctx.fillText('ВЫХОД',dx2+4,dy2-14);
    }

    // ---- ХЛАМ АРХИВА: коробки, стул, ведро, стопка папок ----
    {
      // штабель коробок (сдвинут вправо: при проезде камеры он уезжал за край)
      const bx=w*0.205, byy=h*0.912;
      [[0,0,0.090,0.066],[0.005,-0.067,0.082,0.060],[0.014,-0.127,0.070,0.053]].forEach((b,i)=>{
        const cx2=bx+w*b[0], cy2=byy+h*b[1], cw2=w*b[2], ch2=h*b[3];
        ctx.fillStyle=i===1?'#241c14':'#1e1811';ctx.fillRect(cx2,cy2-ch2,cw2,ch2);
        ctx.fillStyle='rgba(60,48,32,.55)';ctx.fillRect(cx2,cy2-ch2,cw2,h*0.006);
        ctx.fillStyle='rgba(0,0,0,.35)';ctx.fillRect(cx2+cw2*0.46,cy2-ch2,cw2*0.05,ch2);
        ctx.fillStyle='rgba(214,202,170,.22)';ctx.fillRect(cx2+cw2*0.12,cy2-ch2*0.62,cw2*0.42,h*0.008);
      });
      // складной стул под лампой (увеличен: раньше читался как тонкая палочка)
      const sx3=w*0.455, sy3=h*0.930, ss=h*0.185;
      ctx.strokeStyle='#2a363d';ctx.lineWidth=Math.max(3,h*0.0075);
      ctx.beginPath();
      ctx.moveTo(sx3,sy3);ctx.lineTo(sx3+ss*0.20,sy3-ss*0.46);
      ctx.moveTo(sx3+ss*0.52,sy3);ctx.lineTo(sx3+ss*0.32,sy3-ss*0.46);
      ctx.moveTo(sx3+ss*0.20,sy3-ss*0.46);ctx.lineTo(sx3+ss*0.12,sy3-ss*0.94);
      ctx.moveTo(sx3+ss*0.44,sy3-ss*0.46);ctx.lineTo(sx3+ss*0.38,sy3-ss*0.90);
      ctx.stroke();
      ctx.fillStyle='#2b3a42';ctx.fillRect(sx3+ss*0.10,sy3-ss*0.52,ss*0.50,h*0.012);
      ctx.fillStyle='#22303a';ctx.fillRect(sx3+ss*0.08,sy3-ss*0.98,ss*0.34,ss*0.42);
      ctx.fillStyle='rgba(0,0,0,.40)';
      ctx.beginPath();ctx.ellipse(sx3+ss*0.28,sy3+h*0.004,ss*0.40,h*0.010,0,0,Math.PI*2);ctx.fill();
      // ведро и швабра справа на переднем плане
      const kx3=w*0.885, ky3=h*0.945;
      ctx.fillStyle='#26333b';ctx.beginPath();
      ctx.moveTo(kx3,ky3);ctx.lineTo(kx3+w*0.052,ky3);ctx.lineTo(kx3+w*0.044,ky3-h*0.062);
      ctx.lineTo(kx3+w*0.008,ky3-h*0.062);ctx.closePath();ctx.fill();
      ctx.fillStyle='#33434c';ctx.fillRect(kx3+w*0.006,ky3-h*0.066,w*0.040,h*0.008);
      ctx.strokeStyle='#3c4c56';ctx.lineWidth=Math.max(2,h*0.0042);
      ctx.beginPath();ctx.moveTo(kx3+w*0.008,ky3-h*0.062);
      ctx.quadraticCurveTo(kx3+w*0.026,ky3-h*0.104,kx3+w*0.044,ky3-h*0.062);ctx.stroke();
      ctx.strokeStyle='#3a3226';ctx.lineWidth=Math.max(3,h*0.006);
      ctx.beginPath();ctx.moveTo(kx3+w*0.038,ky3-h*0.040);ctx.lineTo(kx3+w*0.072,ky3-h*0.225);ctx.stroke();
      // поддон с архивными коробами в центре — середина пола больше не пустая
      {
        const pxx=w*0.615, pyy=h*0.955;
        ctx.fillStyle='#231c14';ctx.fillRect(pxx,pyy-h*0.016,w*0.155,h*0.016);
        for(let i=0;i<5;i++){ctx.fillStyle='#2c231a';ctx.fillRect(pxx+i*w*0.032,pyy-h*0.022,w*0.024,h*0.008);}
        ctx.fillStyle='#1e1811';ctx.fillRect(pxx+w*0.014,pyy-h*0.070,w*0.062,h*0.050);
        ctx.fillStyle='rgba(60,48,32,.55)';ctx.fillRect(pxx+w*0.014,pyy-h*0.070,w*0.062,h*0.006);
        ctx.fillStyle='#241c14';ctx.fillRect(pxx+w*0.084,pyy-h*0.060,w*0.056,h*0.040);
        ctx.fillStyle='rgba(214,202,170,.20)';ctx.fillRect(pxx+w*0.022,pyy-h*0.050,w*0.040,h*0.008);
      }
      // старый телевизор с выбитым экраном на полу
      {
        const vx2=w*0.345, vy2=h*0.945;
        ctx.fillStyle='#161d22';ctx.fillRect(vx2,vy2-h*0.075,w*0.078,h*0.075);
        ctx.fillStyle='#0a0f13';ctx.fillRect(vx2+w*0.008,vy2-h*0.066,w*0.052,h*0.048);
        ctx.fillStyle='rgba(120,150,165,.10)';ctx.fillRect(vx2+w*0.008,vy2-h*0.066,w*0.052,h*0.012);
        ctx.fillStyle='#202a30';ctx.fillRect(vx2+w*0.064,vy2-h*0.060,w*0.010,h*0.010);
        ctx.fillStyle='rgba(0,0,0,.40)';
        ctx.beginPath();ctx.ellipse(vx2+w*0.039,vy2+h*0.004,w*0.048,h*0.010,0,0,Math.PI*2);ctx.fill();
      }
      // стопка папок прямо на полу
      for(let i=0;i<6;i++){
        ctx.fillStyle=['#2a3a44','#38302a','#243039','#3a3630','#2f2a24','#33404a'][i];
        ctx.fillRect(w*0.775+i*1.8,h*0.938-i*h*0.010,w*0.062,h*0.011);
      }
    }

    // ---- ШКАФ С ЯЩИКАМИ, К КОТОРОМУ ОН ИДЁТ ----
    const kx=w*0.655,ky=h*0.335,kw=w*0.145,kh=h*0.385;
    ctx.fillStyle='#101a21';ctx.fillRect(kx,ky,kw,kh);
    ctx.fillStyle='#16232b';ctx.fillRect(kx+2,ky+2,kw-4,kh-4);
    ctx.fillStyle='rgba(0,0,0,.35)';ctx.fillRect(kx+kw,ky+6,w*0.008,kh);
    for(let d=0;d<3;d++){
      const off=(d===1?drawerP*kw*0.32:0);
      ctx.fillStyle='#0b1217';ctx.fillRect(kx+4-off,ky+6+d*kh*0.33,kw-8,kh*0.29);
      ctx.fillStyle='#1e2c35';ctx.fillRect(kx+4-off,ky+6+d*kh*0.33,kw-8,h*0.009);
      ctx.fillStyle='#8f9aa3';ctx.fillRect(kx+kw*0.42-off,ky+6+d*kh*0.33+kh*0.14,kw*0.16,h*0.007);
      // рамка под ярлык на каждом ящике
      ctx.fillStyle='rgba(214,206,180,.20)';ctx.fillRect(kx+kw*0.12-off,ky+10+d*kh*0.33,kw*0.22,h*0.014);
      if(d===1&&drawerP>0.2){ // внутри ящика видны кассеты
        ctx.fillStyle='#05090c';ctx.fillRect(kx+6-off,ky+8+kh*0.33,kw-12,kh*0.24);
        for(let cc=0;cc<5;cc++){ctx.fillStyle=cc===1?'#3a4a54':'#202a31';
          ctx.fillRect(kx+8-off+cc*(kw-16)/5,ky+10+kh*0.33+kh*0.055,(kw-16)/5-2,kh*0.125);}
        // пыль поднимается из открытого ящика
        if(!low)for(let i=0;i<12;i++){
          const dp=cl((t-5.9)/2.2);
          ctx.fillStyle='rgba(200,190,160,'+(0.16*(1-dp)*epiRnd(i*4.3)).toFixed(3)+')';
          ctx.fillRect(kx+10-off+epiRnd(i*2.1)*(kw-20),ky+kh*0.33-dp*h*0.06-epiRnd(i*6.7)*h*0.03,1.6,1.6);
        }
      }
    }
    ctx.fillStyle='rgba(214,206,180,.55)';
    ctx.font='600 '+Math.round(h*0.015)+'px "JetBrains Mono",monospace';
    ctx.fillText('1991—1994',kx+4,ky-8);

    // ---- СЛУЖЕБНЫЙ МОНИТОР НАД ШКАФОМ ----
    const mx=w*0.845,my=h*0.315,mw=w*0.125,mh=h*0.175;
    // полка-кронштейн под монитором
    ctx.fillStyle='#101820';ctx.fillRect(mx-10,my+mh+6,mw+20,h*0.014);
    ctx.fillStyle='#0b1116';ctx.fillRect(mx-6,my-6,mw+12,mh+12);
    ctx.fillStyle='#04080b';ctx.fillRect(mx,my,mw,mh);
    if(crtP>0){
      ctx.save();ctx.globalAlpha=crtP;
      const scr=ctx.createLinearGradient(mx,my,mx,my+mh);
      scr.addColorStop(0,'#123039');scr.addColorStop(1,'#081820');
      ctx.fillStyle=scr;ctx.fillRect(mx,my,mw,mh);
      // помехи
      if(!low)for(let i=0;i<26;i++){
        const ny=my+((i*37+Math.floor(t*90))%mh);
        ctx.fillStyle='rgba(180,230,240,'+(0.03+0.05*epiRnd(i+Math.floor(t*20))).toFixed(3)+')';
        ctx.fillRect(mx,ny,mw,1.2);
      }
      // кадр записи: четыре силуэта в ряд
      ctx.save();ctx.globalAlpha=crtP*0.85;
      for(let s=0;s<4;s++){
        ctx.fillStyle='rgba(6,12,16,.9)';
        ctx.fillRect(mx+mw*(0.10+s*0.21),my+mh*0.56,mw*0.13,mh*0.32);
        ctx.fillStyle='rgba(150,220,235,'+(0.25+0.2*Math.abs(Math.sin(t*1.7+s))).toFixed(3)+')';
        ctx.fillRect(mx+mw*(0.12+s*0.21),my+mh*0.62,mw*0.04,mh*0.025);
      }
      ctx.restore();
      // строки отчёта
      const rows=['ОТЧЁТ 12.1993','СМЕНА НОЧЬ','ПРОПАЛИ: 4','ДЕЛО ЗАКРЫТО'];
      ctx.font='600 '+Math.round(h*0.0112)+'px "JetBrains Mono",monospace';
      for(let r=0;r<rows.length;r++){
        const k=cl((reportP-r*0.22)/0.22);if(k<=0)continue;
        ctx.globalAlpha=crtP*k*0.92;
        ctx.fillStyle=r===2?'#ffd7a0':'#b9e6f0';
        ctx.fillText(rows[r],mx+mw*0.07,my+mh*0.14+r*h*0.0132);
      }
      ctx.globalAlpha=crtP;
      // блик стекла
      ctx.save();ctx.globalCompositeOperation='lighter';
      const gl=ctx.createLinearGradient(mx,my,mx+mw,my+mh);
      gl.addColorStop(0,'rgba(160,220,240,.10)');gl.addColorStop(.5,'rgba(160,220,240,.02)');gl.addColorStop(1,'rgba(160,220,240,0)');
      ctx.fillStyle=gl;ctx.fillRect(mx,my,mw,mh);ctx.restore();
      ctx.restore();
      // свет монитора в комнату
      ctx.save();ctx.globalCompositeOperation='lighter';
      const sg=ctx.createRadialGradient(mx+mw*0.5,my+mh*0.5,4,mx+mw*0.5,my+mh*0.5,w*0.32);
      sg.addColorStop(0,'rgba(120,200,225,'+(0.22*crtP).toFixed(3)+')');
      sg.addColorStop(1,'rgba(90,170,200,0)');
      ctx.fillStyle=sg;ctx.fillRect(0,0,w,h);ctx.restore();
    }

    // ---- ЧЕТВЕРО В ТЕМНОТЕ ЗА ЕГО СПИНОЙ: КАЖДЫЙ ВЕДЁТ СЕБЯ ПО-СВОЕМУ ----
    // V85: раньше все четверо стояли с одинаковым наклоном и одинаково мигали
    // глазами — ряд копий. Теперь у каждого своя манера: MAIN медленно кивает,
    // FELIX подрагивает мелкой дрожью, EXO стоит мёртво и не мигает вовсе,
    // LAV доворачивает голову в сторону человека.
    if(backP>0){
      const crew=[
        {kind:'main', x:0.205,y:0.805,seed:0.0,
         head:0.05+0.055*Math.sin(t*0.55),                 // тяжёлый кивок
         eye:(0.14+0.16*Math.abs(Math.sin(t*0.62)))*backP, fog:0.28},
        {kind:'felix',x:0.325,y:0.792,seed:3.7,
         head:0.02+Math.sin(t*9.4)*0.020+Math.sin(t*17.1)*0.010, // дрожь механики
         eye:(0.10+0.26*Math.pow(Math.abs(Math.sin(t*2.3)),3))*backP, fog:0.22},
        {kind:'exo',  x:0.445,y:0.782,seed:7.4,
         head:0.0,                                         // мёртвая неподвижность
         eye:0.30*backP, fog:0.32},
        {kind:'lav',  x:0.560,y:0.797,seed:11.1,
         head:-0.03-0.05*Math.sin(t*0.28),                 // медленный доворот
         eye:(0.08+0.20*Math.abs(Math.sin(t*0.41)))*backP, fog:0.25}
      ];
      crew.forEach((a2,i)=>{
        const ax=w*a2.x, ay=h*a2.y;
        // контровое свечение за силуэтом: без него фигуры тонули в стеллажах
        ctx.save();ctx.globalCompositeOperation='lighter';
        const rg=ctx.createRadialGradient(ax,ay-h*0.11,4,ax,ay-h*0.11,h*0.17);
        rg.addColorStop(0,'rgba(96,150,175,'+(0.16*backP).toFixed(3)+')');
        rg.addColorStop(1,'rgba(96,150,175,0)');
        ctx.fillStyle=rg;ctx.fillRect(ax-h*0.2,ay-h*0.32,h*0.4,h*0.4);ctx.restore();
        epiAnimatron(ctx,ax,ay,(h*0.272)/(160*1.34),t,{
          kind:a2.kind,seed:a2.seed,face:1,
          dark:0.80-0.06*backP,
          eye:a2.eye,head:a2.head,
          fog:a2.fog,fogColor:'12,20,26',
          shadow:0.30,shadowDir:1,alpha:0.66+0.30*backP
        });
      });
    }

    // ---- ОХРАННИК: идёт -> вскрывает ящик -> смотрит запись -> уходит ----
    let gx,gy,gsc,gpose,gph,glook;
    if(t<5.4){
      const d=w*0.28*walkP;
      gx=w*0.30+d;gy=h*(0.79-0.01*walkP);gsc=0.98;gpose=walkP>0.99?'stand':'walk';
      gph=epiStridePhase(d,0.98,0.52*1.2);glook=0.35;
    }else if(t<21.0){
      gx=w*0.585;gy=h*0.78;gsc=1.00;gpose='stand';gph=0;
      glook=(t<10.6)?0.55:0.72;
    }else{
      const d=w*0.34*exitP;
      gx=w*0.585-d;gy=h*(0.78+0.02*exitP);gsc=1.00+0.06*exitP;gpose=exitP>0.98?'stand':'walk';
      gph=epiStridePhase(d,1.00,0.52*1.25);glook=-0.30;
    }
    // V95: кассета теперь передаётся в самого персонажа как реквизит в кисти,
    // а не рисуется отдельным прямоугольником рядом с фигурой.
    // Поднимает к лицу на 8.4–11.0 с (рассматривает этикетку и сдувает пыль).
    const tapeUp=cl((t-8.4)/0.8)*(1-cl((t-11.0)/1.2))*0.9;
    drawGuardChar(ctx,gx,gy,gsc,{t,pose:gpose,phase:gph,face:t<21.0?1:-1,
      dust:gpose==='walk',stride:1.2,look:glook,seed:1.7,cold:true,
      prop:tapeP>0.02?'tape':null,tapeK:tapeP,tapeUp,tapeBlow:blowP*(1-cl((t-10.0)/0.6)),
      shadowDir:t<21.0?-1:1,shadowLen:1.0,shadowAlpha:0.42,
      rim:{dir:1,col:crtP>0?'150,215,235':'210,225,235',power:0.20+0.28*crtP}});

    // ---- КАССЕТА В РУКЕ ----
    // V95: блок убран — кассету и пыль теперь рисует drawGuardChar в самой кисти
    // (см. prop:'tape' выше). Раньше она висела в воздухе на gx+26 без связи с рукой.

    // ---- ФОНАРЬ НА РЕМНЕ: узкое пятно на полу ----
    ctx.save();ctx.globalCompositeOperation='lighter';
    const fl=ctx.createRadialGradient(gx+18,gy+8,2,gx+18,gy+8,w*0.10);
    fl.addColorStop(0,'rgba(220,232,240,.14)');fl.addColorStop(1,'rgba(200,220,235,0)');
    ctx.fillStyle=fl;ctx.fillRect(gx-w*0.14,gy-h*0.10,w*0.30,h*0.20);ctx.restore();
    ctx.restore();

    // ---- ПЕРЕДНИЙ ПЛАН: труба сверху и колонна слева (параллакс) ----
    // Кадр перестаёт быть «плоской открыткой»: у него появляется передняя
    // граница, и пустые верхний и левый края закрыты силуэтами.
    {
      ctx.save();
      ctx.translate(-w*0.03*walkP-w*0.05*exitP,0);
      const pg2=ctx.createLinearGradient(0,0,0,h*0.075);
      pg2.addColorStop(0,'#070c10');pg2.addColorStop(0.7,'#0c1318');pg2.addColorStop(1,'#03070a');
      ctx.fillStyle=pg2;ctx.fillRect(-w*0.1,0,w*1.2,h*0.062);
      ctx.fillStyle='rgba(0,0,0,.55)';ctx.fillRect(-w*0.1,h*0.062,w*1.2,h*0.010);
      for(let m=0;m<5;m++){ctx.fillStyle='#101820';ctx.fillRect(-w*0.05+m*w*0.27,0,w*0.022,h*0.072);}
      // колонна у левого края
      const cg=ctx.createLinearGradient(-w*0.02,0,w*0.055,0);
      cg.addColorStop(0,'#04080b');cg.addColorStop(0.75,'#0a1015');cg.addColorStop(1,'#020608');
      ctx.fillStyle=cg;ctx.fillRect(-w*0.02,0,w*0.075,h);
      ctx.restore();
    }
  }

  if(outP>0){
    // ======================= ПАРКОВКА: МИГАЛКИ =======================
    ctx.save();ctx.globalAlpha=outP;
    const sky=ctx.createLinearGradient(0,0,0,h);
    sky.addColorStop(0,'#0d1b2a');sky.addColorStop(.42,'#25384a');sky.addColorStop(.58,'#4a5a5e');sky.addColorStop(1,'#141b1e');
    ctx.fillStyle=sky;ctx.fillRect(0,0,w,h);
    // рассветная полоса у горизонта
    const dawn=ctx.createLinearGradient(0,h*0.42,0,h*0.60);
    dawn.addColorStop(0,'rgba(255,190,120,.18)');dawn.addColorStop(1,'rgba(255,190,120,0)');
    ctx.fillStyle=dawn;ctx.fillRect(0,h*0.42,w,h*0.20);
    // V85: деревья и столбы на горизонте — линия неба больше не пустая
    ctx.fillStyle='rgba(10,16,20,.85)';
    for(let i=0;i<16;i++){
      const tx3=w*(0.02+i*0.064), th3=h*(0.055+epiRnd(i*2.7)*0.055);
      ctx.beginPath();ctx.moveTo(tx3,h*0.60);
      ctx.lineTo(tx3+w*0.012,h*0.60-th3);ctx.lineTo(tx3+w*0.026,h*0.60);ctx.closePath();ctx.fill();
    }
    // асфальт
    ctx.fillStyle='#12171a';ctx.fillRect(0,h*0.60,w,h*0.40);
    ctx.strokeStyle='rgba(230,230,210,.16)';ctx.setLineDash([26,22]);ctx.lineWidth=3;
    ctx.beginPath();ctx.moveTo(w*0.14,h);ctx.lineTo(w*0.42,h*0.61);ctx.stroke();ctx.setLineDash([]);
    // разметка парковочных мест
    ctx.strokeStyle='rgba(220,220,200,.09)';ctx.lineWidth=2;
    for(let i=0;i<5;i++){
      ctx.beginPath();ctx.moveTo(w*(0.46+i*0.13),h*0.70);ctx.lineTo(w*(0.42+i*0.155),h*0.99);ctx.stroke();
    }
    // здание пиццерии слева, тёмное, с мёртвой вывеской
    ctx.fillStyle='#0e1316';ctx.fillRect(-w*0.02,h*0.28,w*0.42,h*0.34);
    ctx.fillStyle='#161d21';ctx.fillRect(w*0.02,h*0.35,w*0.34,h*0.26);
    ctx.fillStyle='#0a0e11';ctx.fillRect(w*0.14,h*0.44,w*0.075,h*0.18);
    // V97: щит вывески был вдвое шире набора (0.28w против 0.10w у букв), и
    // текст висел в его середине с пустыми полями по краям. Щит подогнан под
    // набор и получил рамку.
    ctx.fillStyle='#2a211a';ctx.fillRect(w*0.115,h*0.238,w*0.150,h*0.058);
    ctx.strokeStyle='rgba(120,96,70,.45)';ctx.lineWidth=1;
    ctx.strokeRect(w*0.115,h*0.238,w*0.150,h*0.058);
    {
      // буквы вывески: половина не горит, одна мерцает
      // V97: буквы стояли с шагом 0.052w при собственной ширине около 0.016w —
      // между ними были огромные провалы, и вывеска читалась как «P I Z Z A»,
      // набранная вразрядку. Стало: шаг 0.030w, набор выровнен по центру
      // вывески, у горящих букв появилась своя лампочная подсветка.
      const letters=['P','I','Z','Z','A'], on=[1,0,1,1,1];
      ctx.font='700 '+Math.round(h*0.040)+'px "Oswald",Impact,sans-serif';
      const step=w*0.0245, x0=w*0.19-step*(letters.length-1)*0.5;
      ctx.textAlign='center';
      for(let i=0;i<letters.length;i++){
        const fk=(i===3?(Math.sin(t*11.0)>0.2?1:0.22):1);
        const lx3=x0+i*step;
        if(on[i]){
          ctx.save();ctx.globalCompositeOperation='lighter';
          const lg2=ctx.createRadialGradient(lx3,h*0.268,1,lx3,h*0.268,w*0.026);
          lg2.addColorStop(0,'rgba(255,168,96,'+(0.16*fk).toFixed(3)+')');
          lg2.addColorStop(1,'rgba(255,168,96,0)');
          ctx.fillStyle=lg2;ctx.fillRect(lx3-w*0.03,h*0.23,w*0.06,h*0.08);ctx.restore();
        }
        ctx.fillStyle=on[i]?'rgba(255,178,110,'+(0.72*fk).toFixed(2)+')':'rgba(70,58,46,.55)';
        ctx.fillText(letters[i],lx3,h*0.284);
      }
      ctx.textAlign='left';
      ctx.save();ctx.globalCompositeOperation='lighter';
      const ng=ctx.createRadialGradient(w*0.18,h*0.265,4,w*0.18,h*0.265,w*0.20);
      ng.addColorStop(0,'rgba(255,168,96,.07)');ng.addColorStop(1,'rgba(255,168,96,0)');
      ctx.fillStyle=ng;ctx.fillRect(0,h*0.14,w*0.44,h*0.30);ctx.restore();
    }
    // мусорный бак у стены и сетчатый забор вдоль парковки
    ctx.fillStyle='#151d21';ctx.fillRect(w*0.375,h*0.535,w*0.075,h*0.075);
    ctx.fillStyle='#1d272c';ctx.fillRect(w*0.372,h*0.528,w*0.081,h*0.012);
    {
      ctx.save();ctx.strokeStyle='rgba(150,170,180,.10)';ctx.lineWidth=1;
      for(let i=0;i<40;i++){
        ctx.beginPath();ctx.moveTo(w*(0.50+i*0.014),h*0.50);ctx.lineTo(w*(0.50+i*0.014)+w*0.012,h*0.605);ctx.stroke();
        ctx.beginPath();ctx.moveTo(w*(0.50+i*0.014)+w*0.012,h*0.50);ctx.lineTo(w*(0.50+i*0.014),h*0.605);ctx.stroke();
      }
      ctx.strokeStyle='rgba(170,190,200,.16)';ctx.lineWidth=2;
      ctx.beginPath();ctx.moveTo(w*0.50,h*0.50);ctx.lineTo(w,h*0.50);ctx.stroke();
      for(let i=0;i<5;i++){ctx.fillStyle='#141c20';ctx.fillRect(w*(0.52+i*0.11),h*0.50,w*0.006,h*0.105);}
      ctx.restore();
    }
    // уличный фонарь: конус света режет кадр справа
    {
      const px4=w*0.905;
      ctx.fillStyle='#131a1e';ctx.fillRect(px4,h*0.20,w*0.010,h*0.44);
      ctx.fillStyle='#1a2328';ctx.fillRect(px4-w*0.042,h*0.196,w*0.052,h*0.014);
      ctx.fillStyle='rgba(255,226,170,.75)';ctx.fillRect(px4-w*0.038,h*0.208,w*0.040,h*0.008);
      ctx.save();ctx.globalCompositeOperation='lighter';
      const lg=ctx.createLinearGradient(px4-w*0.02,h*0.21,px4-w*0.02,h*0.78);
      lg.addColorStop(0,'rgba(255,220,160,.16)');lg.addColorStop(1,'rgba(255,220,160,0)');
      ctx.fillStyle=lg;
      ctx.beginPath();ctx.moveTo(px4-w*0.040,h*0.212);ctx.lineTo(px4+w*0.004,h*0.212);
      ctx.lineTo(px4+w*0.10,h*0.80);ctx.lineTo(px4-w*0.17,h*0.80);ctx.closePath();ctx.fill();
      ctx.restore();
    }
    // машина с мигалками справа
    const px=w*0.70,py=h*0.64;
    ctx.fillStyle='#0b0f12';ctx.fillRect(px-w*0.11,py-h*0.10,w*0.24,h*0.10);
    ctx.fillStyle='#141b20';ctx.fillRect(px-w*0.07,py-h*0.145,w*0.14,h*0.05);
    ctx.fillStyle='#243038';ctx.fillRect(px-w*0.055,py-h*0.138,w*0.115,h*0.036);
    ctx.fillStyle='#0a0d10';
    ctx.beginPath();ctx.arc(px-w*0.075,py,h*0.022,0,Math.PI*2);ctx.fill();
    ctx.beginPath();ctx.arc(px+w*0.085,py,h*0.022,0,Math.PI*2);ctx.fill();
    // проблесковый маячок: синий/красный по очереди, свет ложится на асфальт
    const beat=Math.floor(t*3)%2, bcol=beat?'70,140,255':'255,70,80';
    ctx.fillStyle=beat?'#5c93ff':'#ff5560';ctx.fillRect(px-w*0.035,py-h*0.165,w*0.07,h*0.020);
    ctx.save();ctx.globalCompositeOperation='lighter';
    const bg3=ctx.createRadialGradient(px,py-h*0.16,4,px,py-h*0.16,w*0.55);
    bg3.addColorStop(0,'rgba('+bcol+',0.13)');bg3.addColorStop(1,'rgba('+bcol+',0)');
    ctx.fillStyle=bg3;ctx.fillRect(0,0,w,h);
    const road=ctx.createLinearGradient(0,h*0.60,0,h);
    road.addColorStop(0,'rgba('+bcol+',0.05)');road.addColorStop(1,'rgba('+bcol+',0)');
    ctx.fillStyle=road;ctx.fillRect(0,h*0.60,w,h*0.40);ctx.restore();
    // V85: его ждут. Фигура у машины — впервые за пять смен рядом есть живой человек.
    {
      // Силуэт собран заново и увеличен: раньше читался как тёмная клякса
      // без ног рядом с машиной.
      const ox=w*0.800, oy=h*0.790, ou=h*0.0215;
      ctx.save();
      ctx.fillStyle='rgba(0,0,0,.38)';
      ctx.beginPath();ctx.ellipse(ox,oy+ou*0.3,ou*2.4,ou*0.5,0,0,Math.PI*2);ctx.fill();
      ctx.globalAlpha=0.95;
      ctx.fillStyle='#080c10';
      ctx.fillRect(ox-ou*0.75,oy-ou*3.5,ou*0.65,ou*3.5);      // ноги
      ctx.fillRect(ox+ou*0.12,oy-ou*3.5,ou*0.65,ou*3.5);
      ctx.fillRect(ox-ou*1.05,oy-ou*0.35,ou*1.1,ou*0.35);     // ботинки
      ctx.fillRect(ox+ou*0.05,oy-ou*0.35,ou*1.1,ou*0.35);
      ctx.fillStyle='#0b1015';
      ctx.fillRect(ox-ou*1.15,oy-ou*7.4,ou*2.3,ou*4.0);       // корпус в куртке
      ctx.fillRect(ox-ou*1.75,oy-ou*7.1,ou*0.62,ou*3.3);      // руки
      ctx.fillRect(ox+ou*1.13,oy-ou*7.1,ou*0.62,ou*3.3);
      ctx.fillStyle='#0d1318';
      ctx.fillRect(ox-ou*0.52,oy-ou*8.0,ou*1.05,ou*0.7);      // шея
      ctx.fillRect(ox-ou*1.02,oy-ou*9.6,ou*2.05,ou*1.7);      // голова
      ctx.fillStyle='#0a0f14';
      ctx.fillRect(ox-ou*1.20,oy-ou*9.9,ou*2.4,ou*0.42);      // фуражка
      ctx.fillRect(ox-ou*1.35,oy-ou*9.55,ou*1.1,ou*0.22);     // козырёк
      // мигалка обводит его край цветным контровым светом
      ctx.fillStyle='rgba('+bcol+',.34)';
      ctx.fillRect(ox+ou*0.95,oy-ou*9.6,ou*0.20,ou*6.2);
      ctx.fillStyle='rgba(200,222,236,.10)';
      ctx.fillRect(ox-ou*1.15,oy-ou*7.4,ou*0.18,ou*4.0);
      ctx.restore();
    }
    // лужи на асфальте держат отражение мигалки
    ctx.save();ctx.globalCompositeOperation='lighter';
    [[0.30,0.86,0.10],[0.52,0.93,0.13],[0.86,0.82,0.08]].forEach((p,i)=>{
      const pr=ctx.createLinearGradient(0,h*p[1]-h*0.02,0,h*p[1]+h*0.02);
      pr.addColorStop(0,'rgba('+bcol+',.10)');pr.addColorStop(1,'rgba('+bcol+',0)');
      ctx.fillStyle=pr;
      ctx.beginPath();ctx.ellipse(w*p[0],h*p[1],w*p[2]*0.5,h*0.016,0,0,Math.PI*2);ctx.fill();
    });
    ctx.restore();
    // он выходит на парковку с кассетой, спиной к пиццерии
    const outWalk=cl((t-23.6)/3.6);
    // V95: он выходит ЛЕВЕЕ центра. Было: фигура вставала ровно посередине
    // кадра, и карточка концовки ложилась ему прямо на голову — текст шёл по
    // фуражке. Теперь он идёт по левой трети кадра навстречу тому, кто ждёт у машины.
    const gd=w*0.14*outWalk, gsc2=1.06+0.26*outWalk;
    const gx3=w*0.20+gd, gy3=h*(0.74+0.09*outWalk);
    // V95: на парковке кассета тоже в кисти (prop:'tape'). Было: отдельный
    // прямоугольник на gx3+32 — он висел в воздухе в полушаге от фигуры.
    drawGuardChar(ctx,gx3,gy3,gsc2,{t,pose:outWalk<0.94?'walk':'stand',
      phase:epiStridePhase(gd,gsc2),face:1,dust:true,cold:true,
      prop:'tape',tapeK:1,tapeUp:0.15+0.35*cl((t-26.6)/1.2),
      look:outWalk>0.9?0.45:0.25,seed:1.7,shadowDir:-1,shadowLen:1.2,shadowAlpha:0.45,
      rim:{dir:1,col:bcol,power:0.42}});
    // холодный пар от дыхания и морось в свете мигалки
    if(!low){ctx.save();ctx.globalCompositeOperation='lighter';
      for(let i=0;i<50;i++){
        const rx2=(i*151+t*40)%w, ry2=h*(0.30+((i*29)%60)/100);
        ctx.fillStyle='rgba(190,215,235,'+(0.05+0.05*epiRnd(i)).toFixed(3)+')';
        ctx.fillRect(rx2,ry2,1.2,5);
      }
      ctx.restore();}
    ctx.restore();
  }

  if(finalK>0){ctx.save();ctx.globalAlpha=Math.min(1,finalK);ctx.fillStyle='#000';ctx.fillRect(0,0,w,h);ctx.restore();}
  epiGrade(ctx,w,h,t,low,outP>0.5?'rgba(16,26,36,0.10)':'rgba(10,18,24,0.14)',0.42-0.08*outP,1);
  ctx.restore();
  // V85: из надписей остались только две карточки. Всё остальное играет картинкой.
  // V101: вступительного текста в концовках больше нет (см. game.js).
  // V103: НАЗВАНИЕ КОНЦОВКИ И СЧЁТЧИК СМЕРТЕЙ УБРАНЫ.
  // ПОЧЕМУ ТАК БЫЛО: финал заканчивался служебной карточкой «КОНЦОВКА: ...» и
  // строкой «СМЕРТЕЙ: N». Это разрушало сцену: только что был кадр, а сразу
  // после — отчёт. СТАЛО: финал уходит в чёрный без подписей.
  // epiCard(ctx,w,h,t,26.4,3.4,'КОНЦОВКА: ПРАВДА','ЗАПИСЬ ВЫШЛА ИЗ ЗДАНИЯ ВМЕСТЕ С НИМ','#cfeaf4');
  epiBars(ctx,w,h,1);
  epiTimecode(ctx,w,h,'NS-04 · АРХИВ · 05:2'+Math.min(9,Math.floor(t)),0.42);
  epiSkipHint(ctx,w,h,t);

};
