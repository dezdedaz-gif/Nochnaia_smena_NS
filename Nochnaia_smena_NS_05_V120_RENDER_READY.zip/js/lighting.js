window.LightingSystem=(()=>{
 function update(dt,game){
   if(!game.lightFlash) game.lightFlash={side:'',on:false,t:0};
   game.lightFlash.t=Math.max(0,game.lightFlash.t-dt);
   ['left','right'].forEach(side=>{
     const l=game.lights[side];
     // V93: у мёртвой лампы кадр всегда чёрный — мигание её не оживляет.
     if(l.dead){l.renderOff=true;return;}
     if(l.on && l.flicker>0 && Math.random()<dt*6) l.renderOff=!l.renderOff;
     else if(l.flicker<=0) l.renderOff=false;
   });
 }
 function canUse(){return true}
 function toggle(game,side){
   const l=game.lights[side];
   l.on=!l.on;
   l.flicker=l.on?.28:0;
   l.renderOff=false;
   // V111: ТЕНЬ АНИМАТРОННИКА ПОД СВЕТОМ НА 5-Й СМЕНЕ. Лампа загорается, но тень
   // ведёт себя непредсказуемо: либо проступает ярче и чётче (режим 'distinct'),
   // либо вообще не появляется — коридор пуст, будто никого и не было ('none').
   // Решение принимается ОДИН раз за включение лампы, а не каждый кадр.
   if(!game.lightShadow)game.lightShadow={left:null,right:null};
   if(l.on){
     const n=game.night||1;
     if(n>=5){
       game.lightShadow[side]={mode:Math.random()<0.5?'none':'distinct'};
     }else{
       game.lightShadow[side]={mode:'normal'};
     }
   }else{
     game.lightShadow[side]=null;
   }
   // ==== V93: СЛЕПОЙ КОРИДОР ====
   // Было: лампа всегда показывала проём. Стало: с четвёртой смены лампа
   // может не зажечься совсем — питание она жрёт, реле щёлкает, а картинки
   // нет. Понять, стоит ли он там, можно только на слух.
   l.dead=false;
   if(l.on && (game.night||1)>=4 && Math.random()<((game.night>=5)?0.30:0.20)){
     l.dead=true;l.renderOff=true;l.flicker=0;
     try{
       window.MonsterAudio?.relay(true);
       const at=(game.monsters||[]).find(m=>m&&m.room===(side==='left'?6:7));
       // Он там — и теперь его слышно вместо того, чтобы увидеть.
       if(at)window.MonsterAudio?.growl(at.kind,at.room,{dist:0.30,dur:0.9,gain:0.24,wet:0.22});
     }catch(e){}
   }
   AudioFX.play('light',1,{group:'ui'});
   game.lightFlash={side,on:l.on&&!l.dead,t:0.35};
   // Без надписи сверху: состояние лампы видно по свету в проёме.
   return true;
 }
 return {update,canUse,toggle};
})();
