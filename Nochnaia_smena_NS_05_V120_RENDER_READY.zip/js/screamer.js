// ==== СКРИМЕР «СТЁПА» ====
// Вызывается набором номера 79503843858 на служебном телефоне.
//
// V100 — ЧТО ИЗМЕНИЛОСЬ ПРОТИВ V99.
//  1) У ЗВОНКА ПОЯВИЛСЯ ЗВУК. Раньше сцена начиналась сразу с шёпота: игрок
//     набирал номер, и голос возникал из ничего. Теперь это настоящий звонок —
//     шум линии, три гудка (425 Гц, как в городской сети), третий гудок
//     ОБРЫВАЕТСЯ щелчком снятой трубки, и только после этого шёпот. Дальше
//     дыхание вплотную к микрофону, затем линия умирает.
//  2) ТИШИНА ПЕРЕД УДАРОМ СТАЛА ДОЛЬШЕ. Было 0.45 с — глаз даже не успевал
//     заметить, что звук пропал. Стало 3.05 с полной темноты и немоты, с
//     ложным «почти» в середине: тихий стук и силуэт на четверть секунды,
//     после которого снова ничего. Игрок выдыхает — и вот тогда удар.
//  3) УДАР ЖЁСТЧЕ. Крик идёт в полную громкость и слоями (крик + рёв металла
//     + резкий акцент + провал в инфразвук), картинка бьётся сильнее: наезд
//     больше, тряска почти вдвое, три вспышки вместо одной, разрывы спрайта
//     глубже и держатся дольше, вибрация длиннее.
//  4) ПОЯВИЛСЯ ВТОРОЙ УДАР. Когда запись в архиве дочитана, внизу зажигается
//     «ПРОБЕЛ — ПОЛОЖИТЬ ТРУБКУ». Игрок расслабился и тянется к клавише —
//     и получает второй, короткий и другой по цвету скример. Нажатие пробела
//     не висит впустую: оно перематывает сцену ровно к этому удару.
//
// Почему отдельный файл: скример рисуется ПОВЕРХ любого состояния игры и не
// должен зависеть от порядка отрисовки меню, ночи или концовок.
window.Screamer=(()=>{
 // --- тайминги, секунды ---
 const T_RING1  = 0.05;  // первый гудок
 const T_RING2  = 1.45;  // второй гудок
 const T_RING3  = 2.85;  // третий гудок — будет оборван
 const T_PICK   = 3.32;  // трубку сняли: щелчок, гудок обрывается
 const T_VOICE  = 3.60;  // шёпот в трубке (дорожка stepa_call)
 const T_BREATH = 10.85; // дыхание вплотную к микрофону
 const T_HUSH   = 12.30; // линия умирает: полная тишина и темнота
 const T_ALMOST = 13.60; // ложное «почти»: стук и силуэт на миг
 const T_HIT    = 15.35; // УДАР
 const T_HOLD   = 18.10; // фигура начинает уходить в темноту
 const T_AFTER  = 18.85; // закрывающая запись (дорожка stepa_after)
 const T_HIT2   = 29.40; // ВТОРОЙ УДАР
 const T_END    = 32.40; // можно выйти
 const DUR      = T_END;

 // Реплики: [начало, длительность, текст]. Метки сняты с самих дорожек
 // assets/sfx/stepa_call.mp3 и stepa_after.mp3 (по энергии сигнала) и
 // сдвинуты на момент запуска дорожки, поэтому субтитр стоит ровно на голосе.
 const SUBS=[
  [T_VOICE+0.25,0.95,'Алло. Стёпа?'],
  [T_VOICE+1.65,2.05,'Я знаю, что ты слушаешь.'],
  [T_VOICE+4.10,2.95,'Скажи мне: кто из нас двоих ещё жив—'],
  [T_AFTER+0.25,4.75,'По этому номеру никого нет с двухтысячного.'],
  [T_AFTER+5.65,4.35,'Мы не исчезаем. Мы просто перестаём отвечать.']
 ];

 let st=null;

 function isActive(){return !!st}
 function progress(){return st?st.t:0}

 const S=(k,v)=>{try{window.AudioFX?.synth?.(k,v)}catch(e){}};
 const P=(n,v,g)=>{try{window.AudioFX?.play?.(n,v,{group:g||'phone'})}catch(e){}};
 const X=n=>{try{window.AudioFX?.stopSound?.(n)}catch(e){}};
 const VIB=p=>{try{navigator.vibrate?.(p)}catch(e){}};

 function trigger(game,number){
  if(st)return;
  st={t:0,num:number||'79503843858',seed:Math.random()*100,done:{},skip:false};
  // Останавливаем всё, что может забить дорожку звонка.
  try{window.VoiceLines?.stop?.()}catch(e){}
  try{speechSynthesis?.cancel?.()}catch(e){}
  return true;
 }

 function stop(){
  st=null;
  ['stepa_call','stepa_after','stepa_scream','phone_line','phone_whisper','metal_bellow'].forEach(X);
  try{window.AudioFX?.bedStop?.()}catch(e){}
 }

 // Пробел/тап. До удара пропустить нельзя — иначе скример не сработает.
 // Между первым и вторым ударом пробел НЕ выходит из сцены, а перематывает
 // её к второму удару: клавиша живая, но делает не то, чего ждут.
 function skip(){
  if(!st)return false;
  if(st.t<T_HIT+2.0)return true;                       // ввод съеден
  if(st.t<T_HIT2-0.45){st.t=T_HIT2-0.45;return true}   // прыжок к второму удару
  if(st.t>=T_HIT2+1.5){stop();return true}
  return true;
 }

 // Событие срабатывает один раз за прогон.
 function once(key,at,fn){if(!st.done[key]&&st.t>=at){st.done[key]=true;fn()}}

 function update(dt){
  if(!st)return;
  st.t+=dt;
  // --- звонок ---
  once('line', T_RING1-0.05,()=>P('phone_line',0.42));
  once('r1',   T_RING1,()=>S('ringback',0.95));
  once('r2',   T_RING2,()=>S('ringback',0.95));
  once('r3',   T_RING3,()=>S('ringback',0.95));
  once('pick', T_PICK,()=>{
   // трубку сняли: гудок обрывается щелчком реле, линия становится «живой»
   X('phone_line');S('switch',0.9);S('breath',0.35);
  });
  once('voice',T_VOICE,()=>P('stepa_call',1.0));
  once('breath',T_BREATH,()=>{P('phone_whisper',0.85);S('breath',0.55)});
  // --- тишина: под неё подкладывается почти неслышимый гул пустого помещения,
  //     чтобы пауза давила, а не выглядела выключенным звуком ---
  once('hush', T_HUSH,()=>{
   X('stepa_call');X('phone_whisper');
   try{window.AudioFX?.bedStart?.('hollow',0.45)}catch(e){}
  });
  once('almost',T_ALMOST,()=>{S('bone',0.30);S('drip',0.18)});
  // --- удар ---
  once('hit',T_HIT,()=>{
   X('stepa_call');
   try{window.AudioFX?.bedStop?.()}catch(e){}   // гул обрывается вместе с ударом
   P('stepa_scream',1.0,'monster');
   P('metal_bellow',0.80,'monster');
   S('stab',1.0);S('subDrop',0.95);
   try{window.MonsterAudio?.bang?.(0.9)}catch(e){}
   VIB([140,50,220,40,120]);
  });
  once('hitTail',T_HIT+0.60,()=>S('rumble',0.70));
  once('after',T_AFTER,()=>P('stepa_after',1.0));
  // --- второй удар: другой по цвету, короче и ближе ---
  once('hit2',T_HIT2,()=>{
   X('stepa_after');
   P('stepa_scream',0.95,'monster');
   S('stab',1.0);S('grab',0.85);S('ribcrack',0.60);S('subDrop',0.80);
   VIB([200,60,260]);
  });
  once('hit2Tail',T_HIT2+0.85,()=>S('rumble',0.55));
  if(st.t>=DUR+1.2)stop();
 }

 const cl=(v,a,b)=>v<a?a:(v>b?b:v);
 function rnd(i){const n=Math.sin(i*127.1+(st?st.seed:0)*311.7)*43758.5453;return n-Math.floor(n)}

 // ------- служебная типографика: размеры считаются от высоты кадра, поэтому
 // ------- на телефоне в ландшафте текст не наезжает и не уходит за край.
 function subFont(H){return '600 '+Math.round(cl(H*0.038,11,22))+'px "Inter",Arial,sans-serif'}

 function drawSubs(c,W,H,t){
  let line=null,lt=0,dur=0;
  for(const s of SUBS)if(t>=s[0]&&t<s[0]+s[1]){line=s[2];lt=t-s[0];dur=s[1]}
  if(!line)return;
  c.save();
  c.font=subFont(H);c.textAlign='center';c.textBaseline='alphabetic';
  const maxW=W*0.82,words=line.split(' ');const rows=[];let cur='';
  for(const w of words){const tr=cur?cur+' '+w:w;
   if(c.measureText(tr).width>maxW&&cur){rows.push(cur);cur=w}else cur=tr}
  if(cur)rows.push(cur);
  const lh=Math.round(cl(H*0.050,15,28));
  const y0=H-Math.round(cl(H*0.075,16,44))-(rows.length-1)*lh;
  // Субтитр проявляется и гаснет, а не возникает рывком — так спокойнее
  // и текст успевает прочитаться.
  c.globalAlpha=cl(lt/0.28,0,1)*cl((dur-lt)/0.30,0,1);
  c.fillStyle='rgba(0,0,0,.55)';
  const bw=Math.min(maxW+24,W*0.94);
  c.fillRect((W-bw)/2,y0-lh+Math.round(lh*0.28),bw,rows.length*lh+Math.round(lh*0.35));
  c.fillStyle='#ded4c2';
  rows.forEach((r,i)=>c.fillText(r,W/2,y0+i*lh));
  c.restore();
 }

 // Амбровая полоска телефонной линии сверху.
 function drawLineBar(c,W,H,t,text,level){
  const bh=Math.round(cl(H*0.085,22,46)),bw=Math.min(W*0.90,Math.max(280,W*0.62));
  const bx=(W-bw)/2,by=Math.round(cl(H*0.055,10,34));
  c.save();
  c.fillStyle='rgba(8,10,8,.92)';c.fillRect(bx,by,bw,bh);
  c.strokeStyle='rgba(120,80,26,.75)';c.lineWidth=1;c.strokeRect(bx+.5,by+.5,bw-1,bh-1);
  c.fillStyle='rgba(0,0,0,.22)';for(let y=by+3;y<by+bh-3;y+=3)c.fillRect(bx+3,y,bw-6,1);
  c.font='700 '+Math.round(cl(H*0.032,9,16))+'px "JetBrains Mono",monospace';
  c.fillStyle='#ffb44a';c.textAlign='left';c.textBaseline='middle';
  c.fillText(text,bx+10,by+bh*0.36);
  const gx=bx+10,gy=by+bh*0.66,gw=bw-20,gh=Math.max(2,Math.round(bh*0.13));
  c.fillStyle='rgba(255,180,74,.16)';c.fillRect(gx,gy,gw,gh);
  const seg=Math.max(2,Math.round(gw/48));
  for(let i=0;i*seg*1.6<gw;i++){
   const p=i*seg*1.6/gw;
   const v=level*(0.55+0.45*Math.sin(t*7.3+i*0.9))*(1-p*0.25);
   if(p<v){c.fillStyle=p>0.78?'rgba(220,80,60,.9)':'rgba(255,180,74,.75)';c.fillRect(gx+i*seg*1.6,gy,seg,gh)}
  }
  c.restore();
 }

 // ---------------------------------------------------------------------------
 // АТМОСФЕРА
 // Слои взяты у тархуна (V63/V64): мягкое пятно света за фигурой, косые лучи,
 // мерцание на двух частотах, пыль, виньетка. Ни одного жёсткого края.
 // ---------------------------------------------------------------------------
 function flick(t){
  // два несовпадающих периода дают живое, «ламповое» мерцание
  return 0.86+0.10*Math.sin(t*2.7)+0.06*Math.sin(t*11.3+1.7);
 }

 function drawGlow(c,W,H,t,cx,cy,r,a,col){
  if(a<=0.002)return;
  const g=c.createRadialGradient(cx,cy,0,cx,cy,r);
  g.addColorStop(0,'rgba('+col+','+(a).toFixed(3)+')');
  g.addColorStop(0.45,'rgba('+col+','+(a*0.42).toFixed(3)+')');
  g.addColorStop(1,'rgba('+col+',0)');
  c.fillStyle=g;c.fillRect(0,0,W,H);
 }

 // Косые лучи из проёма за фигурой.
 function drawShafts(c,W,H,t,a){
  if(a<=0.004)return;
  c.save();c.globalCompositeOperation='lighter';
  for(let i=0;i<3;i++){
   const x=W*(0.34+i*0.16), wsp=W*(0.055+i*0.022);
   const g=c.createLinearGradient(x,0,x-W*0.10,H);
   const aa=a*(0.9-i*0.22)*(0.82+0.18*Math.sin(t*(1.6+i*0.7)+i));
   g.addColorStop(0,'rgba(255,178,96,'+aa.toFixed(3)+')');
   g.addColorStop(1,'rgba(255,140,60,0)');
   c.fillStyle=g;
   c.beginPath();
   c.moveTo(x,0);c.lineTo(x+wsp,0);c.lineTo(x+wsp-W*0.10,H);c.lineTo(x-W*0.10,H);
   c.closePath();c.fill();
  }
  c.restore();
 }

 // Пыль в луче: точки медленно всплывают, у каждой свой темп.
 function drawDust(c,W,H,t,a,n){
  if(a<=0.004)return;
  c.save();c.globalCompositeOperation='lighter';
  for(let i=0;i<n;i++){
   const sx=rnd(i*2.3)*W;
   const sp=0.010+rnd(i*5.7)*0.030;
   const y=H*(1.05-((t*sp+rnd(i*9.1))%1)*1.15);
   const x=sx+Math.sin(t*(0.5+rnd(i*3.1))+i)*W*0.012;
   const s=1+Math.round(rnd(i*7.7)*1.6);
   c.fillStyle='rgba(255,206,150,'+(a*(0.25+rnd(i*11.3)*0.75)).toFixed(3)+')';
   c.fillRect(Math.round(x),Math.round(y),s,s);
  }
  c.restore();
 }

 function vignette(c,W,H,k){
  const vg=c.createRadialGradient(W*0.5,H*0.48,Math.min(W,H)*0.20,W*0.5,H*0.5,Math.max(W,H)*0.74);
  vg.addColorStop(0,'rgba(0,0,0,0)');
  vg.addColorStop(0.62,'rgba(0,0,0,'+(k*0.34).toFixed(3)+')');
  vg.addColorStop(1,'rgba(0,0,0,'+k.toFixed(3)+')');
  c.fillStyle=vg;c.fillRect(0,0,W,H);
 }

 // Геометрия фигуры: считается один раз и используется всеми слоями,
 // чтобы свет, обвод и сам спрайт не разъезжались.
 function figure(W,H,zoom,shx,shy){
  const A=window.ScreamerArt;
  // Фигура вписывается в высоту кадра целиком. В первой версии стояло
  // H*1.16 и на телефоне (2.2:1) от кота оставалась одна морда без лап и
  // хвоста — «сохранить всё, что на фото» так не работает.
  const base=H*0.90*zoom;
  const cell=Math.max(1,Math.round(base/A.H));
  const sw=cell*A.W,sh=cell*A.H;
  return {A:A,cell:cell,sw:sw,sh:sh,
          x:Math.round(W/2-sw/2+shx),
          y:Math.round(H*0.52-sh*0.50+shy)};
 }

 // ---------------------------------------------------------------------------
 // ВТОРОЙ УДАР. Отдельная короткая сцена: фигура вплотную, холодный обвод
 // вместо амбрового, кадр рвёт крупными полосами — и сразу в чёрное.
 // ---------------------------------------------------------------------------
 function drawSecond(c,W,H,t){
  const A=window.ScreamerArt;
  const k=t-T_HIT2;
  const punch=Math.exp(-k*2.6);
  const out=cl((k-1.35)/1.05,0,1);          // уход в чёрное
  const gq=Math.floor(k*20);
  c.fillStyle='#030203';c.fillRect(0,0,W,H);
  if(A&&out<1){
   const av=1-out;
   const zoom=1.42+0.20*punch+0.05*k;
   const shx=(rnd(gq*3+31)*2-1)*W*0.040*punch;
   const shy=(rnd(gq*3+53)*2-1)*H*0.040*punch;
   const fg=figure(W,H,zoom,shx,shy);
   const sseed=gq+st.seed+77;
   const sskip=k<0.45?0.20*punch:0;
   const sslice=k<1.1?Math.round(2+6*punch):0;
   // холодный контровой обвод: второй удар должен быть ДРУГИМ на цвет
   const rim=Math.max(1,Math.round(fg.cell*1.5));
   c.globalCompositeOperation='lighter';
   c.globalAlpha=av*(0.13+0.12*punch);
   for(const d of [[-rim,0],[rim,0],[0,-rim],[0,rim]])
    A.draw(c,fg.x+d[0],fg.y+d[1],fg.sw,fg.sh,
           {tint:1,tintCol:[150,206,224],minLum:0.05,skip:sskip,slice:sslice,seed:sseed});
   c.globalCompositeOperation='source-over';
   c.globalAlpha=av;
   A.draw(c,fg.x,fg.y,fg.sw,fg.sh,{
    tint:0.10*punch,tintCol:[226,240,255],
    dark:0.06+0.40*out,tintMin:0.05,
    skip:sskip,slice:sslice,seed:sseed});
   c.globalAlpha=1;
   // вспышка холодная и короче, чем на первом ударе
   const fl=Math.exp(-k*22);
   if(fl>0.01){c.fillStyle='rgba(214,236,246,'+(fl*0.40).toFixed(3)+')';c.fillRect(0,0,W,H)}
   // крупные разрывы кадра
   if(k<1.5){
    const nb=Math.round(7*punch)+2;
    for(let i=0;i<nb;i++){
     const yy=Math.round(rnd(gq*7+i)*H), hh=Math.max(3,Math.round(H*0.014+rnd(gq*9+i)*H*0.042));
     c.globalAlpha=(0.26+0.34*rnd(gq*11+i))*punch;
     c.fillStyle='#000';c.fillRect(0,yy,W,hh);
     c.globalAlpha=(0.16+0.22*rnd(gq*13+i))*punch;
     c.fillStyle='rgba(160,214,232,1)';c.fillRect(0,yy+hh,W,Math.max(1,Math.round(hh*0.16)));
    }
    c.globalAlpha=1;
   }
   c.globalAlpha=av*0.28;c.fillStyle='#000';
   for(let y=0;y<H;y+=Math.max(2,fg.cell))c.fillRect(0,y,W,1);
   c.globalAlpha=1;
   vignette(c,W,H,0.94);
  }
  // после удара — оборванная линия и выход
  const fin=cl((k-1.9)/0.8,0,1);
  if(fin>0){
   c.globalAlpha=fin;
   drawLineBar(c,W,H,t,'ЛИНИЯ '+st.num+' // РАЗОРВАНА',0.0);
   c.font='700 '+Math.round(cl(H*0.040,11,20))+'px "JetBrains Mono",monospace';
   c.textAlign='center';c.textBaseline='middle';
   c.fillStyle='rgba(206,64,56,'+(0.58+0.20*Math.sin(t*2.3)).toFixed(3)+')';
   c.fillText('ГУДКИ.',W/2,H*0.46);
   c.font='600 '+Math.round(cl(H*0.028,9,14))+'px "Inter",Arial,sans-serif';
   c.fillStyle='rgba(140,130,116,'+(0.32+0.22*Math.sin(t*3)).toFixed(3)+')';
   c.textBaseline='top';
   c.fillText('ПРОБЕЛ — ВЫЙТИ',W/2,H*0.56);
   c.globalAlpha=1;
  }
 }

 function draw(c,W,H){
  if(!st)return;
  const t=st.t;
  const A=window.ScreamerArt;
  c.save();

  // ---------- 4. Второй удар ----------
  if(t>=T_HIT2){drawSecond(c,W,H,t);c.restore();return}

  // ---------- 1. Звонок, шёпот, тишина ----------
  if(t<T_HIT){
   // линия умирает за 1.2 с и дальше держится мёртвой до самого удара
   const hush=cl((t-T_HUSH)/1.2,0,1);
   const f=flick(t);
   c.fillStyle='#040203';c.fillRect(0,0,W,H);
   // слабое амбровое свечение от трубки, гаснет в тишине
   drawGlow(c,W,H,t,W*0.5,H*0.46,Math.max(W,H)*0.60,(0.085+0.020*Math.sin(t*2.1))*f*(1-hush),'255,164,72');
   drawShafts(c,W,H,t,0.030*(1-hush));
   drawDust(c,W,H,t,0.16*(1-hush),34);
   // Гудок виден так же, как слышен: на каждом гудке свет в кадре чуть
   // подрагивает — сцена реагирует на звонок, а не просто ждёт.
   if(t<T_PICK){
    for(const rt of [T_RING1,T_RING2,T_RING3]){
     const rk=t-rt;
     if(rk>=0&&rk<0.94){
      const a=Math.sin(Math.PI*cl(rk/0.94,0,1))*0.055;
      drawGlow(c,W,H,t,W*0.5,H*0.44,Math.max(W,H)*0.38,a,'255,186,110');
     }
    }
   }
   // ЛОЖНОЕ «ПОЧТИ»: силуэт появляется на четверть секунды в мёртвой
   // тишине и исчезает. Настоящий удар придёт через 1.7 с — когда игрок
   // уже решил, что это и было всё.
   const ak=t-T_ALMOST;
   if(ak>=0&&ak<0.42&&A){
    const aa=Math.sin(Math.PI*cl(ak/0.42,0,1));
    const jx=(rnd(Math.floor(t*30))*2-1)*W*0.006;
    const fg=figure(W,H,0.88,jx,0);
    c.globalAlpha=0.34*aa;
    A.draw(c,fg.x,fg.y,fg.sw,fg.sh,{dark:0.62,tint:0.24,tintCol:[130,28,22],seed:st.seed+5});
    c.globalAlpha=1;
    drawGlow(c,W,H,t,W*0.5,H*0.44,Math.max(W,H)*0.22,0.045*aa,'255,150,90');
   }
   vignette(c,W,H,0.82+0.10*hush);
   if(t<T_PICK)      drawLineBar(c,W,H,t,'ЛИНИЯ '+st.num+' // ГУДОК',cl(t/1.2,0,1)*0.30);
   else if(hush<0.55)drawLineBar(c,W,H,t,'ЛИНИЯ '+st.num+' // АБОНЕНТ ОТВЕТИЛ',0.62*(1-hush));
   else              drawLineBar(c,W,H,t,'ЛИНИЯ '+st.num+' // НЕТ СИГНАЛА',0.01);
   drawSubs(c,W,H,t);
   c.restore();return;
  }

  // ---------- 2. Удар ----------
  const k=t-T_HIT;                                // время от удара
  const out=cl((t-T_HOLD)/(T_AFTER-T_HOLD),0,1);  // уход в темноту
  const punch=Math.exp(-k*3.0);                   // резкий толчок
  const rage=Math.exp(-k*0.55);                   // ярость спадает
  const f=flick(t);
  const gq=Math.floor(k*20);                      // глитч квантован по 1/20 с

  c.fillStyle='#040203';c.fillRect(0,0,W,H);

  if(out<1&&A){
   const av=1-out;
   // Наезд и тряска: V100 — вдвое сильнее, чем было. Кадр действительно
   // бьёт, а не покачивается.
   const zoom=(1.14+0.16*punch+0.050*k)*(1+0.020*Math.sin(k*5.6)*rage);
   const shx=(rnd(gq*3)*2-1)*W*0.036*punch+Math.sin(k*5.3)*W*0.0055*rage;
   const shy=(rnd(gq*3+7)*2-1)*H*0.036*punch+Math.cos(k*4.1)*H*0.0055*rage;
   const fg=figure(W,H,zoom,shx,shy);

   // (а) тёмная масса: та же фигура, сильно увеличенная и уведённая почти в
   //     чёрное. Заполняет широкий кадр телефона и даёт глубину вместо
   //     плоского красного фона.
   c.globalAlpha=av*0.9;
   A.draw(c,W*0.5-fg.sw*1.55*0.5+shx*0.4,H*0.58-fg.sh*1.55*0.54+shy*0.4,
          fg.sw*1.55,fg.sh*1.55,
          {dark:0.90-0.05*punch,tint:0.22,tintCol:[92,12,14],seed:st.seed+11});
   c.globalAlpha=1;

   // (б) свет ЗА фигурой: мягкое пятно + косые лучи + пыль
   c.globalCompositeOperation='lighter';
   drawGlow(c,W,H,t,W*0.5,H*0.50,Math.max(W,H)*0.52,av*(0.13+0.22*punch)*f,'255,126,52');
   drawGlow(c,W,H,t,W*0.5,H*0.44,Math.max(W,H)*0.24,av*(0.10+0.18*punch)*f,'255,196,120');
   c.globalCompositeOperation='source-over';
   drawShafts(c,W,H,t,av*0.075*f);
   drawDust(c,W,H,t,av*0.34,58);

   // Разрывы самого спрайта считаются ОДИН раз и идут во ВСЕ проходы.
   // Баг первой версии V90: основной проход выбрасывал строки (skip),
   // а контровой обвод под ним рисовался целиком — в пропусках амбровое
   // свечение светило насквозь и по фигуре шли ровные яркие полосы.
   const sseed=gq+st.seed;
   const sskip=k<0.34?0.16*punch:0;              // V100: глубже и дольше
   const sslice=k<1.2?Math.round(1+6*punch):0;

   // (в) контровой обвод: четыре смещённых прохода амбровым в режиме сложения.
   const rim=Math.max(1,Math.round(fg.cell*1.2));
   c.globalCompositeOperation='lighter';
   c.globalAlpha=av*(0.10+0.13*punch)*f;
   for(const d of [[-rim,0],[rim,0],[0,-rim],[0,rim]])
    A.draw(c,fg.x+d[0],fg.y+d[1],fg.sw,fg.sh,
           {tint:1,tintCol:[255,158,66],minLum:0.05,skip:sskip,slice:sslice,seed:sseed});
   // (г) хроматическое расхождение — сильнее и почти на секунду
   if(k<0.90){
    const chr=Math.round(fg.cell*(1.0+3.4*punch));
    c.globalAlpha=av*0.18*punch;
    A.draw(c,fg.x-chr,fg.y,fg.sw,fg.sh,{tint:1,tintCol:[220,26,30],minLum:0.055,skip:sskip,slice:sslice,seed:sseed});
    A.draw(c,fg.x+chr,fg.y,fg.sw,fg.sh,{tint:1,tintCol:[26,44,200],minLum:0.055,skip:sskip,slice:sslice,seed:sseed});
   }
   c.globalCompositeOperation='source-over';

   // (д) сама фигура. Подсветка сдержанная: лицо должно ЧИТАТЬСЯ, а не
   //     уходить в белую кашу (та же ошибка правилась в V88 и V89).
   c.globalAlpha=av;
   A.draw(c,fg.x,fg.y,fg.sw,fg.sh,{
    tint:0.08*punch, tintCol:[255,222,186],
    dark:0.10*(1-rage)+0.34*out,
    tintMin:0.05,
    skip:sskip,
    slice:sslice,
    seed:sseed
   });
   c.globalAlpha=1;

   // (е) вспышки. V100: их три — на самом ударе и два коротких доворота
   //     на 0.18 и 0.34 с. Кадр не «мигнул», а забился.
   let fl=Math.exp(-k*18)*0.46;
   for(const s of [0.18,0.34]){const d=k-s;if(d>=0&&d<0.09)fl=Math.max(fl,(1-d/0.09)*0.24)}
   if(fl>0.01){c.fillStyle='rgba(255,232,206,'+fl.toFixed(3)+')';c.fillRect(0,0,W,H)}

   // (ж) провалы сигнала, квантованные по 1/20 с. Помеха гасит кадр полосами
   //     и подсвечивает их кромку; рвёт изображение параметр slice у спрайта.
   if(k<2.2){
    const nb=Math.round(6*punch)+2;
    for(let i=0;i<nb;i++){
     const yy=Math.round(rnd(gq*7+i)*H), hh=Math.max(2,Math.round(H*0.012+rnd(gq*9+i)*H*0.034));
     c.globalAlpha=(0.24+0.34*rnd(gq*11+i))*punch;
     c.fillStyle='#000';c.fillRect(0,yy,W,hh);
     c.globalAlpha=(0.14+0.20*rnd(gq*13+i))*punch;
     c.fillStyle='rgba(255,158,66,1)';c.fillRect(0,yy+hh,W,Math.max(1,Math.round(hh*0.14)));
    }
    c.globalAlpha=1;
   }

   // (з) пиксельные строки развёртки — шаг по размеру клетки спрайта
   c.globalAlpha=av*0.26;c.fillStyle='#000';
   for(let y=0;y<H;y+=Math.max(2,fg.cell))c.fillRect(0,y,W,1);
   c.globalAlpha=1;

   vignette(c,W,H,0.90+0.04*punch);
  }

  // ---------- 3. Закрывающая запись ----------
  if(t>=T_AFTER){
   const fin=cl((t-T_AFTER)/0.9,0,1);
   // Закрывающая часть больше не чёрный лист с текстом: фигура остаётся
   // едва различимой в темноте, свет дышит — сцена не «выключается» рывком.
   // V100: она уже НЕ гаснет к концу — сцену закрывает второй удар.
   if(A){
    const fg=figure(W,H,0.94+0.02*Math.sin(t*0.7),0,0);
    c.globalAlpha=fin*0.10;
    A.draw(c,fg.x,fg.y,fg.sw,fg.sh,{dark:0.86,tint:0.20,tintCol:[110,22,18],seed:st.seed+9});
    c.globalAlpha=1;
   }
   c.globalCompositeOperation='lighter';
   drawGlow(c,W,H,t,W*0.5,H*0.48,Math.max(W,H)*0.42,fin*0.055*flick(t),'255,120,50');
   c.globalCompositeOperation='source-over';
   drawDust(c,W,H,t,fin*0.18,30);
   vignette(c,W,H,0.86);

   c.globalAlpha=fin;
   drawLineBar(c,W,H,t,'АБОНЕНТ '+st.num+' // ЗАПИСЬ В АРХИВЕ',0.05);
   c.font='700 '+Math.round(cl(H*0.058,14,30))+'px "JetBrains Mono",monospace';
   c.textAlign='center';c.textBaseline='middle';
   c.fillStyle='rgba(198,58,52,'+(0.50+0.22*Math.sin(t*1.9)).toFixed(3)+')';
   c.fillText('СТЁПА',W/2,H*0.40);
   c.font='600 '+Math.round(cl(H*0.030,9,15))+'px "Inter",Arial,sans-serif';
   c.fillStyle='rgba(150,138,120,.82)';
   c.fillText('ЛИНИЯ ОТКЛЮЧЕНА ОТ СЕТИ В 2003 ГОДУ',W/2,H*0.40+Math.round(cl(H*0.055,14,28)));
   c.globalAlpha=1;
   drawSubs(c,W,H,t);
   // Подсказка стоит СРАЗУ ПОД полоской линии: внизу идут субтитры.
   // Она честная по механике (пробел реагирует) и нечестная по смыслу:
   // трубку положить уже нельзя.
   if(t>T_AFTER+1.6){
    c.font='600 '+Math.round(cl(H*0.028,9,14))+'px "Inter",Arial,sans-serif';
    c.fillStyle='rgba(140,130,116,'+(0.32+0.22*Math.sin(t*3)).toFixed(3)+')';
    c.textAlign='center';c.textBaseline='top';
    c.fillText('ПРОБЕЛ — ПОЛОЖИТЬ ТРУБКУ',W/2,Math.round(cl(H*0.055,10,34))+Math.round(cl(H*0.085,22,46))+Math.round(cl(H*0.020,5,12)));
   }
  }
  c.restore();
 }

 // Отладка вёрстки: перевод скримера на нужную секунду без ожидания.
 // Все события до этой секунды помечаются сыгранными, чтобы при прыжке
 // вперёд не срабатывали крик и гудки из уже пройденного отрезка.
 function setTime(v){
  if(!st)return;
  st.t=v;st.done={};
  const marks={line:T_RING1-0.05,r1:T_RING1,r2:T_RING2,r3:T_RING3,pick:T_PICK,voice:T_VOICE,
   breath:T_BREATH,hush:T_HUSH,almost:T_ALMOST,hit:T_HIT,hitTail:T_HIT+0.60,after:T_AFTER,
   hit2:T_HIT2,hit2Tail:T_HIT2+0.85};
  for(const key in marks)if(v>=marks[key])st.done[key]=true;
 }
 return {trigger,update,draw,skip,stop,isActive,progress,setTime,DUR,
         T:{T_RING1,T_PICK,T_VOICE,T_BREATH,T_HUSH,T_ALMOST,T_HIT,T_AFTER,T_HIT2,T_END}};
})();
