// ===========================================================================
// НОЧНАЯ СМЕНА — V100. ВСТУПЛЕНИЕ КОНЦОВОК (общий слой для всех пяти финалов).
//
// ПОЧЕМУ ТАК БЫЛО. Каждая концовка начиналась одинаково и очень бедно: на
// нулевой секунде сцена просто ВКЛЮЧАЛАСЬ целиком, поверх неё сразу выезжала
// титульная карточка, а первый звук приходил только через 1.4–2.5 секунды —
// короткий выдох или щелчок. Ни входа, ни движения, ни нарастания: кадр
// выглядел как открытый в редакторе файл, а не как начало финала.
//
// СТАЛО. Первые пять секунд любой концовки идут через один общий слой:
//   0.00–0.62  чёрный кадр, из середины растёт узкая полоса света (красивый
//              вход: сначала слышен тихий колокол, а видно только линию);
//   0.55–2.30  полоса раскрывается диафрагмой — сцена проявляется из темноты
//              сверху и снизу, кромки мягкие, без единого жёсткого края;
//   0.80–3.10  по кадру медленно идёт световая волна (движение есть даже там,
//              где в сцене ещё никто не пошевелился);
//   0.00–4.90  вверх плывут пылинки, кадр живой;
//   0.20–3.50  под всем этим нарастает тон (тревога) и держится атмосферная
//              подложка комнаты;
//   3.50       ВНЕЗАПНОСТЬ: удар, кадр рвёт помехой, в темноте на один миг
//              появляются глаза — и всё сразу гаснет обратно в тишину;
//   3.50–4.90  виньетка отпускает, зерно спадает, сцена остаётся одна.
//
// Сила удара своя у каждого финала: у «Рассвета» это тень, скользнувшая по
// кадру, у «Ловушки» и «Ещё одного костюма» — полноценный скример-акцент.
// Рисуется ПОВЕРХ сцены и карточки, поэтому титр проявляется вместе с кадром.
// ===========================================================================
window.EndIntro=(()=>{
 const cl=(v,a,b)=>v<(a===undefined?0:a)?(a===undefined?0:a):(v>(b===undefined?1:b)?(b===undefined?1:b):v);
 const eio=x=>x<.5?2*x*x:1-Math.pow(-2*x+2,2)/2;
 const eo =x=>1-Math.pow(1-x,3);
 function rnd(n){const v=Math.sin(n*127.1+Math.floor(n)*0.7913)*43758.5453;return v-Math.floor(v)}

 // --- раскадровка вступления, секунды ---
 const T_OPEN0 = 0.55;   // диафрагма начинает раскрываться
 const T_OPEN1 = 2.30;   // диафрагма раскрыта
 const T_HIT   = 3.50;   // точка внезапности
 const T_END   = 4.90;   // слоя больше нет

 // Палитра и характер удара для каждого финала. bed — ключ атмосферной
 // подложки в AudioFX.bedStart().
 const LOOK={
  calm : {col:'255,206,140', eye:'255,232,196', bed:'dawn',    power:0.42, shadow:true , side:0.16},
  burn : {col:'255,152,72',  eye:'255,168,72',  bed:'ash',     power:0.92, shadow:false, side:0.86},
  dark : {col:'150,210,190', eye:'216,240,232', bed:'hollow',  power:1.00, shadow:false, side:0.14},
  trap : {col:'255,186,118', eye:'255,206,150', bed:'stage',   power:1.00, shadow:false, side:0.87},
  truth: {col:'158,214,228', eye:'206,238,246', bed:'archive', power:0.70, shadow:false, side:0.13}
 };
 function look(v){return LOOK[v]||LOOK.calm}

 // ---------------------------------------------------------------------------
 // ЗВУК. Метки идут через epiCue, поэтому каждая срабатывает один раз за
 // прогон и корректно переигрывается после перезапуска концовки.
 // ---------------------------------------------------------------------------
 function cues(variant,t,epiCue){
  const L=look(variant);
  epiCue(t,0.02,()=>{try{window.AudioFX.bedStart?.(L.bed,1.0)}catch(e){}});
  epiCue(t,0.05,()=>window.AudioFX.synth?.('shimmer',0.85));       // красивый вход
  epiCue(t,0.30,()=>window.AudioFX.synth?.('windHall',0.55));      // зал воздуха
  epiCue(t,0.20,()=>window.AudioFX.synth?.('atmosRise',0.50+0.45*L.power)); // нарастание
  epiCue(t,1.90,()=>window.AudioFX.synth?.('shimmer',0.30));       // второй колокол тише
  epiCue(t,T_HIT,()=>{
    window.AudioFX.synth?.('stab',0.35+0.60*L.power);
    window.AudioFX.synth?.('subDrop',0.30+0.45*L.power);
    if(L.power>0.6){try{navigator.vibrate?.([40,30,70])}catch(e){}}
  });
  epiCue(t,T_HIT+0.42,()=>window.AudioFX.synth?.('heartbeat',0.30+0.30*L.power));
  epiCue(t,T_HIT+1.05,()=>window.AudioFX.synth?.('heartbeat',0.20+0.22*L.power));
 }

 // --- мягкое световое пятно, только сложением ---
 function glow(c,x,y,r,col,a){
  if(a<=0.002)return;
  c.save();c.globalCompositeOperation='lighter';
  const g=c.createRadialGradient(x,y,1,x,y,r);
  g.addColorStop(0,'rgba('+col+','+a.toFixed(3)+')');
  g.addColorStop(0.5,'rgba('+col+','+(a*0.30).toFixed(3)+')');
  g.addColorStop(1,'rgba('+col+',0)');
  c.fillStyle=g;c.fillRect(x-r,y-r,r*2,r*2);c.restore();
 }

 // --- диафрагма: чёрное сверху и снизу, кромки размыты ---
 function aperture(c,w,h,k){
  const half=h*(0.006+0.514*k);                 // полувысота открытого окна
  const cy=h*0.5, top=cy-half, bot=cy+half;
  const soft=Math.max(6,h*0.055*(1-k*0.55));    // мягкость кромки
  c.save();
  c.fillStyle='#000';
  if(top>0)c.fillRect(0,0,w,top);
  if(bot<h)c.fillRect(0,bot,w,h-bot);
  const g1=c.createLinearGradient(0,top,0,top+soft);
  g1.addColorStop(0,'rgba(0,0,0,.96)');g1.addColorStop(1,'rgba(0,0,0,0)');
  c.fillStyle=g1;c.fillRect(0,top,w,soft);
  const g2=c.createLinearGradient(0,bot,0,bot-soft);
  g2.addColorStop(0,'rgba(0,0,0,.96)');g2.addColorStop(1,'rgba(0,0,0,0)');
  c.fillStyle=g2;c.fillRect(0,bot-soft,w,soft);
  c.restore();
  return {top:top,bot:bot};
 }

 // ---------------------------------------------------------------------------
 // ОТРИСОВКА. Вызывается последней в кадре концовки — поверх сцены, карточки
 // и полос. После T_END не делает ничего.
 // ---------------------------------------------------------------------------
 function draw(c,w,h,t,variant,low){
  if(!(t>=0)||t>=T_END)return;
  const L=look(variant);
  const openK=eio(cl((t-T_OPEN0)/(T_OPEN1-T_OPEN0)));   // 0 — закрыто, 1 — открыто
  const k=t-T_HIT;
  const fade=cl((T_END-t)/1.30);                        // слой уходит целиком
  c.save();

  // ---- 1. диафрагма ----
  if(openK<1)aperture(c,w,h,openK);

  // ---- 2. растущая полоса света в середине (первые 1.2 с) ----
  const lineK=cl(t/0.62);
  const lineA=cl((1.20-t)/0.58)*lineK;
  if(lineA>0.004){
   const lw=w*(0.02+0.80*eo(lineK));
   const lh=Math.max(1.2,h*(0.0028+0.0060*(1-openK)));
   const x0=w*0.5-lw*0.5, y0=h*0.5-lh*0.5;
   c.save();c.globalCompositeOperation='lighter';
   const g=c.createLinearGradient(x0,0,x0+lw,0);
   g.addColorStop(0,'rgba('+L.col+',0)');
   g.addColorStop(0.5,'rgba('+L.col+','+(0.85*lineA).toFixed(3)+')');
   g.addColorStop(1,'rgba('+L.col+',0)');
   c.fillStyle=g;c.fillRect(x0,y0,lw,lh);
   c.restore();
   glow(c,w*0.5,h*0.5,Math.max(w,h)*0.30,L.col,0.16*lineA);
  }

  // ---- 3. световая волна: медленно идёт по кадру слева направо ----
  const swK=cl((t-0.80)/2.30);
  if(swK>0&&swK<1){
   const a=0.10*Math.sin(Math.PI*swK)*(0.55+0.45*L.power);
   const bx=-w*0.30+w*1.60*eio(swK), bw=w*0.26;
   c.save();c.globalCompositeOperation='lighter';
   const g=c.createLinearGradient(bx,0,bx+bw,0);
   g.addColorStop(0,'rgba('+L.col+',0)');
   g.addColorStop(0.45,'rgba('+L.col+','+a.toFixed(3)+')');
   g.addColorStop(1,'rgba('+L.col+',0)');
   c.fillStyle=g;c.fillRect(bx,0,bw,h);
   c.restore();
  }

  // ---- 4. пылинки: всплывают снизу вверх, у каждой свой темп ----
  const dustA=cl((T_END-t)/2.6)*0.50;
  if(dustA>0.01){
   const n=low?26:52;
   c.save();c.globalCompositeOperation='lighter';
   for(let i=0;i<n;i++){
    const sp=0.020+rnd(i*5.7)*0.055;
    const y=h*(1.06-((t*sp+rnd(i*9.1))%1)*1.16);
    const x=rnd(i*2.3)*w+Math.sin(t*(0.6+rnd(i*3.1))+i)*w*0.014;
    const s=1+Math.round(rnd(i*7.7)*1.7);
    c.fillStyle='rgba('+L.col+','+(dustA*(0.20+0.80*rnd(i*11.3))).toFixed(3)+')';
    c.fillRect(Math.round(x),Math.round(y),s,s);
   }
   c.restore();
  }

  // ---- 5. ВНЕЗАПНОСТЬ ----
  // Удар живёт очень недолго — как настоящая вспышка: два-три кадра. Первая
  // версия держала засветку 0.4 с, и на тёмных финалах («Пустой офис»,
  // «Правда») весь кадр на треть секунды становился молочно-серым — читалось
  // как ошибка отрисовки, а не как испуг. Теперь вспышка гаснет за 0.07 с,
  // разрыв кадра — за 0.2 с, а момент держит только звук.
  // У «Рассвета» вместо засветки по кадру проходит тень: там нельзя ломать
  // тон сцены, но толчок нужен и ей.
  if(k>=0&&k<0.34){
   const p=Math.exp(-k*13.0);          // помеха
   const fp=Math.exp(-k*34.0);         // вспышка
   const gq=Math.floor(k*30);
   if(L.shadow){
    // тень скользит по кадру и на миг гасит свет
    const sx=w*(-0.2+1.5*cl(k/0.34));
    const g=c.createLinearGradient(sx-w*0.22,0,sx+w*0.22,0);
    g.addColorStop(0,'rgba(0,0,0,0)');
    g.addColorStop(0.5,'rgba(0,0,0,'+(0.52*Math.exp(-k*4)).toFixed(3)+')');
    g.addColorStop(1,'rgba(0,0,0,0)');
    c.fillStyle=g;c.fillRect(0,0,w,h);
   }else{
    // Вспышка красится в цвет самого финала, а не в тёплый белый: на «Пустом
    // офисе» белая засветка выглядела как сбой монитора, а холодная зелёная —
    // как аварийный свет, который на миг мигнул.
    if(fp>0.02){c.fillStyle='rgba('+L.col+','+(0.17*fp).toFixed(3)+')';c.fillRect(0,0,w,h)}
    const nb=Math.round(4*p);
    for(let i=0;i<nb;i++){
     const yy=Math.round(rnd(gq*7+i)*h);
     const hh=Math.max(2,Math.round(h*0.006+rnd(gq*9+i)*h*0.020));
     c.globalAlpha=(0.24+0.34*rnd(gq*11+i))*p;
     c.fillStyle='#000';c.fillRect(0,yy,w,hh);
     c.globalAlpha=(0.16+0.20*rnd(gq*13+i))*p;
     c.fillStyle='rgba('+L.col+',1)';
     c.fillRect(0,yy+hh,w,Math.max(1,Math.round(hh*0.16)));
    }
    c.globalAlpha=1;
   }
   // Глаза в темноте: два бледных овала у края кадра, только на самом ударе.
   // Сторона своя у каждого финала и выбрана по тёмной части кадра. Под
   // глазами сначала гасится собственное пятно тьмы — иначе на светлой
   // поверхности (табличка «STORAGE», дверь на улицу) они читались как две
   // случайные точки, а не как взгляд из темноты.
   if(k<0.20){
    const ea=(1-k/0.20)*0.85*(0.45+0.55*L.power);
    const ex=w*L.side, ey=h*0.335;
    const er=Math.max(1.4,h*0.0056);
    const dg=c.createRadialGradient(ex,ey,er*1.2,ex,ey,er*11);
    dg.addColorStop(0,'rgba(2,3,4,'+(0.80*ea).toFixed(3)+')');
    dg.addColorStop(1,'rgba(2,3,4,0)');
    c.fillStyle=dg;c.fillRect(ex-er*11,ey-er*11,er*22,er*22);
    for(const s of[-1,1]){
     c.fillStyle='rgba('+L.eye+','+ea.toFixed(3)+')';
     c.beginPath();c.ellipse(ex+s*er*2.3,ey,er*1.18,er,0,0,Math.PI*2);c.fill();
     glow(c,ex+s*er*2.3,ey,er*6,L.eye,ea*0.26);
    }
   }
  }

  // ---- 6. виньетка: сильно сжимает кадр на входе и после удара отпускает ----
  const vig=0.46*(1-openK)+0.30*Math.exp(-Math.max(0,k)*2.6)*(k>=0?1:0)+0.10*fade;
  if(vig>0.006){
   const g=c.createRadialGradient(w*0.5,h*0.50,Math.min(w,h)*0.20,w*0.5,h*0.52,Math.max(w,h)*0.78);
   g.addColorStop(0,'rgba(0,0,0,0)');
   g.addColorStop(0.60,'rgba(0,0,0,'+(vig*0.34).toFixed(3)+')');
   g.addColorStop(1,'rgba(0,0,0,'+vig.toFixed(3)+')');
   c.fillStyle=g;c.fillRect(0,0,w,h);
  }

  // ---- 7. зерно плёнки: густое на входе, спадает к концу вступления ----
  if(!low){
   const gk=0.75*fade*(0.45+0.55*(1-openK))+0.5*Math.exp(-Math.max(0,k)*8.0)*(k>=0?1:0);
   const fr=Math.floor(t*24);
   const n=Math.round(150*cl(gk));
   for(let i=0;i<n;i++){
    const gx=rnd(i*3.7+fr)*w, gy=rnd(i*7.3+fr*1.7)*h, a3=rnd(i*11.9+fr*2.3);
    c.fillStyle=a3>0.5?'rgba(255,255,255,'+(0.016+0.026*a3).toFixed(3)+')'
                      :'rgba(0,0,0,'+(0.020+0.038*a3).toFixed(3)+')';
    c.fillRect(gx,gy,1.4,1.4);
   }
  }
  c.restore();
 }

 return {draw,cues,DUR:T_END,HIT:T_HIT,bedOf:v=>look(v).bed};
})();
