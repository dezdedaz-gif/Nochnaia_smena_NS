// ============================================================================
// V91: ЗВУЧАНИЕ АНИМАТРОНИКОВ
// ----------------------------------------------------------------------------
// БЫЛО: аниматроники ходили молча. stepSound() в monster.js был пустым, дальние
// шорохи при переходе отключены, и звук оставался ровно один — «stepAlt/thud»
// в момент, когда EXO встаёт у двери. Из-за этого в смене не было ощущения, что
// по зданию кто-то ходит: игрок узнавал о движении только из текстовой строки.
//
// СТАЛО: собственный звуковой слой в духе ФНАФа, целиком на Web Audio, без
// новых файлов (важно: сборка идёт в Яндекс.Игры, внешних запросов быть не
// должно, а размер архива и так 20 МБ).
//
// Главное, что делает звук «фнафовским»:
//   1) РАССТОЯНИЕ. Всё, что звучит из глубины здания, проходит через фильтр:
//      чем дальше комната, тем сильнее срез верхов и тем больше отправка в
//      эхо. Шаг в коридоре — сухой и близкий, шаг на сцене — глухой и с хвостом.
//   2) ЭХО КОРИДОРА. Три коротких делея с обратной связью через фильтр дают
//      гулкое помещение. Отдельного файла реверба не нужно.
//   3) СЛОИ. Один шаг — это не один звук, а четыре: удар в самом низу, стук
//      корпуса, сухой писк сервопривода и металлический скрип обшивки.
//   4) ХАРАКТЕР. У каждого аниматроника свой набор частот, темп шага и своя
//      «глотка», поэтому МОНСТРА, ФЕЛИКСА, EXO и LAV слышно по отдельности.
//   5) ЖИЗНЬ ЗДАНИЯ. Редкий далёкий металлический удар, звон посуды на складе,
//      механическая шкатулка LAV — фон, который идёт сам, без участия игрока.
//
// ----------------------------------------------------------------------------
// V92: СТРАШНЕЕ И БЛИЖЕ К ФНАФУ
// В V91 была география звука: стало понятно, ГДЕ они. Но страшно не было:
// звуки шли ровным фоном, напряжение не накапливалось, и ни один звук не был
// «грязным». Добавлено шесть приёмов, на которых в ФНАФе держится страх:
//   а) ТИШИНА ПЕРЕД УДАРОМ — hush(): вся картина гаснет на треть секунды,
//      и бег вылетает из пустоты. Громкость не росла — страшнее стало вдвое.
//   б) ГНЕТ — общий уровень опасности 0..1 тянет подгул 32 Гц и звон в ушах.
//   в) СЕРДЦЕ охранника — единственный звук без расстояния: он в голове.
//   г) ДЫХАНИЕ вплотную, СТУК в закрытую дверь, ПОЛЗАНИЕ по вентиляции.
//   д) ШЁПОТ и детский СМЕШОК из комнат, где по камерам никого нет.
//   е) КРИК пересобран на жёстком клиппере с рваным гейтом: грязный и рваный.
// ============================================================================
window.MonsterAudio=(()=>{
 let ctx=null, master=null, revIn=null, built=false, live=0;
 let noise=null;

 // Насколько далеко комната от охранной. 0 — за дверью, 3.4 — дальний угол.
 const DIST={0:0.35,6:1.0,7:1.0,1:2.1,3:2.6,5:2.6,4:3.2,2:3.4};
 // Панорама: склад и коридор А — слева, служебная и коридор Б — справа.
 const PAN ={0:0,6:-0.70,7:0.70,1:0.05,3:-0.55,5:0.55,4:-0.10,2:0.18};

 // ==== ХАРАКТЕР КАЖДОГО АНИМАТРОНИКА ====
 // sub    — частота удара стопы (кто тяжелее, у того ниже)
 // gait   — пауза между шагами
 // servo  — громкость сухого сервопривода (у EXO нет обшивки, поэтому громче всех)
 // creak  — металлический скрип корпуса
 // throat — основной тон «глотки» для рычания и смеха
 // ring   — частота кольцевой модуляции: она превращает тон в механический голос
 const VOICE={
  main :{sub:46, gait:0.52, servo:0.22, creak:0.40, throat:58,  ring:37, hiss:0.10},
  felix:{sub:52, gait:0.44, servo:0.34, creak:0.55, throat:76,  ring:53, hiss:0.16},
  exo  :{sub:62, gait:0.29, servo:0.78, creak:0.30, throat:104, ring:81, hiss:0.06},
  lav  :{sub:56, gait:0.37, servo:0.30, creak:0.34, throat:92,  ring:44, hiss:0.22}
 };
 const V=k=>VOICE[k]||VOICE.main;

 function ac(){
  try{
   // ВАЖНО: свой AudioContext здесь НЕ создаём, если есть общий. В игре уже
   // шесть контекстов (процедурные звуки, эмбиент меню, записка, вентиляция,
   // скример, панорама), а Safari на телефоне больше четырёх отказывается давать
   // вовсе — седьмой мог бы просто не включиться. Подсаживаемся к контексту
   // панорамы: он разбужен на первом же жесте игрока в AudioFX.unlock().
   if(!ctx){try{ctx=window.SpatialAudio?.prime?.()||null}catch(e){ctx=null}}
   const C=window.AudioContext||window.webkitAudioContext; if(!ctx&&!C)return null;
   if(!ctx)ctx=new C();
   if(ctx.state!=='running')ctx.resume().catch(()=>{});
   return ctx;
  }catch(e){return null}
 }
 function nbuf(c){
  if(noise)return noise;
  const b=c.createBuffer(1,Math.floor(c.sampleRate*2.5),c.sampleRate), d=b.getChannelData(0);
  for(let i=0;i<d.length;i++)d[i]=Math.random()*2-1;
  noise=b;return b;
 }
 // Эхо помещения: три делея с обратной связью через срез верхов. Дёшево по
 // процессору и звучит как бетонный коридор, а не как студийный ревер.
 function build(c){
  if(built)return;
  master=c.createGain();master.gain.value=1;master.connect(c.destination);
  revIn=c.createGain();revIn.gain.value=1;
  const wet=c.createGain();wet.gain.value=0.55;wet.connect(master);
  [0.037,0.061,0.089].forEach((t,i)=>{
   const d=c.createDelay(0.5);d.delayTime.value=t;
   const fb=c.createGain();fb.gain.value=0.52-i*0.06;
   const lp=c.createBiquadFilter();lp.type='lowpass';lp.frequency.value=2100-i*300;
   revIn.connect(d);d.connect(lp);lp.connect(fb);fb.connect(d);lp.connect(wet);
  });
  built=true;
 }
 function vol(){
  if(window.AudioFX?.muted)return 0;
  const s=window.SaveSystem?.settings||{};
  return Math.max(0,Math.min(1,s.monster??s.sfx??0.5));
 }
 function on(){const c=ac();if(!c)return null;build(c);return vol()>0?c:null}

 // ==== V92: ТИШИНА ПЕРЕД УДАРОМ ====
 // Главный приём ФНАФа, которого здесь не было: перед броском вся
 // звуковая картина на мгновение гаснет. Ухо успевает подстроиться под
 // тишину, и следующий звук бьёт вдвое сильнее без любого роста громкости.
 function hush(dur,depth){
  const c=on();if(!c||!master)return;
  const n=c.currentTime, g=master.gain, dp=depth??0.10;
  try{g.cancelScheduledValues(n);}catch(e){}
  g.setValueAtTime(Math.max(0.0001,g.value),n);
  g.linearRampToValueAtTime(dp,n+0.05);
  g.setValueAtTime(dp,n+Math.max(0.06,dur));
  g.linearRampToValueAtTime(1,n+Math.max(0.06,dur)+0.09);
 }
 // Жёсткая перегрузка: без неё любой синтез звучит чисто и потому не страшно.
 // Крик в ФНАФе — это именно срезанный по пикам, грязный сигнал.
 function drive(c,amt){
  const ws=c.createWaveShaper(), N=1024, cu=new Float32Array(N), k=amt||5.5;
  for(let i=0;i<N;i++){const x=i/(N-1)*2-1;cu[i]=Math.tanh(x*k);}
  ws.curve=cu;try{ws.oversample='4x'}catch(e){}
  return ws;
 }

 // Точка в пространстве: срез верхов и громкость по расстоянию, панорама,
 // отправка в эхо. Всё, что звучит в игре, идёт только через это.
 function place(c,dist,pan,wetK){
  const d=Math.max(0,dist||0);
  const cut=Math.max(320,7800*Math.exp(-0.62*d));
  const att=1/(1+0.62*Math.pow(d,1.35));
  const lp=c.createBiquadFilter();lp.type='lowpass';lp.frequency.value=cut;
  const p=c.createStereoPanner();p.pan.value=Math.max(-1,Math.min(1,pan||0));
  const g=c.createGain();g.gain.value=att*vol();
  lp.connect(p);p.connect(g);g.connect(master);
  const w=c.createGain();w.gain.value=att*vol()*Math.min(0.85,(wetK??0.35)*(0.25+d*0.30));
  g.connect(w);w.connect(revIn);
  return lp;
 }
 // Короткий шумовой всплеск: удар, скрип, шипение.
 function burst(c,dest,t0,dur,g0,lo,hi,q,rate){
  const s=c.createBufferSource();s.buffer=nbuf(c);s.loop=true;
  if(rate)s.playbackRate.value=rate;
  const f=c.createBiquadFilter();
  if(q){f.type='bandpass';f.frequency.value=lo;f.Q.value=q;}
  else {f.type='lowpass';f.frequency.value=lo;}
  const g=c.createGain();g.gain.setValueAtTime(0.0001,c.currentTime+t0);
  g.gain.exponentialRampToValueAtTime(Math.max(0.0002,g0),c.currentTime+t0+Math.min(0.012,dur*0.3));
  g.gain.exponentialRampToValueAtTime(0.0001,c.currentTime+t0+dur);
  s.connect(f);
  if(hi){const h=c.createBiquadFilter();h.type='highpass';h.frequency.value=hi;f.connect(h);h.connect(g);}
  else f.connect(g);
  g.connect(dest);
  s.start(c.currentTime+t0);s.stop(c.currentTime+t0+dur+0.05);
 }
 // Тон с падением частоты: удар стопы, писк сервопривода, рычание.
 function tone(c,dest,type,f0,f1,t0,dur,g0,g1){
  const o=c.createOscillator();o.type=type;
  const n=c.currentTime;
  o.frequency.setValueAtTime(Math.max(12,f0),n+t0);
  o.frequency.exponentialRampToValueAtTime(Math.max(12,f1),n+t0+dur);
  const g=c.createGain();g.gain.setValueAtTime(0.0001,n+t0);
  g.gain.exponentialRampToValueAtTime(Math.max(0.0002,g0),n+t0+Math.min(0.02,dur*0.25));
  g.gain.exponentialRampToValueAtTime(Math.max(0.0001,g1||0.0001),n+t0+dur);
  o.connect(g);g.connect(dest);o.start(n+t0);o.stop(n+t0+dur+0.03);
  return o;
 }

 // ==== ОДИН ШАГ ====
 // Четыре слоя. Именно поэтому шаг слышно как «железо в темноте», а не как щелчок.
 function foot(c,dest,v,t0,power,heel){
  // (а) удар в самом низу — вес корпуса
  tone(c,dest,'sine',v.sub*2.1,v.sub*0.62,t0,0.20,0.62*power,0.001);
  // (б) стук по бетону
  burst(c,dest,t0,0.075,0.50*power,240,90,0,1);
  // (в) сухой сервопривод: он тянет ногу вверх ПЕРЕД ударом
  if(v.servo>0.02){
   tone(c,dest,'sawtooth',430+v.throat,190,Math.max(0,t0-0.085),0.10,0.16*v.servo*power,0.001);
   burst(c,dest,Math.max(0,t0-0.085),0.10,0.12*v.servo*power,3100,1500,0,1.7);
  }
  // (г) металлический скрип обшивки — у каждого шага чуть своя нота
  if(v.creak>0.05)burst(c,dest,t0+0.03,0.13,0.16*v.creak*power,1700+Math.random()*1400,900,7,1);
  // (д) пневматика: сброс воздуха при переносе веса
  if(v.hiss>0.05&&heel)burst(c,dest,t0+0.06,0.22,0.13*v.hiss*power,2400,700,0,0.9);
 }

 // Серия шагов из комнаты. n шагов, у каждого свой вес — походка не ровная.
 function steps(kind,room,opts={}){
  const c=on();if(!c||live>7)return;
  const v=V(kind), d=opts.dist??DIST[room]??2.2, p=opts.pan??PAN[room]??0;
  const dest=place(c,d,p,opts.wet??0.40);
  const n=opts.count??(2+Math.floor(Math.random()*3));
  let t=0;
  for(let i=0;i<n;i++){
   const w=(i%2?0.86:1.0)*(0.80+Math.random()*0.30)*(opts.power??1);
   foot(c,dest,v,t,w,i%2===0);
   t+=v.gait*(0.86+Math.random()*0.30)*(opts.rate??1);
  }
  live++;setTimeout(()=>{live=Math.max(0,live-1)},(t+0.6)*1000);
 }

 // ==== РЫВОК К ДВЕРИ ====
 // Быстрые шаги с нарастанием и визг сервоприводов на пределе: слышно, что
 // он уже не идёт, а бежит, и понятно, с какой стороны.
 function charge(kind,side,night=1){
  const c=on();if(!c)return;
  // V92: сначала треть секунды провала в тишину, и только потом бег.
  // Бег вылетает из ниоткуда — самый страшный момент всей смены.
  hush(0.30,0.07);
  const v=V(kind), pan=side==='left'?-0.85:0.85;
  const dest=place(c,0.55,pan,0.22);
  const n=5+Math.min(3,Math.floor(night*0.6));
  let t=0;
  for(let i=0;i<n;i++){
   foot(c,dest,v,t,0.55+i*(0.55/n),i%2===0);
   t+=v.gait*0.52*(1-i*0.03);
  }
  tone(c,dest,'sawtooth',v.throat*3.6,v.throat*1.5,0,t*0.9,0.10*(0.4+v.servo),0.001);
  burst(c,dest,0,t*0.9,0.06,1200,300,0,1);
  // V92: бег подпирает всхлип глотки — он рвётся, а не аккуратно подходит.
  growl(kind,0,{dist:0.6,pan:pan*0.8,dur:t*0.8,gain:0.16,pitch:1.35,bend:1.25,wet:0.2});
 }

 // ==== ВСТАЛ У ДВЕРИ ====
 // Тяжёлый последний шаг, лязг корпуса о створку, защёлкивание сервоприводов
 // и один вдох пневматики. Дальше подхватывает присутствие в update().
 function arrive(kind,side){
  const c=on();if(!c)return;
  const v=V(kind), pan=side==='left'?-0.85:0.85;
  const dest=place(c,0.30,pan,0.18);
  foot(c,dest,v,0,1.05,true);
  burst(c,dest,0.05,0.34,0.30,420,120,0,1);           // корпус коснулся створки
  for(let i=0;i<3;i++)burst(c,dest,0.16+i*0.055,0.05,0.20-i*0.05,2600+i*400,1600,9,3.2);
  tone(c,dest,'sawtooth',v.throat*2.2,v.throat*0.9,0.10,0.45,0.10,0.001);
  burst(c,dest,0.38,0.50,0.16*Math.max(0.5,v.hiss*3),1900,600,0,0.85);
 }

 // ==== ОТСТУПИЛ ====
 // Шаги удаляются: каждый следующий тише и глуше, эхо длиннее. Это даёт
 // понять, что он ушёл по-настоящему, а не выключился.
 function retreat(kind,side){
  const c=on();if(!c)return;
  const v=V(kind), pan=side==='left'?-0.72:side==='right'?0.72:0;
  let t=0;
  for(let i=0;i<4;i++){
   // Каждый следующий шаг звучит из точки дальше предыдущей: своя цепочка
   // фильтра и эха, поэтому шаги реально уходят, а не просто тише.
   const dest=place(c,0.5+i*0.8,pan*(1-i*0.15),0.45+i*0.12);
   foot(c,dest,v,t,0.95-i*0.17,i%2===0);
   t+=v.gait*(1.06+i*0.10);
  }
 }

 // ==== ВЫШЕЛ ИЗ УГЛА ====
 // Короткий скрежет обшивки по стене — сигнал, что датчик сейчас его увидит.
 function scrape(kind,room){
  const c=on();if(!c)return;
  const dest=place(c,DIST[room]??1.0,PAN[room]??0,0.45);
  burst(c,dest,0,0.55,0.42,1500+Math.random()*900,700,4,0.55);
  tone(c,dest,'sawtooth',150,96,0,0.55,0.12,0.001);
 }

 // ==== ГОЛОС ГЛОТКИ ====
 // Механическое рычание: два расстроенных тона умножаются на кольцевой
 // модулятор — так тон превращается в железный голос, а не в вой зверя.
 function growl(kind,room,opts={}){
  const c=on();if(!c)return;
  const v=V(kind);
  const dest=place(c,opts.dist??DIST[room]??2.1,opts.pan??PAN[room]??0,opts.wet??0.55);
  const dur=opts.dur??(1.0+Math.random()*0.7);
  const g0=opts.gain??0.30;
  // кольцевая модуляция
  const ringGain=c.createGain();ringGain.gain.value=0;
  const ring=c.createOscillator();ring.type='sine';ring.frequency.value=v.ring*(opts.ringMul??1);
  const rg=c.createGain();rg.gain.value=0.55;
  ring.connect(rg);rg.connect(ringGain.gain);ring.start();ring.stop(c.currentTime+dur+0.1);
  const bias=c.createGain();bias.gain.value=1;                 // чтобы тон не пропадал целиком
  ringGain.connect(bias);bias.connect(dest);
  const env=c.createGain();
  // Кольцевая модуляция съедает почти половину амплитуды, поэтому голос
  // заранее поднят: без этого рычание из соседней комнаты не слышно вовсе.
  env.gain.setValueAtTime(0.0001,c.currentTime);
  env.gain.exponentialRampToValueAtTime(g0*1.85,c.currentTime+dur*0.25);
  env.gain.exponentialRampToValueAtTime(0.0001,c.currentTime+dur);
  env.connect(ringGain);
  [1,1.013].forEach((mul,i)=>{
   const o=c.createOscillator();o.type=i?'square':'sawtooth';
   o.frequency.setValueAtTime(v.throat*mul*(opts.pitch??1),c.currentTime);
   o.frequency.linearRampToValueAtTime(v.throat*mul*(opts.pitch??1)*(opts.bend??0.72),c.currentTime+dur);
   const og=c.createGain();og.gain.value=i?0.35:1;
   const lp=c.createBiquadFilter();lp.type='lowpass';lp.frequency.value=900;lp.Q.value=4;
   o.connect(og);og.connect(lp);lp.connect(env);o.start();o.stop(c.currentTime+dur+0.05);
  });
  // сухое дыхание поверх — оно и делает голос «в костюме»
  burst(c,dest,0,dur,0.09,900,220,0,0.8);
 }

 // ==== МЕХАНИЧЕСКИЙ СМЕХ ====
 // Пять-семь толчков глотки с падающей нотой. Тот самый приём, из-за которого
 // смех аниматроника узнаётся мгновенно.
 function laugh(kind,room){
  const c=on();if(!c)return;
  const v=V(kind);
  const dest=place(c,DIST[room]??2.1,PAN[room]??0,0.60);
  const n=5+Math.floor(Math.random()*3);
  for(let i=0;i<n;i++){
   const t=i*0.135, f=v.throat*(1.35-i*0.09);
   tone(c,dest,'sawtooth',f,f*0.80,t,0.12,0.24-i*0.02,0.001);
   tone(c,dest,'square',f*2.02,f*1.6,t,0.10,0.09,0.001);
   burst(c,dest,t,0.11,0.10,1400,260,0,0.9);
  }
 }

 // ==== ДАЛЬНИЙ МЕТАЛЛИЧЕСКИЙ УДАР ====
 // Фон, из-за которого здание кажется живым: где-то в глубине что-то упало.
 // Звенящие обертоны берутся не из шума, а из трёх расстроенных тонов —
 // поэтому удар звучит как железо, а не как хлопок.
 function bang(){
  const c=on();if(!c)return;
  const room=[1,3,4,5,2][Math.floor(Math.random()*5)];
  const dest=place(c,(DIST[room]??2.6)+0.4,(PAN[room]??0)*0.8,0.85);
  burst(c,dest,0,0.13,0.85,300,80,0,1);
  [193,287.5,431.2].forEach((f,i)=>{
   const d=1.0+i*0.35;
   tone(c,dest,'sine',f*(0.99+Math.random()*0.03),f*0.96,0,d,0.32-i*0.07,0.001);
  });
  tone(c,dest,'sine',68,34,0,0.7,0.42,0.001);
 }

 // ==== ПОСУДА НА СКЛАДЕ ====
 // Он там что-то задевает. Слышно, где он, хотя камеру никто не открывал.
 function clatter(room){
  const c=on();if(!c)return;
  const dest=place(c,DIST[room]??2.6,PAN[room]??0,0.75);
  const n=5+Math.floor(Math.random()*5);
  for(let i=0;i<n;i++){
   const t=Math.random()*0.75, f=900+Math.random()*2600;
   burst(c,dest,t,0.06+Math.random()*0.08,0.42+Math.random()*0.30,f,600,10,1+Math.random());
   tone(c,dest,'triangle',f*0.5,f*0.42,t,0.20,0.18,0.001);
  }
 }

 // ==== ШКАТУЛКА LAV ====
 // Он поёт. Мелодия нарочно расстроена и играет медленнее, чем должна:
 // карусельный мотив в миноре, ноты с быстрым затуханием, лёгкий уход строя.
 // Чем ближе LAV, тем громче и тем меньше эха.
 const SONG=[0,3,7,10,7,3,0,-2,0,3,7,3];
 function song(dist){
  const c=on();if(!c)return;
  const dest=place(c,dist,0.05,0.8);
  const root=523.25;                                  // до пятой октавы
  const drift=0.972+Math.random()*0.020;              // строй уплыл сильнее, чем в V91
  // V92: шкатулка ЗАВОДИТСЯ И САДИТСЯ. Последние ноты идут всё медленнее и
  // всё ниже, будто кончилась пружина. В ФНАФе остановившаяся шкатулка
  // означает смерть, и это ожидание страшнее самой мелодии.
  let t=0;
  SONG.forEach((st,i)=>{
   const slow=1+Math.max(0,i-7)*0.24;                 // с восьмой ноты завод кончается
   const sag=1-Math.max(0,i-7)*0.014;                 // и строй проваливается вниз
   const wob=1+(Math.random()-0.5)*0.010;             // дрожание механизма
   const f=root*Math.pow(2,st/12)*drift*sag*wob;
   // случайная задержка ноты: механизм заедает
   const hitch=Math.random()<0.22?0.10+Math.random()*0.12:0;
   tone(c,dest,'triangle',f,f*0.996,t+hitch,0.46*slow,0.21*(hitch?0.7:1),0.001);
   tone(c,dest,'sine',f*2,f*2,t+hitch,0.14,0.07,0.001);  // «молоточек» шкатулки
   burst(c,dest,t+hitch,0.03,0.05,5200,2600,8,1.6);      // щелчок гребёнки
   t+=0.40*slow;
  });
 }

 // ==== ПРИСУТСТВИЕ ЗА ДВЕРЬЮ ====
 // Пока кто-то стоит у створки, там не тишина: низкий гул приводов, дыхание
 // пневматики и редкие щелчки реле. Слой держится постоянно и плавно уходит,
 // когда аниматроник отступает, — это самая «фнафовская» деталь всей сцены.
 let pres=null;
 // V92: ДЫХАНИЕ ВПЛОТНУЮ. В V91 у двери был только ровный гул с медленным
 // дрожанием — это фон, а не живое существо. Теперь идут отдельные циклы:
 // втягивание воздуха, короткая пауза, тяжёлый выдох. Пауза важнее самого
 // звука: пока её держишь, слышно, что он там и ждёт.
 function breathCycle(c,pan){
  const dest=place(c,0.26,pan,0.16);
  burst(c,dest,0,0.44,0.16,540,170,0,0.55);            // вдох
  tone(c,dest,'sine',72,56,0,0.44,0.05,0.001);
  burst(c,dest,0.60,0.62,0.21,920,240,0,0.50);         // выдох
  tone(c,dest,'sine',58,40,0.60,0.62,0.06,0.001);
  if(Math.random()<0.3)burst(c,dest,0.52,0.09,0.10,1900,800,6,1.2);  // щёлкнула челюсть
 }
 function presence(c){
  if(pres)return pres;
  const g=c.createGain();g.gain.value=0.0001;g.connect(master);
  const pan=c.createStereoPanner();pan.pan.value=0;pan.connect(g);
  const lp=c.createBiquadFilter();lp.type='lowpass';lp.frequency.value=520;lp.connect(pan);
  const hum=c.createOscillator();hum.type='sawtooth';hum.frequency.value=47;
  const hg=c.createGain();hg.gain.value=0.30;hum.connect(hg);hg.connect(lp);hum.start();
  const sub=c.createOscillator();sub.type='sine';sub.frequency.value=23.5;
  const sg=c.createGain();sg.gain.value=0.26;sub.connect(sg);sg.connect(pan);sub.start();
  const n=c.createBufferSource();n.buffer=nbuf(c);n.loop=true;n.playbackRate.value=0.6;
  const bp=c.createBiquadFilter();bp.type='bandpass';bp.frequency.value=330;bp.Q.value=1.1;
  const ng=c.createGain();ng.gain.value=0.22;n.connect(bp);bp.connect(ng);ng.connect(pan);n.start();
  // дыхание: медленный LFO по громкости шума
  const lfo=c.createOscillator();lfo.type='sine';lfo.frequency.value=0.42;
  const lg=c.createGain();lg.gain.value=0.16;lfo.connect(lg);lg.connect(ng.gain);lfo.start();
  pres={g,pan,relay:0,br:1.2};
  return pres;
 }
 function setPresence(level,pan,dt){
  const c=on();
  if(!c){if(pres)try{pres.g.gain.value=0.0001}catch(e){}return;}
  const p=presence(c);
  // 0.16, а не 0.55: это фоновый слой, он не должен быть громче шагов и ударов.
  const tgt=Math.max(0.0001,level*vol()*0.16);
  p.g.gain.setTargetAtTime(tgt,c.currentTime,level>0.01?0.35:0.9);
  p.pan.pan.setTargetAtTime(Math.max(-1,Math.min(1,pan)),c.currentTime,0.4);
  // редкий щелчок реле — он там стоит и переставляет вес
  if(level>0.2){
   p.relay-=dt;
   if(p.relay<=0){
    p.relay=1.6+Math.random()*3.4;
    const dest=place(c,0.3,pan,0.2);
    burst(c,dest,0,0.045,0.16,2400+Math.random()*1200,1500,9,3);
    if(Math.random()<0.35)burst(c,dest,0.08,0.30,0.10,1600,500,0,0.85);
   }
  }
  // V92: дыхание — только когда он реально вплотную
  if(level>0.45){
   p.br-=dt;
   if(p.br<=0){p.br=2.3+Math.random()*1.8;breathCycle(c,pan);}
  }else if(p.br<1)p.br=1.2;
 }

 // ==== V92: СЕРДЦЕ ОХРАННИКА ====
 // Это единственный звук в слое, который НЕ идёт через place(): у него нет
 // ни расстояния, ни эха, ни стороны — он внутри головы. Темп и громкость
 // растут вместе с опасностью, поэтому игрок слышит беду раньше, чем понимает её.
 function beat(c,g0){
  const mk=(t0,g)=>{
   const n=c.currentTime+t0;
   const o=c.createOscillator();o.type='sine';
   o.frequency.setValueAtTime(66,n);
   o.frequency.exponentialRampToValueAtTime(28,n+0.20);
   const gg=c.createGain();
   gg.gain.setValueAtTime(0.0001,n);
   gg.gain.exponentialRampToValueAtTime(Math.max(0.0002,g),n+0.02);
   gg.gain.exponentialRampToValueAtTime(0.0001,n+0.24);
   o.connect(gg);gg.connect(master);o.start(n);o.stop(n+0.3);
  };
  mk(0,g0);mk(0.17,g0*0.60);
 }

 // ==== V92: ГНЕТ ====
 // Непрерывный подгул на 32 Гц, который поднимается тем выше, чем ближе
 // ближайший аниматроник. На самом пределе добавляется тонкий звон 3120 Гц —
 // тот самый «звон в ушах» перед ударом. Сознательно на грани слышимости.
 let dread=null;
 function dreadNodes(c){
  if(dread)return dread;
  const g=c.createGain();g.gain.value=0.0001;g.connect(master);
  const mkOsc=(f,gain)=>{const o=c.createOscillator();o.type='sine';o.frequency.value=f;
   const gg=c.createGain();gg.gain.value=gain;o.connect(gg);gg.connect(g);o.start();return gg;};
  mkOsc(32,0.55);mkOsc(48.3,0.22);
  const n=c.createBufferSource();n.buffer=nbuf(c);n.loop=true;n.playbackRate.value=0.35;
  const bp=c.createBiquadFilter();bp.type='bandpass';bp.frequency.value=170;bp.Q.value=0.8;
  const ng=c.createGain();ng.gain.value=0.30;n.connect(bp);bp.connect(ng);ng.connect(g);n.start();
  const hg=mkOsc(3120,0.0001);
  dread={g,hg};return dread;
 }
 function setDread(level){
  const c=on();
  if(!c){if(dread)try{dread.g.gain.value=0.0001}catch(e){}return;}
  const d=dreadNodes(c);
  d.g.gain.setTargetAtTime(Math.max(0.0001,Math.pow(level,1.6)*vol()*0.13),c.currentTime,0.7);
  d.hg.gain.setTargetAtTime(Math.max(0.0001,Math.max(0,level-0.78)*0.05),c.currentTime,0.5);
 }

 // ==== ВОПЛЬ В МОМЕНТ СМЕРТИ ====
 // Общий скример в audio.js остаётся как удар, а это — голос конкретного
 // аниматроника поверх него: у каждого своя нота и свой скрежет.
 function scream(kind){
  const c=on();if(!c)return;
  const v=V(kind);
  const dest=place(c,0.1,0,0.55);
  // (а) Перегруженная шина. Шесть расстроенных голосов проходят через форманты
  // и жёсткий клиппер: получается грязный металлический вопль, а не чистая нота.
  const ws=drive(c,7.5);
  // (б) Рваный гейт 41 Гц: вопль дробится, как через сорванный динамик.
  const gate=c.createGain();gate.gain.value=0.62;
  const gl=c.createOscillator();gl.type='square';gl.frequency.value=41;
  const gg=c.createGain();gg.gain.value=0.38;gl.connect(gg);gg.connect(gate.gain);
  gl.start();gl.stop(c.currentTime+1.8);
  // Выходной зажим после клиппера: без него замер давал пик 1.08 и три
  // срезанных отсчёта — вопль был громкий, но с цифровым треском.
  const outg=c.createGain();outg.gain.value=0.52;
  ws.connect(gate);gate.connect(outg);outg.connect(dest);
  [1,1.007,0.993,1.49,2.01,2.97].forEach((mul,i)=>{
   const o=c.createOscillator();o.type=i<3?'sawtooth':'square';
   const f=v.throat*3.0*mul;
   o.frequency.setValueAtTime(f*1.14,c.currentTime);
   o.frequency.exponentialRampToValueAtTime(f*0.58,c.currentTime+1.45);
   const g=c.createGain();
   g.gain.setValueAtTime(0.0001,c.currentTime);
   g.gain.exponentialRampToValueAtTime(0.16/(1+i*0.7),c.currentTime+0.045);
   g.gain.exponentialRampToValueAtTime(0.0001,c.currentTime+1.30+i*0.05);
   const bp=c.createBiquadFilter();bp.type='bandpass';bp.frequency.value=[720,1260,2450][i%3];bp.Q.value=1.6;
   o.connect(g);g.connect(bp);bp.connect(ws);o.start();o.stop(c.currentTime+1.75);
  });
  // (в) Взрыв шума в самом начале и длинный хвост шипения.
  burst(c,ws,0,0.30,0.55,5400,900,0,1.5);
  burst(c,dest,0,1.15,0.22,2600,400,0,1.1);
  // (г) Срыв вниз в самом низу — удар в грудь.
  tone(c,dest,'square',v.sub*3.0,v.sub*0.45,0,1.5,0.30,0.001);
  growl(kind,0,{dist:0.1,pan:0,dur:1.5,gain:0.22,pitch:2.6,bend:0.35,ringMul:1.7,wet:0.25});
 }

 // ==== V92: ШЁПОТ ИЗ ГЛУБИНЫ ЗДАНИЯ ====
 // Три форманты на шуме, собранные в слоги. Слышно, что это речь, но слов
 // не разобрать. Самое неприятное — что шёпот идёт и тогда, когда в комнате
 // по камерам никого нет.
 function whisper(room){
  const c=on();if(!c)return;
  const dest=place(c,(DIST[room]??2.6)+0.2,(PAN[room]??0)*0.9,0.95);
  const n=3+Math.floor(Math.random()*3);
  let t=0;
  for(let i=0;i<n;i++){
   const dur=0.16+Math.random()*0.20;
   // Узкая полоса пропускает мало энергии: первый замер дал пик 0.007,
   // то есть шёпота было не слышно вовсе. Отсюда большие числа и Q помягче.
   [[430,3.2],[1180,2.1],[2500,1.0]].forEach(([f,g])=>{
    burst(c,dest,t,dur,g*(0.7+Math.random()*0.6),f*(0.85+Math.random()*0.3),0,3.5,0.9);
   });
   tone(c,dest,'sine',96+Math.random()*40,90,t,dur,0.05,0.001);   // призвук голоса
   t+=dur+0.05+Math.random()*0.14;
  }
 }

 // ==== V92: СМЕШОК В ТЕМНОТЕ ====
 // Не механический смех аниматроника, а тонкий детский — короткий и
 // падающий. В здании нет детей, и именно поэтому это работает.
 function giggle(room){
  const c=on();if(!c)return;
  const dest=place(c,(DIST[room]??2.6)+0.4,(PAN[room]??0)*0.85,1.0);
  const n=4+Math.floor(Math.random()*3);
  for(let i=0;i<n;i++){
   const t=i*0.115, f=770*(1-i*0.06)*(0.94+Math.random()*0.12);
   tone(c,dest,'triangle',f,f*0.70,t,0.09,0.46,0.001);
   tone(c,dest,'sine',f*1.5,f*1.1,t,0.07,0.20,0.001);
   burst(c,dest,t,0.08,0.16,1800,700,3,1.2);
  }
 }

 // ==== V92: ОН СТУЧИТ В ЗАКРЫТУЮ ДВЕРЬ ====
 // Раньше закрытая дверь была абсолютно безопасной и тихой. Теперь по ней
 // бьют изнутри — короткие тяжёлые удары в самом низу, без эха: вплотную.
 function knock(side){
  const c=on();if(!c)return;
  const dest=place(c,0.22,side==='left'?-0.9:0.9,0.22);
  const n=2+Math.floor(Math.random()*2);
  for(let i=0;i<n;i++){
   const t=i*(0.30+Math.random()*0.14);
   burst(c,dest,t,0.10,0.60,300,90,0,1);
   tone(c,dest,'sine',96,50,t,0.30,0.34,0.001);
   tone(c,dest,'triangle',214,180,t,0.22,0.10,0.001);
  }
 }

 // ==== V92: КТО-ТО ПОЛЗЁТ ПО ВЕНТИЛЯЦИИ ====
 // Звук едет в панораме и приближается: каждый следующий шорох считается
 // из точки ближе предыдущей. Слышно, что оно едет к кабине.
 function vent(side){
  const c=on();if(!c)return;
  const dir=side==='left'?-1:1;
  for(let i=0;i<7;i++){
   const k=i/6, t=i*0.30;
   const dest=place(c,1.55-k*1.15,dir*(0.88-k*0.66),0.50-k*0.26);
   burst(c,dest,t,0.26,0.34,900+Math.random()*700,300,3,0.7);   // жесть прогибается
   burst(c,dest,t+0.12,0.18,0.20,2600,1200,6,1.3);              // скрежет по железу
   tone(c,dest,'sine',54,44,t,0.28,0.20,0.001);
  }
 }

 // ==== ФОН СМЕНЫ ====
 // Свои таймеры: далёкий удар, посуда там, где кто-то стоит, голос из
 // темноты и песня LAV. Всё реже, если игрок и так под давлением.
 // ============================================================================
 // V93: ЩИТОК ПИТАНИЯ
 // Главный источник ужаса в ФНАФе — не аниматроник, а счётчик энергии.
 // В игре он был с самого начала, но звуком не озвучивался вовсе: каждое
 // включение было бесплатным на слух. Теперь под полом гудит трансформатор,
 // громкость гула растёт с каждой включённой системой, а на остатке ниже 25%
 // добавляется дребезг: сеть не держит.
 let pwr=null;
 function pwrNodes(c){
  if(pwr)return pwr;
  const g=c.createGain();g.gain.value=0.0001;
  const lp=c.createBiquadFilter();lp.type='lowpass';lp.frequency.value=420;
  // Сетевые 50 Гц и вторая гармоника — узнаваемый гул железа под ногами.
  const o1=c.createOscillator();o1.type='sawtooth';o1.frequency.value=50;
  const o2=c.createOscillator();o2.type='sine';o2.frequency.value=100;
  const g1=c.createGain();g1.gain.value=0.55;const g2=c.createGain();g2.gain.value=0.30;
  o1.connect(g1);g1.connect(lp);o2.connect(g2);g2.connect(lp);
  // Дребезг при садящейся сети: амплитудная модуляция 7 Гц поверх гула.
  const fl=c.createOscillator();fl.type='triangle';fl.frequency.value=7.1;
  const flg=c.createGain();flg.gain.value=0;fl.connect(flg);flg.connect(g.gain);
  lp.connect(g);g.connect(master);
  try{o1.start();o2.start();fl.start();}catch(e){}
  pwr={g,lp,o1,o2,flg,lvl:0};
  return pwr;
 }
 // usage — сколько систем включено (0..5), batt — остаток в процентах.
 function setPower(usage,batt){
  const c=on();if(!c)return;
  const p=pwrNodes(c),t=c.currentTime;
  const lvl=(0.010+Math.min(5,usage||0)*0.019)*vol();
  try{p.g.gain.setTargetAtTime(Math.max(0.0001,lvl),t,0.30);}catch(e){}
  // На остатке ниже 25% гул начинает дрожать и чуть проваливаться по высоте.
  const bad=Math.max(0,1-Math.max(0,Math.min(100,batt===undefined?100:batt))/25);
  try{p.flg.gain.setTargetAtTime(lvl*0.55*bad,t,0.4);}catch(e){}
  try{p.o1.frequency.setTargetAtTime(50-bad*4.5,t,0.6);}catch(e){}
 }
 // Щёлчок реле: каждое действие охранника теперь слышно в щитке, а не только
 // в интерфейсе. Сухой, без эха — щиток в двух шагах от кресла.
 function relay(hard){
  const c=on();if(!c)return;
  const dest=place(c,0.18,-0.28,0.08);
  const g0=hard?0.30:0.20;
  burst(c,dest,0,0.018,g0,2600,1400,0,1.0);
  tone(c,dest,'square',1250,540,0,0.030,g0*0.5,0.0002);
  if(hard){burst(c,dest,0.055,0.022,g0*0.7,1800,900,0,1.0);}
 }
 // ПЛЁНКА СРЫВАЕТСЯ. Запись инструктажа на поздних сменах заикается: шипение,
 // уход скорости и глухой щёлчок обрыва. Один из самых страшных звуков ФНАФа.
 function tape(hard){
  const c=on();if(!c)return;
  const dest=place(c,0.30,0.10,0.12);
  burst(c,dest,0,hard?0.34:0.16,hard?0.20:0.12,5200,900,0,1.0);
  tone(c,dest,'sawtooth',hard?190:240,hard?70:150,0,hard?0.30:0.16,0.055,0.0002);
  burst(c,dest,0.005,0.012,0.16,1500,600,0,1.0);   // щёлчок лентопротяжки
  if(hard)tone(c,dest,'square',52,30,0.24,0.42,0.09,0.0002);
 }
 // ЛОЖНОЕ СОБЫТИЕ. Шаги и стук оттуда, где никого нет. Работает только
 // потому, что редкое: один-два раза за смену. Звук настоящий, источник — нет.
 function fake(room,kind){
  steps(kind||'main',room,{count:2+Math.floor(Math.random()*3)});
  if(Math.random()<0.45)setTimeout(()=>{try{scrape(kind||'main',room)}catch(e){}},520);
 }
 // ЗАТИШЬЕ. Не нарастание, а полная пропажа звука на несколько секунд,
 // пока он стоит у створки. Страшнее любого дыхания: кажется, что он ушёл.
 function lull(sec){hush(Math.max(1.5,sec||4.5),0.02);}
 // ============================================================================
 // V94: ОТКЛЮЧЕНИЕ ПИТАНИЯ — ГЛАВНЫЙ ЗВУК ИГРЫ
 // Было (V93): гул съезжал вниз, четыре щелчка реле и один низкий выдох. Всё
 // занимало две секунды, звучало как выключенный вентилятор и НЕ пугало: не
 // было ни удара по нервам в первый момент, ни того, что остаётся после.
 // Стало — сцена из семи слоёв на восемь секунд:
 //   1. ВДОХ. За мгновение до срыва весь звук проваливается почти в ноль, и
 //      сеть перед смертью коротко ВЫРАСТАЕТ в громкости — щиток тянет
 //      последнее.
 //   2. СРЫВ СЕТИ. 50 Гц уезжает до 6 Гц через грязный тракт с перегрузом:
 //      ровный гул превращается в рваное биение железа.
 //   3. РУБИЛЬНИК. Три тяжёлых удара с металлическим звоном и низким телом —
 //      слышно массу, а не щелчок кнопки.
 //   4. ЛАМПЫ УМИРАЮТ. Писк 9 кГц ссыпается вниз и рвётся вспышками: трубки
 //      гаснут не разом, а дёргаясь.
 //   5. ПРОВАЛ. Сабтон 76 → 16 Гц на три с половиной секунды. Его почти не
 //      слышно — его чувствуешь.
 //   6. ВОЗДУХ УХОДИТ. Вентиляция встаёт: шипение затягивается вниз и глохнет.
 //   7. МЁРТВАЯ КОМНАТА. Дальше — не тишина, а два расстроенных тона 41.0 и
 //      41.7 Гц: биение 0.7 Гц, от которого воздух кажется плотным, и в него
 //      вплывает металлический стон здания и далёкий, почти неслышный вопль.
 // ============================================================================
 function powerDown(){
  const c=on();if(!c)return;
  const p=pwrNodes(c),t=c.currentTime;
  // (1) вдох перед срывом
  hush(2.9,0.05);
  // (2) срыв сети: последний рывок громкости, затем падение в инфразвук
  try{
   p.o1.frequency.cancelScheduledValues(t);p.o1.frequency.setValueAtTime(50,t);
   p.o1.frequency.setValueAtTime(50,t+0.16);
   p.o1.frequency.exponentialRampToValueAtTime(6.2,t+2.35);
   p.g.gain.cancelScheduledValues(t);
   p.g.gain.setValueAtTime(Math.max(0.0004,p.g.gain.value),t);
   p.g.gain.linearRampToValueAtTime(Math.max(0.0008,p.g.gain.value*2.6),t+0.14);
   p.g.gain.exponentialRampToValueAtTime(0.0001,t+2.6);
   p.flg.gain.cancelScheduledValues(t);
   p.flg.gain.setValueAtTime(Math.max(0.0001,p.flg.gain.value),t);
   p.flg.gain.linearRampToValueAtTime(0.030*vol(),t+0.55);   // сеть бьётся
   p.flg.gain.linearRampToValueAtTime(0,t+2.5);
   p.lp.frequency.cancelScheduledValues(t);
   p.lp.frequency.setValueAtTime(420,t);
   p.lp.frequency.exponentialRampToValueAtTime(90,t+2.2);
  }catch(e){}
  const dest=place(c,0.22,-0.20,0.10);
  const wide=place(c,0.55,0.10,0.42);
  // грязный тракт: всё, что идёт через него, срезано по пикам и звучит как
  // железо, а не как синтезатор
  const dirty=drive(c,7.5);dirty.connect(place(c,0.30,-0.08,0.26));
  // (3) рубильник: три удара с разным весом
  [[0.00,1.00],[0.19,0.82],[0.46,0.66]].forEach(([t0,k])=>{
   burst(c,dest,t0,0.034,0.40*k,2400,900,0,1.0);          // сухой щелчок контакта
   burst(c,dirty,t0+0.004,0.16,0.26*k,1300,220,0,0.8);    // тело удара
   tone(c,dest,'square',760,190,t0,0.07,0.17*k,0.0002);
   tone(c,dirty,'sine',96,38,t0+0.006,0.34,0.30*k,0.0002);// масса рубильника
   burst(c,wide,t0+0.03,0.42,0.10*k,3600,1500,4.5,1.0);   // звон по металлу шкафа
  });
  // (4) лампы умирают: писк ссыпается вниз и дёргается вспышками
  tone(c,wide,'square',9200,1250,0.02,1.15,0.028,0.0002);
  tone(c,wide,'sawtooth',15700,4200,0.02,0.75,0.014,0.0002);
  for(let i=0;i<5;i++){
   const t0=0.12+i*0.17+Math.random()*0.05;
   burst(c,wide,t0,0.035,0.13,5200,1800,0,1.0);
   tone(c,wide,'square',2600-i*300,700,t0,0.05,0.05,0.0002);
  }
  // разряд по кабелю: редкие микротреска в первый момент
  for(let i=0;i<7;i++)burst(c,dest,0.03+Math.random()*0.85,0.012+Math.random()*0.02,0.09+Math.random()*0.08,4800,2200,0,1.0);
  // (5) провал: сабтон, который чувствуешь телом
  tone(c,dirty,'sine',76,16,0.06,3.60,0.34,0.0002);
  tone(c,dest,'triangle',52,19,0.30,2.60,0.15,0.0002);
  // (6) воздух уходит: вентиляция встаёт
  burst(c,wide,0.05,1.90,0.16,1200,140,0,0.62);
  burst(c,wide,0.60,1.60,0.09,520,90,0,0.42);
  // (7) мёртвая комната: биение двух расстроенных тонов и стон здания
  tone(c,wide,'sine',41.0,40.6,2.55,5.40,0.075,0.0002);
  tone(c,wide,'sine',41.7,41.4,2.55,5.40,0.070,0.0002);
  tone(c,dirty,'sawtooth',63,47,3.10,3.20,0.055,0.0002);   // металл ведёт
  burst(c,wide,3.30,2.40,0.045,900,240,0,0.30);            // шорох в темноте
  // и в самом конце — вопль так далеко, что его можно принять за помеху
  burst(c,place(c,2.60,0.55,0.85),5.10,1.10,0.085,1500,420,3.0,0.86);
  tone(c,place(c,2.60,0.55,0.85),'sawtooth',420,190,5.14,0.90,0.030,0.0002);
 }
 // V94: ТЕМНОТА ПОСЛЕ ПИТАНИЯ. Четырнадцать секунд в темноте раньше держались
 // только на шкатулке. Теперь у каждой стадии свой звук: он подходит, он рядом,
 // он смотрит. Вызывается из сцены темноты по стадиям 1..3.
 function powerDark(stage){
  const c=on();if(!c)return;
  if(stage===1){
   // шаги в полной темноте: три тяжёлых, каждый ближе, и вдох рядом
   const d=[1.5,1.0,0.55];
   d.forEach((dist,i)=>{
    const dest=place(c,dist,0.35-i*0.12,0.42);
    tone(c,dest,'sine',58,26,i*0.62,0.26,0.34,0.0002);
    burst(c,dest,i*0.62,0.10,0.20,900,180,0,0.8);
   });
   burst(c,place(c,0.42,0.55,0.20),2.10,0.62,0.13,700,190,0,0.55);
  }else if(stage===2){
   // железо тянут по бетону совсем близко
   const dest=place(c,0.34,0.62,0.30);
   burst(c,dest,0,1.30,0.17,2600,700,0,0.34);
   tone(c,dest,'sawtooth',124,74,0,1.30,0.075,0.0002);
   burst(c,dest,1.20,0.09,0.22,3200,900,0,1.0);
  }else{
   // он смотрит: сабтон встаёт и в нём шёпот без слов
   const dirty=drive(c,6.0);dirty.connect(place(c,0.28,0.30,0.22));
   tone(c,dirty,'sine',30,58,0,2.40,0.001,0.30);      // рост, а не затухание
   const dest=place(c,0.30,0.30,0.30);
   for(let i=0;i<6;i++)burst(c,dest,0.20+i*0.24,0.14,0.075,1400,520,2.4,0.9+Math.random()*0.2);
   tone(c,dest,'square',15700,15700,0.60,1.60,0.012,0.0002);
  }
 }
 let tBang=14+Math.random()*20, tClat=9+Math.random()*14, tVoice=26+Math.random()*22, tSong=30+Math.random()*30;
 // V92: новые таймеры и уровень опасности, который тянет сердце и гнет.
 let tWhis=34+Math.random()*40, tGig=48+Math.random()*44, tKnock=6+Math.random()*7, tVent=40+Math.random()*35;
 let danger=0, hbeat=0;
 // V93: таймеры ложного события и затишья у двери.
 let tFake=55+Math.random()*70, fakes=0, doorHold=0, tLull=0;
 function reset(){
  tFake=55+Math.random()*70;fakes=0;doorHold=0;tLull=0;
  if(pwr&&ctx)try{pwr.g.gain.value=0.0001;pwr.flg.gain.value=0;pwr.o1.frequency.value=50;}catch(e){}
  tBang=14+Math.random()*20;tClat=9+Math.random()*14;tVoice=26+Math.random()*22;tSong=30+Math.random()*30;
  tWhis=34+Math.random()*40;tGig=48+Math.random()*44;tKnock=6+Math.random()*7;tVent=40+Math.random()*35;
  danger=0;hbeat=0;
  if(pres&&ctx)try{pres.g.gain.value=0.0001}catch(e){}
  if(dread&&ctx)try{dread.g.gain.value=0.0001;dread.hg.gain.value=0.0001}catch(e){}
 }
 function update(dt,G){
  if(!G||G.state!=='game'||G.screamer?.active){setPresence(0,0,dt);setDread(0);danger=0;return;}
  const night=G.night||1, ms=(G.monsters||[]).filter(Boolean);
  // V93: гул щитка по числу включённых систем и по остатку энергии.
  setPower(G.powerUsage||0,G.battery);
  // присутствие за дверью
  const atDoor=ms.filter(m=>m.room===0);
  if(atDoor.length){
   const side=atDoor[0].doorSide==='left'?-0.85:atDoor[0].doorSide==='right'?0.85:0;
   const lvl=Math.min(1,0.55+atDoor.length*0.25+(atDoor.some(m=>m.state==='preparingAttack')?0.25:0));
   setPresence(lvl,side,dt);
  }else setPresence(0,0,dt);
  const c=on();if(!c)return;

  // ==== V92: ОПАСНОСТЬ КАК ЕДИНЫЙ УРОВЕНЬ ====
  // Раньше каждое событие жило само по себе и напряжение не накапливалось.
  // Теперь есть общий уровень 0..1 по ближайшей угрозе, и он сглаживается
  // плавно: страшно становится постепенно, а не рывком.
  let tgt=0;
  ms.forEach(m=>{tgt=Math.max(tgt,1-Math.min(1,(DIST[m.room]??2.6)/3.4));});
  if(atDoor.length)tgt=Math.max(tgt,0.70+Math.min(0.22,atDoor.length*0.11));
  if(ms.some(m=>m.state==='preparingAttack'))tgt=1;
  danger+=(tgt-danger)*Math.min(1,dt*0.85);
  setDread(danger);
  // сердце: с 0.30 появляется, от 52 до 130 ударов в минуту
  if(danger>0.30){
   hbeat-=dt;
   if(hbeat<=0){hbeat=60/(52+danger*78);beat(c,(0.05+danger*0.12)*vol());}
  }else hbeat=0.2;

  // шёпот из глубины: иногда оттуда, где кто-то есть, иногда из пустой комнаты
  tWhis-=dt;
  if(tWhis<=0){
   tWhis=Math.max(20,42-night*2.4)+Math.random()*34;
   const far=ms.filter(m=>(DIST[m.room]??0)>=2.0);
   const room=(far.length&&Math.random()<0.6)?far[Math.floor(Math.random()*far.length)].room
                                            :[1,2,3,4,5][Math.floor(Math.random()*5)];
   whisper(room);
  }
  // смешок в темноте — только со второй смены, чтобы первая не выдавала всё сразу
  tGig-=dt;
  if(tGig<=0){
   tGig=Math.max(30,60-night*3.5)+Math.random()*40;
   if(night>=2)giggle([1,2,3,4,5][Math.floor(Math.random()*5)]);
  }
  // стук в закрытую дверь: только если он там и створка действительно закрыта
  tKnock-=dt;
  if(tKnock<=0){
   tKnock=5+Math.random()*7;
   const d=G.doors||{};
   const shut=atDoor.filter(m=>(m.doorSide==='left'&&d.left)||(m.doorSide==='right'&&d.right));
   if(shut.length&&Math.random()<0.7)knock(shut[0].doorSide);
  }
  // вентиляция: кто-то едет по железу в сторону кабины
  tVent-=dt;
  if(tVent<=0){
   tVent=Math.max(24,46-night*3.0)+Math.random()*30;
   const inHall=ms.filter(m=>m.room===6||m.room===7);
   if(inHall.length)vent(inHall[0].room===6?'left':'right');
   else if(Math.random()<0.4)vent(Math.random()<0.5?'left':'right');
  }
  // далёкий металлический удар
  tBang-=dt;
  if(tBang<=0){tBang=Math.max(9,26-night*2.2)+Math.random()*22;bang();}
  // посуда там, где кто-то возится: склад и служебная
  tClat-=dt;
  if(tClat<=0){
   tClat=12+Math.random()*20;
   const near=ms.filter(m=>m.room===3||m.room===5);
   if(near.length)clatter(near[Math.floor(Math.random()*near.length)].room);
  }
  // голос из темноты: рычание или смех, но только от того, кого игрок не видит
  tVoice-=dt;
  if(tVoice<=0){
   tVoice=Math.max(14,30-night*2.0)+Math.random()*20;
   const hidden=ms.filter(m=>m.room!==0&&!(G.monitor&&G.cam===m.room));
   if(hidden.length){
    const m=hidden[Math.floor(Math.random()*hidden.length)];
    if((m.kind==='felix'||m.kind==='main')&&Math.random()<0.42)laugh(m.kind,m.room);
    else growl(m.kind,m.room,{gain:0.22+night*0.02});
   }
  }
  // ==== V93: ЛОЖНОЕ СОБЫТИЕ ====
  // Один-два раза за смену шаги идут из комнаты, где гарантированно никого нет.
  // Игрок проверит камеру и увидит пустоту — и перестанет верить глазам.
  // Не чаще двух раз: иначе приём превратится в шум и перестанет работать.
  tFake-=dt;
  if(tFake<=0&&fakes<2&&night>=2){
   tFake=70+Math.random()*80;
   const busy=new Set(ms.map(m=>m.room));
   const empty=[1,2,3,4,5,6,7].filter(r=>!busy.has(r));
   if(empty.length){
    const room=empty[Math.floor(Math.random()*empty.length)];
    fakes++;
    fake(room,['main','felix','exo','lav'][Math.floor(Math.random()*4)]);
    if(G.say&&Math.random()<0.55)G.say('ДВИЖЕНИЕ: '+(window.World?.rooms?.[room]?.name||''),1.2);
   }
  }

  // ==== V93: ОН У ДВЕРИ МОЛЧИТ ====
  // Раньше присутствие только нарастало. Теперь, постояв у створки больше
  // десяти секунд, он иногда замирает полностью на пять секунд. Кажется, что
  // ушёл — и именно поэтому страшно открывать дверь.
  tLull=Math.max(0,tLull-dt);
  if(atDoor.length){
   doorHold+=dt;
   if(doorHold>10&&tLull<=0&&Math.random()<dt*0.14){
    tLull=22+Math.random()*20;
    lull(4.2+Math.random()*1.6);
   }
  }else doorHold=0;

  // песня LAV: тем громче, чем он ближе
  tSong-=dt;
  if(tSong<=0){
   tSong=34+Math.random()*30;
   const lav=ms.find(m=>m.kind==='lav');
   if(lav&&!(G.radio&&G.radio.on))song(Math.max(0.6,(DIST[lav.room]??2.6)*0.8));
  }
 }
 // Игрок открыл камеру и увидел его: помеха в тракте плюс голос вплотную к
 // микрофону камеры. Тот самый эффект «он смотрит в объектив».
 // V93: grit 0..1 — насколько он близко к кабине. Раньше переключение звучало
 // одинаково на любом расстоянии. Теперь чем ближе угроза, тем грязнее тракт:
 // долгая помеха, пробой по строчной развёртке и голос громче.
 function camSeen(kind,room,grit){
  const c=on();if(!c)return;
  const k=Math.max(0,Math.min(1,grit===undefined?0.3:grit));
  const dest=place(c,0.8,PAN[room]??0,0.30);
  burst(c,dest,0,0.30+k*0.45,0.26+k*0.16,4200,1200,0,1.4);
  if(k>0.45){
   // Пробой строчной развёртки: гейт 15 Гц на шуме — картинка рвётся.
   for(let i=0;i<6;i++)burst(c,dest,0.06+i*0.066,0.030,0.10+k*0.14,2600,800,0,1.0);
   tone(c,dest,'square',15700,15700,0,0.34,0.012+k*0.014,0.0002);
  }
  growl(kind,room,{dist:0.9,dur:0.85+k*0.4,gain:0.26+k*0.14,pitch:1.15,wet:0.3});
 }
 function stopAll(){
  setPresence(0,0,0);
  setDread(0);
  reset();
 }
 return {steps,charge,arrive,retreat,scrape,growl,laugh,bang,clatter,song,scream,camSeen,
         whisper,giggle,knock,vent,hush,lull,relay,tape,fake,setPower,powerDown,powerDark,
         update,reset,stopAll};
})();
