// ===========================================================================
// НОЧНАЯ СМЕНА — V101. ВИД ОТ ПЕРВОГО ЛИЦА ЧЕЛОВЕКА (не из костюма).
//
// ПОЧЕМУ ТАК БЫЛО. В игре был только один субъективный кадр — epiPOVMask:
// взгляд ИЗ ГОЛОВЫ ЗАЙЦА, с прорезями, сеткой, ушами и зубами. Для двух новых
// сцен он не годится: в «Пепле» герой падает на траву в своей же одежде, а в
// «Рассвете» он стоит в дверях и его накрывает флэшбэк. Нужен был кадр без
// маски — просто глаза человека.
//
// ЧТО ЗДЕСЬ ЕСТЬ.
//   human()    — субъективный кадр: веки (моргание и провис при потере
//                сознания), тоннельное зрение, кровь на ресницах, пар от
//                дыхания, полосы смаза при беге, руки в нижних углах кадра,
//                трава перед лицом, когда он лежит.
//   flashback()— накат никотинового флэшбэка: зрение сужается, кадр ведёт в
//                сторону, по нему идут белые всполохи и полосы дыма, а по
//                краям всплывает старая привычка — тлеющая точка сигареты.
//   whiteCalm()— спокойный выход в белый свет: не вспышка, а мягкое
//                раскрытие от центра, с тёплым тоном и дрожанием света.
//
// Всё рисуется ПОВЕРХ готовой сцены и ничего не знает про игру, поэтому
// модуль можно вызывать из любой концовки.
// ===========================================================================
window.EndPOV=(()=>{
 const cl=v=>v<0?0:v>1?1:v;
 const eo=x=>1-Math.pow(1-x,3);
 const eio=x=>x<.5?2*x*x:1-Math.pow(-2*x+2,2)/2;
 function rnd(n){const v=Math.sin(n*127.1+Math.floor(n)*0.7913)*43758.5453;return v-Math.floor(v)}

 // Мягкое световое пятно — только сложением, как во всех финалах.
 function glow(c,x,y,r,col,a){
  if(a<=0.002)return;
  c.save();c.globalCompositeOperation='lighter';
  const g=c.createRadialGradient(x,y,1,x,y,r);
  g.addColorStop(0,'rgba('+col+','+a.toFixed(3)+')');
  g.addColorStop(0.5,'rgba('+col+','+(a*0.30).toFixed(3)+')');
  g.addColorStop(1,'rgba('+col+',0)');
  c.fillStyle=g;c.fillRect(x-r,y-r,r*2,r*2);c.restore();
 }

 // ---------------------------------------------------------------------------
 // СУБЪЕКТИВНЫЙ КАДР ЧЕЛОВЕКА.
 // o.blood  0..1 — кровь на ресницах и красный прилив по краям
 // o.tunnel 0..1 — сужение зрения (боль, потеря крови)
 // o.lids   0..1 — веки прикрываются (0 — открыты, 1 — почти закрыты)
 // o.blink        — принудительное моргание 0..1 (1 — глаз закрыт)
 // o.run    0..1 — смаз и подскок кадра от бега
 // o.grass  0..1 — он лежит: перед лицом стебли травы и роса
 // o.hands  0..1 — руки входят в нижние углы кадра
 // o.breath 0..1 — пар от дыхания
 // ---------------------------------------------------------------------------
 function human(c,w,h,t,o){
  o=o||{};
  const blood=cl(o.blood||0), tunnel=cl(o.tunnel||0), run=cl(o.run||0);
  const grass=cl(o.grass||0), hands=cl(o.hands||0), br=cl(o.breath===undefined?0.6:o.breath);
  const low=document.body.classList.contains('low-end');
  // Моргание: автоматическое, но с провисом — чем тяжелее он ранен, тем
  // дольше веки не поднимаются.
  const cyc=(t*0.62)%3.4;
  let blink=(cyc<0.10)?1-Math.abs(cyc-0.05)/0.05:0;
  blink=Math.max(blink,cl(o.blink||0));
  const lids=cl(o.lids||0);
  c.save();
  // ---- полосы смаза от бега: только по краям, центр кадра остаётся резким ----
  if(run>0.02&&!low){
   c.save();c.globalAlpha=0.10+0.16*run;
   for(let i=0;i<18;i++){
    const s=i%2?1:-1, r=rnd(i*3.3+Math.floor(t*20)*0.11);
    const y=h*r, len=w*(0.06+0.20*r)*run;
    c.fillStyle=i%3?'rgba(0,0,0,.55)':'rgba(180,190,200,.16)';
    c.fillRect(s>0?w-len:0,y,len,1+3*r);
   }
   c.restore();
  }
  // ---- тоннельное зрение: чёрные края наступают на кадр ----
  {
   const rIn=w*(0.62-0.34*tunnel), rOut=w*(0.86-0.20*tunnel);
   const g=c.createRadialGradient(w*0.5,h*0.5,rIn,w*0.5,h*0.5,rOut);
   g.addColorStop(0,'rgba(2,3,4,0)');
   g.addColorStop(0.55,'rgba(2,3,4,'+(0.42+0.40*tunnel).toFixed(3)+')');
   g.addColorStop(1,'rgba(2,3,4,'+(0.88+0.12*tunnel).toFixed(3)+')');
   c.fillStyle=g;c.fillRect(0,0,w,h);
  }
  // ---- трава перед лицом: он лежит, и половина кадра — стебли вблизи ----
  if(grass>0.02){
   const gk=grass;
   // нижняя треть: расфокусированная зелёная масса
   const gm=c.createLinearGradient(0,h*(1-0.34*gk),0,h);
   gm.addColorStop(0,'rgba(28,44,24,0)');
   gm.addColorStop(0.45,'rgba(26,44,22,'+(0.55*gk).toFixed(3)+')');
   gm.addColorStop(1,'rgba(12,24,12,'+(0.92*gk).toFixed(3)+')');
   c.fillStyle=gm;c.fillRect(0,h*(1-0.34*gk),w,h*0.34*gk);
   // отдельные стебли, наклонённые ветром; ближние толще и темнее
   // V101: стеблей стало БОЛЬШЕ и они выше: раньше на кадре торчало несколько
   // одиноких палочек и «он лежит в траве» не читалось.
   const N=low?34:96;
   for(let i=0;i<N;i++){
    const r1=rnd(i*2.7), r2=rnd(i*6.1), near=r2>0.62?1:0;
    const bx=w*r1, by=h*(1.0-0.02*r2);
    const len=h*(0.16+0.34*r2)*gk;
    const sw=Math.sin(t*(0.7+r1*0.6)+i)*w*0.012*(0.4+r2);
    c.strokeStyle=near?'rgba(10,22,10,'+(0.86*gk).toFixed(3)+')':'rgba(46,74,38,'+(0.62*gk).toFixed(3)+')';
    c.lineWidth=near?2.6+2.4*r2:1.2+1.4*r1;
    c.beginPath();c.moveTo(bx,by);
    c.quadraticCurveTo(bx+sw*0.6,by-len*0.6,bx+sw,by-len);c.stroke();
    // роса на ближних стеблях — ловит свет пожара
    if(near&&!low&&r1>0.55){
     c.fillStyle='rgba(255,214,168,'+(0.30*gk).toFixed(3)+')';
     c.beginPath();c.arc(bx+sw*0.8,by-len*0.82,1.4+1.2*r2,0,Math.PI*2);c.fill();
    }
   }
   // земля прямо под глазом: тёмное размытое пятно в правом нижнем углу
   c.save();c.globalAlpha=0.55*gk;
   const soil=c.createRadialGradient(w*0.78,h*1.02,w*0.02,w*0.78,h*1.02,w*0.32);
   soil.addColorStop(0,'rgba(24,18,12,.95)');soil.addColorStop(1,'rgba(24,18,12,0)');
   c.fillStyle=soil;c.fillRect(w*0.42,h*0.66,w*0.58,h*0.34);c.restore();
  }
  // ---- руки в нижних углах: он держится за раму двери / за землю ----
  if(hands>0.02){
   const hk=eio(hands), sh=Math.sin(t*1.7)*h*0.006;
   [-1,1].forEach(s=>{
    c.save();
    // V101: руки поднялись выше. На h*1.08 в кадр попадали только концы пальцев,
    // а служебные полосы кадра срезали и их — получались две светлые дощечки
    // в углах. Теперь видно кисть целиком.
    c.translate(w*0.5+s*w*0.34,h*(1.00-0.22*hk)+sh*s);
    c.rotate(s*(0.42-0.10*hk));
    c.fillStyle='rgba(14,17,20,.96)';                       // рукав
    c.fillRect(-w*0.075,0,w*0.15,h*0.30);
    c.fillStyle='rgba(178,138,112,.95)';                    // кисть
    c.beginPath();
    c.moveTo(-w*0.060,0);c.lineTo(w*0.060,0);
    c.lineTo(w*0.048,-h*0.070);c.lineTo(-w*0.052,-h*0.062);
    c.closePath();c.fill();
    for(let f=0;f<4;f++){                                    // пальцы
     const fx=-w*0.046+f*w*0.030;
     c.fillStyle=f%2?'rgba(168,128,104,.95)':'rgba(186,146,118,.95)';
     c.fillRect(fx,-h*(0.070+0.026*rnd(f*3.1)),w*0.024,h*0.040);
    }
    if(blood>0.15){                                          // кровь на костяшках
     c.fillStyle='rgba(128,12,16,'+(0.62*blood).toFixed(3)+')';
     c.fillRect(-w*0.040,-h*0.052,w*0.052,h*0.016);
     c.fillRect(-w*0.010,-h*0.030,w*0.020,h*0.040);
    }
    c.restore();
   });
  }
  // ---- пар от дыхания у нижней кромки ----
  if(br>0.02&&!low){
   const p=0.5+0.5*Math.sin(t*2.2);
   c.save();c.globalAlpha=(0.10+0.14*p)*br;
   const fg=c.createLinearGradient(0,h*0.74,0,h);
   fg.addColorStop(0,'rgba(206,218,226,0)');fg.addColorStop(1,'rgba(206,218,226,.55)');
   c.fillStyle=fg;c.fillRect(0,h*0.74,w,h*0.26);c.restore();
  }
  // ---- кровь: капли на ресницах и красный прилив по краям кадра ----
  if(blood>0.02){
   c.save();
   const rp=c.createRadialGradient(w*0.5,h*0.5,w*0.20,w*0.5,h*0.5,w*0.78);
   rp.addColorStop(0,'rgba(120,10,14,0)');
   rp.addColorStop(1,'rgba(120,10,14,'+(0.34*blood).toFixed(3)+')');
   c.fillStyle=rp;c.fillRect(0,0,w,h);
   // мазки на самом глазу: они не двигаются вместе со сценой — они на нас
   // V101: МАЗКИ, А НЕ БУЛАВКИ. Раньше каждая капля была ровным эллипсом с тонкой
   // вертикальной палочкой под ним — в кадре это выглядело как красные булавки,
   // висящие в воздухе. Теперь это размазанные пятна из трёх смещённых овалов,
   // они сидят по краям кадра (в центр глаз смотрит) и вытянуты вниз по потёку.
   for(let i=0;i<(low?7:16);i++){
    const r1=rnd(i*4.7),r2=rnd(i*9.3),r3=rnd(i*13.1);
    const edge=0.5+0.5*(r1<0.5?-1:1)*(0.42+0.46*r3);        // ближе к кромкам
    const bx=w*edge, by=h*(0.08+0.84*r2);
    const rr=(3.0+15*r3)*Math.min(1,blood*1.5);
    c.save();c.globalAlpha=(0.16+0.30*r2)*blood;
    c.fillStyle='rgb('+(96+Math.floor(52*r3))+',8,12)';
    for(let j=0;j<3;j++){
     const jx=bx+(rnd(i*3.1+j)-0.5)*rr*1.4, jy=by+j*rr*0.55;
     c.beginPath();
     c.ellipse(jx,jy,rr*(1.0-j*0.24),rr*(0.42+0.30*r1)*(1.0-j*0.18),r3*3,0,Math.PI*2);
     c.fill();
    }
    c.restore();
   }
   c.restore();
  }
  // ---- веки: сверху и снизу, с мягкой кромкой и ресницами ----
  {
   const k=Math.max(lids*0.62,blink);
   if(k>0.002){
    const topH=h*(0.06+0.46*k), botH=h*(0.05+0.40*k);
    c.fillStyle='#05070a';
    c.fillRect(0,0,w,topH);c.fillRect(0,h-botH,w,botH);
    const tg=c.createLinearGradient(0,topH,0,topH+h*0.05);
    tg.addColorStop(0,'rgba(5,7,10,.92)');tg.addColorStop(1,'rgba(5,7,10,0)');
    c.fillStyle=tg;c.fillRect(0,topH,w,h*0.05);
    const bg2=c.createLinearGradient(0,h-botH,0,h-botH-h*0.05);
    bg2.addColorStop(0,'rgba(5,7,10,.92)');bg2.addColorStop(1,'rgba(5,7,10,0)');
    c.fillStyle=bg2;c.fillRect(0,h-botH-h*0.05,w,h*0.05);
    if(!low&&k>0.10){                                        // ресницы по кромке
     c.save();c.globalAlpha=0.5*k;c.strokeStyle='#04060a';c.lineWidth=2;
     for(let i=0;i<26;i++){
      const x=w*(i/25), r=rnd(i*7.1);
      c.beginPath();c.moveTo(x,topH);c.lineTo(x+(r-0.5)*10,topH+h*0.016*(0.5+r));c.stroke();
     }
     c.restore();
    }
   }
  }
  c.restore();
 }

 // ---------------------------------------------------------------------------
 // НИКОТИНОВЫЙ ФЛЭШБЭК. k — сила накатa 0..1.
 // Кадр сужается, ведёт влево, по нему идут белые всполохи и полосы дыма,
 // а справа снизу тлеет точка сигареты — то, чем он это когда-то глушил.
 // ---------------------------------------------------------------------------
 function flashback(c,w,h,t,k){
  k=cl(k);if(k<=0.002)return;
  const low=document.body.classList.contains('low-end');
  c.save();
  // тёплый никотиновый тон поверх кадра
  c.globalCompositeOperation='overlay';
  c.fillStyle='rgba(214,168,96,'+(0.30*k).toFixed(3)+')';c.fillRect(0,0,w,h);
  c.globalCompositeOperation='source-over';
  // всполохи: три несинхронных пульса, каждый короче предыдущего
  for(let i=0;i<3;i++){
   const per=1.9-i*0.45, ph=((t+i*0.7)%per)/per;
   const a=Math.pow(1-ph,4.5)*k*(0.30-i*0.07);
   if(a>0.004){c.fillStyle='rgba(255,246,224,'+a.toFixed(3)+')';c.fillRect(0,0,w,h);}
  }
  // полосы дыма: медленные горизонтальные пряди, подсвеченные сбоку
  if(!low){
   c.save();c.globalCompositeOperation='lighter';
   for(let i=0;i<9;i++){
    const r=rnd(i*3.7);
    const y=h*(0.12+0.76*r)+Math.sin(t*0.5+i)*h*0.03;
    const x=((t*(12+r*26)+i*260)%(w*1.4))-w*0.2;
    c.globalAlpha=(0.05+0.07*r)*k;
    const sg=c.createLinearGradient(x,y,x+w*0.42,y);
    sg.addColorStop(0,'rgba(226,206,172,0)');
    sg.addColorStop(0.5,'rgba(226,206,172,.9)');
    sg.addColorStop(1,'rgba(226,206,172,0)');
    c.fillStyle=sg;c.fillRect(x,y,w*0.42,h*0.012+h*0.02*r);
   }
   c.restore();
  }
  // тлеющая точка сигареты в правом нижнем углу — она дышит вместе с ним
  {
   const ember=0.45+0.55*Math.abs(Math.sin(t*0.9));
   const ex=w*0.845, ey=h*0.815;
   glow(c,ex,ey,w*0.10,'255,132,42',0.26*k*ember);
   c.fillStyle='rgba(255,176,96,'+(0.80*k*ember).toFixed(3)+')';
   c.beginPath();c.arc(ex,ey,w*0.0055*(0.8+0.3*ember),0,Math.PI*2);c.fill();
   c.fillStyle='rgba(228,222,208,'+(0.55*k).toFixed(3)+')';   // бумажная гильза
   c.save();c.translate(ex,ey);c.rotate(0.34);
   c.fillRect(0,-w*0.004,w*0.055,w*0.008);c.restore();
  }
  // сужение зрения и дрожание света в углах
  const vg=c.createRadialGradient(w*0.5-w*0.04*k,h*0.5,w*(0.50-0.16*k),w*0.5,h*0.5,w*0.80);
  vg.addColorStop(0,'rgba(6,5,4,0)');
  vg.addColorStop(1,'rgba(6,5,4,'+(0.72*k).toFixed(3)+')');
  c.fillStyle=vg;c.fillRect(0,0,w,h);
  // хроматический развал по вертикали: кадр «плывёт», как в дурноте
  if(!low){
   c.save();c.globalCompositeOperation='lighter';c.globalAlpha=0.05*k;
   for(let i=0;i<5;i++){
    const y=h*((i*0.21+t*0.07)%1);
    c.fillStyle=i%2?'rgba(255,120,90,1)':'rgba(90,150,255,1)';
    c.fillRect(0,y,w,h*0.006);
   }
   c.restore();
  }
  c.restore();
 }

 // ---------------------------------------------------------------------------
 // ВЫХОД В БЕЛЫЙ СВЕТ. k — 0..1. Это НЕ вспышка: свет раскрывается из
 // середины кадра, съедая его, и в самом конце по белому идёт тёплое
 // дыхание — на этом финал первой концовки и заканчивается.
 // ---------------------------------------------------------------------------
 function whiteCalm(c,w,h,t,k){
  k=cl(k);if(k<=0.002)return;
  const e=eo(k);
  c.save();
  const r0=w*0.02+w*1.10*e;
  const g=c.createRadialGradient(w*0.5,h*0.48,r0*0.20,w*0.5,h*0.48,r0);
  g.addColorStop(0,'rgba(255,255,252,'+Math.min(1,e*1.25).toFixed(3)+')');
  g.addColorStop(0.62,'rgba(252,250,244,'+(0.90*e).toFixed(3)+')');
  g.addColorStop(1,'rgba(250,246,238,0)');
  c.fillStyle=g;c.fillRect(0,0,w,h);
  if(k>0.72){                                    // добор до чистого белого
   c.globalAlpha=cl((k-0.72)/0.28);
   c.fillStyle='#fdfcf8';c.fillRect(0,0,w,h);
   c.globalAlpha=1;
  }
  // тёплое дыхание света по белому — кадр не мёртвый, он живой и тихий
  if(k>0.30){
   c.globalCompositeOperation='multiply';
   const br=0.985+0.015*Math.sin(t*0.7);
   const wg=c.createRadialGradient(w*0.5,h*0.44,w*0.10,w*0.5,h*0.52,w*0.78);
   wg.addColorStop(0,'rgba(255,255,255,1)');
   wg.addColorStop(1,'rgba('+Math.round(252*br)+','+Math.round(246*br)+','+Math.round(232*br)+',1)');
   c.globalAlpha=cl((k-0.30)/0.40)*0.55;
   c.fillStyle=wg;c.fillRect(0,0,w,h);
  }
  c.restore();
 }

 return {human,flashback,whiteCalm,glow};
})();
