// Original WebGL post-processing for Night Shift: CRT, scanlines, grain, vignette, chromatic aberration, bloom-like lift, color grading and glitch.
window.PostFX = (() => {
  let canvas,gl,progFull,progLight,tex,pos,enabled=true;
  // V88: на телефоне широкий блум (два цикла 5×5 = 50 выборок текстуры на пиксель)
  // не проходил по бюджету, как только буфер шейдера подняли до Full HD.
  // Поэтому собирается вторая, облегчённая программа из того же кода: радиус 1
  // вместо 2, то есть 18 выборок вместо 50. Границы циклов в GLSL ES 1.0 должны
  // быть константой, поэтому радиус приходит через #define, а не через uniform.
  const isMobile=/Android|iPhone|iPad|iPod|Windows Phone/i.test(navigator.userAgent)||Math.min(innerWidth,innerHeight)<720;
  const vert=`attribute vec2 a_pos;varying vec2 v_uv;void main(){v_uv=a_pos*.5+.5;gl_Position=vec4(a_pos,0.,1.);}`;
  const frag=`precision mediump float;
  varying vec2 v_uv; uniform sampler2D u_tex; uniform float u_time,u_intensity,u_scan,u_grain,u_vig,u_chroma,u_glitch; uniform vec2 u_res; uniform float u_state;
  float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
  vec3 sampleCol(vec2 uv){return texture2D(u_tex,clamp(uv,0.001,0.999)).rgb;}
  vec3 sampleWrap(vec2 uv){return texture2D(u_tex,clamp(uv,0.0,1.0)).rgb;}
  // bright-pass bloom: blur several taps of a downscaled luminance mask
  vec3 bloom(vec2 uv){
    vec3 b=vec3(0.); float n=0.;
    // tight radius (crisp highlight)
    for(float i=-BLOOM_R;i<=BLOOM_R;i+=1.){for(float j=-BLOOM_R;j<=BLOOM_R;j+=1.){
      vec2 o=vec2(i,j)*(2.0/u_res);
      vec3 c=sampleWrap(uv+o);
      float l=dot(c,vec3(.299,.587,.114));
      float bright=smoothstep(.66,1.0,l);
      b+=c*bright; n+=1.;
    }}
    b=(b/max(n,1.));
    // wide soft radius for a gentle glow halo
    vec3 bw=vec3(0.); float nw=0.;
    for(float i=-BLOOM_R;i<=BLOOM_R;i+=1.){for(float j=-BLOOM_R;j<=BLOOM_R;j+=1.){
      vec2 o=vec2(i,j)*(6.0/u_res);
      vec3 c=sampleWrap(uv+o);
      float l=dot(c,vec3(.299,.587,.114));
      float bright=smoothstep(.74,1.0,l);
      bw+=c*bright; nw+=1.;
    }}
    bw=(bw/max(nw,1.));
    return b*0.42+bw*0.30;
  }
  // filmic ACES tonemap approximation for smoother highlight roll-off
  vec3 aces(vec3 x){return clamp((x*(2.51*x+0.03))/(x*(2.43*x+0.59)+0.14),0.,1.);}
  void main(){
    vec2 uv=v_uv;
    // ===== 3D-in-2D: barrel/CRT curvature — bends the flat image into a slight CRT bowl =====
    vec2 p=uv-.5;
    float k=u_intensity*0.045;
    uv += p*(dot(p,p)*k);
    // subtle vertical pinch so the curvature reads as a 3D screen surface
    uv.y += p.y*dot(p,p)*0.03*k;
    p=uv-.5;
    float t=u_time;
    float wave=sin(uv.y*u_res.y*.035+t*2.2)*.0015*u_intensity;
    float g=step(.985,hash(vec2(floor(t*12.),floor(uv.y*90.))))*u_glitch*u_state;
    uv.x+=wave+g*.008*(hash(vec2(floor(t*20.),floor(uv.y*60.)))-.5);
    float ca=.0028*u_chroma*u_intensity;
    vec3 col=vec3(sampleCol(uv+vec2(ca,0.)).r,sampleCol(uv).g,sampleCol(uv-vec2(ca,0.)).b);
    // soft bloom: warm lift on highlights (tight + wide halo)
    vec3 bl=bloom(uv);
    col+=bl*vec3(1.,.80,.58)*0.085*u_intensity;
    // smoother scanlines, vertically feathered (less harsh banding)
    float scan=(.5+.5*sin(uv.y*u_res.y*1.1))*0.05*u_scan*u_intensity;
    scan*=smoothstep(0.0,1.0,abs(fract(uv.y*u_res.y)-0.5)*2.0)*0.4+0.6;
    float grain=(hash(floor(uv*u_res*.45)+t*19.)-.5)*.085*u_grain*u_intensity;
    // softer, rounder vignette
    float vig=1.-smoothstep(.28,.84,length(p))*.62*u_vig*u_intensity;
    col*=vig;
    // refined horror grade: lift shadows very slightly, cool midtones, warm highlights
    col+=max(col-vec3(.62),0.)*vec3(.030,.012,-.004)*u_intensity;
    col.r*=0.985; col.b*=1.022;
    float lum=dot(col,vec3(.299,.587,.114));
    col=mix(col,mix(vec3(.10,.12,.16),vec3(.99,.97,.90),lum),0.12*u_intensity);
    // filmic ACES tonemap for smoother highlight roll-off, then scanline/grain on top
    col=aces(col*1.01);
    col-=scan; col+=grain;
    if(u_state>.5){float line=step(.992,hash(vec2(floor(t*16.),floor(uv.x*120.))));col+=line*vec3(.12,.015,.02)*u_glitch;}
    gl_FragColor=vec4(clamp(col,0.,1.),1.);
  }`;
  function compile(type,src){const s=gl.createShader(type);gl.shaderSource(s,src);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))throw Error(gl.getShaderInfoLog(s));return s;}
  function init(){canvas=document.createElement('canvas');canvas.id='postfx';canvas.setAttribute('aria-hidden','true');canvas.style.cssText='position:fixed;inset:0;width:100%;height:100%;pointer-events:none;z-index:20;display:block';document.body.appendChild(canvas);try{gl=canvas.getContext('webgl',{alpha:false,antialias:false});}catch(e){}if(!gl){enabled=false;return;}
   // Если браузер теряет WebGL-контекст (слабое устройство, сон вкладки), шейдер
   // отключается навсегда и оверлей скрывается — иначе он остаётся пустым поверх игры
   // и экран выглядит белым/чёрным.
   canvas.addEventListener('webglcontextlost',e=>{e.preventDefault();enabled=false;canvas.style.display='none';console.warn('PostFX: WebGL context lost — шейдер отключён')},false);
   try{const build=r=>{const pr=gl.createProgram();gl.attachShader(pr,compile(gl.VERTEX_SHADER,vert));gl.attachShader(pr,compile(gl.FRAGMENT_SHADER,'#define BLOOM_R '+r+'\n'+frag));gl.linkProgram(pr);if(!gl.getProgramParameter(pr,gl.LINK_STATUS))throw Error(gl.getProgramInfoLog(pr));return pr;};
   progFull=build('2.');
   try{progLight=build('1.');}catch(e2){progLight=progFull;console.warn('PostFX: облегчённый блум не собрался',e2);}
   pos=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,pos);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array([-1,-1,1,-1,-1,1,-1,1,1,-1,1,1]),gl.STATIC_DRAW);const a=gl.getAttribLocation(progFull,'a_pos');gl.enableVertexAttribArray(a);gl.vertexAttribPointer(a,2,gl.FLOAT,false,0,0);tex=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,tex);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);resize();}catch(e){enabled=false;console.warn(e)}}
  // V88: буфер шейдера считался в CSS-пикселях (innerWidth×innerHeight). На телефоне
  // с DPR 3 это треть реального разрешения, а шейдер — верхний непрозрачный слой,
  // через который видна вся игра. Из-за этого любое повышение разрешения самого
  // холста гаслось здесь. Теперь буфер в реальных пикселях, до 1920 по длинной стороне.
  function resize(){if(!canvas||!gl)return;
   const dm=window.SaveSystem?.settings?.deviceMode;
   const q=dm==='low'?.55:dm==='balanced'?.82:1;
   const cw=Math.max(320,innerWidth), ch=Math.max(180,innerHeight);
   const long=Math.max(cw,ch), dp=Math.min(devicePixelRatio||1,3);
   const k=Math.max(.5,Math.min(dp,(Math.min(1920,Math.round(long*dp))/long)))*q;
   canvas.width=Math.max(320,Math.round(cw*k));canvas.height=Math.max(180,Math.round(ch*k));
   gl.viewport(0,0,canvas.width,canvas.height);
  }
  function render(source,state,quality){try{return renderInner(source,state,quality)}catch(e){enabled=false;if(canvas)canvas.style.display='none';console.warn('PostFX disabled:',e)}}
  function renderInner(source,state,quality){const c=window.SaveSystem.settings||{};const shaderOff=!enabled||!gl||quality==='off'||c.deviceMode==='low'||c.effects==='low';const show=(state==='game'||state==='teaser')&&!shaderOff;if(canvas) canvas.style.display=show?'block':'none'; if(!show)return;const q=quality==='low'?.35:quality==='medium'?.6:.9, base=(c.shaderIntensity??.75)*q;
   // на телефоне и на среднем режиме берём облегчённый блум — картинка почти та же,
   // а выборок текстуры на пиксель втрое меньше, что и окупает Full HD-буфер.
   const program=(progLight&&(isMobile||c.deviceMode==='balanced'||quality==='low'||quality==='medium'))?progLight:progFull;gl.useProgram(program);gl.bindBuffer(gl.ARRAY_BUFFER,pos);gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,tex);gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,true);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,source);const U=n=>gl.getUniformLocation(program,n);gl.uniform1i(U('u_tex'),0);gl.uniform1f(U('u_time'),performance.now()/1000);gl.uniform2f(U('u_res'),source.width,source.height);gl.uniform1f(U('u_intensity'),base);const fx=c.effectsEnabled!==false&&c.effects!=='low';gl.uniform1f(U('u_scan'),fx&&c.effectScanlines!==false?(c.scanlines??.55):0);gl.uniform1f(U('u_grain'),fx&&c.effectGrain!==false?(c.grain??.35):0);gl.uniform1f(U('u_vig'),fx&&c.effectVignette!==false?(c.vignette??.45):0);gl.uniform1f(U('u_chroma'),fx&&c.effectChromatic!==false?(c.chromatic??.18):0);gl.uniform1f(U('u_glitch'),fx&&c.effectGlitch!==false?(c.glitch??.15):0);gl.uniform1f(U('u_state'),state==='game'||state==='teaser'?1:.35);gl.drawArrays(gl.TRIANGLES,0,6)}
  init();addEventListener('resize',resize);return {render,resize,enabled:()=>enabled};
})();