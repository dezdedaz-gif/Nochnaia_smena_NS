// ============================================================================
// V83: НАСТОЯЩИЕ ГОЛОСА. Раньше аниматроники и охранник говорили встроенным
// синтезатором браузера (speechSynthesis): в Яндекс Играх и на части устройств
// он вообще молчал, а там, где работал, звучал как навигатор, а не как железная
// кукла. Теперь все 31 реплика — заранее записанные и обработанные дорожки:
//   охранник  — плёнка/телефон, низкий хриплый шёпот;
//   МОНСТР    — кольцевая модуляция 42 Гц, биткрашер, металлическое эхо;
//   ФЕЛИКС    — хор + флэнжер, треск динамика, «сломанная праздничная запись»;
//   EXO       — вокодер на 78/131 Гц, сильный биткрашер, вой сервоприводов;
//   LAV       — плывущая высота, радиополоса, помехи.
// Дорожки есть на русском и английском; на остальных языках интерфейса играет
// английская озвучка, а субтитры остаются переведёнными.
// ============================================================================
window.VoiceLines = (() => {
  const M = window.VOICE_MANIFEST || { ids: [], byText: {}, guard: {} };
  let current = null, currentId = '';

  function lang() { try { return window.I18N ? window.I18N.voiceLang() : 'ru'; } catch (e) { return 'ru'; } }
  function key(id) { return 'voice_' + lang() + '_' + id; }
  function norm(t) {
    return String(t || '').toLowerCase()
      .replace(/[«»"'`]/g, '')
      .replace(/[\u2026]/g, '...')
      .replace(/\s+/g, ' ')
      .replace(/[.,!?:;—-]+$/g, '')
      .trim();
  }

  function has(id) { return !!id && M.ids.indexOf(id) >= 0; }

  function stop() {
    if (current) { try { current.pause(); current.currentTime = 0; } catch (e) {} }
    current = null; currentId = '';
  }

  // group: 'monster' для аниматроников, 'phone' для телефонных линий и охранника.
  function play(id, group, vol) {
    if (!has(id)) return null;
    stop();
    const name = key(id);
    window.AudioFX.register(name, 'assets/voice/' + lang() + '/' + id + '.mp3', group || 'monster');
    // rate:0 — без «мрачной» подкрутки скорости: обработка уже запечена в файл.
    const a = window.AudioFX.play(name, vol === undefined ? 1 : vol, { group: group || 'monster', rate: 0 });
    if (a) { current = a; currentId = id; }
    return a;
  }

  function playByText(text, group, vol) {
    const id = M.byText[norm(text)];
    return id ? play(id, group, vol) : null;
  }

  // Реплика прошлого охранника по номеру смены (1–5). short=true — короткий
  // вариант для второй ночи, где связь обрывается на середине.
  function playGuard(night, group, opts) {
    const n = Math.max(1, Math.min(5, Number(night) || 1));
    const id = (opts && opts.short && has('guard_n' + n + '_short')) ? 'guard_n' + n + '_short' : 'guard_n' + n;
    return play(id, group || 'phone', (opts && opts.vol) || 1);
  }

  // Длительность реплики нужна, чтобы субтитр не исчезал раньше голоса.
  // V85: длительности хранятся отдельно для русской и английской дорожки — они
  // отличаются на несколько секунд, и раньше субтитр обрывался или висел в тишине.
  function duration(id) {
    const table = (lang() === 'ru') ? M.duration : (M.durationEn || M.duration);
    const d = table && table[id];
    return d || (M.duration && M.duration[id]) || 0;
  }
  function durationByText(t) { return duration(M.byText[norm(t)]); }
  function guardDuration(night, short) {
    const n = Math.max(1, Math.min(5, Number(night) || 1));
    return duration(short && has('guard_n' + n + '_short') ? 'guard_n' + n + '_short' : 'guard_n' + n);
  }

  // Предзагрузка: первые реплики не должны «опаздывать» на 200–400 мс.
  function warm(ids) {
    (ids || []).forEach(id => {
      if (!has(id)) return;
      try { const a = new Audio('assets/voice/' + lang() + '/' + id + '.mp3'); window.AudioFX?.noSystemPlayer?.(a); a.preload = 'auto'; a.load(); } catch (e) {}
    });
  }

  return { play, playByText, playGuard, stop, has, duration, durationByText, guardDuration, warm,
    get playing() { return !!current; }, get currentId() { return currentId; } };
})();
