// V114: ПЛАТФОРМЕННЫЙ СЛОЙ БЕЗ ЯНДЕКС SDK.
// ПОЧЕМУ ТАК БЫЛО: рядом с этим адаптером лежал отдельный модуль нативного SDK
// Яндекс Игр (js/yandex.js) плюс подключение внешнего /sdk.js в index.html, и при
// загрузке игра угадывала площадку по домену и referrer. Для сборки под .io-порталы
// это лишний внешний запрос и лишняя ветка кода.
// СТАЛО: остался ОДИН слой — Playgama Bridge (Playgama, CrazyGames, GameDistribution,
// VK, Telegram, y8 и т. д.). Ничего яндексового в сборке нет. Если мост не
// загрузился (игра открыта локально или просто с сайта) — все методы работают как
// безопасные заглушки, игра полностью играбельна и сохраняется в localStorage.
// V115: ЛИДЕРБОРДЫ ВЕРНУЛИСЬ, НО БЕЗ ПРИВЯЗКИ К ОДНОЙ ПЛОЩАДКЕ.
// Сборка едет на itch.io, а там нет никакого игрового SDK и никакого сервера:
// страница — это просто статические файлы в iframe. Поэтому таблица результатов
// сделана двухслойной. Нижний слой — локальные забеги в localStorage, он работает
// ВСЕГДА, в том числе на itch.io. Верхний слой — общая таблица площадки через
// Playgama Bridge (Playgama, CrazyGames, VK, Telegram и т. д.), он включается сам,
// если площадка это умеет. На itch.io просто останется локальный слой, и экран
// всё равно не будет пустым.
(()=>{
  window.PLATFORM_ACTIVE='bridge';

  // Идентификаторы рекламных мест из playgama-bridge-config.json.
  const AD_INT='shift_end', AD_REW='extra_life';

  let bridge=null, ready=false, gameplay=false, paused=false;
  let readySent=false, readyPending=false;
  let adBusy=false, adAt=0, rewBusy=false;
  const AD_GAP=65000;

  function loadScript(){
    return new Promise((res,rej)=>{
      if(window.bridge) return res(window.bridge);
      const s=document.createElement('script');
      s.src='vendor/playgama-bridge.js';
      s.onload=()=>res(window.bridge);
      s.onerror=()=>rej(new Error('bridge script failed'));
      document.head.appendChild(s);
    });
  }

  async function init(){
    if(ready) return bridge;
    try{
      bridge=await loadScript();
      if(!bridge) return null;
      await bridge.initialize();
      ready=true;

      // Требование всех площадок (и Яндекса, и Playgama): звук и геймплей
      // ставятся на паузу, когда площадка об этом просит.
      try{
        bridge.platform.on(bridge.EVENT_NAME.PAUSE_STATE_CHANGED,isPaused=>{
          paused=!!isPaused;
          if(isPaused) window.NightShift?.platformPause?.();
          else window.NightShift?.platformResume?.();
        });
        bridge.platform.on(bridge.EVENT_NAME.AUDIO_STATE_CHANGED,isEnabled=>{
          if(isEnabled) window.NightShift?.platformResume?.();
          else window.NightShift?.platformPause?.();
        });
        // Начальное состояние звука площадка НЕ применяет сама.
        if(bridge.platform.isAudioEnabled===false) window.NightShift?.platformPause?.();
      }catch(e){}

      if(readyPending) gameReady();
      await load();
      return bridge;
    }catch(e){
      console.warn('Playgama Bridge init failed',e);
      return null;
    }
  }

  function gameReady(){
    if(readySent) return;
    if(!ready){ readyPending=true; return; }
    try{ bridge.platform.sendMessage('game_ready'); readySent=true; readyPending=false; }
    catch(e){ readyPending=true; }
  }

  async function save(data){
    try{ if(ready) await bridge.storage.set(['nightShift'],[JSON.stringify(data)]); }
    catch(e){ console.warn('bridge save failed',e); }
  }

  async function load(){
    try{
      if(!ready) return null;
      const v=await bridge.storage.get(['nightShift']);
      let raw=Array.isArray(v)?v[0]:v;
      if(!raw) return null;
      if(typeof raw==='string'){ try{ raw=JSON.parse(raw); }catch(e){ return null; } }
      if(raw && window.SaveSystem?.mergeCloud){
        window.SaveSystem.mergeCloud(raw);
        window.NightShift?.syncCloudProgress?.();
      }
      return raw||null;
    }catch(e){ return null; }
  }

  async function authorize(){
    try{
      if(!ready) return false;
      if(!bridge.player.isAuthorizationSupported) return false;
      if(bridge.player.isAuthorized) return true;
      await bridge.player.authorize({});
      return !!bridge.player.isAuthorized;
    }catch(e){ return false; }
  }

  function startGameplay(){
    if(gameplay||paused) return;
    gameplay=true;
    try{ bridge?.platform?.sendMessage?.('gameplay_started'); }catch(e){}
  }
  function stopGameplay(){
    if(!gameplay) return;
    gameplay=false;
    try{ bridge?.platform?.sendMessage?.('gameplay_stopped'); }catch(e){}
  }

  function fullscreen(){
    try{ if(!document.fullscreenElement) document.documentElement.requestFullscreen?.(); }catch(e){}
  }

  // Как и в нативном модуле: игра НЕ закрывает страницу площадки.
  function exit(){ try{stopGameplay()}catch(e){} return false; }

  function adReady(){ try{ return !!ready && !!bridge.advertisement?.isInterstitialSupported; }catch(e){ return false; } }
  function canShowAd(){ return adReady() && !adBusy && (Date.now()-adAt)>=AD_GAP; }

  // Реклама во весь экран: звук и геймплей на паузу, возврат — по закрытию.
  function showAd(){
    if(!canShowAd()) return false;
    adBusy=true; adAt=Date.now();
    stopGameplay();
    const back=()=>{
      if(!adBusy) return;
      adBusy=false;
      window.NightShift?.platformResume?.();
      if(window.NightShift?.state==='game') startGameplay();
    };
    try{
      const off=bridge.advertisement.on(bridge.EVENT_NAME.INTERSTITIAL_STATE_CHANGED,state=>{
        if(state==='opened') window.NightShift?.platformPause?.();
        if(state==='closed'||state==='failed'){ back(); try{off?.()}catch(e){} }
      });
      bridge.advertisement.showInterstitial(AD_INT);
      // Страховка: если площадка не пришлёт ни одного события.
      setTimeout(back,60000);
      return true;
    }catch(e){ back(); return false; }
  }

  function rewardReady(){ try{ return !!ready && !!bridge.advertisement?.isRewardedSupported && !rewBusy; }catch(e){ return false; } }

  // Награда выдаётся ТОЛЬКО в состоянии 'rewarded' — закрытый досрочно ролик
  // ничего не начисляет (требование площадок к rewarded-рекламе).
  function rewarded(onReward,onDone){
    if(!rewardReady()){ try{onDone?.(false)}catch(e){} return false; }
    let got=false, done=false;
    rewBusy=true;
    stopGameplay();
    const back=()=>{
      if(done) return; done=true;
      rewBusy=false;
      window.NightShift?.platformResume?.();
      if(window.NightShift?.state==='game') startGameplay();
      try{onDone?.(got)}catch(e){}
    };
    try{
      const off=bridge.advertisement.on(bridge.EVENT_NAME.REWARDED_STATE_CHANGED,state=>{
        if(state==='opened') window.NightShift?.platformPause?.();
        if(state==='rewarded'){ got=true; try{onReward?.()}catch(e){} }
        if(state==='closed'||state==='failed'){ back(); try{off?.()}catch(e){} }
      });
      bridge.advertisement.showRewarded(AD_REW);
      setTimeout(back,120000);
      return true;
    }catch(e){ back(); return false; }
  }

  // Идентификаторы таблиц из playgama-bridge-config.json.
  const LB_SCORE='night_shift_score', LB_TIME='night_shift_time';
  function lbId(kind){ return kind==='time'?LB_TIME:LB_SCORE; }

  // 'not_available' | 'in_game' | 'native_popup'
  function lbType(){
    try{ return ready?(bridge.leaderboards?.type||'not_available'):'not_available'; }
    catch(e){ return 'not_available'; }
  }
  function lbReady(){ return lbType()==='in_game'; }

  async function lbSet(kind,value){
    try{
      if(lbType()==='not_available') return false;
      const v=Math.floor(Math.max(0,Number(value)||0));
      await bridge.leaderboards.setScore(lbId(kind),v);
      return true;
    }catch(e){ return false; }
  }

  // Приводим ответ площадки к одному виду: у разных порталов поля называются
  // по-разному, поэтому проверяем все встречающиеся варианты.
  function lbNorm(list,kind){
    if(!Array.isArray(list)) return [];
    const me=(()=>{try{return bridge.player?.id||''}catch(e){return ''}})();
    return list.map((e,i)=>{
      const pid=e.playerId||e.id||e.player?.uniqueID||e.player?.id||'';
      const nm=e.playerName||e.name||e.player?.publicName||e.player?.name||'';
      const v=Number(e.score!==undefined?e.score:e.value)||0;
      return {
        rank:Number(e.rank)||i+1,
        name:nm||'АНОНИМ',
        score:kind==='time'?0:v,
        seconds:kind==='time'?v:0,
        you:!!me&&!!pid&&String(pid)===String(me),
        global:true
      };
    });
  }

  async function lbTop(kind,limit=10){
    try{
      if(!lbReady()) return null;
      const raw=await bridge.leaderboards.getEntries(lbId(kind));
      const rows=lbNorm(Array.isArray(raw)?raw:(raw?.entries||[]),kind);
      return rows.slice(0,limit);
    }catch(e){ return null; }
  }

  async function lbPopup(kind){
    try{
      if(lbType()!=='native_popup') return false;
      await bridge.leaderboards.showNativePopup(lbId(kind));
      return true;
    }catch(e){ return false; }
  }

  function lang(){ try{ return bridge?.platform?.language||''; }catch(e){ return ''; } }
  function authorized(){ try{ return !!bridge?.player?.isAuthorized; }catch(e){ return false; } }

  window.Platform={
    init,gameReady,save,load,authorize,
    startGameplay,stopGameplay,fullscreen,exit,
    showAd,canShowAd,adReady,rewarded,rewardReady,lang,
    lbType,lbReady,lbSet,lbTop,lbPopup,
    get ok(){return ready},
    get player(){try{return ready?bridge.player:null}catch(e){return null}},
    get authorized(){return authorized()},
    get platformId(){try{return bridge?.platform?.id||''}catch(e){return ''}}
  };
})();
