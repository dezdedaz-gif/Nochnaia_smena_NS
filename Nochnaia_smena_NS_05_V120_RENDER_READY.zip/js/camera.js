window.CameraSystem=(()=>{
 const cameras={
  1:{name:'Зал',state:'active',interval:.72,frameTimer:0,lastMonsters:[],glitch:0,breakTimer:0},
  2:{name:'Выход',state:'active',interval:.86,frameTimer:0,lastMonsters:[],glitch:0},
  3:{name:'Склад',state:'active',interval:.66,frameTimer:0,lastMonsters:[],glitch:0},
  4:{name:'Сцена',state:'active',interval:.78,frameTimer:0,lastMonsters:[],glitch:0,breakTimer:0},
  5:{name:'Служебная',state:'active',interval:.92,frameTimer:0,lastMonsters:[],glitch:0},
  6:{name:'Коридор А',state:'active',interval:.74,frameTimer:0,lastMonsters:[],glitch:0,breakTimer:0},
  7:{name:'Коридор Б',state:'active',interval:.80,frameTimer:0,lastMonsters:[],glitch:0,breakTimer:0}
 };
 // Corridor rooms 6 and 7 are the only approaches to the security office.
 const CORRIDOR_ROOMS=[6,7];
 // Room 0 = тамбур у двери охраны. С камеры это видно как силуэт в конце соответствующего
 // коридора: левая дверь = Коридор А (6), правая = Коридор Б (7).
 function corridorForSide(side){return side==='left'?6:side==='right'?7:0;}
 // V72: какая лампа освещает этот коридор и включена ли она сейчас.
 // Коридор А (6) освещает ЛЕВАЯ лампа, коридор Б (7) — ПРАВАЯ.
 function sideForCorridor(room){return room===6?'left':room===7?'right':null;}
 function corridorLit(game,room){
  const s=sideForCorridor(room);if(!s)return true;
  const l=game&&game.lights?game.lights[s]:null;
  return !!(l&&l.on&&!l.renderOff);
 }
 function doorMonsters(game,room){
  if(CORRIDOR_ROOMS.indexOf(room)<0)return [];
  const c=cameras[room];if(!c||c.state!=='active'||c.glitch>0)return [];
  return (game.monsters||[]).filter(m=>m&&m.room===0&&m.state!=='hidden'&&corridorForSide(m.doorSide)===room);
 }
 // V73: аниматроник, сидящий в углу коридора, НЕ считается тревогой ни для одной
 // системы: ни маяк, ни рамка кадра, ни метка на карте, ни строка в HUD.
 function alertActive(game){return (game.monsters||[]).some(m=>m&&m.state!=='hidden'&&((CORRIDOR_ROOMS.indexOf(m.room)>=0&&!m.corner)||m.room===0));}
 // Красный маяк в коридоре горит ТОЛЬКО когда аниматроник в этом коридоре:
 //   0 — пусто (маяк погашен), 1 — аниматроник в коридоре, 2 — уже у двери охраны.
 function doorAlert(game,room){
  if(CORRIDOR_ROOMS.indexOf(room)<0)return 0;
  const c=cameras[room];if(!c||c.state!=='active')return 0;
  if(doorMonsters(game,room).length)return 2;
  // V72: если аниматроник забился в угол коридора — он не попадает в зону датчика,
  // и маяк остаётся погашенным. Тревога включается, только когда он выходит к проходу.
  const inCor=(game.monsters||[]).filter(m=>m&&m.room===room&&m.state!=='hidden');
  return inCor.some(m=>!m.corner)?1:0;
 }
 function update(dt,game){Object.keys(cameras).forEach(id=>{const c=cameras[id];if(c.state==='broken'){c.breakTimer-=dt;if(c.breakTimer<=0){c.state='active';c.breakTimer=0;c.glitch=0;}}else{c.frameTimer-=dt;if(c.glitch>0)c.glitch=Math.max(0,c.glitch-dt);if(c.frameTimer<=0){c.frameTimer=c.interval;const room=Number(id);c.lastMonsters=(game.monsters||[]).filter(m=>m&&m.room===room&&m.state!=='hidden').map(m=>m.kind);if(Math.random()<.055+game.night*.012)c.glitch=.12+Math.random()*.38;}}}); if(game.monitor){for(const id of Object.keys(cameras)){const c=cameras[id];if(c.state==='active' && Math.random()<dt*(.00055+game.night*.00018)){c.state='broken';c.breakTimer=20;c.lastMonsters=[];c.glitch=0; if(Number(id)===game.cam) game.say('КАМЕРА '+String(id).padStart(2,'0')+' СЛОМАЛАСЬ — ВОССТАНОВЛЕНИЕ 20 С',2); break;}}}}
 function shouldShowMonster(game,room){const c=cameras[room];if(!c||c.state!=='active'||c.glitch>0)return [];return c.lastMonsters||[]}
 function setState(id,state){if(cameras[id])cameras[id].state=state}
 function get(id){return cameras[id]}
 // V84: РОВНАЯ КАМЕРА, КОТОРАЯ ВЕДЁТ ПО ДЕЙСТВИЮ.
 // Было: кадр всё время мелко плавал по синусоиде и дополнительно ездил за курсором
 // мыши — картинка дрожала, читать её было тяжело, а на слабом железе дрожь ещё и
 // размазывала кадр между перерисовками.
 // Стало: камера стоит ровно. Она плавно и медленно доводит кадр туда, где
 // происходит действие (фигура в комнате, силуэт у двери охраны), с лёгким
 // приближением, и так же плавно возвращается в исходное положение, когда в
 // помещении снова пусто. Никакой дрожи и никакой реакции на мышь.
 const PAN_GEO={1:-.30,2:.34,3:.36,4:.30,5:-.38,6:.30,7:-.30};
 const pans={};
 function panState(id){return pans[id]||(pans[id]={x:0,y:0,z:1.0,at:0});}
 // Куда смотреть: exact-значение приходит из отрисовки фигур (focusLat), иначе
 // берём штатное место аниматроника в этой комнате.
 function focusLat(id){
  const c=cameras[id];if(!c||c.state!=='active')return null;
  if(typeof c.focusLat==='number')return c.focusLat;
  const seen=c.lastMonsters||[];if(!seen.length)return null;
  return PAN_GEO[id]||0;
 }
 function viewOffset(id,t,mouse={x:.5,y:.5}){
   const p=panState(id);
   let dt=p.at?(t-p.at):0.016;
   if(!(dt>0)||dt>0.25)dt=0.016;
   p.at=t;
   const f=focusLat(id);
   const tx=f===null?0:-Math.max(-1,Math.min(1,f))*0.052;
   const ty=f===null?0:-0.014;
   const tz=f===null?1.0:1.042;
   // одна и та же мягкая доводка на подъезде и на возврате: кадр не рвётся
   const k=Math.min(1,dt*1.6);
   p.x+=(tx-p.x)*k;p.y+=(ty-p.y)*k;p.z+=(tz-p.z)*k;
   return {x:p.x,y:p.y,zoom:p.z};
 }
 return {cameras,update,shouldShowMonster,setState,get,viewOffset,alertActive,doorMonsters,doorAlert,corridorAlert:doorAlert,corridorForSide,sideForCorridor,corridorLit,CORRIDOR_ROOMS};
})();
