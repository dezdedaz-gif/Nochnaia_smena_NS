// Мини-игры между сменами — 8-битные вставки в духе Фредди.
// Зачем так: главный агент дёргает ровно шесть функций и флаг done, поэтому весь
// модуль — одна замкнутая IIFE без импортов, без сети, без ассетов. Вся графика
// собирается из «жирных пикселей» (размер пикселя считается от W и H), весь звук —
// через window.AudioFX в try/catch, чтобы модуль жил и без звуковой подсистемы.
window.MiniGame=(()=>{

 // ---------------------------------------------------------------- звук
 // Было: прямые вызовы AudioFX.synth. Стало: обёртки, которые молча глотают
 // любую ошибку и отсутствие модуля — мини-игра не должна падать из-за звука.
 function beep(name,g){try{if(window.AudioFX&&window.AudioFX.synth)window.AudioFX.synth(name,g==null?.5:g);}catch(e){}}
 function uiSnd(name,g){try{if(window.AudioFX&&window.AudioFX.play)window.AudioFX.play(name,g==null?.5:g,{group:'ui'});}catch(e){}}

 // ---------------------------------------------------------------- сетка
 // Виртуальное поле всегда GW×GH «жирных пикселей»; размер пикселя P считается
 // от свободного места, поэтому 915×412 и 1920×1080 дают одну и ту же картинку.
 const GW=92,GH=26;

 function layout(W,H){
  const padX=Math.round(W*.03);
  const top=Math.round(H*.155);          // полоса под заголовок/подсказку
  const bot=Math.round(H*.22);           // полоса под экранное управление
  const fw=Math.max(40,W-padX*2), fh=Math.max(30,H-top-bot);
  const P=Math.min(fw/GW,fh/GH);
  const gw=P*GW, gh=P*GH;
  // Джойстик и кнопка действия: размер от меньшей стороны, чтобы палец попадал
  // и на телефоне в ландшафте, и на большом экране.
  const ds=Math.max(26,Math.min(W,H)*.135);
  const py=Math.round(H*.035);
  return {P,W,H,top,bot,padX,
   ox:padX+(fw-gw)/2, oy:top+(fh-gh)/2, gw,gh,
   dpad:{cx:padX+ds, cy:H-py-ds, r:ds},
   act:{cx:W-padX-ds*.72, cy:H-py-ds*.72, r:ds*.72}};
 }

 // Пиксель поля -> экран. Округляем, иначе на дробном P между пикселями видны щели.
 function px(ctx,L,gx,gy,gwid,ghei,col){
  const p=L.P;
  ctx.fillStyle=col;
  ctx.fillRect(Math.round(L.ox+gx*p),Math.round(L.oy+gy*p),
               Math.ceil(gwid*p)+1,Math.ceil(ghei*p)+1);
 }

 // ---------------------------------------------------------------- спрайты
 // Каждый спрайт — массив строк одинаковой длины; символ -> цвет из палитры,
 // '.' — прозрачно. Зачем так: ноль ассетов, всё редактируется руками.
 const ART={
  monster:[ // МОНСТР: тяжёлый, широкий, занимает почти всю высоту клетки
   '.B.....B.',
   '..BBBBB..',
   '.BBBBBBB.',
   '.BEBBBEB.',
   '.BBBBBBB.',
   '..BWWWB..',
   '.BBBBBBB.',
   'BBBBBBBBB',
   'BBBBBBBBB',
   '.BB...BB.',
   '.BB...BB.',
   '.KK...KK.'],
  child:[
   '.HHHH.',
   'HSSSSH',
   'HSESEH',
   '.SSSS.',
   '..SS..',
   '.CCCC.',
   '.CCCC.',
   '.L..L.'],
  felix:[ // ФЕЛИКС: заяц-ведущий, длинные уши, трещина на морде
   '.P...P.',
   '.P...P.',
   '.PP.PP.',
   '.PPPPP.',
   'PEP.PEP',
   '.PWWWP.',
   '.PPPPP.',
   'PPPPPPP',
   'PPKPPPP',
   '.PP.PP.',
   '.PP.PP.',
   '.KK.KK.'],
  exo:[ // EXO: голый экзоскелет, видно рёбра и штыри
   '..GGG..',
   '.GEGEG.',
   '..GGG..',
   '...G...',
   '.GGGGG.',
   'G.G.G.G',
   'G.GGG.G',
   '.GGGGG.',
   '..G.G..',
   '.GG.GG.',
   '.G...G.',
   '.G...G.'],
  lav:[ // LAV: жёлтый, поёт, рот открыт
   '..YYY..',
   '.YEYEY.',
   '.YYYYY.',
   '..YWY..',
   '.YYYYY.',
   'YYYYYYY',
   'YYYYYYY',
   '.YYYYY.',
   '..YYY..',
   '.YY.YY.',
   '.Y...Y.',
   '.KK.KK.'],
  guard:[ // Прошлый охранник: кепка, рубашка, фонарь в руке
   '..UUU..',
   '.UUUUU.',
   '.SESES.',
   '..SSS..',
   '..CCC..',
   '.CCCCC.',
   'FCCCCC.',
   '.CCCCC.',
   '..C.C..',
   '..C.C..',
   '.KK.KK.'],
  box:[ // Шкатулка с заводным ключом
   '..K....',
   '.MMMMM.',
   'MMMMMMM',
   'MMWWWMM',
   'MMMMMMM',
   '.MMMMM.'],
  pizza:[
   '.RRR.',
   'RYRYR',
   'RYRYR',
   '.RRR.'],
  plate:[ // Кусок обшивки: пластина с креплениями
   'MMMMM',
   'MKMKM',
   'MMMMM'],
  tape:[ // Кассета 1993 года
   'MMMMMMM',
   'MWWMWWM',
   'MWWMWWM',
   'MMMMMMM']
 };

 function spr(ctx,L,art,gx,gy,pal){
  for(let r=0;r<art.length;r++){
   const row=art[r];
   for(let c=0;c<row.length;c++){
    const ch=row[c]; if(ch==='.')continue;
    const col=pal[ch]; if(!col)continue;
    px(ctx,L,gx+c,gy+r,1,1,col);
   }
  }
 }
 function sprW(art){return art[0].length}
 function sprH(art){return art.length}

 // ---------------------------------------------------------------- текст
 // Все размеры шрифта считаются от H, поэтому на телефоне текст не вылезает.
 function fs(L,k){return Math.max(9,Math.round(L.H*k))}
 function setFont(ctx,size,bold){ctx.font=(bold?'bold ':'')+size+'px monospace'}

 // Перенос по словам с жёстким лимитом ширины: если слово длиннее строки — режем.
 function wrap(ctx,text,maxW){
  const words=String(text).split(/\s+/),out=[];let line='';
  for(let i=0;i<words.length;i++){
   let w=words[i];
   const test=line?line+' '+w:w;
   if(ctx.measureText(test).width<=maxW){line=test;continue}
   if(line){out.push(line);line=''}
   while(ctx.measureText(w).width>maxW&&w.length>1){
    let cut=w.length;
    while(cut>1&&ctx.measureText(w.slice(0,cut)).width>maxW)cut--;
    out.push(w.slice(0,cut));w=w.slice(cut);
   }
   line=w;
  }
  if(line)out.push(line);
  return out;
 }

 // Блок текста по центру: сам уменьшает шрифт, пока не влезет по высоте.
 function block(ctx,L,lines,cx,cy,maxW,maxH,size,col,bold,lead){
  let s=size,ls=[];
  for(let guard=0;guard<24;guard++){
   setFont(ctx,s,bold);
   ls=[];
   // V93: перевод делается ДО переноса строк. Было: длинная фраза сначала
   // резалась на куски, и словарь не узнавал ни один из кусков — карточки
   // мини-игры оставались русскими на других языках.
   for(let i=0;i<lines.length;i++){
    let src=lines[i];
    try{if(window.T)src=window.T(src)}catch(e){}
    ls=ls.concat(wrap(ctx,src,maxW));
   }
   const lh=s*(lead||1.35);
   if(ls.length*lh<=maxH||s<=9)break;
   s=Math.max(9,Math.round(s*.9));
  }
  setFont(ctx,s,bold);
  const lh=s*(lead||1.35);
  ctx.fillStyle=col;ctx.textAlign='center';ctx.textBaseline='middle';
  const y0=cy-(ls.length-1)*lh/2;
  for(let i=0;i<ls.length;i++)ctx.fillText(ls[i],cx,y0+i*lh);
  return ls.length*lh;
 }

 // ---------------------------------------------------------------- состояние
 const API={done:false};
 let night=0,sc=null,L=null,t=0,flick=0,glitch=0,noiseT=0;

 // Ввод. Контракт даёт только key(keydown), поэтому направление с клавиатуры
 // живёт коротким таймером (автоповтор клавиши продлевает его) — было бы иначе
 // нельзя идти, не имея keyup. Палец задаёт направление до отпускания.
 const kb={l:0,r:0,u:0,d:0};
 let touch={x:0,y:0,active:false}, act=false, actLatch=0;
 const KHOLD=.20;

 function dirVec(){
  let dx=(kb.r>0?1:0)-(kb.l>0?1:0), dy=(kb.d>0?1:0)-(kb.u>0?1:0);
  if(touch.active){dx+=touch.x;dy+=touch.y}
  const m=Math.hypot(dx,dy);
  return m>0?{x:dx/m,y:dy/m}:{x:0,y:0};
 }
 function takeAct(){const a=act;act=false;return a}

 // ---------------------------------------------------------------- палитры
 // 4-6 цветов на сцену, как на 8-битной консоли.
 const PAL={
  1:{bg:'#140a16',floor:'#3a1c3e',wall:'#5a2b52',ink:'#ffd9a0',hot:'#ff5f7e',cold:'#8d8d99'},
  2:{bg:'#0a0f1a',floor:'#1b2740',wall:'#31456b',ink:'#cfe3ff',hot:'#ff7ab8',cold:'#6d7b96'},
  3:{bg:'#07100c',floor:'#16281f',wall:'#2b4436',ink:'#b8ffd0',hot:'#e8e8f0',cold:'#4d6b57'},
  4:{bg:'#160f04',floor:'#2c1f08',wall:'#4a3510',ink:'#ffe27a',hot:'#ffd23c',cold:'#7a5c22'},
  5:{bg:'#0b0b0b',floor:'#1c1c1c',wall:'#333333',ink:'#d8d8d8',hot:'#8fd0ff',cold:'#5a5a5a'}
 };

 // ---------------------------------------------------------------- сцены
 // Каждая сцена: init / step / paint / hint / truth. Смерть не наказывает:
 // ни одна сцена не откатывает игрока, максимум заканчивается раньше фразой.
 const SCENES={};

 // --- СМЕНА 1: МОНСТР разносит пиццу. Последний ребёнок серый и не берёт.
 SCENES[1]={
  title:'СМЕНА 1 — РАЗДАЧА',
  sub:'ВЕДЁШЬ МОНСТРА. ОТДАЙ ПИЦЦУ ДЕТЯМ.',
  playTime:22,
  init(s){
   s.p={x:12,y:14};
   s.kids=[
    {x:26,y:6,fed:false,grey:false},
    {x:46,y:5,fed:false,grey:false},
    {x:62,y:15,fed:false,grey:false},
    {x:78,y:9,fed:false,grey:false},
    {x:84,y:17,fed:false,grey:true}
   ];
   s.fed=0;s.greyTouch=0;s.msg='';s.msgT=0;
  },
  step(s,dt){
   move(s.p,10,sprW(ART.monster),sprH(ART.monster));
   for(let i=0;i<s.kids.length;i++){
    const k=s.kids[i];
    if(Math.abs(k.x-s.p.x)<7&&Math.abs(k.y-s.p.y)<8){
     if(k.grey){
      if(s.greyTouch<=0){s.greyTouch=1;s.msg='ОН НЕ БЕРЁТ ПИЦЦУ.';s.msgT=3;beep('drip',.35);}
     }else if(!k.fed){
      k.fed=true;s.fed++;s.msg='ВЗЯЛ.';s.msgT=1.2;beep('paper',.4);
     }
    }
   }
   if(s.msgT>0)s.msgT-=dt;
   if(s.fed>=4&&s.greyTouch>0&&s.t>3)finish();
  },
  paint(ctx,s,C){
   px(ctx,L,0,18,GW,GH-18,C.floor);
   for(let i=0;i<7;i++)px(ctx,L,4+i*13,19,7,3,C.wall);   // столы
   px(ctx,L,0,0,GW,2,C.wall);
   for(let i=0;i<s.kids.length;i++){
    const k=s.kids[i], grey=k.grey;
    spr(ctx,L,ART.child,k.x,k.y,{H:grey?C.cold:'#7a3b8a',S:grey?'#9a9aa4':'#ffd9a0',
      E:grey?'#1a1a1a':'#241018',C:grey?C.cold:C.hot,L:grey?'#6c6c76':'#3a1c3e'});
    if(k.fed)spr(ctx,L,ART.pizza,k.x,k.y-5,{R:'#c8452d',Y:C.ink});
   }
   // Было: спрайт сдвигался на -4 и обрезался у верхней кромки поля.
   // Стало: рисуем по своей позиции, а тарелку — на брюхе МОНСТРА.
   spr(ctx,L,ART.monster,s.p.x,s.p.y,{B:'#20101f',E:C.hot,W:C.ink,K:'#0d060c'});
   spr(ctx,L,ART.pizza,s.p.x+2,s.p.y+7,{R:'#c8452d',Y:C.ink});
  },
  hint(s){return s.msgT>0?s.msg:'ПИЦЦА ОТДАНА: '+s.fed+' ИЗ 4'},
  truth(){return['ЧЕТЫРЕ ТАРЕЛКИ РАЗДАНЫ. ПЯТЫЙ РЕБЁНОК НЕ ВЗЯЛ ПИЦЦУ.',
                 'В 1993 ГОДУ ДЕТЕЙ СЧИТАЛИ ПО ТАРЕЛКАМ. ОДНОГО НЕ ХВАТАЕТ ДО СИХ ПОР.']}
 };

 // --- СМЕНА 2: ребёнок идёт по коридору к сцене, ФЕЛИКС зовёт, выход закрывается.
 SCENES[2]={
  title:'СМЕНА 2 — КОРИДОР',
  sub:'ВЕДЁШЬ РЕБЁНКА. ФЕЛИКС ЗОВЁТ НА СЦЕНУ.',
  playTime:24,
  init(s){
   s.p={x:6,y:13};s.door=0;s.call=0;s.ci=0;s.reached=false;
   s.calls=['ИДИ СЮДА','ТУТ ТОРТ','ТЕБЯ ЖДУТ','НЕ ОБОРАЧИВАЙСЯ'];
  },
  step(s,dt){
   move(s.p,11,sprW(ART.child),sprH(ART.child),{y0:9,y1:18});
   s.door=Math.min(1,s.door+dt/9);                       // створка ползёт вниз
   if(s.door>=1&&!s.doorSnd){s.doorSnd=true;beep('bone',.5);glitch=.25}
   s.call-=dt;
   if(s.call<=0){s.call=4;s.ci=(s.ci+1)%s.calls.length;beep('blip',.3)}
   if(s.p.x>GW-16&&!s.reached){s.reached=true;beep('sting',.35);}
   if(s.reached&&s.t>4)finish();
  },
  paint(ctx,s,C){
   px(ctx,L,0,7,GW,2,C.wall);
   px(ctx,L,0,21,GW,GH-21,C.floor);
   px(ctx,L,0,9,GW,12,C.bg);
   for(let i=0;i<10;i++)px(ctx,L,4+i*9,9,2,12,C.wall);   // рёбра коридора
   // Выход за спиной: створка опускается сверху вниз.
   px(ctx,L,0,7,5,14,C.wall);
   px(ctx,L,0,7,5,Math.max(1,Math.round(14*s.door)),C.hot);
   // Сцена справа и ФЕЛИКС на ней.
   px(ctx,L,GW-14,9,14,12,C.floor);
   spr(ctx,L,ART.felix,GW-11,10,{P:C.hot,E:'#fff2b0',W:'#f4f4f4',K:'#2a0d1f'});
   spr(ctx,L,ART.child,s.p.x,s.p.y,{H:'#5a3a2a',S:'#ffd9a0',E:'#201018',C:C.ink,L:C.wall});
   // Реплика Феликса — короткая, в рамке, чтобы не спорить с подсказкой сверху.
   const size=fs(L,.036);setFont(ctx,size,true);
   const txt=s.calls[s.ci], tw=ctx.measureText(txt).width;
   const bx=L.ox+L.gw-tw-size*1.2, by=L.oy+L.P*4;
   ctx.fillStyle='#000';ctx.fillRect(bx-size*.5,by-size*.9,tw+size,size*1.8);
   ctx.strokeStyle=C.hot;ctx.lineWidth=Math.max(1,size*.08);
   ctx.strokeRect(bx-size*.5,by-size*.9,tw+size,size*1.8);
   ctx.fillStyle=C.hot;ctx.textAlign='left';ctx.textBaseline='middle';
   ctx.fillText(txt,bx,by);
  },
  hint(s){return s.door>=1?'ВЫХОД ЗАКРЫТ':'ДО СЦЕНЫ: '+Math.max(0,Math.round(GW-16-s.p.x))}
  ,truth(){return['ФЕЛИКС ЗВАЛ, ПОКА ДВЕРЬ ЗА СПИНОЙ НЕ ЗАКРЫЛАСЬ.',
                  'КОРИДОР ЗАПИРАЮТ СНАРУЖИ. В 1993 ГОДУ ИЗ ЭТОГО КОРИДОРА НЕ ВЫШЛИ.']}
 };

 // --- СМЕНА 3: EXO в вентиляции собирает четыре куска обшивки.
 SCENES[3]={
  title:'СМЕНА 3 — ВЕНТИЛЯЦИЯ',
  sub:'ВЕДЁШЬ EXO. СОБЕРИ ЧЕТЫРЕ КУСКА ОБШИВКИ.',
  playTime:26,
  init(s){
   s.p={x:6,y:4};
   s.bits=[{x:80,y:3,got:false},{x:16,y:19,got:false},{x:52,y:11,got:false},{x:84,y:19,got:false}];
   s.got=0;s.knock=1.5;s.wx=10;s.wd=1;
  },
  step(s,dt){
   move(s.p,12,sprW(ART.exo),sprH(ART.exo));
   for(let i=0;i<s.bits.length;i++){
    const b=s.bits[i];
    if(!b.got&&Math.abs(b.x-s.p.x)<6&&Math.abs(b.y-s.p.y)<7){b.got=true;s.got++;beep('switch',.4)}
   }
   // Кто-то ходит за стеной: силуэт мотается вдоль верхней шахты и стучит.
   s.wx+=s.wd*14*dt; if(s.wx>GW-14||s.wx<6)s.wd*=-1;
   s.knock-=dt;
   if(s.knock<=0){s.knock=2.2+Math.random();beep('bone',.3);glitch=.12}
   if(s.got>=4&&s.t>3)finish();
  },
  paint(ctx,s,C){
   // Шахты: три горизонтальных рукава и перемычки.
   px(ctx,L,0,0,GW,GH,C.bg);
   const arms=[2,10,18];
   for(let i=0;i<arms.length;i++)px(ctx,L,2,arms[i],GW-4,6,C.floor);
   px(ctx,L,20,2,6,22,C.floor);px(ctx,L,60,2,6,22,C.floor);
   for(let i=0;i<arms.length;i++)for(let j=0;j<GW-6;j+=6)px(ctx,L,3+j,arms[i],1,6,C.wall);
   // За стеной — тень, отделённая решёткой.
   spr(ctx,L,ART.monster,s.wx,0,{B:C.cold,E:C.hot,W:C.cold,K:C.cold});
   for(let j=0;j<GW;j+=3)px(ctx,L,j,0,2,2,C.bg);
   for(let i=0;i<s.bits.length;i++){
    const b=s.bits[i];if(b.got)continue;
    spr(ctx,L,ART.plate,b.x,b.y,{M:C.ink,K:C.wall});
   }
   spr(ctx,L,ART.exo,s.p.x,s.p.y,{G:'#c3c8d2',E:C.hot});
   for(let i=0;i<s.got;i++)spr(ctx,L,ART.plate,s.p.x-1+i*2,s.p.y+2,{M:C.ink,K:C.wall});
  },
  hint(s){return 'ОБШИВКА: '+s.got+' ИЗ 4   ЗА СТЕНОЙ КТО-ТО ХОДИТ'},
  truth(){return['EXO СОБРАЛ ЧЕТЫРЕ КУСКА ОБШИВКИ. ОНИ НЕ ЕГО.',
                 'ОБШИВКУ СНЯЛИ, ЧТОБЫ ВНУТРЬ КОСТЮМА ПОМЕСТИЛОСЬ ЧТО-ТО ЕЩЁ.']}
 };

 // --- СМЕНА 4: LAV заводит шкатулки в четырёх комнатах.
 SCENES[4]={
  title:'СМЕНА 4 — ШКАТУЛКИ',
  sub:'ВЕДЁШЬ LAV. КРУТИ КЛЮЧ: ДЕЙСТВИЕ У ШКАТУЛКИ.',
  playTime:26,
  init(s){
   s.p={x:44,y:11};
   // Было: нижние комнаты стояли на y=19 и полоска завода уезжала за кромку.
   // Стало: y=17 — шкатулка и её полоска целиком внутри поля.
   s.rooms=[{x:14,y:4},{x:70,y:4},{x:14,y:17},{x:70,y:17}];
   s.w=[1,.85,.7,.55];s.dead=[false,false,false,false];s.msg='';s.msgT=0;s.note=0;
  },
  step(s,dt){
   move(s.p,12,sprW(ART.lav),sprH(ART.lav));
   const a=takeAct();
   for(let i=0;i<4;i++){
    if(s.dead[i])continue;
    s.w[i]-=dt*(.055+i*.012);
    if(s.w[i]<=0){s.w[i]=0;s.dead[i]=true;s.msg='ШКАТУЛКА '+(i+1)+' ВСТАЛА.';s.msgT=2.5;beep('blackout',.4);glitch=.3}
   }
   if(a){
    let near=-1;
    for(let i=0;i<4;i++){
     const r=s.rooms[i];
     if(Math.abs(r.x-s.p.x)<10&&Math.abs(r.y-s.p.y)<9){near=i;break}
    }
    if(near>=0&&!s.dead[near]){s.w[near]=1;beep('blip',.35);s.msg='ЗАВЕДЕНА.';s.msgT=1}
    else if(near<0){s.msg='ПОДОЙДИ К ШКАТУЛКЕ.';s.msgT=1.2}
   }
   s.note-=dt;
   if(s.note<=0){s.note=.9;if(s.dead.indexOf(false)>=0)beep('blip',.12)}
   if(s.msgT>0)s.msgT-=dt;
   if(s.dead[0]&&s.dead[1]&&s.dead[2]&&s.dead[3]){s.silence=true;finish()}
  },
  paint(ctx,s,C){
   px(ctx,L,0,0,GW,GH,C.floor);
   px(ctx,L,44,0,4,GH,C.wall);px(ctx,L,0,12,GW,3,C.wall);   // крест стен
   px(ctx,L,44,12,4,3,C.floor);                              // проход в центре
   px(ctx,L,44,5,4,3,C.floor);px(ctx,L,44,20,4,3,C.floor);
   for(let i=0;i<4;i++){
    const r=s.rooms[i];
    spr(ctx,L,ART.box,r.x,r.y,{M:s.dead[i]?C.cold:'#8a5a1c',K:s.dead[i]?C.cold:C.hot,W:C.ink});
    // Полоска завода прямо под шкатулкой — читается без текста.
    px(ctx,L,r.x,r.y+7,7,1,C.wall);
    if(!s.dead[i])px(ctx,L,r.x,r.y+7,Math.max(.4,7*s.w[i]),1,C.hot);
    else px(ctx,L,r.x,r.y+7,7,1,C.cold);
   }
   spr(ctx,L,ART.lav,s.p.x,s.p.y,{Y:'#e8c23a',E:'#201408',W:'#2a1a06',K:'#4a3510'});
  },
  hint(s){
   if(s.msgT>0)return s.msg;
   let alive=0;for(let i=0;i<4;i++)if(!s.dead[i])alive++;
   return 'ИГРАЮТ: '+alive+' ИЗ 4';
  },
  truth(s){
   const a=['LAV ЗАВОДИЛ ЧЕТЫРЕ ШКАТУЛКИ ОДИН, ВСЮ НОЧЬ.'];
   if(s&&s.silence)a.push('ВСЕ ЧЕТЫРЕ ВСТАЛИ. СТАЛО ТИХО.');
   a.push('КОГДА МУЗЫКА КОНЧАЕТСЯ, ШКАТУЛКУ ОТКРЫВАЮТ ИЗНУТРИ.');
   return a;
  }
 };

 // --- СМЕНА 5: прошлый охранник идёт к архиву под залом за кассетой 1993 года.
 SCENES[5]={
  title:'СМЕНА 5 — АРХИВ',
  sub:'ВЕДЁШЬ ПРОШЛОГО ОХРАННИКА. КАССЕТА 1993 ВНИЗУ.',
  playTime:24,
  init(s){s.p={x:8,y:14};s.door=64;s.scroll=0;s.warn=0;s.step=0}
  ,
  step(s,dt){
   const before=s.p.x;
   move(s.p,11,sprW(ART.guard),sprH(ART.guard),{y0:10,y1:19});
   // Зачем так: дверь архива всегда отодвигается чуть быстрее шага — охранник
   // физически не может дойти, но игрок этого не чувствует как блокировку.
   const gained=s.p.x-before;
   if(gained>0){s.door+=gained*1.05;s.scroll+=gained*.6}
   if(s.door>GW-12){const back=s.door-(GW-12);s.door-=back;s.p.x=Math.max(4,s.p.x-back)}
   s.step-=dt;
   if(s.step<=0){s.step=.55;beep('switch',.12)}
   s.warn-=dt;
   if(s.warn<=0){s.warn=5;glitch=.2;beep('rumble',.2)}
  },
  paint(ctx,s,C){
   px(ctx,L,0,0,GW,GH,C.bg);
   px(ctx,L,0,8,GW,2,C.wall);
   px(ctx,L,0,20,GW,GH-20,C.floor);
   // Лестница вниз слева и уходящие вдаль полки.
   for(let i=0;i<8;i++)px(ctx,L,2+i*2,20+((i%3===0)?0:0),2,GH-20,i%2?C.wall:C.floor);
   for(let i=0;i<12;i++){
    const x=(((i*9)-s.scroll)%(GW+9)+GW+9)%(GW+9)-9;
    px(ctx,L,x,10,2,10,C.wall);
   }
   // Дверь архива с кассетой на полке.
   px(ctx,L,s.door,9,10,11,C.wall);
   px(ctx,L,s.door+2,11,6,7,C.bg);
   spr(ctx,L,ART.tape,s.door+2,13,{M:C.hot,W:C.bg});
   spr(ctx,L,ART.guard,s.p.x,s.p.y,{U:'#2a3a4a',S:'#e8c39a',E:'#141414',C:'#43506b',F:C.hot,K:'#1a1a1a'});
   // Табличка «АРХИВ» строго над дверью, размер от H — не наезжает на подсказку.
   const size=fs(L,.034);setFont(ctx,size,true);
   ctx.fillStyle=C.hot;ctx.textAlign='center';ctx.textBaseline='bottom';
   ctx.fillText('АРХИВ',L.ox+(s.door+5)*L.P,L.oy+9*L.P-size*.3);
  },
  hint(s){return 'КАССЕТА 1993 — ДАЛЬШЕ ПО КОРИДОРУ'},
  truth(){return['ОХРАННИК ШЁЛ К АРХИВУ ПОД ЗАЛОМ И НЕ ДОШЁЛ.',
                 'КАССЕТА 1993 ГОДА ОСТАЛАСЬ НА ПОЛКЕ. ЕЁ НЕ ЗАБРАЛ НИКТО.',
                 'ОНА ВСЁ ЕЩЁ ТАМ. ПОД ЗАЛОМ.']}
 };

 // ---------------------------------------------------------------- движение
 // Один общий шаг для всех сцен: клетка спрайта не выходит за поле.
 function move(p,speed,w,h,lim){
  const d=dirVec(); if(!d.x&&!d.y)return;
  const dt=sc?sc.dt:0;
  p.x+=d.x*speed*dt; p.y+=d.y*speed*dt;
  const y0=lim&&lim.y0!=null?lim.y0:0, y1=lim&&lim.y1!=null?lim.y1:GH-h;
  p.x=Math.max(1,Math.min(GW-w-1,p.x));
  p.y=Math.max(y0,Math.min(Math.min(GH-h,y1),p.y));
 }
 function finish(){if(sc&&sc.phase==='play'){sc.phase='out';sc.t=0;beep('sting',.3);glitch=.35}}

 // ---------------------------------------------------------------- контракт
 function available(n){return !!SCENES[n|0]}

 function start(G,n){
  night=n|0;
  const def=SCENES[night];
  API.done=false;
  if(!def){sc=null;API.done=true;return}
  sc={def,phase:'in',t:0,dt:0,silence:false};
  def.init(sc);
  kb.l=kb.r=kb.u=kb.d=0;act=false;touch={x:0,y:0,active:false};
  t=0;glitch=.15;flick=0;
  beep('switch',.35);
 }

 function stop(){sc=null;night=0;API.done=false;kb.l=kb.r=kb.u=kb.d=0;act=false;touch={x:0,y:0,active:false}}

 function update(dt,G){
  if(!sc){API.done=true;return}
  const d=Math.max(0,Math.min(.05,dt||0));
  sc.dt=d;sc.t+=d;t+=d;
  flick+=d;
  if(glitch>0)glitch-=d;
  noiseT-=d;
  if(noiseT<=0){noiseT=1.2+Math.random()*2.5;glitch=Math.max(glitch,.09)}
  for(const k in kb)if(kb[k]>0)kb[k]-=d;
  if(sc.phase==='in'){ if(sc.t>2.2){sc.phase='play';sc.t=0} takeAct(); return }
  if(sc.phase==='play'){
   sc.def.step(sc,d);
   if(sc.phase==='play'&&sc.t>sc.def.playTime){sc.phase='out';sc.t=0;beep('sting',.28);glitch=.3}
   return;
  }
  // Финальная карточка с правдой: 5 секунд, дальше сцена сама себя закрывает.
  if(sc.t>5||takeAct()&&sc.t>1.2)API.done=true;
 }

 function draw(ctx,W,H,G){
  L=layout(W,H);
  ctx.save();
  ctx.fillStyle='#000';ctx.fillRect(0,0,W,H);            // фон всегда чёрный
  if(!sc){ctx.restore();return}
  const C=PAL[night]||PAL[1];
  if(sc.phase==='in')drawCard(ctx,[sc.def.title,sc.def.sub],C.ink,C);
  else if(sc.phase==='out')drawCard(ctx,sc.def.truth(sc),C.hot,C,'ПРАВДА '+night+'/5');
  else{
   px(ctx,L,0,0,GW,GH,C.bg);
   sc.def.paint(ctx,sc,C);
   drawTop(ctx,C);
   drawPad(ctx,C);
  }
  drawScan(ctx,W,H);
  ctx.restore();
 }

 // Карточка (вступление и правда) — на весь экран, без экранных кнопок,
 // поэтому текст никогда не спорит с джойстиком.
 function drawCard(ctx,lines,col,C,cap){
  const maxW=L.W*.86;
  if(cap){
   const s=fs(L,.045);setFont(ctx,s,true);
   ctx.fillStyle=C.cold;ctx.textAlign='center';ctx.textBaseline='middle';
   ctx.fillText(cap,L.W/2,L.H*.16);
  }
  block(ctx,L,lines,L.W/2,L.H*.5,maxW,L.H*.52,fs(L,.062),col,true,1.45);
  const s2=fs(L,.036);setFont(ctx,s2,false);
  ctx.fillStyle=C.cold;ctx.textAlign='center';ctx.textBaseline='middle';
  ctx.fillText('ДАЛЕЕ — ДЕЙСТВИЕ',L.W/2,L.H*.9);
 }

 // Верхняя полоса: название сцены слева, подсказка справа, обе с лимитом ширины.
 function drawTop(ctx,C){
  const s=fs(L,.042);setFont(ctx,s,true);
  ctx.textBaseline='middle';
  ctx.fillStyle=C.cold;ctx.textAlign='left';
  const title=sc.def.title;
  let ts=s;while(ctx.measureText(title).width>L.W*.42&&ts>9){ts=Math.round(ts*.92);setFont(ctx,ts,true)}
  ctx.fillText(title,L.padX,L.top*.42);
  const hint=String(sc.def.hint(sc)||'');
  let hs=s;setFont(ctx,hs,true);
  while(ctx.measureText(hint).width>L.W*.52&&hs>9){hs=Math.round(hs*.92);setFont(ctx,hs,true)}
  ctx.fillStyle=C.ink;ctx.textAlign='right';
  ctx.fillText(hint,L.W-L.padX,L.top*.42);
  // Таймер сцены полоской под текстом — без цифр, чтобы не занимать место.
  const p=Math.max(0,1-sc.t/sc.def.playTime);
  ctx.fillStyle='#222';ctx.fillRect(L.padX,L.top*.78,L.W-L.padX*2,Math.max(2,L.H*.008));
  ctx.fillStyle=C.hot;ctx.fillRect(L.padX,L.top*.78,(L.W-L.padX*2)*p,Math.max(2,L.H*.008));
 }

 // Экранное управление: крестовина слева, кнопка действия справа.
 // Зачем так: игра обязана проходиться одним пальцем.
 function drawPad(ctx,C){
  const d=L.dpad,a=L.act,u=d.r*.62;
  ctx.globalAlpha=.42;
  ctx.fillStyle=C.wall;
  ctx.fillRect(d.cx-u*1.5,d.cy-u*.5,u*3,u);
  ctx.fillRect(d.cx-u*.5,d.cy-u*1.5,u,u*3);
  ctx.globalAlpha=.85;
  ctx.fillStyle=C.ink;
  const t2=u*.28;
  tri(ctx,d.cx-u*1.1,d.cy,t2,'l');tri(ctx,d.cx+u*1.1,d.cy,t2,'r');
  tri(ctx,d.cx,d.cy-u*1.1,t2,'u');tri(ctx,d.cx,d.cy+u*1.1,t2,'d');
  ctx.globalAlpha=.5;ctx.fillStyle=C.hot;
  ctx.beginPath();ctx.arc(a.cx,a.cy,a.r,0,Math.PI*2);ctx.fill();
  ctx.globalAlpha=1;
  const s=fs(L,.036);setFont(ctx,s,true);
  ctx.fillStyle='#0a0a0a';ctx.textAlign='center';ctx.textBaseline='middle';
  ctx.fillText('ОК',a.cx,a.cy);
 }
 function tri(ctx,x,y,r,dir){
  ctx.beginPath();
  if(dir==='l'){ctx.moveTo(x-r,y);ctx.lineTo(x+r,y-r);ctx.lineTo(x+r,y+r)}
  if(dir==='r'){ctx.moveTo(x+r,y);ctx.lineTo(x-r,y-r);ctx.lineTo(x-r,y+r)}
  if(dir==='u'){ctx.moveTo(x,y-r);ctx.lineTo(x-r,y+r);ctx.lineTo(x+r,y+r)}
  if(dir==='d'){ctx.moveTo(x,y+r);ctx.lineTo(x-r,y-r);ctx.lineTo(x+r,y-r)}
  ctx.closePath();ctx.fill();
 }

 // Развёртка: дрожащие строки плюс редкий кадр-помеха.
 function drawScan(ctx,W,H){
  const step=Math.max(3,Math.round(H/180));
  ctx.globalAlpha=.16;ctx.fillStyle='#000';
  const jit=Math.sin(flick*7)*step*.5;
  for(let y=0;y<H;y+=step*2)ctx.fillRect(0,Math.round(y+jit),W,step);
  // Было: белые полосы-помехи били и по карточкам с текстом, из-за чего строки
  // выглядели порванными. Стало: на карточках помеха только тёмная и слабее.
  if(glitch>0){
   const card=sc&&sc.phase!=='play';
   ctx.globalAlpha=Math.min(card?.2:.5,glitch*(card?.6:1.4));
   for(let i=0;i<7;i++){
    const y=Math.random()*H;
    ctx.fillStyle=(!card&&i%2)?'#ffffff':'#000000';
    ctx.fillRect(Math.random()*W*.3,y,W*(.3+Math.random()*.7),Math.max(2,H*.012));
   }
  }
  ctx.globalAlpha=1;
 }

 // keydown; если главный агент прокинет keyup — гасим направление сразу.
 function key(e){
  if(!e)return;
  const k=(e.key||'').toLowerCase(),code=e.code||'';
  const up=e.type==='keyup';
  const set=(n)=>{kb[n]=up?0:KHOLD};
  if(k==='arrowleft'||k==='a'||code==='KeyA')set('l');
  else if(k==='arrowright'||k==='d'||code==='KeyD')set('r');
  else if(k==='arrowup'||k==='w'||code==='KeyW')set('u');
  else if(k==='arrowdown'||k==='s'||code==='KeyS')set('d');
  else if(!up&&(k==='enter'||k===' '||k==='spacebar'||code==='Space'||code==='Enter'))act=true;
  else if(!up&&(k==='escape'||code==='Escape')){API.done=true;beep('switch',.25)}
 }

 // Палец: левая половина низа — крестовина, правая — действие.
 // Если раскладки ещё нет (draw не вызывался) — считаем её на месте.
 function pointer(x,y,W,H,down){
  const M=L&&L.W===W&&L.H===H?L:layout(W,H);
  if(!down){touch={x:0,y:0,active:false};return}
  const a=M.act;
  if(Math.hypot(x-a.cx,y-a.cy)<=a.r*1.35){act=true;touch={x:0,y:0,active:false};return}
  const d=M.dpad;
  if(x<M.W*.5&&y>M.H*.45){
   const dx=x-d.cx,dy=y-d.cy,m=Math.hypot(dx,dy);
   if(m<d.r*.28){touch={x:0,y:0,active:false};return}
   // Оси разделены: по большей проекции — чтобы палец не «плыл» по диагонали.
   if(Math.abs(dx)>Math.abs(dy)*1.6)touch={x:dx>0?1:-1,y:0,active:true};
   else if(Math.abs(dy)>Math.abs(dx)*1.6)touch={x:0,y:dy>0?1:-1,active:true};
   else touch={x:dx>0?1:-1,y:dy>0?1:-1,active:true};
   return;
  }
  if(x>=M.W*.5)act=true;                 // тап по правой половине = действие
 }

 return {available,start,stop,update,draw,key,pointer,
  get done(){return API.done}, set done(v){API.done=!!v}};
})();
