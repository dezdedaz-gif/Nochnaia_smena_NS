window.AudioFX=(()=>{
 let muted=false, music=null, radioMusic=null, menuMusic=null, calmMenuMusic=null, ready=false, unlocked=false, victoryTimer=null, victoryNodes=[];
 let radioOn=false;
 // Приглушение (ducking): когда по радио идёт песня, все прочие звуки тише,
 // чтобы музыка звучала атмосферно и «занимала» комнату.
 let duck=1, duckStamp=performance.now();
 const DUCK_LEVEL=.42;
 function tickDuck(){
   const now=performance.now();
   const dt=Math.max(0,Math.min(.5,(now-duckStamp)/1000));
   duckStamp=now;
   const target=radioOn?DUCK_LEVEL:1;
   // Плавно: быстро приглушаем, медленнее возвращаем.
   const k=1-Math.exp(-dt*(target<duck?4.5:1.8));
   duck+=(target-duck)*k;
   if(Math.abs(target-duck)<.005)duck=target;
   return duck;
 }
 const files={
  click:'assets/sfx/ui_click.wav',
  // Новый звук дверей охранной (открытие/закрытие створки).
  door:'assets/sfx/door_move.mp3',
  // Старый мотор остался для шагов и возни аниматроников в глубине здания.
  doorMotor:'assets/sfx/door_motor.wav',
  thud:'assets/sfx/door_thud.wav', tabletOpen:'assets/sfx/tablet_open.wav',
  tabletClose:'assets/sfx/tablet_close.wav', cam:'assets/sfx/camera_switch.wav',
  light:'assets/sfx/light_click.wav', radio:'assets/sfx/radio_static.wav',
  phone:'assets/sfx/phone_ring.wav', scream:'assets/sfx/scream.wav',
  repair:'assets/sfx/repair.wav', hum:'assets/sfx/hum.wav', menu:'assets/sfx/menu_horror_drone.wav', button:'assets/sfx/button_click_horror.wav', metal_bellow:'assets/sfx/metal_bellow.wav', phone_line:'assets/sfx/phone_line.wav', phone_whisper:'assets/sfx/phone_whisper.wav', stepAlt:'assets/sfx/monster_step_alt.wav',guardVoice:'assets/sfx/guard_night1_voice.wav',guard_night1_phone:'assets/sfx/guard_night1_voice.wav',camera_glitch:'assets/sfx/camera_glitch.wav',camera_click:'assets/sfx/camera_click.wav',felix_warning:'assets/sfx/felix_warning.wav',monster_heavy:'assets/sfx/monster_heavy.wav',industrial20:'assets/sfx/industrial_call_20s.wav',tarhun:'assets/sfx/tarhun_eat_me.wav',number666:'assets/sfx/number_666_growl.wav',number1488:'assets/sfx/number_1488_blocked.wav',ventAmbient:'assets/sfx/vent_ambient.mp3',monsterDistant:'assets/sfx/monster_distant.mp3',
  // V89: скример «СТЁПА» (номер 79503843858). stepa_scream — синтезирован
  // специально для игры, не готовый семпл из библиотеки.
  stepa_call:'assets/sfx/stepa_call.mp3',stepa_after:'assets/sfx/stepa_after.mp3',stepa_scream:'assets/sfx/stepa_scream.wav'
 };
 const groups={music:'music',ambience:'ambience',monster:'monster',radio:'radio',phone:'phone',ui:'ui',menu:'ambience',ventAmbient:'ambience',monsterDistant:'monster'};
 const cache={};
 // Живые копии звуков: каждый вызов play() проигрывается на своём элементе,
 // поэтому быстрые повторные щелчки (дверь туда-обратно) не обрывают друг друга,
 // а stopAll() всё равно может остановить всё разом.
 const live=new Set();
 // V103: ТРЕБОВАНИЕ ЯНДЕКС ИГР — «в любых браузерах не отображается системный
 // плеер, вызываемый игрой».
 // ПОЧЕМУ ТАК БЫЛО: музыка и звуки создаются обычными элементами <audio>. На
 // iOS и в части Android-браузеров такой элемент попадает в системный плеер:
 // на экране блокировки и в шторке появляется «трек» с кнопками, а игрок может
 // остановить оттуда звук игры. Модерация считает это нарушением.
 // СТАЛО: каждый созданный элемент помечается как встроенный и невыносимый
 // наружу (playsinline, без пульта, без AirPlay, без remote playback), а
 // mediaSession принудительно очищается — площадке нечего показывать в плеере.
 function noSystemPlayer(a){
   try{
     a.playsInline=true;
     a.setAttribute('playsinline','');
     a.setAttribute('webkit-playsinline','');
     a.setAttribute('x-webkit-airplay','deny');
     a.controls=false;
     a.disableRemotePlayback=true;
     a.setAttribute('disableremoteplayback','');
   }catch(e){}
   return a;
 }
 try{
   if(navigator.mediaSession){
     navigator.mediaSession.metadata=null;
     try{navigator.mediaSession.playbackState='none'}catch(e){}
     ['play','pause','stop','seekto','previoustrack','nexttrack'].forEach(k=>{
       try{navigator.mediaSession.setActionHandler(k,null)}catch(e){}
     });
   }
 }catch(e){}
 function load(src){if(!cache[src]){cache[src]=noSystemPlayer(new Audio(src));cache[src].preload='auto'}return cache[src]}
 function spawn(src){
   const base=load(src);
   let a=null;
   try{a=base.cloneNode(true)}catch(e){a=null}
   if(!a||typeof a.play!=='function')a=new Audio(src);
   noSystemPlayer(a);
   a.preload='auto';a.playsInline=true;a.loop=false;
   live.add(a);
   const done=()=>{live.delete(a)};
   a.addEventListener('ended',done,{once:true});
   a.addEventListener('error',done,{once:true});
   setTimeout(done,20000);
   return a;
 }
 function gain(group){return Math.max(0,Math.min(1,window.SaveSystem.settings[group]??window.SaveSystem.settings.sfx??.5))}
 function playElement(src,volume,rate){
   let a=null;
   try{
     a=spawn(src);
     a.currentTime=0;
     a.volume=volume;
     if(rate&&rate>0){try{a.preservesPitch=false;a.mozPreservesPitch=false;a.webkitPreservesPitch=false;}catch(_){}
       a.playbackRate=Math.max(0.5,Math.min(2,rate));}
     a.play().catch(()=>{});
   }catch(e){try{a&&a.play().catch(()=>{})}catch(_){}}
   return a;
 }
 // V70: «мрачные голоса». Все неигроковые голоса звучат ниже и чуть по-разному
 // при каждом воспроизведении. Голос прошлого охранника в этот список НЕ входит
 // и звучит ровно так, как записан.
 const GUARD_VOICES=['guardVoice','guard_night1_phone','guard_night1_voice'];
 const DARK_VOICES={stepa_call:0.82,stepa_after:0.82,stepa_scream:0.94,tarhun:0.84,felix_warning:0.80,phone_whisper:0.76,number666:0.86,number1488:0.88,metal_bellow:0.90,scream:0.92,monster_heavy:0.88,monsterDistant:0.90};
 function voiceRate(name,opts){
   if(opts&&opts.rate)return opts.rate;
   if(GUARD_VOICES.includes(name))return 0;          // охранник — без обработки
   const base=DARK_VOICES[name];if(!base)return 0;
   return base*(0.965+Math.random()*0.07);           // лёгкий разброс на каждый вызов
 }
 function play(name,vol=1,opts={}){
   if(muted)return null;
   const src=files[name]; if(!src)return null;
   const grp=opts.group||groups[name]||'ui';
   // Радио и явно помеченные звуки не приглушаются.
   const d=(grp==='radio'||opts.noDuck)?1:tickDuck();
   const volume=Math.max(0,Math.min(1,gain(grp)*vol*d));
   if(volume<=0)return null;
   // С панорамой: если семпл уже декодирован — играем его через Web Audio
   // (точно, без обрывов, со стерео). Если нет — СРАЗУ играем обычным
   // <audio> (звук есть всегда, даже при запуске с диска file://) и декодируем впрок.
   const rate=voiceRate(name,opts);
   if('pan' in opts && !rate){
     if(SpatialAudio.playBuffer(src,volume,opts.pan))return null;
     SpatialAudio.prepare(src);
     return playElement(src,volume,rate);
   }
   return playElement(src,volume,rate);
 }
 // ==== V70: процедурные звуки. Нужны там, где готового файла нет: интерфейс,
 // предметы в комнате охраны, сердцебиение, дыхание, катсцены смерти. ====
 let _sc=null;
 function sctx(){try{const C=window.AudioContext||window.webkitAudioContext;if(!C)return null;if(!_sc)_sc=new C();_sc.resume().catch(()=>{});return _sc;}catch(e){return null}}
 function noiseBuf(c,sec){
   const n=Math.floor(c.sampleRate*sec),b=c.createBuffer(1,n,c.sampleRate),d=b.getChannelData(0);
   for(let i=0;i<n;i++)d[i]=(Math.random()*2-1);
   return b;
 }
 function synth(kind,vol=1){
   if(muted)return;
   const c=sctx();if(!c)return;
   const grp=kind==='click'||kind==='switch'||kind==='paper'?'ui':kind==='heartbeat'||kind==='breath'?'ambience':'monster';
   const v=Math.max(0,Math.min(1,gain(grp)*vol));if(v<=0)return;
   const now=c.currentTime,out=c.createGain();out.gain.value=v;out.connect(c.destination);
   const osc=(type,f0,f1,t0,dur,g0,g1)=>{const o=c.createOscillator(),g=c.createGain();o.type=type;
     o.frequency.setValueAtTime(f0,now+t0);o.frequency.exponentialRampToValueAtTime(Math.max(20,f1),now+t0+dur);
     g.gain.setValueAtTime(Math.max(0.0001,g0),now+t0);g.gain.exponentialRampToValueAtTime(Math.max(0.0001,g1),now+t0+dur);
     o.connect(g);g.connect(out);o.start(now+t0);o.stop(now+t0+dur+0.02);};
   const noise=(t0,dur,g0,lp,hp)=>{const s2=c.createBufferSource();s2.buffer=noiseBuf(c,dur+0.05);
     const f=c.createBiquadFilter();f.type='lowpass';f.frequency.value=lp||1200;
     const g=c.createGain();g.gain.setValueAtTime(g0,now+t0);g.gain.exponentialRampToValueAtTime(0.0001,now+t0+dur);
     let node=s2;node.connect(f);let tail=f;
     if(hp){const h=c.createBiquadFilter();h.type='highpass';h.frequency.value=hp;f.connect(h);tail=h;}
     tail.connect(g);g.connect(out);s2.start(now+t0);s2.stop(now+t0+dur+0.05);};
   switch(kind){
     case 'switch': noise(0,0.05,0.5,3200,800);osc('square',180,90,0,0.05,0.18,0.001);break;
     case 'paper': noise(0,0.22,0.28,5200,1400);break;
     case 'sip': noise(0,0.30,0.20,900,120);osc('sine',220,120,0,0.28,0.06,0.001);break;
     case 'fan': osc('sawtooth',60,52,0,1.2,0.10,0.02);noise(0,1.2,0.10,600);break;
     case 'heartbeat': osc('sine',62,34,0,0.16,0.55,0.001);osc('sine',56,30,0.24,0.20,0.38,0.001);break;
     case 'breath': noise(0,0.55,0.16,700,180);noise(0.62,0.45,0.10,600,160);break;
     case 'drip': osc('sine',900,300,0,0.10,0.20,0.001);break;
     case 'thunder': noise(0,1.9,0.55,320);osc('sine',48,26,0,1.9,0.30,0.001);break;
     case 'sting': osc('sawtooth',1300,220,0,0.55,0.30,0.001);osc('square',760,120,0.02,0.5,0.16,0.001);noise(0,0.35,0.30,4000,700);break;
     case 'rumble': osc('sine',44,28,0,2.6,0.35,0.02);noise(0,2.6,0.10,240);break;
     case 'grab': noise(0,0.35,0.65,2600,300);osc('sawtooth',210,60,0,0.4,0.42,0.001);osc('square',90,40,0.05,0.5,0.30,0.001);break;
     case 'squelch': noise(0,0.28,0.55,1400,90);osc('sine',150,52,0,0.3,0.30,0.001);noise(0.24,0.34,0.32,700,60);break;
     case 'bone': noise(0,0.10,0.60,5200,1800);osc('square',420,120,0,0.12,0.28,0.001);break;
     case 'metalDrag': noise(0,1.1,0.30,3000,900);osc('sawtooth',120,80,0,1.1,0.10,0.005);break;
     // V73: треск пожара и вспышка воспламенения для финальной катсцены.
     case 'fire': noise(0,2.4,0.26,900,120);noise(0.1,2.2,0.16,3200,1400);osc('sine',70,42,0,2.4,0.16,0.01);break;
     case 'ignite': noise(0,0.9,0.55,1800,200);osc('sawtooth',160,48,0,0.9,0.30,0.001);break;
     // V74: пружинный механизм костюма, хруст рёбер, хрип и сухой смешок.
     case 'springlock': for(let i=0;i<7;i++){noise(i*0.055,0.06,0.55-i*0.05,6200-i*400,2200);osc('square',900-i*90,180,i*0.055,0.07,0.20,0.001);}osc('sawtooth',120,38,0,0.9,0.28,0.001);break;
     case 'ribcrack': for(let i=0;i<5;i++){noise(i*0.11,0.09,0.62-i*0.08,5200,1600);osc('square',380-i*40,110,i*0.11,0.10,0.26,0.001);}noise(0.1,0.6,0.20,700,80);break;
     case 'gurgle': noise(0,0.9,0.30,600,60);osc('sine',120,44,0,0.9,0.16,0.001);noise(0.5,0.7,0.20,420,50);break;
     case 'laugh': for(let i=0;i<5;i++){noise(i*0.14,0.10,0.26,1500,220);osc('sawtooth',210-i*14,140-i*10,i*0.14,0.11,0.12,0.001);}break;
     // V94: отключение питания. Было — один съезжающий тон и полсекунды шума.
     // Стало: удар рубильника, писк умирающих ламп, воздух, уходящий из
     // вентиляции, и трёхсекундный провал в инфразвук. Основной слой пишет
     // MonsterAudio.powerDown(), это — его продолжение в общем тракте.
     case 'blackout':
       noise(0,0.06,0.42,3400,900);osc('square',720,150,0,0.08,0.20,0.001);
       osc('sine',180,22,0,2.2,0.30,0.001);osc('sine',72,15,0.04,3.4,0.26,0.001);
       osc('square',8600,1200,0.02,0.9,0.030,0.001);
       noise(0.03,1.7,0.20,1100,140);noise(0.9,1.5,0.10,480,90);
       osc('sine',41,40,2.4,4.2,0.075,0.001);osc('sine',41.7,41,2.4,4.2,0.070,0.001);
       break;
     // =====================================================================
     // V100: АТМОСФЕРНЫЕ ЗВУКИ ДЛЯ НАЧАЛА КОНЦОВОК.
     // Раньше финал открывался в полной тишине: первый звук приходил через
     // 1.4–2.5 секунды и это был короткий выдох или щелчок. Начало читалось
     // как «кадр включили», а не как вступление. Ниже — пять новых голосов:
     // тихий колокол (красивый вход), нарастание (тревога), обрыв нарастания
     // ударом, зал воздуха и провал в инфразвук.
     // =====================================================================
     // Мягкий колокол: три обертона одной ноты с долгим затуханием. Первый
     // звук концовки — он должен быть КРАСИВЫМ, а не пугающим.
     case 'shimmer':
       osc('sine',1046.50,1046.50,0.00,2.60,0.075,0.0005);
       osc('sine',1567.98,1567.90,0.03,2.10,0.038,0.0005);
       osc('sine',2093.00,2092.80,0.06,1.60,0.020,0.0005);
       osc('sine', 523.25, 523.20,0.00,3.10,0.045,0.0005);
       break;
     // Нарастание: два расстроенных пилообразных тона идут вверх, за ними
     // тянется шумовой подъём. Кончается НЕ затуханием, а обрывом — на этом
     // месте в раскадровке стоит удар.
     case 'atmosRise':
       osc('sawtooth', 68, 720,0.00,3.30,0.020,0.115);
       osc('sawtooth', 71, 752,0.00,3.30,0.016,0.100);
       osc('sine',     34, 180,0.00,3.30,0.070,0.150);
       noise(0.10,3.20,0.020,900,220);
       noise(1.60,1.70,0.030,6200,1500);
       break;
     // Удар-акцент: короткий и злой. Ставится в точку внезапности.
     case 'stab':
       noise(0,0.11,0.62,7200,1400);
       osc('sawtooth',2100,190,0.00,0.46,0.34,0.001);
       osc('square', 1150,150,0.01,0.40,0.18,0.001);
       osc('sine',     96, 34,0.00,1.20,0.30,0.001);
       break;
     // Зал воздуха: длинный отфильтрованный шум с двумя полосами. Держит
     // «комнату» под кадром, пока в ней ничего не происходит.
     case 'windHall':
       noise(0.00,6.40,0.075,380);
       noise(0.35,5.60,0.030,1500,520);
       osc('sine',52,49,0.00,6.40,0.055,0.006);
       break;
     // Провал в инфразвук: чувство, что пол уходит из-под кадра.
     case 'subDrop':
       osc('sine',132,26,0.00,2.80,0.28,0.001);
       osc('sine', 66,19,0.05,3.20,0.22,0.001);
       noise(0.00,0.60,0.10,300);
       break;
     // Гудок в трубке: советская телефонная сеть даёт 425 Гц. Два близких
     // тона с биением и тихий шум линии — звук ожидания ответа.
     case 'ringback':
       osc('sine',425,425,0.00,0.92,0.085,0.070);
       osc('sine',426.8,426.8,0.00,0.92,0.055,0.045);
       noise(0.00,0.94,0.014,2600,900);
       break;
     // =====================================================================
     // V101: НАСТОЯЩИЕ ЗВУКИ ДЛЯ ПЕРЕДЕЛАННЫХ КОНЦОВОК.
     // ПОЧЕМУ ТАК БЫЛО: в финалах на все события шли четыре универсальных
     // тембра — 'grab', 'bone', 'rumble', 'metalDrag'. Кирпичная кладка,
     // обрушение здания, чирк спички, падение тела на траву и каскад
     // спринглоков звучали одинаково: короткий шум с пилой. Ниже — свои
     // голоса на каждое из этих событий, собранные по физике источника.
     // =====================================================================
     // Чирк спички: сначала шершавый протяг по коробку (шум с подъёмом полосы),
     // потом хлопок вспышки и мягкое ровное горение.
     case 'matchStrike':
       noise(0.00,0.09,0.34,2200,700);
       noise(0.05,0.06,0.46,7000,2600);
       osc('sawtooth',300,110,0.05,0.10,0.10,0.001);
       noise(0.13,0.16,0.40,1500,240);
       osc('sine',180,70,0.13,0.20,0.12,0.001);
       noise(0.30,1.60,0.055,700,120);
       break;
     // Обрушение: сначала лопается несущий металл, потом идёт обвал (шум с
     // падающей полосой), под ним инфразвук, сверху — щебень.
     case 'collapse':
       osc('sawtooth',420,90,0.00,0.34,0.20,0.001);
       noise(0.00,0.30,0.50,3600,900);
       noise(0.16,2.60,0.60,900,60);
       noise(0.30,2.20,0.34,240);
       osc('sine',60,20,0.10,3.20,0.42,0.001);
       osc('sine',31,16,0.20,3.60,0.30,0.001);
       for(let i=0;i<9;i++)noise(0.40+i*0.16,0.10,0.16,6000,2200);
       break;
     // Кладка встаёт в проём: восемь глухих ударов кирпича о раствор, каждый
     // тяжелее предыдущего, между ними скрежет мастерка и шорох крошки.
     case 'bricks':
       for(let i=0;i<8;i++){
         const t0=i*0.135;
         noise(t0,0.07,0.30+i*0.030,900,120);
         osc('square',150-i*7,52-i*2,t0,0.09,0.16+i*0.014,0.001);
         if(i%2)noise(t0+0.05,0.09,0.10,4200,1600);
       }
       osc('sine',70,26,0.90,1.40,0.30,0.001);
       noise(1.00,0.80,0.14,600,90);
       break;
     // Падение тела на траву: мягкий глухой удар без металла плюс шорох
     // стеблей и выбитый воздух из груди.
     case 'bodyFall':
       noise(0.00,0.16,0.44,420,40);
       osc('sine',96,30,0.00,0.26,0.34,0.001);
       noise(0.06,0.50,0.20,5200,1900);
       noise(0.20,0.70,0.14,3000,900);
       break;
     case 'grass':
       noise(0.00,0.90,0.13,6200,2200);
       noise(0.25,0.70,0.09,4200,1500);
       break;
     // Удар когтя по спине: рвётся ткань, под ней звенит металл.
     case 'clawSwipe':
       noise(0.00,0.22,0.42,6800,2400);
       osc('sawtooth',900,240,0.00,0.20,0.16,0.001);
       osc('square',260,80,0.04,0.26,0.12,0.001);
       noise(0.10,0.30,0.18,1200,200);
       break;
     case 'bloodDrip':
       osc('sine',640,180,0.00,0.09,0.16,0.001);
       noise(0.00,0.05,0.10,2600,900);
       break;
     // Звон в ушах: два близких высоких тона, долго и ровно. Никотиновый
     // флэшбэк начинается именно с него.
     case 'tinnitus':
       osc('sine',4180,4180,0.00,3.60,0.030,0.0008);
       osc('sine',4212,4212,0.00,3.60,0.024,0.0008);
       osc('sine',8300,8300,0.05,2.40,0.008,0.0008);
       break;
     // Накат флэшбэка: провал вниз, сердце и глухой прилив крови в голову.
     case 'nicotine':
       osc('sine',210,42,0.00,1.60,0.26,0.001);
       osc('sine',105,28,0.06,2.20,0.20,0.001);
       noise(0.00,1.80,0.16,320);
       noise(0.40,1.40,0.07,900,140);
       osc('sine',58,34,0.30,0.22,0.44,0.001);
       osc('sine',54,30,0.72,0.26,0.36,0.001);
       break;
     // РЕАЛЬНАЯ СИСТЕМА КОСТЮМА: двадцать четыре защёлки уходят каскадом.
     // Шаг между щелчками сокращается — механизм срывается, а не тикает.
     case 'springArray':{
       let t0=0;
       for(let i=0;i<24;i++){
         const step=0.075*Math.pow(0.90,i);
         noise(t0,0.035,0.34+0.22*(i/24),7600-i*140,2600);
         osc('square',1500-i*46,300,t0,0.045,0.13+0.07*(i/24),0.001);
         if(i%4===0)osc('triangle',2600-i*60,700,t0,0.06,0.05,0.001);
         t0+=step;
       }
       osc('sawtooth',180,40,0.00,t0+0.5,0.20,0.001);
       osc('sine',48,22,t0*0.6,1.60,0.34,0.001);
       break;}
     // Звуковое извержение: сжатый воздух рвётся из корпуса, за ним звенит
     // металл и уходит длинный шумовой хвост.
     case 'pressureBurst':
       noise(0.00,0.06,0.62,9000,3200);
       noise(0.02,1.10,0.44,2600,600);
       noise(0.10,1.80,0.22,700,100);
       osc('sine',1860,520,0.02,0.70,0.070,0.001);
       osc('sine',2790,760,0.03,0.55,0.040,0.001);
       osc('sine',74,26,0.00,1.60,0.30,0.001);
       break;
     // Стон несущего металла: пила, ползущая вверх с биением.
     case 'metalGroan':
       osc('sawtooth',86,150,0.00,2.40,0.055,0.030);
       osc('sawtooth',88.7,154,0.00,2.40,0.045,0.026);
       osc('sine',43,52,0.00,2.60,0.16,0.010);
       noise(0.20,2.00,0.030,1800,600);
       break;
     // Ригель замка: сухой щелчок с металлическим послезвучием.
     case 'doorLatch':
       noise(0.00,0.045,0.44,7400,2600);
       osc('square',680,180,0.00,0.06,0.20,0.001);
       osc('triangle',1900,900,0.01,0.18,0.030,0.001);
       break;
     // Умиротворение: мажорное трезвучие с долгим затуханием. Ставится на
     // белый финал первой концовки — единственное место в игре, где звук
     // не должен тревожить.
     case 'whiteCalm':
       osc('sine',261.63,261.63,0.00,5.20,0.070,0.0006);
       osc('sine',329.63,329.63,0.10,4.80,0.050,0.0006);
       osc('sine',392.00,392.00,0.20,4.40,0.040,0.0006);
       osc('sine',523.25,523.25,0.30,4.00,0.024,0.0006);
       osc('sine',783.99,783.99,0.45,3.20,0.012,0.0006);
       break;
     default: osc('sine',300,120,0,0.12,0.20,0.001);
   }
 }
 // =========================================================================
 // V100: АТМОСФЕРНАЯ ПОДЛОЖКА КОНЦОВОК («bed»).
 // ПОЧЕМУ ТАК БЫЛО: у финалов были только точечные метки — выдох, щелчок,
 // удар. Между метками стояла абсолютная тишина, и красивый кадр оставался
 // немым; «атмосферных звуков» в концовках не было вообще.
 // СТАЛО: под всю сцену подкладывается непрерывный слой — своя подложка на
 // каждый финал. Она входит и уходит плавно (0.9 с), живёт на общем графе
 // Web Audio и гасится вместе со всем остальным в stopAll().
 // =========================================================================
 let bedNodes=[], bedMaster=null, bedKind=null, bedTimer=null;
 function bedStop(){
   if(bedTimer){clearTimeout(bedTimer);bedTimer=null;}
   if(!bedMaster){bedKind=null;return;}
   const c=_sc, nodes=bedNodes, master=bedMaster;
   bedNodes=[];bedMaster=null;bedKind=null;
   try{if(c){master.gain.cancelScheduledValues(c.currentTime);
     master.gain.setTargetAtTime(0.0001,c.currentTime,0.28);}}catch(e){}
   setTimeout(()=>{nodes.forEach(n=>{try{n.stop&&n.stop()}catch(e){}
     try{n.disconnect&&n.disconnect()}catch(e){}});
     try{master.disconnect()}catch(e){}},1100);
 }
 // kind: dawn (рассвет) | ash (пожарище) | hollow (пустой офис) |
 //       stage (сцена и зал) | archive (подвал с уликами)
 function bedStart(kind,vol=1){
   if(muted)return;
   const c=sctx();if(!c)return;
   if(bedKind===kind&&bedMaster){
     try{bedMaster.gain.setTargetAtTime(Math.max(0.0001,gain('ambience')*vol*0.9),c.currentTime,0.5)}catch(e){}
     return;
   }
   bedStop();
   const v=Math.max(0,Math.min(1,gain('ambience')*vol*0.9));
   if(v<=0.001)return;
   const now=c.currentTime;
   const master=c.createGain();
   master.gain.setValueAtTime(0.0001,now);
   master.gain.exponentialRampToValueAtTime(Math.max(0.0002,v),now+0.9);
   master.connect(c.destination);
   bedMaster=master;bedKind=kind;bedNodes=[];
   // Долгий тон с медленным биением громкости: «дышит», а не гудит ровно.
   const pad=(type,f,g,lfoHz,lfoDepth)=>{
     const o=c.createOscillator(),gn=c.createGain();
     o.type=type;o.frequency.value=f;gn.gain.value=g;
     o.connect(gn);gn.connect(master);o.start(now);
     bedNodes.push(o);
     if(lfoHz){
       const l=c.createOscillator(),lg=c.createGain();
       l.type='sine';l.frequency.value=lfoHz;lg.gain.value=g*(lfoDepth||0.5);
       l.connect(lg);lg.connect(gn.gain);l.start(now);bedNodes.push(l);
     }
     return gn;
   };
   // Непрерывный шум: буфер на 4 секунды крутится по кругу.
   const air=(g,lp,hp,lfoHz)=>{
     const s=c.createBufferSource();s.buffer=noiseBuf(c,4);s.loop=true;
     const f=c.createBiquadFilter();f.type='lowpass';f.frequency.value=lp||600;
     let tail=f;s.connect(f);
     if(hp){const hpf=c.createBiquadFilter();hpf.type='highpass';hpf.frequency.value=hp;f.connect(hpf);tail=hpf;}
     const gn=c.createGain();gn.gain.value=g;tail.connect(gn);gn.connect(master);
     s.start(now);bedNodes.push(s);
     if(lfoHz){
       const l=c.createOscillator(),lg=c.createGain();
       l.type='sine';l.frequency.value=lfoHz;lg.gain.value=g*0.7;
       l.connect(lg);lg.connect(gn.gain);l.start(now);bedNodes.push(l);
     }
     return gn;
   };
   switch(kind){
     case 'dawn':      // тепло и покой: чистая квинта, воздух, высокий обертон
       pad('sine',110,0.085,0.07,0.45);
       pad('sine',165,0.055,0.05,0.55);
       pad('sine',440,0.014,0.11,0.80);
       air(0.030,900,180,0.045);
       break;
     case 'ash':       // пожарище: низкий гул, ветер и далёкий треск
       pad('sine',48,0.115,0.06,0.50);
       pad('sine',48.6,0.085,0.043,0.60);
       air(0.070,420,0,0.05);
       air(0.026,5200,1600,0.29);
       break;
     case 'hollow':    // пустой офис: инфразвук с биением и вентиляция
       pad('sine',38,0.130,0.037,0.55);
       pad('sine',38.7,0.105,0.041,0.60);
       pad('sawtooth',60,0.020,0.09,0.45);
       air(0.034,700,120,0.06);
       break;
     case 'stage':     // зал: пад с малой секундой — красиво и неуютно сразу
       pad('sine',98,0.090,0.055,0.50);
       pad('sine',103.8,0.070,0.048,0.55);
       pad('sine',1244,0.008,0.13,0.85);
       air(0.024,1400,300,0.07);
       break;
     case 'archive':   // подвал: шипение плёнки и низкий тон под ним
       pad('sine',41,0.110,0.035,0.55);
       pad('sine',220,0.020,0.08,0.70);
       air(0.045,3600,900,0.10);
       air(0.040,300,0,0.04);
       break;
     // V101: подложки для переделанных концовок.
     case 'creep':     // скрытное продвижение: почти тишина, только комната
       pad('sine',36,0.105,0.030,0.60);
       pad('sine',36.4,0.080,0.034,0.62);
       air(0.028,520,90,0.05);
       air(0.012,4200,1800,0.19);
       break;
     case 'chase':      // бег: пульсирующий низ, воздух в ушах
       pad('sine',55,0.120,0.9,0.85);
       pad('sine',82.4,0.055,1.8,0.70);
       pad('sawtooth',110,0.022,0.9,0.80);
       air(0.075,1200,240,0.9);
       break;
     case 'white':      // белый финал: тёплый мажорный воздух без низа
       pad('sine',196,0.045,0.05,0.40);
       pad('sine',293.66,0.032,0.043,0.45);
       pad('sine',392,0.018,0.06,0.50);
       air(0.020,2600,700,0.035);
       break;
     default:
       pad('sine',44,0.10,0.05,0.5);air(0.03,600,0,0.06);
   }
   // Страховка: подложка не может жить дольше самой длинной концовки.
   bedTimer=setTimeout(()=>{bedTimer=null;bedStop()},60000);
 }
 function playRandom(list,opts={}){if(list?.length)play(list[Math.floor(Math.random()*list.length)],opts.volume??1,opts)}
 function init(){
  if(ready)return;
  ready=true;
  music=null;
  radioMusic=noSystemPlayer(new Audio('assets/music/radio_music.mp3'));
  radioMusic.loop=true; radioMusic.preload='auto'; radioMusic.volume=0; radioMusic.playsInline=true; radioMusic.autoplay=false;
  menuMusic=noSystemPlayer(new Audio('assets/music/menu_horror_loop.mp3'));
  menuMusic.loop=true; menuMusic.preload='auto'; menuMusic.volume=0; menuMusic.playsInline=true; menuMusic.autoplay=false;
  calmMenuMusic=noSystemPlayer(new Audio('assets/music/calm_epilogue.wav'));
  calmMenuMusic.loop=true; calmMenuMusic.preload='auto'; calmMenuMusic.volume=0; calmMenuMusic.playsInline=true; calmMenuMusic.autoplay=false
}
 function unlock(){
  unlocked=true;init();
  // Разбудить графы Web Audio на первом же жесте, чтобы первый звук двери не пропал.
  try{SpatialAudio.prime();['door','thud','doorMotor','stepAlt','monster_heavy','monsterDistant'].forEach(n=>SpatialAudio.prepare(files[n]));}catch(e){}
  const inMenu=window.NightShift?.state==='menu';
  if(music){
    music.volume=muted?0:(inMenu?0:gain('music'));
    if(inMenu) music.pause(); else music.play().catch(()=>{});
  }
  update();
}

 function stopVictory(){
   if(victoryTimer){clearTimeout(victoryTimer);victoryTimer=null;}
   victoryNodes.forEach(n=>{try{n.stop?.()}catch(e){} try{n.disconnect?.()}catch(e){}});
   victoryNodes=[];
 }
 function playVictory(){
   if(muted)return;
   stopVictory();
   try{
     const C=window.AudioContext||window.webkitAudioContext;if(!C)return;
     const ctx=this._victoryCtx||(this._victoryCtx=new C());ctx.resume().catch(()=>{});
     const master=ctx.createGain();master.gain.setValueAtTime(0.0001,ctx.currentTime);master.gain.exponentialRampToValueAtTime(.18,ctx.currentTime+.08);master.gain.exponentialRampToValueAtTime(.0001,ctx.currentTime+4.6);master.connect(ctx.destination);
     const notes=[523.25,659.25,783.99,1046.5,783.99,1046.5,1318.51];
     notes.forEach((freq,i)=>{
       const o=ctx.createOscillator(),g=ctx.createGain();o.type='triangle';o.frequency.value=freq;g.gain.setValueAtTime(.0001,ctx.currentTime+i*.42);g.gain.exponentialRampToValueAtTime(.32,ctx.currentTime+i*.42+.035);g.gain.exponentialRampToValueAtTime(.0001,ctx.currentTime+i*.42+.36);o.connect(g);g.connect(master);o.start(ctx.currentTime+i*.42);o.stop(ctx.currentTime+i*.42+.4);victoryNodes.push(o);
     });
     const bell=ctx.createOscillator(),bg=ctx.createGain();bell.type='sine';bell.frequency.value=1567.98;bg.gain.setValueAtTime(.0001,ctx.currentTime+2.52);bg.gain.exponentialRampToValueAtTime(.16,ctx.currentTime+2.58);bg.gain.exponentialRampToValueAtTime(.0001,ctx.currentTime+3.4);bell.connect(bg);bg.connect(master);bell.start(ctx.currentTime+2.52);bell.stop(ctx.currentTime+3.45);victoryNodes.push(bell);
     victoryTimer=setTimeout(()=>{victoryNodes=[];victoryTimer=null},5000);
   }catch(e){}
 }
 function startRadioMusic(seed=0){
  init();
  if(!radioMusic)return false;
  radioOn=true;
  // Радио должно начинать музыку сразу после нажатия кнопки.
  // Не перематываем на случайную позицию: стартуем с начала трека.
  try{radioMusic.pause(); radioMusic.currentTime=0;}catch(e){}
  radioMusic.volume=muted?0:Math.max(.05,gain('radio')*.65);
  radioMusic.muted=!!muted;
  const p=radioMusic.play();
  if(p&&typeof p.catch==='function'){
    p.catch(()=>{
      // Если браузер временно отклонил play(), повторяем после следующего жеста пользователя.
      const retry=()=>{
        if(!radioOn)return;
        radioMusic.muted=!!muted;
        radioMusic.volume=muted?0:Math.max(.05,gain('radio')*.65);
        radioMusic.play().catch(()=>{});
        window.removeEventListener('pointerdown',retry,true);
        window.removeEventListener('keydown',retry,true);
      };
      window.addEventListener('pointerdown',retry,true);
      window.addEventListener('keydown',retry,true);
    });
  }
  return true;
}
 function stopRadioMusic(){radioOn=false;if(radioMusic){radioMusic.pause();try{radioMusic.currentTime=0}catch(e){}}}

// ================= V81: АТМОСФЕРА МЕНЮ ПО КОНЦОВКЕ =================
// Раньше после любой пройденной концовки в меню играл один и тот же спокойный
// трек — и после сожжения пиццерии, и после смерти в костюме звучало одно и то
// же. Теперь для каждой концовки собирается свой процедурный эмбиент на
// Web Audio: никаких новых файлов, но у каждого финала своё звучание.
//   burn — низкий гул пожара и треск угасающих угольков
//   dark — подвальный саб-дрон с биением расстроенных тонов и дальние удары
//   trap — металлический диссонанс, щелчки спринглоков и хриплое дыхание
//   calm — тёплый мажорный пад (плюс существующий тихий трек)
let ambCtx=null, ambKind=null, ambNodes=[], ambMaster=null, ambEvt=null, ambNoise=null;
function ambNoiseBuf(c){
  if(ambNoise)return ambNoise;
  const b=c.createBuffer(1,c.sampleRate*3,c.sampleRate), d=b.getChannelData(0);
  let last=0;
  for(let i=0;i<d.length;i++){const wn=Math.random()*2-1;last=(last+0.02*wn)/1.02;d[i]=last*3.2;}
  ambNoise=b;return b;
}
function ambOsc(c,type,freq,g,dest,detune){
  const o=c.createOscillator();o.type=type;o.frequency.value=freq;
  if(detune)o.detune.value=detune;
  const gn=c.createGain();gn.gain.value=g;
  o.connect(gn);gn.connect(dest);o.start();
  ambNodes.push(o,gn);return {o,gn};
}
function ambLFO(c,rate,depth,target){
  const l=c.createOscillator();l.type='sine';l.frequency.value=rate;
  const lg=c.createGain();lg.gain.value=depth;
  l.connect(lg);lg.connect(target);l.start();
  ambNodes.push(l,lg);
}
function stopAmbience(){
  if(!ambCtx)return;
  if(ambEvt){clearInterval(ambEvt);ambEvt=null;}
  if(ambMaster){try{ambMaster.gain.cancelScheduledValues(ambCtx.currentTime);
    ambMaster.gain.setTargetAtTime(0.0001,ambCtx.currentTime,0.25);}catch(e){}}
  const nodes=ambNodes, master=ambMaster;
  ambNodes=[];ambMaster=null;ambKind=null;
  setTimeout(()=>{nodes.forEach(n=>{try{n.stop&&n.stop()}catch(e){} try{n.disconnect&&n.disconnect()}catch(e){}});
    try{master&&master.disconnect()}catch(e){}},900);
}
function startAmbience(kind,vol){
  if(ambKind===kind){if(ambMaster)ambMaster.gain.setTargetAtTime(Math.max(0.0001,vol),ambCtx.currentTime,0.4);return;}
  stopAmbience();
  try{
    const C=window.AudioContext||window.webkitAudioContext;if(!C)return;
    if(!ambCtx)ambCtx=new C();
    const c=ambCtx;c.resume().catch(()=>{});
    const m=c.createGain();m.gain.value=0.0001;m.connect(c.destination);
    ambMaster=m;ambKind=kind;
    m.gain.setTargetAtTime(Math.max(0.0001,vol),c.currentTime,1.2);
    const noiseSrc=()=>{const n=c.createBufferSource();n.buffer=ambNoiseBuf(c);n.loop=true;n.start();ambNodes.push(n);return n;};
    const filt=(type,f,q)=>{const b=c.createBiquadFilter();b.type=type;b.frequency.value=f;if(q)b.Q.value=q;ambNodes.push(b);return b;};
    if(kind==='burn'){
      // низкий гул огня: шум через полосовой фильтр + сабтон
      const n=noiseSrc(), lp=filt('lowpass',260,0.7), g=c.createGain();g.gain.value=0.42;
      n.connect(lp);lp.connect(g);g.connect(m);ambNodes.push(g);
      ambLFO(c,0.09,140,lp.frequency);
      ambLFO(c,0.055,0.16,g.gain);
      ambOsc(c,'sine',41,0.30,m);
      ambOsc(c,'sine',61.5,0.10,m,-6);
      // редкий треск догорающего дерева
      ambEvt=setInterval(()=>{
        if(!ambMaster)return;
        const now=c.currentTime, cn=c.createBufferSource();cn.buffer=ambNoiseBuf(c);
        cn.playbackRate.value=2.2+Math.random();
        const hp=c.createBiquadFilter();hp.type='highpass';hp.frequency.value=1400;
        const cg=c.createGain();cg.gain.setValueAtTime(0.0001,now);
        cg.gain.exponentialRampToValueAtTime(0.22+Math.random()*0.18,now+0.01);
        cg.gain.exponentialRampToValueAtTime(0.0001,now+0.10+Math.random()*0.12);
        cn.connect(hp);hp.connect(cg);cg.connect(m);cn.start(now);cn.stop(now+0.4);
      },900);
    }else if(kind==='dark'){
      // подвальный дрон: два почти одинаковых тона дают медленное биение
      ambOsc(c,'sine',32.7,0.34,m);
      ambOsc(c,'sine',32.7,0.26,m,14);      // расстройка → биение ~0.5 Гц
      ambOsc(c,'triangle',49.0,0.075,m,-8);
      const n=noiseSrc(), lp=filt('lowpass',150,0.9), g=c.createGain();g.gain.value=0.16;
      n.connect(lp);lp.connect(g);g.connect(m);ambNodes.push(g);
      ambLFO(c,0.035,0.09,g.gain);
      // дальний глухой удар — как будто в глубине здания закрылась дверь
      ambEvt=setInterval(()=>{
        if(!ambMaster||Math.random()>0.45)return;
        const now=c.currentTime, o=c.createOscillator();o.type='sine';
        o.frequency.setValueAtTime(90,now);o.frequency.exponentialRampToValueAtTime(38,now+0.5);
        const g2=c.createGain();g2.gain.setValueAtTime(0.0001,now);
        g2.gain.exponentialRampToValueAtTime(0.26,now+0.02);
        g2.gain.exponentialRampToValueAtTime(0.0001,now+0.9);
        o.connect(g2);g2.connect(m);o.start(now);o.stop(now+1.0);
      },4200);
    }else if(kind==='trap'){
      // металлический диссонанс: чистая квинта испорчена тритоном
      ambOsc(c,'sine',36.7,0.30,m);
      ambOsc(c,'sawtooth',110.0,0.030,m);
      ambOsc(c,'sawtooth',155.6,0.026,m,+9);   // тритон — «неправильный» интервал
      const n=noiseSrc(), bp=filt('bandpass',820,3.2), g=c.createGain();g.gain.value=0.10;
      n.connect(bp);bp.connect(g);g.connect(m);ambNodes.push(g);
      ambLFO(c,0.13,220,bp.frequency);
      // щелчки спринглоков и хриплый вдох
      ambEvt=setInterval(()=>{
        if(!ambMaster)return;
        const now=c.currentTime;
        if(Math.random()<0.6){
          const cn=c.createBufferSource();cn.buffer=ambNoiseBuf(c);cn.playbackRate.value=3.4;
          const bp2=c.createBiquadFilter();bp2.type='bandpass';bp2.frequency.value=2600;bp2.Q.value=9;
          const cg=c.createGain();cg.gain.setValueAtTime(0.0001,now);
          cg.gain.exponentialRampToValueAtTime(0.30,now+0.004);
          cg.gain.exponentialRampToValueAtTime(0.0001,now+0.06);
          cn.connect(bp2);bp2.connect(cg);cg.connect(m);cn.start(now);cn.stop(now+0.2);
        }else{
          const bn=c.createBufferSource();bn.buffer=ambNoiseBuf(c);bn.playbackRate.value=0.7;
          const bf=c.createBiquadFilter();bf.type='bandpass';bf.frequency.value=520;bf.Q.value=1.4;
          const bg=c.createGain();bg.gain.setValueAtTime(0.0001,now);
          bg.gain.linearRampToValueAtTime(0.16,now+0.35);
          bg.gain.linearRampToValueAtTime(0.0001,now+1.1);
          bn.connect(bf);bf.connect(bg);bg.connect(m);bn.start(now);bn.stop(now+1.3);
        }
      },2600);
    }else{
      // calm — тёплый пад, мажорное трезвучие в нижнем регистре
      ambOsc(c,'sine',55.0,0.22,m);
      ambOsc(c,'sine',82.4,0.11,m);
      ambOsc(c,'sine',110.0,0.07,m,+4);
      ambOsc(c,'triangle',164.8,0.022,m);
      const n=noiseSrc(), lp=filt('lowpass',600,0.6), g=c.createGain();g.gain.value=0.05;
      n.connect(lp);lp.connect(g);g.connect(m);ambNodes.push(g);
      ambLFO(c,0.06,0.03,g.gain);
    }
  }catch(e){ambKind=null;}
}
 function update(){
  const inMenu=window.NightShift?.state==='menu';
  const d=tickDuck();
  if(music){
    music.volume=muted?0:(inMenu?0:gain('music')*d);
    if(inMenu){music.pause();}else if(unlocked && music.paused){music.play().catch(()=>{});}
  }
  const epilogue=!!(window.NightShift?.menuVariant==='epilogue'||window.SaveSystem?.data?.completed);
  if(menuMusic){
    menuMusic.volume=muted?0:(inMenu&&!epilogue?gain('music'):0);
    if(inMenu && !epilogue && unlocked){if(menuMusic.paused)menuMusic.play().catch(()=>{});}
    else {menuMusic.pause();try{menuMusic.currentTime=0}catch(e){}}
  }
  // V81: спокойный трек оставлен ТОЛЬКО за мирной концовкой. После пожара,
  // тёмного финала и смерти в костюме он звучал издевательски неуместно.
  const ending=window.SaveSystem?.data?.lastEnding||'';
  const calmMenu=epilogue&&(ending===''||ending==='calm');
  if(calmMenuMusic){
    calmMenuMusic.volume=muted?0:(inMenu&&calmMenu?gain('music')*.78:0);
    if(inMenu && calmMenu && unlocked){if(calmMenuMusic.paused)calmMenuMusic.play().catch(()=>{});}
    else {calmMenuMusic.pause();try{calmMenuMusic.currentTime=0}catch(e){}}
  }
  // V81: свой процедурный эмбиент для каждой концовки
  if(inMenu&&epilogue&&unlocked&&!muted){
    const k=(ending==='burn'||ending==='dark'||ending==='trap')?ending:'calm';
    const v=gain('music')*(k==='calm'?0.16:k==='trap'?0.30:0.26);
    startAmbience(k,v);
  }else stopAmbience();
  if(radioMusic)radioMusic.volume=(muted||!radioOn)?0:gain('radio')*.62;
}
 function noteSound(open=true){
  if(muted)return;
  try{
    const C=window.AudioContext||window.webkitAudioContext;if(!C)return;
    const c=this._noteCtx||(this._noteCtx=new C());c.resume().catch(()=>{});
    const now=c.currentTime;const g=c.createGain();g.gain.setValueAtTime(.0001,now);
    g.gain.exponentialRampToValueAtTime(open?.10:.075,now+.012);g.gain.exponentialRampToValueAtTime(.0001,now+(open?.16:.20));g.connect(c.destination);
    const o=c.createOscillator();o.type='triangle';o.frequency.setValueAtTime(open?420:300,now);o.frequency.exponentialRampToValueAtTime(open?230:160,now+(open?.12:.17));o.connect(g);o.start(now);o.stop(now+(open?.18:.22));
    const n=c.createBufferSource();const b=c.createBuffer(1,c.sampleRate*.08,c.sampleRate);const d=b.getChannelData(0);for(let i=0;i<d.length;i++)d[i]=(Math.random()*2-1)*Math.pow(1-i/d.length,2)*.035;n.buffer=b;const ng=c.createGain();ng.gain.value=1; n.connect(ng);ng.connect(c.destination);n.start(now);
  }catch(e){}
 }
 function playVentCreak(vol=0.8){
  if(muted)return;
  try{
    const C=window.AudioContext||window.webkitAudioContext;if(!C){AudioFX.play('metal_bellow',vol*0.7,{group:'ambience'});return;}
    const c=this._creakCtx||(this._creakCtx=new C());c.resume().catch(()=>{});
    const now=c.currentTime;
    const master=c.createGain();master.gain.setValueAtTime(0.0001,now);master.gain.exponentialRampToValueAtTime(vol*0.5,now+0.03);master.gain.exponentialRampToValueAtTime(0.0001,now+1.4);master.connect(c.destination);
    const o=c.createOscillator();o.type='sawtooth';o.frequency.setValueAtTime(90,now);o.frequency.linearRampToValueAtTime(60,now+0.5);o.frequency.linearRampToValueAtTime(140,now+0.9);o.frequency.linearRampToValueAtTime(70,now+1.3);
    const f=c.createBiquadFilter();f.type='lowpass';f.frequency.value=520;f.Q.value=6;
    o.connect(f);f.connect(master);
    // wobble LFO for the creaky rub
    const lfo=c.createOscillator(),lg=c.createGain();lfo.frequency.value=11;lg.gain.value=0.35;const wm=c.createGain();wm.gain.value=18;o.frequency.connect(wm);lg.connect(wm);wm.connect(o.frequency);lfo.connect(lg);
    o.start(now);o.stop(now+1.4);lfo.start(now);lfo.stop(now+1.4);
    // a tiny metallic tick at the start
    const n=c.createBufferSource();const b=c.createBuffer(1,c.sampleRate*0.05,c.sampleRate);const d=b.getChannelData(0);for(let i=0;i<d.length;i++)d[i]=(Math.random()*2-1)*Math.pow(1-i/d.length,3)*0.2;n.buffer=b;const ng=c.createGain();ng.gain.value=0.5;n.connect(ng);ng.connect(c.destination);n.start(now);
  }catch(e){try{AudioFX.play('metal_bellow',vol*0.7,{group:'ambience'})}catch(_){}}
 }
 // Резкий скример: синтезируется на месте, поэтому работает и при запуске с диска.
 // Мгновенная атака, металлический визг, рычание вниз и стена шума.
 function playJumpscare(power=1){
  if(muted)return;
  const v=Math.max(0,Math.min(1,gain('monster')*power));
  if(v<=0)return;
  try{
    const C=window.AudioContext||window.webkitAudioContext;if(!C)throw new Error('no ctx');
    const c=this._scareCtx||(this._scareCtx=new C());c.resume().catch(()=>{});
    const now=c.currentTime;
    const master=c.createGain();
    master.gain.setValueAtTime(v*1.0,now);
    master.gain.setValueAtTime(v*1.0,now+.45);
    master.gain.exponentialRampToValueAtTime(.0001,now+1.5);
    const clip=c.createWaveShaper();
    const cur=new Float32Array(1024);
    for(let i=0;i<1024;i++){const x=i/512-1;cur[i]=Math.tanh(x*4.2);}
    clip.curve=cur;clip.oversample='2x';
    master.connect(clip);clip.connect(c.destination);
    // 1) удар-стена шума с резким срезом
    const n=c.createBufferSource();
    const len=Math.floor(c.sampleRate*1.2);
    const b=c.createBuffer(2,len,c.sampleRate);
    for(let ch=0;ch<2;ch++){const d2=b.getChannelData(ch);for(let i=0;i<len;i++){const e=Math.pow(1-i/len,2.2);d2[i]=(Math.random()*2-1)*e;}}
    n.buffer=b;
    const nf=c.createBiquadFilter();nf.type='bandpass';nf.frequency.setValueAtTime(2600,now);nf.frequency.exponentialRampToValueAtTime(320,now+.9);nf.Q.value=.8;
    const ng=c.createGain();ng.gain.setValueAtTime(.9,now);ng.gain.exponentialRampToValueAtTime(.0001,now+1.15);
    n.connect(nf);nf.connect(ng);ng.connect(master);n.start(now);
    // 2) визг: две расстроенные пилы вниз
    [1,1.007].forEach((mul,i)=>{
      const o=c.createOscillator();o.type='sawtooth';
      o.frequency.setValueAtTime(1750*mul,now);
      o.frequency.exponentialRampToValueAtTime(210*mul,now+.62);
      const g=c.createGain();g.gain.setValueAtTime(.0001,now);g.gain.exponentialRampToValueAtTime(.55,now+.008);g.gain.exponentialRampToValueAtTime(.0001,now+.75);
      const f=c.createBiquadFilter();f.type='lowpass';f.frequency.value=5200;f.Q.value=3;
      const p=c.createStereoPanner();p.pan.value=i?.35:-.35;
      o.connect(f);f.connect(g);g.connect(p);p.connect(master);o.start(now);o.stop(now+.8);
    });
    // 3) рычание в самом низу
    const sub=c.createOscillator();sub.type='square';
    sub.frequency.setValueAtTime(150,now);sub.frequency.exponentialRampToValueAtTime(38,now+1.0);
    const sg=c.createGain();sg.gain.setValueAtTime(.0001,now);sg.gain.exponentialRampToValueAtTime(.5,now+.02);sg.gain.exponentialRampToValueAtTime(.0001,now+1.25);
    const sf=c.createBiquadFilter();sf.type='lowpass';sf.frequency.value=260;
    sub.connect(sf);sf.connect(sg);sg.connect(master);sub.start(now);sub.stop(now+1.3);
    // 4) металлический лязг сверху
    const m1=c.createOscillator();m1.type='square';m1.frequency.setValueAtTime(3100,now);m1.frequency.exponentialRampToValueAtTime(900,now+.18);
    const mg=c.createGain();mg.gain.setValueAtTime(.0001,now);mg.gain.exponentialRampToValueAtTime(.3,now+.005);mg.gain.exponentialRampToValueAtTime(.0001,now+.3);
    m1.connect(mg);mg.connect(master);m1.start(now);m1.stop(now+.32);
  }catch(e){
    // Резервный вариант, если Web Audio недоступен.
    try{play('scream',1.15,{group:'monster',noDuck:true})}catch(_){}
  }
  // Готовый крик поверх синтеза — так удар звучит живее.
  try{play('scream',.9,{group:'monster',noDuck:true})}catch(e){}
 }
 // V89: остановка одного конкретного звука по имени. Нужна скримеру: шёпот в
 // трубке обязан замолчать в момент удара, а не доигрывать под воплем.
 function stopSound(name){
  const src=files[name];if(!src)return;
  live.forEach(a=>{if(a&&a.src&&a.src.indexOf(src)>=0){try{a.pause();a.currentTime=0}catch(e){}live.delete(a)}});
  const c=cache[name]||cache[src];if(c){try{c.pause();c.currentTime=0}catch(e){}}
 }
 function stopAll(){
  stopRadioMusic();
  stopVictory();
  stopAmbience();
  bedStop();                                    // V100: атмосферная подложка концовок
  // V91: слой аниматроников тоже гасим — иначе гул приводов за дверью
  // продолжал бы идти в меню и в катсценах смерти.
  try{window.MonsterAudio?.stopAll?.()}catch(e){}
  try{window.speechSynthesis?.cancel?.()}catch(e){}
  Object.values(cache).forEach(a=>{try{a.pause();a.currentTime=0}catch(e){}});
  live.forEach(a=>{try{a.pause();a.currentTime=0}catch(e){}});live.clear();
  try{SpatialAudio.stopAll()}catch(e){}
  try{if(music){music.pause();music.currentTime=0}}catch(e){}
  try{if(menuMusic){menuMusic.pause();menuMusic.currentTime=0}}catch(e){}
  try{if(calmMenuMusic){calmMenuMusic.pause();calmMenuMusic.currentTime=0}}catch(e){}
  try{if(radioMusic){radioMusic.pause();radioMusic.currentTime=0}}catch(e){}
 }
 function toggleMute(){muted=!muted;update();return muted}
 function setPlatformMuted(v){muted=!!v;update()}
 function setMusic(v){window.SaveSystem.settings.music=Math.max(0,Math.min(1,v));window.SaveSystem.saveSettings();update()}
 function setSfx(v){window.SaveSystem.settings.ui=Math.max(0,Math.min(1,v));window.SaveSystem.saveSettings();update()}
 // V83: озвученные реплики регистрируются на ходу — путь к файлу зависит от
 // выбранного языка, поэтому список нельзя задать статически.
 function register(name,src,group){files[name]=src;if(group)groups[name]=group;return name}
 return {unlock,noSystemPlayer,play,playRandom,register,synth,bedStart,bedStop,stopSound,stopAmbience,playJumpscare,playVictory,stopVictory,stopAll,update,startRadioMusic,stopRadioMusic,noteSound,playVentCreak,toggleMute,setPlatformMuted,isMuted:()=>muted,setMusic,setSfx,get muted(){return muted},get musicVolume(){return window.SaveSystem.settings.music},get sfxVolume(){return window.SaveSystem.settings.ui}};
})();
// Панорамирование звука. Главное правило: звук обязан быть слышен всегда.
// НИКОГДА не используем createMediaElementSource: при запуске с диска (file://)
// или при чужом источнике такой граф молчит, и звук исчезает без ошибок.
// Панорама даётся только через заранее декодированный семпл; если его нет —
// звук играет обычным <audio> без стерео, но гарантированно слышно.
const SpatialAudio={
 ctx:null,
 buffers:{},
 playing:new Set(),
 stopAll(){this.playing.forEach(s=>{try{s.stop(0)}catch(e){}});this.playing.clear()},
 prime(){
  try{
   const C=window.AudioContext||window.webkitAudioContext;if(!C)return null;
   this.ctx ||= new C();
   if(this.ctx.state!=='running')this.ctx.resume().catch(()=>{});
   return this.ctx;
  }catch(e){return null}
 },
 // Фоновое декодирование семпла. Не удалось — помечаем null и больше не пытаемся.
 prepare(src){
  if(!src||this.buffers[src]!==undefined)return;
  if(location.protocol==='file:'){this.buffers[src]=null;return}
  const ctx=this.prime();
  if(!ctx){this.buffers[src]=null;return}
  this.buffers[src]='loading';
  const self=this;
  const fail=()=>{self.buffers[src]=null};
  try{
   fetch(src).then(r=>r.ok?r.arrayBuffer():Promise.reject(new Error('http')))
    .then(ab=>new Promise((res,rej)=>{
      const p=ctx.decodeAudioData(ab,res,rej);
      if(p&&typeof p.then==='function')p.then(res,rej);
    }))
    .then(buf=>{self.buffers[src]=buf||null})
    .catch(fail);
  }catch(e){fail()}
 },
 // true — звук ушёл в Web Audio с панорамой; false — звать обычный <audio>.
 playBuffer(src,volume,pan){
  const buf=this.buffers[src];
  if(!buf||buf==='loading')return false;
  const ctx=this.ctx;
  if(!ctx||ctx.state!=='running')return false;
  try{
   const s=ctx.createBufferSource();s.buffer=buf;
   const g=ctx.createGain();g.gain.value=Math.max(0,Math.min(1,volume));
   const p=ctx.createStereoPanner();p.pan.value=Math.max(-1,Math.min(1,pan||0));
   s.connect(g);g.connect(p);p.connect(ctx.destination);
   const self=this;s.onended=()=>{self.playing.delete(s)};self.playing.add(s);
   s.start(0);
   return true;
  }catch(e){return false}
 }
};
window.SpatialAudio=SpatialAudio;
