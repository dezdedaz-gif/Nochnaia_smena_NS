window.MonsterAI=(()=>{
 const State=Object.freeze({HIDDEN:'hidden',MOVING:'moving',WATCHING:'watching',AT_DOOR:'atDoor',LINGERING:'lingering',RETREATING:'retreating',PREPARING:'preparingAttack',ATTACKING:'attacking'});
 // Two corridors lead to the office: room 6 (Коридор А) -> LEFT door, room 7 (Коридор Б) -> RIGHT door.
 // Corridors interweave with the side rooms: Склад(3)->Коридор А, Служебная(5)->Коридор Б.
 // Room 4 (Сцена) is the spawn point; room 1 (Зал) is the hub; room 2 (Выход) is a dead-end.
 const graph={1:[3,4,5,6,7],2:[1],3:[1,6],4:[1],5:[1,7],6:[1,3,0],7:[1,5,0],0:[6,7]};
 const routes={
   main:[4,1,3,6,0,1,5,7,0,1,2,1,4],
   felix:[4,1,5,7,0,1,3,6,0,1,4,1,5],
   // EXO — голый экзоскелет: держится служебных помещений и оба коридора обходит по очереди.
   exo:[4,1,3,1,5,7,0,1,6,0,1,3,4],
   // LAV — жёлтый, появляется с 3-й смены. Любит Зал и Выход, к двери идёт рывками.
   lav:[4,1,2,1,6,0,1,5,7,0,1,3,1]
 };
 // Имя аниматроника для всего UI и сообщений.
 function label(kind){return kind==='felix'?'ФЕЛИКС':kind==='exo'?'EXO':kind==='lav'?'LAV':'МОНСТР';}
 // ==== V85: реплики аниматроников. У каждого свой характер и свой голос:
 // MAIN — тяжёлый собственник, ФЕЛИКС — сломанный ведущий со срывами в смех,
 // EXO — сухой технический голос без эмоций, LAV — ненормально радостный певец.
 // Тексты совпадают с записанными дорожками (VOICE_MANIFEST.byText) — менять только вместе.
 const taunts={
  main:{early:['Свет под твоей дверью. Ты забыл его выключить.','Ты дышишь громче, чем тебе кажется.','Сиди. Смена только началась.'],
        late:['Я запомнил, какую дверь ты закрываешь первой.','Твоё питание кончится немного раньше тебя.','Не вставай. Я почти пришёл.']},
  felix:{early:['Фе... фе... Феликс идёт! Феликс идёт к тебе!','Сними маску. Я хочу посмотреть на лицо.','Кто-то забыл выключить свет. Опять. Опять!'],
         late:['Маска больше не работает. Мне жаль.','Я слышу твоё сердце сквозь железо. Тук. Тук.','Дверь тонкая. Такая тонкая... Я подожду здесь.']},
  exo:{early:['Без кожи холодно. Ты не знаешь, как это холодно.','Сервоприводы сухие. Двенадцать лет без смазки.','Я помню номер твоей смены. Он был и у прошлого.'],
       late:['Свет спас тебя один раз. Второго раза не будет.','Я считаю твои вдохи. Осталось двести сорок.','Кресло тёплое. Значит, ты ещё там.']},
  lav:{early:['Лав! Меня зовут Лав. Запомни, пригодится.','Где мой праздник? Где все дети?','Ты сидишь на моём месте. Я не злюсь. Пока.'],
       late:['Выключи радио. Оно мешает мне петь для тебя.','Я был на складе. Там просторно. Там хватит места.','Я приготовил тебе стул. В первом ряду.']}
 };
 // V85: аниматроники не повторяются: каждый помнит, что уже сказал, и берёт
 // следующую реплику из тех, что ещё не звучали. Раньше одна и та же фраза могла
 // выпасть два-три раза подряд и все четверо звучали одинаково.
 const saidLog={};
 function pickLine(kind,pool){
   const seen=saidLog[kind]||(saidLog[kind]=[]);
   let fresh=pool.filter(l=>seen.indexOf(l)<0);
   if(!fresh.length){seen.length=0;fresh=pool.slice();}
   const line=fresh[Math.floor(Math.random()*fresh.length)];
   seen.push(line);
   if(seen.length>pool.length-1)seen.splice(0,seen.length-(pool.length-1));
   return line;
 }
 function speak(m,game,night){
   if(!game.monSay)return;
   // V91: перед репликой щёлкает реле и коротко рычит глотка — голос включается,
   // а не появляется из тишины.
   try{window.MonsterAudio?.growl(m.kind,m.room,{dur:0.5,gain:0.16,dist:0.4})}catch(e){}
   const set=taunts[m.kind]||taunts.main;
   const pool=night>=3?set.late.concat(set.early):set.early;
   game.monSay(pickLine(m.kind,pool),m.kind);
 }
 function make(kind='main'){
   const felix=kind==='felix', exo=kind==='exo', lav=kind==='lav';
   // Все аниматроники стартуют на Сцене (комната 4) и видны на КАМ 04 с первой
   // секунды смены; таймеры разнесены, чтобы они не ушли со сцены одновременно.
   return {kind,room:4,state:State.WATCHING,timer:exo?16:felix?11:lav?13:6,warning:0,doorSide:null,attackTimer:0,visibleUntil:0,lastStep:0,frame:0,red:!felix&&!exo&&!lav,routeIndex:0,stuck:0,seen:0,doorVisits:0,doorQuota:0,nextDoorAt:0,doorCooldown:0,maskRepel:0,lightBlind:0,radioRepel:0,feint:0,corner:false,sayCd:6+Math.random()*8,
     // V111: СТОЯНИЕ У ДВЕРИ. Отдельный таймер от отсчёта атаки: аниматроник
     // может просто простоять в проёме 3+ секунды — молча или с репликой —
     // и только потом решить, бросаться или уйти. Длительность случайная и
     // растёт со сменой. silent — пришёл без объявления, для внезапности.
     doorLinger:0,doorLingerMax:0,silent:false,eyesVisible:true};
 }
 function doorForRoom(room){return room===6?'left':room===7?'right':null;}
 // ==== V70: «память» аниматроников. Они запоминают, какую дверь охранник закрывает
 // чаще, где он держит свет и как часто смотрит камеры, и давят в слабое место. ====
 function mem(game){
   if(!game.aiMem)game.aiMem={closes:{left:0,right:0},lights:{left:0,right:0},cams:0,camTime:0,prevDoors:{left:false,right:false},lastRoom:{}};
   return game.aiMem;
 }
 function observe(game,dt){
   const a=mem(game);
   ['left','right'].forEach(s2=>{
     const now=!!game.doors[s2];
     if(now&&!a.prevDoors[s2])a.closes[s2]++;
     a.prevDoors[s2]=now;
     if(game.lights?.[s2]?.on)a.lights[s2]+=dt;
   });
   if(game.monitor)a.camTime+=dt;
 }
 // Выбор двери: реже закрываемая сторона, без света и не занятая другим аниматроником.
 function smartSide(m,game,night){
   const a=mem(game);
   const busy=(game.monsters||[]).filter(x=>x&&x!==m&&x.room===0&&x.doorSide).map(x=>x.doorSide);
   const score=s2=>{
     let v=0;
     v-=a.closes[s2]*1.0;                       // эту дверь охранник закрывает часто
     v-=(a.lights[s2]||0)*0.10;                 // и часто светит
     if(busy.includes(s2))v-=night>=4?3.0:1.0;  // напарник уже там — идём с другой стороны
     if(game.doors[s2])v-=2.0;                  // дверь уже закрыта
     return v+Math.random()*(night>=4?0.8:2.2); // чем выше смена, тем меньше случайности
   };
   return score('left')>=score('right')?'left':'right';
 }
 function routeNext(m,game){
   const route=routes[m.kind]||routes.main;
   let candidates=[];
   // Follow a personal route with controlled branching so the AI is not predictable.
   for(let i=0;i<route.length;i++){
     if(route[i]===m.room){
       candidates.push(route[(i+1)%route.length]);
       if(i+2<route.length)candidates.push(route[i+2]);
       break;
     }
   }
   if(!candidates.length)candidates=graph[m.room]||[1];
   candidates=candidates.filter(r=>r!==m.room);
   // Night difficulty increases route deviations and pressure toward the office.
   if(game.night>=2 && Math.random()<0.22+game.night*.035)candidates.push(0);
   if(m.room!==0 && m.timer<=0 && Math.random()<0.10+game.night*.02)candidates=[0,...candidates];
   if(game.monitor && candidates.length>1 && Math.random()<0.28)candidates.reverse();
   const unique=[...new Set(candidates)];
   return unique[Math.floor(Math.random()*unique.length)] ?? (graph[m.room]||[1])[0];
 }
 function movementChance(night,dt,m){
   const base=m.kind==='exo'?.062:m.kind==='felix'?.050:.038;
   const bonus=(m.kind==='exo'?night*.014:m.kind==='felix'?night*.012:night*.010);
   const pressure=night>=4?.018:night>=3?.010:0;
   const lav=m.kind==='lav'?.010:0;
   return Math.min(.72,dt*(base+bonus+pressure+lav));
 }
 // V91: шаги вернулись, но уже не как «шорох из библиотеки», а как собственный
 // слой MonsterAudio: удар корпуса, сервопривод, скрип обшивки и эхо коридора,
 // отфильтрованные по расстоянию от охранной. Раньше здесь была пустая функция
 // и по зданию никто не ходил слышимо.
 function stepSound(m,game){
   try{window.MonsterAudio?.steps(m.kind,m.room,{count:2+Math.floor(Math.random()*3)})}catch(e){}
 }
 // EXO бегает быстрее, но ходит к двери реже остальных.
 function quotaForNight(night,kind){
   const q=night>=5 ? (Math.random()<0.5?5:6) : night+1;
   return kind==='exo'?Math.max(1,q-1):q;
 }
 function ensureQuota(m,game){ if(!m.doorQuota) { m.doorQuota=quotaForNight(m.aggrNight||game.night,m.kind); m.nextDoorAt=(m.kind==='exo'?46:28)+Math.random()*35; } }
 function retreatFrom(m,game,reason){
   // V91: слышно, как он уходит — четыре шага из точек всё дальше от двери.
   try{window.MonsterAudio?.retreat(m.kind,m.doorSide)}catch(e){}
   m.state=State.RETREATING;m.room=routeNext(m,game);m.warning=0;m.attackTimer=0;m.doorSide=null;m.maskRepel=0;m.lightBlind=0;m.doorCooldown=18+Math.random()*20;m.nextDoorAt=Math.max(game.time+18,m.nextDoorAt+35+Math.random()*30);m.doorLinger=0;m.doorLingerMax=0;m.silent=false;m.eyesVisible=true;
   game.say(reason,1.5);
 }
 function update(m,dt,night,game){
   // V93: смены 6 и 7. У каждого может быть СВОЯ агрессия, не связанная с номером
   // смены: вся шкала сложности читает m.aggrNight вместо night.
   if(m.aggrNight)night=m.aggrNight;
   ensureQuota(m,game);
   if(!m._obs){m._obs=true;}
   if((game.monsters||[])[0]===m)observe(game,dt);       // память обновляет только один из них
   m.sayCd=Math.max(0,(m.sayCd||0)-dt);
   m.doorCooldown=Math.max(0,(m.doorCooldown||0)-dt);
   // Pressure target: when a door visit is due, nudge the AI toward the office via corridors (NO teleport).
   if(m.room!==0 && m.doorVisits<m.doorQuota && m.doorCooldown<=0 && game.time>=m.nextDoorAt){
     m.timer=Math.min(m.timer,0.6);
     m.nextDoorAt=game.time+30+Math.random()*30;
   }
   // MASK WARD-OFF (checked BEFORE the attack branches so the player always has the 3-4s window):
   // wearing the rabbit mask holds Felix at the door and repels him after 3-4 seconds.
   if(m.kind==='felix' && m.room===0 && game.mask && game.mask.worn){
     // ==== V93: МАСКА ОБМАНЫВАЕТ НЕ ВСЕГДА ====
     // Было: маска работала в любой момент — можно было надеть её в последнюю
     // долю секунды и всегда выжить. Стало: маска обманывает, только если она
     // была надета ЗАРАНЕЕ, пока до броска оставалось больше 1.6 с. Надетая
     // позже — он уже видел лицо и бьёт всё равно.
     if(m.maskOk===undefined||m.maskOk===null){
       m.maskOk=!(m.state===State.PREPARING&&(m.attackTimer||0)<=1.6);
       if(!m.maskOk){
         game.say('МАСКА НЕ ОБМАНУЛА — ОН УЖЕ ВИДЕЛ ЛИЦО',1.8);
         try{window.MonsterAudio?.laugh(m.kind,m.room)}catch(e){}
       }
     }
     if(!m.maskOk){ /* маска бесполезна: отсчёт идёт дальше, как если бы её не было */ }
     else{
     if(!m.maskRepelMax)m.maskRepelMax=3.2+Math.random()*1.2;
     m.maskRepel=(m.maskRepel||0)+dt;
     // freeze the attack countdown while the mask is held
     if(m.state===State.PREPARING){m.attackTimer=Math.max(m.attackTimer,0.2);m.warning=Math.max(m.warning,0.2);}
     if(m.maskRepel>=m.maskRepelMax){
       retreatFrom(m,game,'ФЕЛИКС ОТСТУПАЕТ — МАСКА ЗАЙЦА');game.ach?.('mask_keeper');return;
     }
     return; // mask holds Felix at the door; the attack countdown does not advance
     }
   } else if(m.kind==='felix'){ m.maskRepel=0; m.maskRepelMax=0; m.maskOk=null; }
   // СВЕТ ПРОТИВ EXO: у экзоскелета открытые сенсоры — включённая лампа с его стороны
   // держит его у двери и через пару секунд отгоняет. Зато свет жрёт питание.
   // V93: мёртвая лампа не слепит — она только жрёт питание.
   if(m.kind==='exo' && m.room===0 && m.doorSide && game.lights?.[m.doorSide]?.on && !game.lights[m.doorSide].dead){
     if(!m.lightBlindMax)m.lightBlindMax=2.2+Math.random()*1.1;
     m.lightBlind=(m.lightBlind||0)+dt;
     if(m.state===State.PREPARING){m.attackTimer=Math.max(m.attackTimer,0.2);m.warning=Math.max(m.warning,0.2);}
     if(m.lightBlind>=m.lightBlindMax){ retreatFrom(m,game,'EXO ОСЛЕПЛЁН СВЕТОМ — ОТСТУПАЕТ'); m.lightBlindMax=0; return; }
     return; // пока горит лампа, отсчёт атаки не идёт
   } else if(m.kind==='exo'){ m.lightBlind=0; m.lightBlindMax=0; }
   // LAV не переносит радио: включённый служебный канал держит его у двери и отгоняет.
   if(m.kind==='lav' && m.room===0 && game.radio && game.radio.on){
     if(!m.radioRepelMax)m.radioRepelMax=2.8+Math.random()*1.2;
     m.radioRepel=(m.radioRepel||0)+dt;
     if(m.state===State.PREPARING){m.attackTimer=Math.max(m.attackTimer,0.2);m.warning=Math.max(m.warning,0.2);}
     if(m.radioRepel>=m.radioRepelMax){ retreatFrom(m,game,'LAV УХОДИТ — ЕМУ МЕШАЕТ РАДИО'); m.radioRepelMax=0; return; }
     return;
   } else if(m.kind==='lav'){ m.radioRepel=0; m.radioRepelMax=0; }
   if(m.state===State.ATTACKING){
     // A closed door cancels the attack even during the final attack animation.
     if(m.doorSide && game.doors[m.doorSide]){retreatFrom(m,game,label(m.kind)+' ОТСТУПАЕТ');return;}
     m.attackTimer-=dt;if(m.attackTimer<=0)game.kill(m.kind);return}
   if(m.state===State.PREPARING){
     // The player has the full reaction window to close the correct door.
     if(m.doorSide && game.doors[m.doorSide]){retreatFrom(m,game,label(m.kind)+' ОТСТУПАЕТ');game.ach?.('door_keeper');return;}
     m.warning=Math.max(0,m.warning-dt);m.attackTimer=Math.max(0,m.attackTimer-dt);
     if(m.attackTimer<=0){m.state=State.ATTACKING;m.attackTimer=.35;game.say('ОПАСНОСТЬ — ДВЕРЬ НЕ УСПЕЛА ЗАКРЫТЬСЯ',1.8)}
     return
   }
   m.timer-=dt;if(m.warning>0)m.warning-=dt;
   // V72: в коридоре аниматроник либо забивается в угол у стены — тогда датчик его
   // не видит и тревоги нет, либо выходит к самому проходу к охране. Он переходит
   // из одного состояния в другое, пока стоит в коридоре.
   if(m.room===6||m.room===7){
     if(m.corner){
       // Вышел из угла к проходу — вот теперь датчик его видит и включается тревога.
       if(Math.random()<dt*(0.10+night*0.012)){
         m.corner=false;
         // V91: скрежет обшивки по стене — датчик сейчас его увидит.
         try{window.MonsterAudio?.scrape(m.kind,m.room)}catch(e){}
         game.say(label(m.kind)+' ВЫШЕЛ ИЗ УГЛА: '+(window.World.rooms[m.room]?.name||''),1.4);
       }
     }
     else { if(Math.random()<dt*0.05) m.corner=true; }
   } else if(m.corner) m.corner=false;
   // Looking at the correct camera can briefly delay the AI, but never freeze it.
   if(game.monitor && m.room===game.cam && m.room!==0 && Math.random()<dt*(.55+night*.04)){m.seen+=dt;m.timer=Math.max(m.timer,.7);m.state=State.WATCHING;}
   if(m.room===0){
     if(m.doorVisits<m.doorQuota){
       m.doorVisits++;
       // V111: ВНЕЗАПНОСТЬ. С поздних смен аниматроник может прийти к двери БЕЗ
       // объявления — ни сообщения, ни реплики. Игрок узнаёт о нём только по
       // звуку или включив свет. Чем выше смена, тем чаще тишина.
       m.silent=(night>=3 && Math.random()<Math.min(0.50,0.18+night*0.06));
       if(!m.silent)game.say(label(m.kind)+' У ДВЕРИ',1.2);else game.say('',0);
       // V91: он встал у створки — лязг корпуса, защёлкивание приводов и вдох
       // пневматики. Дальше держится постоянный слой присутствия за дверью.
       try{window.MonsterAudio?.arrive(m.kind,m.doorSide||smartSide(m,game,night))}catch(e){}
       // V111: ГЛАЗА В ТЕМНОТЕ 50/50. При приходе к двери решается один раз:
       // видны ли глаза в темноте, пока лампа выключена. Если нет — игрок видит
       // абсолютно чёрный коридор и не знает, что кто-то уже стоит у двери.
       m.eyesVisible=(Math.random()<0.5);
       // V111: СТОЯНИЕ У ДВЕРИ. С вероятностью, растущей со сменой, аниматроник не
       // бросается сразу, а просто стоит в проёме 3+ секунды — молча или с репликой.
       // Длительность случайная и длиннее на поздних сменах. Только после этого
       // начинается отсчёт атаки (или он уходит). Так дверь нельзя закрыть
       // «по таймеру» — момент броска непредсказуем.
       if(Math.random()<Math.min(0.70,0.35+night*0.08)){
         m.state=State.LINGERING;
         m.doorLingerMax=3+Math.random()*(2+night);
         m.doorLinger=m.doorLingerMax;
         return;
       }
     }
     // V111: пока длится стойка — аниматроник просто стоит. Отсчёт атаки не идёт.
     if(m.state===State.LINGERING){
       m.doorLinger=Math.max(0,m.doorLinger-dt);
       // дверь закрыли во время стойки — он уходит.
       if(m.doorSide&&game.doors[m.doorSide]){retreatFrom(m,game,label(m.kind)+' ОТСТУПАЕТ');game.ach?.('door_keeper');return;}
       // иногда за время стойки он молча проговаривает реплику — но не всегда
       if(!m.silent&&m.sayCd<=0&&Math.random()<dt*0.6){speak(m,game,night);m.sayCd=22+Math.random()*26;}
       if(m.doorLinger<=0){m.state=State.AT_DOOR;}
       else return;
     }
     m.state=State.AT_DOOR;
     if(!m.doorSide)m.doorSide=smartSide(m,game,night);
     // Обманный маневр (со 4-й смены): делает вид, что ушёл, и мгновенно возвращается.
     if(night>=4 && !m.feint && m.state===State.AT_DOOR && Math.random()<0.012){
       m.feint=1;m.doorCooldown=1.2+Math.random()*1.0;m.warning=0;m.attackTimer=0;
       AudioFX.play('doorMotor',.35,{group:'monster',pan:m.doorSide==='left'?-.7:.7});
       retreatFrom(m,game,label(m.kind)+' ОТСТУПАЕТ...');return;
     }
     if(!m.silent&&m.sayCd<=0){speak(m,game,night);m.sayCd=22+Math.random()*26;}
     // (Mask ward-off handled above, before the attack branches.)
     const closed=game.doors[m.doorSide];
     if(closed){
       retreatFrom(m,game,m.kind==='felix'?'ТЯЖЁЛЫЕ ШАГИ ОТХОДЯТ':m.kind==='exo'?'EXO УХОДИТ В ТЕМНОТУ':'СИЛУЭТ ОТСТУПАЕТ');game.ach?.('door_keeper');
     } else if(m.warning<=0){
       let w=(m.kind==='exo'?4.2:m.kind==='lav'?4.6:5.0)-Math.max(0,night-2)*0.42;
       if(m.feint===1){w*=0.62;m.feint=2;}                 // после обманки времени меньше
       m.warning=Math.max(2.4,w);m.state=State.PREPARING;m.attackTimer=m.warning;game.say('',0);
       // V91: рывок к двери слышно у всех, а не только у EXO: быстрые шаги с
       // нарастанием и визг сервоприводов на пределе — понятно, с какой стороны.
       try{window.MonsterAudio?.charge(m.kind,m.doorSide,night)}catch(e){}
       if(m.kind==='exo')AudioFX.playRandom(['stepAlt','thud'],{group:'monster',volume:.55,pan:m.doorSide==='left'?-0.8:.8});
     } else {
       m.warning=Math.max(0,m.warning-dt);
       if(m.warning<=0){m.state=State.ATTACKING;m.attackTimer=0.35;game.say('ОПАСНОСТЬ — ДВЕРЬ НЕ УСПЕЛА ЗАКРЫТЬСЯ',1.2);}
     }
     return;
   }
   if(m.timer>0)return;
   // Умное поведение: пока планшет открыт на ДРУГОЙ камере, охранник не видит их —
   // и они пользуются этим, двигаясь заметно охотнее.
   let chance=movementChance(night,1,m);
   if(game.monitor && game.cam!==m.room)chance=Math.min(.9,chance*(night>=3?1.55:1.3));
   if(!game.monitor && night>=3)chance*=1.12;               // сидит в офисе — тоже подбираются
   if(Math.random()>chance){m.timer=Math.max(1.2,2.5+Math.random()*5-night*.35);return}
   const prev=m.room;
   const next=routeNext(m,game);
   m.room=next;m.state=Math.random()<(.18+night*.025)?State.WATCHING:State.MOVING;
   // Входя в коридор, решает: сразу встать у прохода или переждать в углу.
   // Чем позже смена, тем реже он прячется и тем чаще сразу идёт к двери.
   m.corner=(next===6||next===7)?(Math.random()<Math.max(0.20,0.62-night*0.07)):false;
   m.visibleUntil=performance.now()/1000+.65+Math.random()*1.2;
   // Шаги при переходе идут ниже, через stepSound — с учётом расстояния и эха.
   m.routeIndex=(m.routeIndex+1)%((routes[m.kind]||routes.main).length);
   m.timer=Math.max(m.kind==='felix'?2.0:2.6,(m.kind==='felix'?6.0:7.0)-night*.70+Math.random()*3.0);
   // V91: переход между комнатами теперь всегда слышен. Раньше стоял бросок
   // монеты 50/50, а сама функция была пустой — то есть не слышно было никогда.
   stepSound(m,game);
   if(next===0){
     // doorSide is deterministic from the corridor the monster came through.
     m.doorSide=doorForRoom(prev)||(Math.random()<.5?'left':'right');
     game.say(m.doorSide==='left'?'КТО-ТО ИДЁТ К ЛЕВОЙ ДВЕРИ':'КТО-ТО ИДЁТ К ПРАВОЙ ДВЕРИ',1.5);
   } else if(next>0 && !m.corner){
     // V73: если он зашёл в коридор и сразу забился в угол — датчик молчит,
     // подсказки о движении тоже нет. Тревогу поднимает только выход к проходу.
     game.say((m.kind==='felix'?'ТЯЖЁЛОЕ ДВИЖЕНИЕ: ':m.kind==='exo'?'EXO В ДВИЖЕНИИ: ':'ДВИЖЕНИЕ: ')+(window.World.rooms[next]?.name||''),1.2);
   }
 }
 return {make,update,State,routes,label};
})();
